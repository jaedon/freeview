/***************************************************************
* $Workfile:   ci_cc_cipher_bn_lib.c  $
* $Modtime:
* Auther : hmkim
*
* Desc : Small BN library
*
* Copyright (c) 2008 by Humax Co., Ltd.
* All right reserved
****************************************************************/


/***************************************************************
* #ifdef statements and include ////////////////////////////////
***************************************************************/

#include "ci_cc_cipher.h"


/***************************************************************
* definition ///////////////////////////////////////////////////
***************************************************************/



/***************************************************************
* BN library ///////////////////////////////////////////////////
***************************************************************/

/* make big number a from byte array with len */
void bn_init(bignum *a, unsigned char *c, bn_len_type len)
{
	if (len > MAX_BN_LEN)
	{
		PrintErr("[CICC]---> bn_init()---> Error : MAX_BN_LEN(%d) is too small for %d !!!\n", MAX_BN_LEN, len);
		return;
	}

	a->len = len;
	VK_memcpy(a->num, c, len);
}

/* compare big number a and b : return 1 if a > b, 0 if a = b, -1 if a < b */
int bn_cmp(bignum *a, bignum *b)
{
	int cmp;

	if (a->len > b->len)
		return 1;

	if (b->len > a->len)
		return -1;

	cmp = VK_memcmp(a->num, b->num, a->len);

	if (cmp > 0)
		return 1;

	if (cmp < 0)
		return -1;

	return 0;
}

/* compute big number (a + b) using pencil-and-paper method */
void bn_add(bignum *a, bignum *b, bignum *out)
{
	unsigned char *p, *q;
	bn_len_type pLen, qLen, i;
	signed_bn_len_type ip, iq;
	unsigned short add;
	unsigned char tmp[MAX_BN_LEN];

	if (bn_cmp(a, b) >= 0)
	{
		p = a->num; pLen = a->len;
		q = b->num; qLen = b->len;
	}
	else
	{
		p = b->num; pLen = b->len;
		q = a->num; qLen = a->len;
	}

	if (pLen+1 > MAX_BN_LEN)
	{
		PrintErr("[CICC]---> bn_add()---> Error : MAX_BN_LEN(%d) is too small !!!\n", MAX_BN_LEN);
		return;
	}

	VK_memset(tmp, 0x00, pLen+1);

	i = 0;

	for (ip = pLen-1, iq = qLen-1; iq >= 0; ip--, iq--, i++)
	{
		add = (unsigned short)(p[ip] + q[iq] + tmp[i]);
		tmp[i] = (unsigned char)(add & 0xff);
		if (add > 0xff)
			tmp[i+1] = 0x01;
	}

	for (; ip >= 0; ip--, i++)
	{
		add = (unsigned short)(p[ip] + tmp[i]);
		tmp[i] = (unsigned char)(add & 0xff);
		if (add > 0xff)
			tmp[i+1] = 0x01;
	}

	out->len = (tmp[i] == 0x00) ? i : i+1;

	for (i = 0; i < out->len; i++)
		out->num[i] = tmp[out->len-1-i];
}

/* compute big number (a - b) using pencil-and-paper method : return 1 and compute b - a if a < b, return 0 and compute a - b if a >= b */
/* ���� : ���� ������ bignum ���̺귯���� ������� ����Ѵ�. ���� b > a �� ��쿡 ���� ó���� caller �ʿ��� �ڵ鸵�ؾ� �Ѵ�! */
int bn_sub(bignum *a, bignum *b, bignum *out)
{
	unsigned char *p, *q;
	bn_len_type pLen, qLen, i;
	signed_bn_len_type ip, iq;
	unsigned short sub;
	unsigned char tmp[MAX_BN_LEN];
	int cmp;

	cmp = bn_cmp(a, b);

	if (cmp == 0) // ���ʿ��� ������ ���� ����.
	{
		out->len = 1;
		out->num[0] = 0x00;
		return 0;
	}
	else if (cmp > 0)
	{
		p = a->num; pLen = a->len;
		q = b->num; qLen = b->len;
	}
	else
	{
		p = b->num; pLen = b->len;
		q = a->num; qLen = a->len;
	}

	VK_memset(tmp, 0x00, pLen);

	i = 0;

	for (ip = pLen-1, iq = qLen-1; iq >= 0; ip--, iq--, i++)
	{
		sub = q[iq] + tmp[i];
		if (p[ip] < sub)
		{
			tmp[i] = (unsigned char)((0x100 + p[ip] - sub) & 0xff);
			tmp[i+1] = 0x01;
		}
		else
		{
			tmp[i] = (unsigned char)((p[ip] - sub) & 0xff);
		}
	}

	for (; ip >= 0; ip--, i++)
	{
		if (p[ip] < tmp[i])
		{
			tmp[i] = (unsigned char)((0x100 + p[ip] - tmp[i]) & 0xff);
			tmp[i+1] = 0x01;
		}
		else
		{
			tmp[i] = (unsigned char)((p[ip] - tmp[i]) & 0xff);
		}
	}

	for (; i > 0; i--)
	{
		if (tmp[i-1] != 0x00)
			break;
	}
	out->len = (i == 0) ? 1 : i;

	for (i = 0; i < out->len; i++)
		out->num[i] = tmp[out->len-1-i];

	return (cmp < 0) ? 1 : 0;
}

#ifndef DEACTIVATE_NOT_USED_FUNCTIONS

/* compute big number (0 - a) as two's complement representation */
static void bn_neg(bignum *a, bignum *out)
{
	bn_len_type i;

	for (i = 0; i < a->len; i++)
		out->num[i] = ~a->num[i];
	bn_add(out, &bn_one, out);
}

#endif // not used

/* compute big number (a x b) using pencil-and-paper method */
/* �Է°��� ���� P, Q ����Ʈ�� �� O(PxQ)�� �ҿ�Ǵ� �Ϲ�����(?) ���. ���߿� Karatsuba multiplication ��� ���� �ŷ� ������ ����.
   �ٸ�, b�� 2�� ����̸� bn_mul_2_n(), bn_mul_256_n()�� �̿��ϰ� ������ ��쿣 bn_square()�� �̿��ϵ��� �Ѵ�.
   ����, a x b = ((a+b)^2 - (a-b)^2) / 4 �̹Ƿ� �����ս��� �� ���ٸ� bn_mul() ��ſ� bn_square() �� bn_right_shift_n()�� �̿��� ���� �ִ�. */
void bn_mul(bignum *a, bignum *b, bignum *out)
{
	unsigned char *p, *q;
	bn_len_type pLen, qLen, i, j, k;
	signed_bn_len_type ip, iq;
	unsigned short mul;
	unsigned char tmp[MAX_BN_LEN];

	p = a->num; pLen = a->len;
	q = b->num; qLen = b->len;

	if ((bn_cmp(a, &bn_zero) == 0) || (bn_cmp(b, &bn_zero) == 0)) // ���ʿ��� ������ ���� ���� (�ڸ��� ���� ���� ����).
	{
		out->len = 1;
		out->num[0] = 0x00;
		return;
	}

	if (bn_cmp(a, &bn_one) == 0) // ���ʿ��� ������ ���� ����.
	{
		out->len = qLen;
		VK_memcpy(out->num, q, qLen);
		return;
	}

	if (bn_cmp(b, &bn_one) == 0) // ���ʿ��� ������ ���� ����.
	{
		out->len = pLen;
		VK_memcpy(out->num, p, pLen);
		return;
	}

	if (pLen+qLen > MAX_BN_LEN)
	{
		PrintErr("[CICC]---> bn_mul()---> Error : MAX_BN_LEN(%d) is too small for %d !!!\n", MAX_BN_LEN, pLen+qLen);
		return;
	}

	VK_memset(tmp, 0x00, pLen+qLen);

	i = 0;

	for (iq = qLen-1, j = 0; iq >= 0; iq--, j++)
	{
		for (ip = pLen-1, i = j; ip >= 0; ip--, i++)
		{
			mul = (unsigned short)(p[ip] * q[iq] + tmp[i]);
			tmp[i] = (unsigned char)(mul & 0xff);
			mul >>= 8;
			for (k = 1; mul; k++)
			{
				mul += (unsigned short)tmp[i+k];
				tmp[i+k] = (unsigned char)(mul & 0xff);
				mul >>= 8;
			}
		}
	}

	out->len = (tmp[i] == 0x00) ? i : i+1;

	for (i = 0; i < out->len; i++)
		out->num[i] = tmp[out->len-1-i];
}

#ifndef USE_MPI_LIB

/* compute big number (a ^ 2) */
static void bn_square(bignum *a, bignum *out)
{
	unsigned char *x = a->num;
	bn_len_type t = a->len, tx2 = t<<1;
	signed_bn_len_type i, j, k;
	unsigned int mul;
	unsigned char w[MAX_BN_LEN];

	if (bn_cmp(a, &bn_x10) < 0) // ���ʿ��� ������ ���� ���� (�ڸ��� ���� ���� ����).
	{
		out->len = 1;
		out->num[0] = x[0] * x[0];
		return;
	}

	if (tx2 > MAX_BN_LEN)
	{
		PrintErr(("[CICC]---> bn_square()---> Error : MAX_BN_LEN(%d) is too small for %d !!!\n", MAX_BN_LEN, tx2));
		return;
	}

	VK_memset(w, 0x00, tx2);

	for (i = t - 1; i >= 0; i--)
	{
		mul = (unsigned int)(w[2*i+1] + x[i] * x[i]);
		w[2*i+1] = (unsigned char)(mul & 0xff);
		mul >>= 8;
		for (j = i - 1; j >= 0; j--)
		{
			mul = (unsigned int)(w[i+j+1] + 2 * x[j] * x[i] + mul);
			w[i+j+1] = (unsigned char)(mul & 0xff);
			mul >>= 8;
		}
		for (k = 0; k <= i && mul; k++)
		{
			mul += (unsigned int)w[i-k];
			w[i-k] = (unsigned char)(mul & 0xff);
			mul >>= 8;
		}
	}

	if (w[0] == 0x00)
	{
		out->len = tx2-1;
		VK_memcpy(out->num, &w[1], out->len);
	}
	else
	{
		out->len = tx2;
		VK_memcpy(out->num, w, out->len);
	}
}

#endif // #ifndef USE_MPI_LIB

#ifndef DEACTIVATE_NOT_USED_FUNCTIONS

/* compute big number (a x (2 ^ n)), n = 0 ~ 7 only !! */
static void bn_mul_2_n(bignum *a, int n, bignum *out)
{
	unsigned char *p, *q, mask, rshft;
	bn_len_type i;

	if (bn_cmp(a, &bn_zero) == 0) // ���ʿ��� ������ ���� ���� (�ڸ��� ���� ���� ����).
	{
		out->len = 1;
		out->num[0] = 0x00;
		return;
	}

	if (n == 0) // ���ʿ��� ������ ���� ���� (�ڸ��� ���� ���� ����).
	{
		out->len = a->len;
		VK_memcpy(out->num, a->num, a->len);
		return;
	}

	p = a->num; q = out->num;

	mask = (0xff >> n) ^ 0xff;
	rshft = 8 - n;

	if (p[0] & mask)
	{
		out->len = a->len + 1;
		q[0] = p[0] >> rshft;
		for (i = 1; i < a->len; i++)
		{
			if (p[i] & mask)
				q[i] = (p[i-1] << n) | (p[i] >> rshft);
			else
				q[i] = p[i-1] << n;
		}
		q[i] = p[i-1] << n;
	}
	else
	{
		out->len = a->len;
		for (i = 0; i < a->len - 1; i++)
		{
			if (p[i+1] & mask)
				q[i] = (p[i] << n) | (p[i+1] >> rshft);
			else
				q[i] = p[i] << n;
		}
		q[i] = p[i] << n;
	}
}

#endif // not used

/* compute big number (a x (256 ^ n)) */
static void bn_mul_256_n(bignum *a, bn_len_type n, bignum *out)
{
	if (bn_cmp(a, &bn_zero) == 0) // ���ʿ��� ������ ���� ���� (�ڸ��� ���� ���� ����).
	{
		out->len = 1;
		out->num[0] = 0x00;
		return;
	}

	if (n == 0) // ���ʿ��� ������ ���� ���� (�ڸ��� ���� ���� ����).
	{
		out->len = a->len;
		VK_memcpy(out->num, a->num, a->len);
		return;
	}

	out->len = a->len + n;
	VK_memcpy(out->num, a->num, a->len);
	VK_memset(&out->num[a->len], 0x00, n);
}

#ifndef DEACTIVATE_NOT_USED_FUNCTIONS

/* compute big number (a >> n), n = 0 ~ 7 only !! */
static void bn_right_shift_n(bignum *a, int n, bignum *out)
{
	unsigned char *p, *q, mask, lshft;
	bn_len_type i;

	if ((bn_cmp(a, &bn_zero) == 0) || (bn_cmp(a, &bn_one) == 0)) // ���ʿ��� ������ ���� ���� (�ڸ��� ���� ���� ����).
	{
		out->len = 1;
		out->num[0] = 0x00;
		return;
	}

	if (n == 0) // ���ʿ��� ������ ���� ���� (�ڸ��� ���� ���� ����).
	{
		out->len = a->len;
		VK_memcpy(out->num, a->num, a->len);
		return;
	}

	p = a->num; q = out->num;

	mask = (0xff >> n) ^ 0xff;
	lshft = 8 - n;

	if (p[0] > n)
	{
		out->len = a->len;
		q[0] = p[0] >> n;
		for (i = 1; i < out->len; i++)
			q[i] = ((p[i-1] << lshft) & mask) | (p[i] >> n);
	}
	else
	{
		out->len = a->len - 1;
		for (i = 0; i < out->len; i++)
			q[i] = ((p[i] << lshft) & mask) | (p[i+1] >> n);
	}
}

/* compute big number (a ^ b) */
/* ���� : b�� ū���� ���� �� MAX_BN_LEN ���� ����� ũ�� �ʴٸ� �� �Լ��� buffer overflow �� �߱��� ���̴�.
          bn_mod(), bn_mod_exp()�� mod �� ������ �̿��ؼ� ����ϱ� ������ ������ b�� ū���� ���� �� �� �Լ��� ���Ǵ� ���� ����. */
static void bn_pow(bignum *a, bignum *b, bignum *out)
{
	bignum cnt, tmp;

	if (bn_cmp(b, &bn_zero) == 0) // any a ^ 0 = 1
	{
		out->len = 1;
		out->num[0] = 0x01;
		return;
	}

	if ((bn_cmp(a, &bn_zero) == 0) || (bn_cmp(a, &bn_one) == 0)) // ���ʿ��� ������ ���� ����.
	{
		out->len = 1;
		out->num[0] = a->num[0];
		return;
	}

	if (bn_cmp(b, &bn_one) == 0) // ���ʿ��� ������ ���� ����.
	{
		out->len = a->len;
		VK_memcpy(out->num, a->num, a->len);
		return;
	}

	out->len = a->len;
	VK_memcpy(out->num, a->num, a->len);

	cnt.len = b->len;
	VK_memcpy(cnt.num, b->num, b->len);

	while (1)
	{
		bn_sub(&cnt, &bn_one, &cnt);
		if (bn_cmp(&cnt, &bn_zero) == 0)
			break;
		bn_mul(out, a, &tmp);
		out->len = tmp.len;
		VK_memcpy(out->num, tmp.num, tmp.len);
	}
}

#endif // not used

/* compute big number (a mod b) */
void bn_mod(bignum *a, bignum *b, bignum *out)
{
//	#define CHECK_BN_MOD

	bignum mul1, mul2, factor;
	unsigned short m;
	int cmp;

#ifdef CHECK_BN_MOD
	int i = 0, j, k; // for debugging

	VK_Print("\n\n === input : a (%d) ===", a->len);
	for (k = 0; k < a->len; k++)
	{
		if ((k & 15) == 0)
			VK_Print("\n");
		VK_Print(" %02X", a->num[k]);
	}
	VK_Print("\n\n === input : b (%d) ===", b->len);
	for (k = 0; k < b->len; k++)
	{
		if ((k & 15) == 0)
			VK_Print("\n");
		VK_Print(" %02X", b->num[k]);
	}
	VK_Print("\n");
#endif

	if (bn_cmp(b, &bn_zero) == 0)
	{
		PrintErr(("[CICC]---> bn_mod()---> Error : divided by zero !!!\n"));
		return;
	}

	out->len = a->len;
	VK_memcpy(out->num, a->num, a->len);

	while (1) // i ����
	{
#ifdef CHECK_BN_MOD
		VK_Print("\n[i=%03d]", ++i); j = 0;
#endif

		cmp = bn_cmp(out, b);
		if (cmp <= 0)
			goto EXIT;

		bn_mul_256_n(b, out->len - b->len, &mul1);
		cmp = bn_cmp(&mul1, out);
		if (cmp == 0)
			goto EXIT;
		else if (cmp > 0)
			mul1.len -= 1;

		if (out->len > mul1.len)
		{
			m = (unsigned short)((out->num[0]*0x100+out->num[1]) / mul1.num[0]);
			if (m > 0xff)
			{
				factor.len = 2;
				factor.num[0] = m >> 8;
				factor.num[1] = m & 0xff;
			}
			else
			{
				factor.len = 1;
				factor.num[0] = m;
			}
		}
		else
		{
			factor.len = 1;
			factor.num[0] = out->num[0] / mul1.num[0];
		}

		bn_mul(&mul1, &factor, &mul2);
		while (bn_cmp(&mul2, out) > 0)
		{
#ifdef CHECK_BN_MOD
			j++;
#endif

			bn_sub(&factor, &bn_one, &factor);
			bn_mul(&mul1, &factor, &mul2);
		}

#ifdef CHECK_BN_MOD
		VK_Print("[j=%d]", j);
		#if 0
		VK_Print("\n --- out (%d) ---", out->len);
		for (k = 0; k < out->len; k++)
		{
			if ((k & 15) == 0)
				VK_Print("\n");
			VK_Print(" %02X", out->num[k]);
		}
		VK_Print("\n --- mul #1 (%d) ---", mul1.len);
		for (k = 0; k < mul1.len; k++)
		{
			if ((k & 15) == 0)
				VK_Print("\n");
			VK_Print(" %02X", mul1.num[k]);
		}
		VK_Print("\n --- factor (%d) ---", factor.len);
		for (k = 0; k < factor.len; k++)
		{
			if ((k & 15) == 0)
				VK_Print("\n");
			VK_Print(" %02X", factor.num[k]);
		}
		VK_Print("\n --- mul #2 (%d) ---", mul2.len);
		for (k = 0; k < mul2.len; k++)
		{
			if ((k & 15) == 0)
				VK_Print("\n");
			VK_Print(" %02X", mul2.num[k]);
		}
		#endif
#endif

		bn_sub(out, &mul2, out);
	}

EXIT :

	if (cmp == 0)
	{
		out->len = 1;
		out->num[0] = 0x00;
	}

#ifdef CHECK_BN_MOD
	VK_Print("\n\n === result (%d) ===", out->len);
	for (k = 0; k < out->len; k++)
	{
		if ((k & 15) == 0)
			VK_Print("\n");
		VK_Print(" %02X", out->num[k]);
	}
#endif
}

#ifndef USE_MPI_LIB

/* compute big number (a ^ b mod n) using repeated square-and-multiply (right-to-left binary) method for modular exponentiation */
void bn_mod_exp(bignum *a, bignum *b, bignum *n, bignum *out)
{
	bignum base, tmp;
	#if 0 // old
	bignum exponent;
	#else
	bn_len_type totBits, modBits;
	#endif

	if (bn_cmp(n, &bn_zero) == 0)
	{
		PrintErr(("[CICC]---> bn_mod_exp()---> Error : divided by zero !!!\n"));
		return;
	}

	if (bn_cmp(b, &bn_zero) == 0) // any a ^ 0 = 1
	{
		tmp.len = 1;
		tmp.num[0] = 0x01;
		bn_mod(&tmp, n, out);
		return;
	}

	if ((bn_cmp(a, &bn_zero) == 0) || (bn_cmp(a, &bn_one) == 0)) // ���ʿ��� ������ ���� ����.
	{
		bn_mod(a, n, out);
		return;
	}

	if (bn_cmp(b, &bn_one) == 0) // ���ʿ��� ������ ���� ����.
	{
		bn_mod(a, n, out);
		return;
	}

	out->len = 1;
	out->num[0] = 0x01;

	base.len = a->len;
	VK_memcpy(base.num, a->num, a->len);

	#if 0 // old
	exponent.len = b->len;
	VK_memcpy(exponent.num, b->num, b->len);
	while (bn_cmp(&exponent, &bn_zero) > 0)
	{
		if (exponent.num[exponent.len-1] & 0x01)
		{
			bn_mul(out, &base, &tmp);
			bn_mod(&tmp, n, out);
		}
		bn_right_shift_n(&exponent, 1, &tmp);
		exponent.len = tmp.len;
		VK_memcpy(exponent.num, tmp.num, tmp.len);
		bn_square(&base, &tmp);
		bn_mod(&tmp, n, &base);
		#ifdef GIVE_TASK_SLEEP_FOR_BIG_COMPUTATION
		VK_TASK_Sleep(10); // ��� �ð��� �ҿ�ǹǷ� �ּ� �� ���� sleep �ʿ�.
		#endif
	}
	#else //
	totBits = b->len * 8;
	for (modBits = 0; modBits < 8; modBits++)
	{
		if (b->num[0] & (0x80 >> modBits))
			break;
	}
	modBits = totBits - modBits;
	while (modBits)
	{
		totBits--;
		modBits--;
		if (b->num[totBits/8] & (0x80 >> (totBits&7)))
		{
			bn_mul(out, &base, &tmp);
			bn_mod(&tmp, n, out);
		}
		bn_square(&base, &tmp);
		bn_mod(&tmp, n, &base);
		#ifdef GIVE_TASK_SLEEP_FOR_BIG_COMPUTATION
		VK_TASK_Sleep(10); // ��� �ð��� �ҿ�ǹǷ� �ּ� �� ���� sleep �ʿ�.
		#endif
	}
	#endif //
}

#endif // #ifndef USE_MPI_LIB


/***************************************************************
* for self-test ////////////////////////////////////////////////
***************************************************************/

#ifdef INCLUDE_BN_TEST
void BN_Test(void)
{
	bignum A = {7, {0xff,0x77,0xee,0x22,0xdd,0x33,0xcc}};
	bignum B = {7, {0xff,0x76,0xff,0x32,0x10,0x01,0x02}};
	bignum C = {4, {0xff,0x11,0xee,0x22}};
	bignum D = {3, {0xfe,0x76,0x54}};
	bignum E = {3, {0x0e,0x76,0x54}};
	bignum F = {2, {0xab,0xcd}};
	bignum G = {1, {0x03}};
//	bignum H = {1, {0x02}};
//	bignum I = {1, {0x01}};
	bignum J = {1, {0x00}};
	bignum n = {128, {
		0xA5, 0x6E, 0x4A, 0x0E, 0x70, 0x10, 0x17, 0x58, 0x9A, 0x51, 0x87, 0xDC, 0x7E, 0xA8, 0x41, 0xD1,
		0x56, 0xF2, 0xEC, 0x0E, 0x36, 0xAD, 0x52, 0xA4, 0x4D, 0xFE, 0xB1, 0xE6, 0x1F, 0x7A, 0xD9, 0x91,
		0xD8, 0xC5, 0x10, 0x56, 0xFF, 0xED, 0xB1, 0x62, 0xB4, 0xC0, 0xF2, 0x83, 0xA1, 0x2A, 0x88, 0xA3,
		0x94, 0xDF, 0xF5, 0x26, 0xAB, 0x72, 0x91, 0xCB, 0xB3, 0x07, 0xCE, 0xAB, 0xFC, 0xE0, 0xB1, 0xDF,
		0xD5, 0xCD, 0x95, 0x08, 0x09, 0x6D, 0x5B, 0x2B, 0x8B, 0x6D, 0xF5, 0xD6, 0x71, 0xEF, 0x63, 0x77,
		0xC0, 0x92, 0x1C, 0xB2, 0x3C, 0x27, 0x0A, 0x70, 0xE2, 0x59, 0x8E, 0x6F, 0xF8, 0x9D, 0x19, 0xF1,
		0x05, 0xAC, 0xC2, 0xD3, 0xF0, 0xCB, 0x35, 0xF2, 0x92, 0x80, 0xE1, 0x38, 0x6B, 0x6F, 0x64, 0xC4,
		0xEF, 0x22, 0xE1, 0xE1, 0xF2, 0x0D, 0x0C, 0xE8, 0xCF, 0xFB, 0x22, 0x49, 0xBD, 0x9A, 0x21, 0x37}
	};
	/*
	bignum d = {128, {
		0x33, 0xA5, 0x04, 0x2A, 0x90, 0xB2, 0x7D, 0x4F, 0x54, 0x51, 0xCA, 0x9B, 0xBB, 0xD0, 0xB4, 0x47,
		0x71, 0xA1, 0x01, 0xAF, 0x88, 0x43, 0x40, 0xAE, 0xF9, 0x88, 0x5F, 0x2A, 0x4B, 0xBE, 0x92, 0xE8,
		0x94, 0xA7, 0x24, 0xAC, 0x3C, 0x56, 0x8C, 0x8F, 0x97, 0x85, 0x3A, 0xD0, 0x7C, 0x02, 0x66, 0xC8,
		0xC6, 0xA3, 0xCA, 0x09, 0x29, 0xF1, 0xE8, 0xF1, 0x12, 0x31, 0x88, 0x44, 0x29, 0xFC, 0x4D, 0x9A,
		0xE5, 0x5F, 0xEE, 0x89, 0x6A, 0x10, 0xCE, 0x70, 0x7C, 0x3E, 0xD7, 0xE7, 0x34, 0xE4, 0x47, 0x27,
		0xA3, 0x95, 0x74, 0x50, 0x1A, 0x53, 0x26, 0x83, 0x10, 0x9C, 0x2A, 0xBA, 0xCA, 0xBA, 0x28, 0x3C,
		0x31, 0xB4, 0xBD, 0x2F, 0x53, 0xC3, 0xEE, 0x37, 0xE3, 0x52, 0xCE, 0xE3, 0x4F, 0x9E, 0x50, 0x3B,
		0xD8, 0x0C, 0x06, 0x22, 0xAD, 0x79, 0xC6, 0xDC, 0xEE, 0x88, 0x35, 0x47, 0xC6, 0xA3, 0xB3, 0x25}
	};
	*/
	bignum p = {64, {
		0xE7, 0xE8, 0x94, 0x27, 0x20, 0xA8, 0x77, 0x51, 0x72, 0x73, 0xA3, 0x56, 0x05, 0x3E, 0xA2, 0xA1,
		0xBC, 0x0C, 0x94, 0xAA, 0x72, 0xD5, 0x5C, 0x6E, 0x86, 0x29, 0x6B, 0x2D, 0xFC, 0x96, 0x79, 0x48,
		0xC0, 0xA7, 0x2C, 0xBC, 0xCC, 0xA7, 0xEA, 0xCB, 0x35, 0x70, 0x6E, 0x09, 0xA1, 0xDF, 0x55, 0xA1,
		0x53, 0x5B, 0xD9, 0xB3, 0xCC, 0x34, 0x16, 0x0B, 0x3B, 0x6D, 0xCD, 0x3E, 0xDA, 0x8E, 0x64, 0x43}
	};
	bignum q = {64, {
		0xB6, 0x9D, 0xCA, 0x1C, 0xF7, 0xD4, 0xD7, 0xEC, 0x81, 0xE7, 0x5B, 0x90, 0xFC, 0xCA, 0x87, 0x4A,
		0xBC, 0xDE, 0x12, 0x3F, 0xD2, 0x70, 0x01, 0x80, 0xAA, 0x90, 0x47, 0x9B, 0x6E, 0x48, 0xDE, 0x8D,
		0x67, 0xED, 0x24, 0xF9, 0xF1, 0x9D, 0x85, 0xBA, 0x27, 0x58, 0x74, 0xF5, 0x42, 0xCD, 0x20, 0xDC,
		0x72, 0x3E, 0x69, 0x63, 0x36, 0x4A, 0x1F, 0x94, 0x25, 0x45, 0x2B, 0x26, 0x9A, 0x67, 0x99, 0xFD}
	};
	bignum dP = {64, {
		0x28, 0xFA, 0x13, 0x93, 0x86, 0x55, 0xBE, 0x1F, 0x8A, 0x15, 0x9C, 0xBA, 0xCA, 0x5A, 0x72, 0xEA,
		0x19, 0x0C, 0x30, 0x08, 0x9E, 0x19, 0xCD, 0x27, 0x4A, 0x55, 0x6F, 0x36, 0xC4, 0xF6, 0xE1, 0x9F,
		0x55, 0x4B, 0x34, 0xC0, 0x77, 0x79, 0x04, 0x27, 0xBB, 0xDD, 0x8D, 0xD3, 0xED, 0xE2, 0x44, 0x83,
		0x28, 0xF3, 0x85, 0xD8, 0x1B, 0x30, 0xE8, 0xE4, 0x3B, 0x2F, 0xFF, 0xA0, 0x27, 0x86, 0x19, 0x79}
	};
	bignum dQ = {64, {
		0x1A, 0x8B, 0x38, 0xF3, 0x98, 0xFA, 0x71, 0x20, 0x49, 0x89, 0x8D, 0x7F, 0xB7, 0x9E, 0xE0, 0xA7,
		0x76, 0x68, 0x79, 0x12, 0x99, 0xCD, 0xFA, 0x09, 0xEF, 0xC0, 0xE5, 0x07, 0xAC, 0xB2, 0x1E, 0xD7,
		0x43, 0x01, 0xEF, 0x5B, 0xFD, 0x48, 0xBE, 0x45, 0x5E, 0xAE, 0xB6, 0xE1, 0x67, 0x82, 0x55, 0x82,
		0x75, 0x80, 0xA8, 0xE4, 0xE8, 0xE1, 0x41, 0x51, 0xD1, 0x51, 0x0A, 0x82, 0xA3, 0xF2, 0xE7, 0x29}
	};
	bignum qInv = {64, {
		0x27, 0x15, 0x6A, 0xBA, 0x41, 0x26, 0xD2, 0x4A, 0x81, 0xF3, 0xA5, 0x28, 0xCB, 0xFB, 0x27, 0xF5,
		0x68, 0x86, 0xF8, 0x40, 0xA9, 0xF6, 0xE8, 0x6E, 0x17, 0xA4, 0x4B, 0x94, 0xFE, 0x93, 0x19, 0x58,
		0x4B, 0x8E, 0x22, 0xFD, 0xDE, 0x1E, 0x5A, 0x2E, 0x3B, 0xD8, 0xAA, 0x5B, 0xA8, 0xD8, 0x58, 0x41,
		0x94, 0xEB, 0x21, 0x90, 0xAC, 0xF8, 0x32, 0xB8, 0x47, 0xF1, 0x3A, 0x3D, 0x24, 0xA7, 0x9F, 0x4D}
	};
	bignum X, Y;
	bn_len_type i;

	VK_Print("\n BN_Test Start... ");

	bn_add(&A, &B, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 8 : 01 FE EE ED 54 ED 34 CE

	bn_add(&B, &A, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 8 : 01 FE EE ED 54 ED 34 CE

	bn_add(&A, &J, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 7 : FF 77 EE 22 DD 33 CC

	bn_sub(&A, &B, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 5 : EE F0 CD 32 CA

//	bn_sub(&B, &A, &X);
//	bn_neg(&X, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be ? : 11 0F 32 CD 36

	bn_sub(&A, &J, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 7 : FF 77 EE 22 DD 33 CC

//	bn_sub(&J, &A, &X);
//	bn_neg(&X, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be ? : 00 88 11 DD 22 CC 34

	bn_sub(&A, &A, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 1 : 00

	bn_mul(&C, &D, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 7 : FD 89 B0 3B 61 CF 28

	bn_mul(&C, &J, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 1 : 00

#ifndef USE_MPI_LIB

	bn_square(&C, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 8 : FE 24 B9 A9 3A 07 3C 84

	bn_square(&D, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 6 : FC EF 05 61 8B 90

	bn_square(&E, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 5 : D1 27 E1 8B 90

	bn_square(&F, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 4 : 73 4B 82 29

#endif

//	bn_mul_2_n(&C, 1, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 5 : 01 FE 23 DC 44

//	bn_mul_2_n(&E, 1, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 3 : 1C EC A8

//	bn_mul_2_n(&G, 1, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 1 : 06

//	bn_mul_2_n(&C, 4, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 5 : 0F F1 1E E2 20

//	bn_mul_2_n(&E, 4, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 3 : E7 65 40

//	bn_mul_2_n(&G, 4, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 1 : 30

	bn_mul_256_n(&C, 1, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 5 : FF 11 EE 22 00

//	bn_right_shift_n(&F, 1, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 2 : 55 E6

//	bn_right_shift_n(&F, 2, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 2 : 2A F3

//	bn_right_shift_n(&F, 3, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 2 : 15 79

//	bn_right_shift_n(&F, 4, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 2 : 0A BC

//	bn_pow(&F, &G, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 6 : 4D 5F C3 68 9D D5

//	bn_pow(&F, &H, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 4 : 73 4B 82 29

//	bn_pow(&F, &I, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 2 : AB CD

//	bn_pow(&F, &J, &X);
//	VK_Print("\n %d :", X.len);
//	for (i = 0; i < X.len; i++)
//		VK_Print(" %02X", X.num[i]); // should be 1 : 01

	bn_mod(&A, &B, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 5 : EE F0 CD 32 CA

	bn_mod(&A, &C, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 4 : 34 54 49 2E

	bn_mod(&A, &D, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 3 : 69 80 04

	bn_mod(&A, &F, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 2 : 32 4E

	bn_mod(&A, &G, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 1 : 00

	bn_mod(&J, &A, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 1 : 00

	bn_mod(&B, &A, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 7 : FF 76 FF 32 10 01 02

	bn_mod_exp(&F, &G, &C, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 4 : FA 16 0B A7

	bn_mod_exp(&F, &G, &D, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 3 : 7B 10 C9

	bn_mod_exp(&F, &G, &E, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 3 : 08 E5 E5

	bn_mod_exp(&F, &G, &F, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 1 : 00

	bn_mod_exp(&F, &G, &G, &X);
	VK_Print("\n %d :", X.len);
	for (i = 0; i < X.len; i++)
		VK_Print(" %02X", X.num[i]); // should be 1 : 01

	bn_mul(&p, &q, &X);
	if (bn_cmp(&X, &n) == 0)
		VK_Print("\n OK"); // should be
	else
		VK_Print("\n NOT OK !!!");

	bn_mul(&bn_e, &dP, &X);
	bn_sub(&p, &bn_one, &Y);
	bn_mod(&X, &Y, &X);
	if (bn_cmp(&X, &bn_one) == 0)
		VK_Print("\n OK"); // should be
	else
		VK_Print("\n NOT OK !!!");

	bn_mul(&bn_e, &dQ, &X);
	bn_sub(&q, &bn_one, &Y);
	bn_mod(&X, &Y, &X);
	if (bn_cmp(&X, &bn_one) == 0)
		VK_Print("\n OK"); // should be
	else
		VK_Print("\n NOT OK !!!");

	bn_mul(&q, &qInv, &X);
	bn_mod(&X, &p, &X);
	if (bn_cmp(&X, &bn_one) == 0)
		VK_Print("\n OK"); // should be
	else
		VK_Print("\n NOT OK !!!");

	VK_Print("\n BN_Test End. \n");
}
#endif // #ifdef INCLUDE_BN_TEST

