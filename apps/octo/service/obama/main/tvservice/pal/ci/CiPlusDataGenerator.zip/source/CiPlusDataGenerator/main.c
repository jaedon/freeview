/***************************************************************
* $Workfile:   ci_plus.h  $
* $Modtime:
* Auther : dslee
*
* Desc : CI+ Data Generator start point (main)
*
* Copyright (c) 2009 by Humax Co., Ltd.
* All right reserved
****************************************************************/


/***************************************************************
* include //////////////////////////////////////////////////////
***************************************************************/
#include "ci_plus.h"
#include <stdio.h>
#include <string.h>



/***************************************************************
* local definition
***************************************************************/
#define ENV_CFG_FILE				"env.cfg"
#define FILE_RELATED_ARGS_COUNT		3
#define MAX_CHAR_PER_1_LINE			512



/***************************************************************
* local function bodies
***************************************************************/
static int GetTokens(char *lineBuf, char commandArgs[][MAX_CHAR_PER_1_LINE])
{
	char seps[]   = " ,\t\n";
	char *token;
	int argsC = 0;

	token = strtok(lineBuf, seps);
	while(token != NULL )
	{	
		strcpy(commandArgs[argsC], token);
		argsC++;
		
		// Get next token: 
		token = strtok(NULL, seps);
	}

	return argsC;
}


// set run environment
// file extension configures 
// check CI_HOST_LICENSE_CONST debug enabled (display CI_HOST_LICENSE_CONST contents)	
static int SetEnvConfig(int *fileRelatedArgsCount, char fileRelatedArgs[][MAX_CHAR_PER_1_LINE])
{		
	int argsCount = 0;
	

	char lineBuf[MAX_CHAR_PER_1_LINE];
	FILE* fp = fopen(ENV_CFG_FILE, "r");
	if (fp == NULL)
	{
		printf("\n The (%s) file should be required\n", ENV_CFG_FILE);						
		return -1;
	}	
	
	// get file extension identifiers 
	fgets(lineBuf, MAX_CHAR_PER_1_LINE, fp);	
	*fileRelatedArgsCount = GetTokens(lineBuf, fileRelatedArgs);
	if (FILE_RELATED_ARGS_COUNT != *fileRelatedArgsCount)
	{
		printf("\n First Line in (%s) file should have (%d) args\n", ENV_CFG_FILE, FILE_RELATED_ARGS_COUNT);
		fclose(fp);
		return -1;
	}	

	// set file extension identifiers (second line)
	SetCertExt(fileRelatedArgs[0]);
	SetCertIdentifier(fileRelatedArgs[1]);
	SetKeyIdentifier(fileRelatedArgs[2]);

	
	// read second line - (-debug)
	fscanf(fp, "%s\n", lineBuf);
	if (0 == strcmp(lineBuf, "-debug"))
	{
		SetLicenseConstDebug(TRUE);
	}

	fclose(fp);

	return 0;
}




int main(int argc, char *argv[])
{		
	int fileRelatedArgsCount = 0; 
	char fileRelatedArgs[FILE_RELATED_ARGS_COUNT][MAX_CHAR_PER_1_LINE];
		
	// set device cert file extension identifier (device certificate <--> key file)
	if (SetEnvConfig(&fileRelatedArgsCount, fileRelatedArgs))
	{
		printf("\nPress Any Key to exit the program ... \n");
		getch();
		return -1;
	}


	// options (-e / -d, -t(hidden))
	// * usage explaining 
	if (argc <  2)
	{			
		printf (" make ci+ data             : .exe -e rootCertFile brandCertFile deviceCertFolder ciplusDataFolder\n");		
		printf (" check hostid from ci+data : .exe -d ciPlusDataFolder [-debug]\n");		
		return -1;
	}

	
	/*******************************
	******* do each functions 
	*******************************/
	
	// make ci+ data files
	if (0 == strcmp(argv[1], "-e"))
	{
		if (argc < 6)
		{
			printf (" Usage : .exe -e rootCertFile brandCertFile deviceCertFolder ciplusDataFolder\n");
			return -1;
		}

		if (ERR_OK != CI_MakeCiPlusDataWholeProcess(argv[2], argv[3], argv[4], argv[5]))
		{
			printf("Error : CI_MakeCiPlusDataWholeProcess()\n");
		}				
	}
		
	// display certificate's hostid(s) from ci+ data files
	else if (0 == strcmp(argv[1], "-d"))
	{
		if (argc < 3)
		{
			printf (" Usage : .exe -d ciPlusDataFolder\n");
			return -1;
		}	
		if (ERR_OK != CI_DisplayHostIdFromCiDataFiles(argv[2]))
		{
			printf("Error : CI_DisplayHostIdFromCiDataFiles()\n");
		}			
	}
	else if (0 == strcmp(argv[1], "-t"))
	{
		CI_SaveHostLicenseConstantsForTestKitOnly();
	}
	
	return 0;
}




