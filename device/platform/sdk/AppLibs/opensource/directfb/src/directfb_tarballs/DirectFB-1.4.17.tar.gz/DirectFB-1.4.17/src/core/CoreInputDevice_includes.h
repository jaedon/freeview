#include "CoreDFB_includes.h"

#ifdef __cplusplus
extern "C" {
#endif


#include <core/input.h>


#ifdef __cplusplus
}
#endif

