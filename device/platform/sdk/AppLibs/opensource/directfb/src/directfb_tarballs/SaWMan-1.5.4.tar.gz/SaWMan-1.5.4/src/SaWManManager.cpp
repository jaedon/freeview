/*
   (c) Copyright 2001-2011  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjälä <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.
*/

#include <config.h>

#include "SaWManManager.h"

extern "C" {
#include <directfb_util.h>

#include <direct/debug.h>
#include <direct/mem.h>
#include <direct/memcpy.h>
#include <direct/messages.h>

#include <fusion/conf.h>

#include <core/core.h>
}

D_DEBUG_DOMAIN( DirectFB_SaWManManager, "DirectFB/SaWManManager", "DirectFB SaWManManager" );

/*********************************************************************************************************************/

DFBResult
SaWManManager_Activate(
                    SaWManManager                             *obj

)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.Activate(  );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.Activate(  );
}

DFBResult
SaWManManager_QueueUpdate(
                    SaWManManager                             *obj,
                    DFBWindowStackingClass                     stacking,
                    const DFBRegion                           *update
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.QueueUpdate( stacking, update );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.QueueUpdate( stacking, update );
}

DFBResult
SaWManManager_ProcessUpdates(
                    SaWManManager                             *obj,
                    DFBSurfaceFlipFlags                        flags
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.ProcessUpdates( flags );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.ProcessUpdates( flags );
}

DFBResult
SaWManManager_CloseWindow(
                    SaWManManager                             *obj,
                    SaWManWindow                              *window
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.CloseWindow( window );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.CloseWindow( window );
}

DFBResult
SaWManManager_InsertWindow(
                    SaWManManager                             *obj,
                    SaWManWindow                              *window,
                    SaWManWindow                              *relative,
                    SaWManWindowRelation                       relation
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.InsertWindow( window, relative, relation );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.InsertWindow( window, relative, relation );
}

DFBResult
SaWManManager_RemoveWindow(
                    SaWManManager                             *obj,
                    SaWManWindow                              *window
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.RemoveWindow( window );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.RemoveWindow( window );
}

DFBResult
SaWManManager_SwitchFocus(
                    SaWManManager                             *obj,
                    SaWManWindow                              *window
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.SwitchFocus( window );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.SwitchFocus( window );
}

DFBResult
SaWManManager_SetScalingMode(
                    SaWManManager                             *obj,
                    SaWManScalingMode                          mode
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.SetScalingMode( mode );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.SetScalingMode( mode );
}

DFBResult
SaWManManager_SetWindowConfig(
                    SaWManManager                             *obj,
                    SaWManWindow                              *window,
                    const SaWManWindowConfig                  *config,
                    SaWManWindowConfigFlags                    flags
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.SetWindowConfig( window, config, flags );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.SetWindowConfig( window, config, flags );
}

DFBResult
SaWManManager_IsShowingWindow(
                    SaWManManager                             *obj,
                    SaWManWindow                              *window,
                    DFBBoolean                                *ret_showing
)
{
    if (!fusion_config->secure_fusion || dfb_core_is_master( core_dfb )) {
        DirectFB::ISaWManManager_Real real( core_dfb, obj );

        return real.IsShowingWindow( window, ret_showing );
    }

    DirectFB::ISaWManManager_Requestor requestor( core_dfb, obj );

    return requestor.IsShowingWindow( window, ret_showing );
}

/*********************************************************************************************************************/

static FusionCallHandlerResult
SaWManManager_Dispatch( int           caller,   /* fusion id of the caller */
                     int           call_arg, /* optional call parameter */
                     void         *ptr, /* optional call parameter */
                     unsigned int  length,
                     void         *ctx,      /* optional handler context */
                     unsigned int  serial,
                     void         *ret_ptr,
                     unsigned int  ret_size,
                     unsigned int *ret_length )
{
    SaWManManager *obj = (SaWManManager*) ctx;
    DirectFB::SaWManManagerDispatch__Dispatch( obj, caller, call_arg, ptr, length, ret_ptr, ret_size, ret_length );

    return FCHR_RETURN;
}

void SaWManManager_Init_Dispatch(
                    CoreDFB              *core,
                    SaWManManager        *obj,
                    FusionCall           *call
)
{
    fusion_call_init3( call, SaWManManager_Dispatch, obj, core->world );
}

void  SaWManManager_Deinit_Dispatch(
                    FusionCall           *call
)
{
     fusion_call_destroy( call );
}

/*********************************************************************************************************************/

namespace DirectFB {



DFBResult
ISaWManManager_Requestor::Activate(

)
{
    DFBResult           ret;
    SaWManManagerActivate       *args = (SaWManManagerActivate*) alloca( sizeof(SaWManManagerActivate) );
    SaWManManagerActivateReturn *return_args = (SaWManManagerActivateReturn*) alloca( sizeof(SaWManManagerActivateReturn) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );



    ret = (DFBResult) SaWManManager_Call( obj, FCEF_NONE, SaWManManager_Activate, args, sizeof(SaWManManagerActivate), return_args, sizeof(SaWManManagerActivateReturn), NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_Activate ) failed!\n", __FUNCTION__ );
        return ret;
    }

    if (return_args->result) {
         D_DERROR( return_args->result, "%s: SaWManManager_Activate failed!\n", __FUNCTION__ );
         return return_args->result;
    }


    return DFB_OK;
}


DFBResult
ISaWManManager_Requestor::QueueUpdate(
                    DFBWindowStackingClass                     stacking,
                    const DFBRegion                           *update
)
{
    DFBResult           ret;
    SaWManManagerQueueUpdate       *args = (SaWManManagerQueueUpdate*) alloca( sizeof(SaWManManagerQueueUpdate) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );


    args->stacking = stacking;
  if (update) {
    args->update = *update;
    args->update_set = true;
  }
  else
    args->update_set = false;

    ret = (DFBResult) SaWManManager_Call( obj, FCEF_ONEWAY, SaWManManager_QueueUpdate, args, sizeof(SaWManManagerQueueUpdate), NULL, 0, NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_QueueUpdate ) failed!\n", __FUNCTION__ );
        return ret;
    }


    return DFB_OK;
}


DFBResult
ISaWManManager_Requestor::ProcessUpdates(
                    DFBSurfaceFlipFlags                        flags
)
{
    DFBResult           ret;
    SaWManManagerProcessUpdates       *args = (SaWManManagerProcessUpdates*) alloca( sizeof(SaWManManagerProcessUpdates) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );


    args->flags = flags;

    ret = (DFBResult) SaWManManager_Call( obj, FCEF_ONEWAY, SaWManManager_ProcessUpdates, args, sizeof(SaWManManagerProcessUpdates), NULL, 0, NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_ProcessUpdates ) failed!\n", __FUNCTION__ );
        return ret;
    }


    return DFB_OK;
}


DFBResult
ISaWManManager_Requestor::CloseWindow(
                    SaWManWindow                              *window
)
{
    DFBResult           ret;
    SaWManManagerCloseWindow       *args = (SaWManManagerCloseWindow*) alloca( sizeof(SaWManManagerCloseWindow) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );

    D_ASSERT( window != NULL );

    args->window_id = SaWManWindow_GetID( window );

    ret = (DFBResult) SaWManManager_Call( obj, FCEF_ONEWAY, SaWManManager_CloseWindow, args, sizeof(SaWManManagerCloseWindow), NULL, 0, NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_CloseWindow ) failed!\n", __FUNCTION__ );
        return ret;
    }


    return DFB_OK;
}


DFBResult
ISaWManManager_Requestor::InsertWindow(
                    SaWManWindow                              *window,
                    SaWManWindow                              *relative,
                    SaWManWindowRelation                       relation
)
{
    DFBResult           ret;
    SaWManManagerInsertWindow       *args = (SaWManManagerInsertWindow*) alloca( sizeof(SaWManManagerInsertWindow) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );

    D_ASSERT( window != NULL );

    args->window_id = SaWManWindow_GetID( window );
  if (relative) {
    args->relative_id = SaWManWindow_GetID( relative );
    args->relative_set = true;
  }
  else
    args->relative_set = false;
    args->relation = relation;

    ret = (DFBResult) SaWManManager_Call( obj, FCEF_ONEWAY, SaWManManager_InsertWindow, args, sizeof(SaWManManagerInsertWindow), NULL, 0, NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_InsertWindow ) failed!\n", __FUNCTION__ );
        return ret;
    }


    return DFB_OK;
}


DFBResult
ISaWManManager_Requestor::RemoveWindow(
                    SaWManWindow                              *window
)
{
    DFBResult           ret;
    SaWManManagerRemoveWindow       *args = (SaWManManagerRemoveWindow*) alloca( sizeof(SaWManManagerRemoveWindow) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );

    D_ASSERT( window != NULL );

    args->window_id = SaWManWindow_GetID( window );

    ret = (DFBResult) SaWManManager_Call( obj, FCEF_ONEWAY, SaWManManager_RemoveWindow, args, sizeof(SaWManManagerRemoveWindow), NULL, 0, NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_RemoveWindow ) failed!\n", __FUNCTION__ );
        return ret;
    }


    return DFB_OK;
}


DFBResult
ISaWManManager_Requestor::SwitchFocus(
                    SaWManWindow                              *window
)
{
    DFBResult           ret;
    SaWManManagerSwitchFocus       *args = (SaWManManagerSwitchFocus*) alloca( sizeof(SaWManManagerSwitchFocus) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );

    D_ASSERT( window != NULL );

    args->window_id = SaWManWindow_GetID( window );

    ret = (DFBResult) SaWManManager_Call( obj, FCEF_ONEWAY, SaWManManager_SwitchFocus, args, sizeof(SaWManManagerSwitchFocus), NULL, 0, NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_SwitchFocus ) failed!\n", __FUNCTION__ );
        return ret;
    }


    return DFB_OK;
}


DFBResult
ISaWManManager_Requestor::SetScalingMode(
                    SaWManScalingMode                          mode
)
{
    DFBResult           ret;
    SaWManManagerSetScalingMode       *args = (SaWManManagerSetScalingMode*) alloca( sizeof(SaWManManagerSetScalingMode) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );


    args->mode = mode;

    ret = (DFBResult) SaWManManager_Call( obj, FCEF_ONEWAY, SaWManManager_SetScalingMode, args, sizeof(SaWManManagerSetScalingMode), NULL, 0, NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_SetScalingMode ) failed!\n", __FUNCTION__ );
        return ret;
    }


    return DFB_OK;
}


DFBResult
ISaWManManager_Requestor::SetWindowConfig(
                    SaWManWindow                              *window,
                    const SaWManWindowConfig                  *config,
                    SaWManWindowConfigFlags                    flags
)
{
    DFBResult           ret;
    SaWManManagerSetWindowConfig       *args = (SaWManManagerSetWindowConfig*) alloca( sizeof(SaWManManagerSetWindowConfig) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );

    D_ASSERT( window != NULL );
    D_ASSERT( config != NULL );

    args->window_id = SaWManWindow_GetID( window );
    args->config = *config;
    args->flags = flags;

    ret = (DFBResult) SaWManManager_Call( obj, FCEF_ONEWAY, SaWManManager_SetWindowConfig, args, sizeof(SaWManManagerSetWindowConfig), NULL, 0, NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_SetWindowConfig ) failed!\n", __FUNCTION__ );
        return ret;
    }


    return DFB_OK;
}


DFBResult
ISaWManManager_Requestor::IsShowingWindow(
                    SaWManWindow                              *window,
                    DFBBoolean                                *ret_showing
)
{
    DFBResult           ret;
    SaWManManagerIsShowingWindow       *args = (SaWManManagerIsShowingWindow*) alloca( sizeof(SaWManManagerIsShowingWindow) );
    SaWManManagerIsShowingWindowReturn *return_args = (SaWManManagerIsShowingWindowReturn*) alloca( sizeof(SaWManManagerIsShowingWindowReturn) );

    D_DEBUG_AT( DirectFB_SaWManManager, "ISaWManManager_Requestor::%s()\n", __FUNCTION__ );

    D_ASSERT( window != NULL );

    args->window_id = SaWManWindow_GetID( window );

    ret = (DFBResult) SaWManManager_Call( obj, FCEF_NONE, SaWManManager_IsShowingWindow, args, sizeof(SaWManManagerIsShowingWindow), return_args, sizeof(SaWManManagerIsShowingWindowReturn), NULL );
    if (ret) {
        D_DERROR( ret, "%s: SaWManManager_Call( SaWManManager_IsShowingWindow ) failed!\n", __FUNCTION__ );
        return ret;
    }

    if (return_args->result) {
         D_DERROR( return_args->result, "%s: SaWManManager_IsShowingWindow failed!\n", __FUNCTION__ );
         return return_args->result;
    }

    *ret_showing = return_args->showing;

    return DFB_OK;
}

/*********************************************************************************************************************/

static DFBResult
__SaWManManagerDispatch__Dispatch( SaWManManager *obj,
                                FusionID      caller,
                                int           method,
                                void         *ptr,
                                unsigned int  length,
                                void         *ret_ptr,
                                unsigned int  ret_size,
                                unsigned int *ret_length )
{
    D_UNUSED
    DFBResult ret;


    DirectFB::ISaWManManager_Real real( core_dfb, obj );


    switch (method) {
        case SaWManManager_Activate: {
            D_UNUSED
            SaWManManagerActivate       *args        = (SaWManManagerActivate *) ptr;
            SaWManManagerActivateReturn *return_args = (SaWManManagerActivateReturn *) ret_ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_Activate\n" );

            return_args->result = real.Activate(  );
            if (return_args->result == DFB_OK) {
            }

            *ret_length = sizeof(SaWManManagerActivateReturn);

            return DFB_OK;
        }

        case SaWManManager_QueueUpdate: {
            D_UNUSED
            SaWManManagerQueueUpdate       *args        = (SaWManManagerQueueUpdate *) ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_QueueUpdate\n" );

            real.QueueUpdate( args->stacking, args->update_set ? &args->update : NULL );

            return DFB_OK;
        }

        case SaWManManager_ProcessUpdates: {
            D_UNUSED
            SaWManManagerProcessUpdates       *args        = (SaWManManagerProcessUpdates *) ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_ProcessUpdates\n" );

            real.ProcessUpdates( args->flags );

            return DFB_OK;
        }

        case SaWManManager_CloseWindow: {
    SaWManWindow *window = NULL;
            D_UNUSED
            SaWManManagerCloseWindow       *args        = (SaWManManagerCloseWindow *) ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_CloseWindow\n" );

            ret = (DFBResult) SaWManWindow_Lookup( core_dfb, args->window_id, caller, &window );
            if (ret) {
                 D_DERROR( ret, "%s: Looking up window by ID %u failed!\n", __FUNCTION__, args->window_id );
                 return DFB_OK;
            }

            real.CloseWindow( window );

            if (window)
                SaWManWindow_Unref( window );

            return DFB_OK;
        }

        case SaWManManager_InsertWindow: {
    SaWManWindow *window = NULL;
    SaWManWindow *relative = NULL;
            D_UNUSED
            SaWManManagerInsertWindow       *args        = (SaWManManagerInsertWindow *) ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_InsertWindow\n" );

            ret = (DFBResult) SaWManWindow_Lookup( core_dfb, args->window_id, caller, &window );
            if (ret) {
                 D_DERROR( ret, "%s: Looking up window by ID %u failed!\n", __FUNCTION__, args->window_id );
                 return DFB_OK;
            }

            if (args->relative_set) {
                ret = (DFBResult) SaWManWindow_Lookup( core_dfb, args->relative_id, caller, &relative );
                if (ret) {
                     D_DERROR( ret, "%s: Looking up relative by ID %u failed!\n", __FUNCTION__, args->relative_id );
                     return DFB_OK;
                }
            }

            real.InsertWindow( window, args->relative_set ? relative : NULL, args->relation );

            if (window)
                SaWManWindow_Unref( window );

            if (relative)
                SaWManWindow_Unref( relative );

            return DFB_OK;
        }

        case SaWManManager_RemoveWindow: {
    SaWManWindow *window = NULL;
            D_UNUSED
            SaWManManagerRemoveWindow       *args        = (SaWManManagerRemoveWindow *) ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_RemoveWindow\n" );

            ret = (DFBResult) SaWManWindow_Lookup( core_dfb, args->window_id, caller, &window );
            if (ret) {
                 D_DERROR( ret, "%s: Looking up window by ID %u failed!\n", __FUNCTION__, args->window_id );
                 return DFB_OK;
            }

            real.RemoveWindow( window );

            if (window)
                SaWManWindow_Unref( window );

            return DFB_OK;
        }

        case SaWManManager_SwitchFocus: {
    SaWManWindow *window = NULL;
            D_UNUSED
            SaWManManagerSwitchFocus       *args        = (SaWManManagerSwitchFocus *) ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_SwitchFocus\n" );

            ret = (DFBResult) SaWManWindow_Lookup( core_dfb, args->window_id, caller, &window );
            if (ret) {
                 D_DERROR( ret, "%s: Looking up window by ID %u failed!\n", __FUNCTION__, args->window_id );
                 return DFB_OK;
            }

            real.SwitchFocus( window );

            if (window)
                SaWManWindow_Unref( window );

            return DFB_OK;
        }

        case SaWManManager_SetScalingMode: {
            D_UNUSED
            SaWManManagerSetScalingMode       *args        = (SaWManManagerSetScalingMode *) ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_SetScalingMode\n" );

            real.SetScalingMode( args->mode );

            return DFB_OK;
        }

        case SaWManManager_SetWindowConfig: {
    SaWManWindow *window = NULL;
            D_UNUSED
            SaWManManagerSetWindowConfig       *args        = (SaWManManagerSetWindowConfig *) ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_SetWindowConfig\n" );

            ret = (DFBResult) SaWManWindow_Lookup( core_dfb, args->window_id, caller, &window );
            if (ret) {
                 D_DERROR( ret, "%s: Looking up window by ID %u failed!\n", __FUNCTION__, args->window_id );
                 return DFB_OK;
            }

            real.SetWindowConfig( window, &args->config, args->flags );

            if (window)
                SaWManWindow_Unref( window );

            return DFB_OK;
        }

        case SaWManManager_IsShowingWindow: {
    SaWManWindow *window = NULL;
            D_UNUSED
            SaWManManagerIsShowingWindow       *args        = (SaWManManagerIsShowingWindow *) ptr;
            SaWManManagerIsShowingWindowReturn *return_args = (SaWManManagerIsShowingWindowReturn *) ret_ptr;

            D_DEBUG_AT( DirectFB_SaWManManager, "=-> SaWManManager_IsShowingWindow\n" );

            ret = (DFBResult) SaWManWindow_Lookup( core_dfb, args->window_id, caller, &window );
            if (ret) {
                 D_DERROR( ret, "%s: Looking up window by ID %u failed!\n", __FUNCTION__, args->window_id );
                 return_args->result = ret;
                 return DFB_OK;
            }

            return_args->result = real.IsShowingWindow( window, &return_args->showing );
            if (return_args->result == DFB_OK) {
            }

            *ret_length = sizeof(SaWManManagerIsShowingWindowReturn);

            if (window)
                SaWManWindow_Unref( window );

            return DFB_OK;
        }

    }

    return DFB_NOSUCHMETHOD;
}
/*********************************************************************************************************************/

DFBResult
SaWManManagerDispatch__Dispatch( SaWManManager *obj,
                                FusionID      caller,
                                int           method,
                                void         *ptr,
                                unsigned int  length,
                                void         *ret_ptr,
                                unsigned int  ret_size,
                                unsigned int *ret_length )
{
    DFBResult ret;

    D_DEBUG_AT( DirectFB_SaWManManager, "SaWManManagerDispatch::%s()\n", __FUNCTION__ );

    ret = __SaWManManagerDispatch__Dispatch( obj, caller, method, ptr, length, ret_ptr, ret_size, ret_length );

    return ret;
}

}
