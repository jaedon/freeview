#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static char *chipId = NULL;    // -i option

void showUsage()
{
    printf("Usage: DCAP.39 [-h]\n\
Set the Golden Node to default conditions:\n\
\n\
Options:\n\
  -h   Display this help and exit\n");
}

int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_INITIALIZATION_PARMS initParms;
    MoCA_CONFIG_PARAMS cfgParms;
    UINT64 initMask;
    UINT64 cfgMask;
    int i;

    // ----------- Parse parameters

    opterr = 0;
    
    while((ret = getopt(argc, argv, "hi:")) != -1) 
    {
        switch(ret)
        {
        case 'i':
            chipId = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Set Defaults 
    
    MoCACtl2_GetPersistent(ctx, "MoCAINITPARMS", (char *)&initParms, sizeof(initParms));   

    if (initParms.rfType == MoCA_RF_TYPE_E_BAND)
    {
       initParms.nvParams.lastOperFreq = MoCA_DEF_MID_FREQ_MHZ;
       initParms.beaconChannel         = MoCA_DEF_BEACON_CHANNEL ;
    }
    else if (initParms.rfType == MoCA_RF_TYPE_F_BAND)
    {
        initParms.nvParams.lastOperFreq = MoCA_DEF_MIDHI_FREQ_MHZ;
        initParms.beaconChannel         = MoCA_DEF_MIDHI_FREQ_MHZ;
    }
    else if (initParms.rfType == MoCA_RF_TYPE_H_BAND)
    {
        initParms.nvParams.lastOperFreq = MoCA_DEF_HBAND_FREQ_MHZ;
        initParms.beaconChannel         = MoCA_DEF_HBAND_FREQ_MHZ;
    }
    else
        initParms.nvParams.lastOperFreq = MoCA_NULL_FREQ_MHZ ;

    initParms.privacyEn             = MoCA_DEF_PRIVACY ;
    initParms.autoNetworkSearchEn   = MoCA_DEF_AUTO_NW_SEARCH ;
    initParms.ncMode                = MoCA_DEF_NC_MODE ;

    if (initParms.terminalIntermediateType == MoCA_NODE_TYPE_TERMINAL)
        initParms.preferedNC        = MoCA_PREFERED_NC_MODE ;
    else        
        initParms.preferedNC        = MoCA_DEF_PREFERED_NC_MODE ;

    initParms.constTransmitMode     = MoCA_DEF_CONST_TX_MODE ;
    initParms.passwordSize          = MoCA_DEF_PASSWORD_SIZE ;
    strcpy ((char *)initParms.password, MoCA_DEF_USER_PASSWORD) ;
    initParms.beaconPwrReduction    = MoCA_DEF_BEACON_PWR_REDUCTION ;
    initParms.beaconPwrReductionEn  = MoCA_DEF_BEACON_PWR_REDUCTION_EN ;
    initParms.continuousRxModeAttn  = MoCA_DEF_RX_MODE_ATTN ;
    initParms.tabooLeftMask         = MoCA_DEF_TABOO_LEFT_MASK ;
    initParms.tabooRightMask        = MoCA_DEF_TABOO_RIGHT_MASK ;

    initMask = MoCA_INIT_PARAM_NC_MODE_MASK                 |
               MoCA_INIT_PARAM_AUTO_NETWORK_SEARCH_EN_MASK  |
               MoCA_INIT_PARAM_PRIVACY_MASK                 |
               MoCA_INIT_PARAM_NV_PARAMS_LOF_MASK           |
               MoCA_INIT_PARAM_PASSWORD_SIZE_MASK           |
               MoCA_INIT_PARAM_PASSWORD_MASK                |
               MoCA_INIT_PARAM_PREFERED_NC_MASK             |
               MoCA_INIT_PARAM_CONST_TRANSMIT_MODE_MASK     |
               MoCA_INIT_PARAM_BEACON_PWR_REDUCTION_MASK    |
               MoCA_INIT_PARAM_BEACON_PWR_REDUCTION_EN_MASK |
               MoCA_INIT_PARAM_BEACON_CHANNEL_MASK          |
               MoCA_INIT_PARAM_TABOO_LEFT_MASK_MASK         |
               MoCA_INIT_PARAM_TABOO_RIGHT_MASK_MASK        |
               MoCA_INIT_PARAM_CONTINUOUS_RX_MODE_ATTN_MASK;

    cmsret = MoCACtl2_SetInitParms(ctx, &initParms, initMask);
    if (cmsret != CMSRET_SUCCESS)
    {
        MoCACtl_Close(ctx);
        fprintf(stderr, "Error!  SetInitParms\n");
        return(-3);
    }

    MoCACtl2_SetPersistent(ctx, "MoCAINITPARMS", &initParms, sizeof(initParms));

    MoCACtl2_GetPersistent(ctx, "MoCACFGPARMS", &cfgParms, sizeof(cfgParms));

    for (i = 0; i < MoCA_MAX_NODES; i++)
    {
        cfgParms.constellation[i] = MoCA_DEF_CONSTELLATION_INFO;
    }
    cfgParms.continuousIEMapInsert = MoCA_DEF_CONTINUOUS_IE_MAP_INSERT;
    cfgParms.continuousIERRInsert  = MoCA_DEF_CONTINUOUS_IE_RR_INSERT;
    cfgParms.maxPktAggr            = MoCA_DEF_PKT_AGGR;
    cfgParms.minAggrWaitTime       = MOCA_DEF_MIN_AGGR_WAIT_TIME;
    cfgParms.pssEn                 = MoCA_PSS_IE_DEFAULT;

    if ((initParms.rfType == MoCA_RF_TYPE_C4_BAND) ||
        (initParms.rfType == MoCA_RF_TYPE_D_BAND))
        cfgParms.rlapmEn           = MoCA_DEF_RLAPM_EN;
    else
        cfgParms.rlapmEn           = 1;
        
    cfgParms.loopbackEn            = MoCA_DEF_LOOPBACK_EN;
    cfgParms.arplTh                = MoCA_DEF_ARPL_TH;
    cfgParms.sapmEn                = MoCA_DEF_SAPM_EN;
    cfgParms.freqShiftMode         = MoCA_DEF_FREQ_SHIFT_MODE;

    cfgMask = MoCA_CFG_PARAM_MAX_CONSTELLATION_MASK  |
              MoCA_CFG_PARAM_CONT_IE_MAP_INS_MASK    |
              MoCA_CFG_PARAM_CONT_IE_RR_INS_MASK     |
              MoCA_CFG_PARAM_MAX_PKT_AGGR_MASK       |
              MoCA_CFG_PARAM_MIN_AGGR_WAIT_TIME_MASK |
              MoCA_CFG_PARAM_PSS_EN_MASK             |
              MoCA_CFG_PARAM_RLAPM_EN_MASK           |
              MoCA_CFG_PARAM_LOOPBACK_EN_MASK        |
              MoCA_CFG_PARAM_ARPL_TH_MASK            |
              MoCA_CFG_PARAM_SAPM_EN_MASK            |
              MoCA_CFG_PARAM_FREQ_SHIFT_MASK;

    cmsret=MoCACtl2_ReInitialize( 
                ctx,
                &initParms, 
                initMask,
                &cfgParms,
                cfgMask );

    MoCACtl2_SetPersistent(ctx, "MoCACFGPARMS", &cfgParms, sizeof(cfgParms));

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}
