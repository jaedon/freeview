#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>
#include <pthread.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "mocalib-cli.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

#define RESP_CODE_SUCCESS 0x2

char *chipId = NULL;    // -i option
int numOfNodesResp = 0;
int bitMaskofRspNodes = 0;
    
void showUsage()
{
    printf("Usage: DCAP.40 <BitMasknodeId> [resettimer] [-h] \n\
Send reset request to all the nodes in the network.\n\
\n\
Options:\n\
  <BitMasknodeId>  BitMask in hex (e.g 0x123) of the Node Id \n\
                   of the nodes to be rebooted\n\
  [resettimer]     Reset time in seconds\n\
  -h   Display this help and exit\n");
}

static void print_mr_info(void * ctx, int requiredNodes)
{

   printf("Bitmask of the nodes responded  0x%x\n", bitMaskofRspNodes);
   if (requiredNodes == numOfNodesResp )
   {      
       printf("All Nodes Responded\n");
   }
   else
   { 
        printf("Some Nodes Responded\n");
   }
   printf("\n");
}

static void mr_rsp_cb(void *arg, struct moca_mr_response *in)
{
   uint8_t *nodes;
   int i;
   uint8_t rspCode;
   
   nodes = &in->n00ResetStatus;

   for (i=0; i< MOCA_MAX_NODES;i++)
   {
      nodes++;
      rspCode = *nodes;  
      nodes++;
      if ( rspCode == RESP_CODE_SUCCESS )
      {
         bitMaskofRspNodes |= (1 << i);
         numOfNodesResp++;
      }

   }
   pqos_callback_return(arg);
}


int main(int argc, char **argv)
{
    int nRet = CMSRET_SUCCESS;
    void *ctx;
    MoCA_STATUS status;
    pthread_t       event_thread;
    struct moca_gen_status gs;
    struct moca_mr_request req;
    struct moca_gen_node_status gns;
    int resetTmr = 1;
    int altnode = 0xFF;
    int i;
    int numOfrequestedNodes = 0;
    UINT32 BitMasknodeId = 0;
    char *end;

     
    // ----------- Parse parameters
    opterr = 0;

    if ( (argc < 2) || (argc > 3) )
    {
            fprintf(stderr, "Error! Insufficient arguments\n");
            return(-1);
    }
    while((nRet = getopt(argc, argv, "hi:")) != -1) 
    {
        switch(nRet)
        {
        case 'i':
            chipId = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }
 
    for (i=1;i < argc;i++)
    {
        if (argv[i][0] == '0')
    {
            if (argv[i][1] != 'x')
            {
                fprintf(stderr, "Error! Invalid parameter\n");
                return(-1);
            }
            
                BitMasknodeId = strtoul(argv[i], &end, 16);
            
            if (*end != '\0')
            {
                fprintf(stderr, "Error!  Invalid parameter\n");
                return(-4);
            }
    }
    else
    {
            resetTmr =  atoi(argv[i]);
    }
   } 
    

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }
    
    // ----------- Get info

    nRet = MoCACtl2_GetStatus(ctx, &status);

    if (nRet != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  unable to get moca status\n");
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        return(-4);
    }  


    nRet = moca_start_event_loop(ctx, &event_thread);
    if (nRet == CMSRET_SUCCESS) 
    {
        moca_register_mr_response_cb(ctx, &mr_rsp_cb, ctx);

         memset (&req, 0x00, sizeof(req));
         /* get node bitmask */
         moca_get_gen_status(ctx, &gs);
         
         /* get status entry for each node */
         for(altnode = 0; altnode < MOCA_MAX_NODES; altnode++) {
           if(! (gs.connected_nodes & (1 << altnode)))
               continue;
           if ((BitMasknodeId & (1 << altnode)))
           {
                 numOfrequestedNodes++; 

                  nRet = moca_get_gen_node_status(ctx, altnode, &gns);
                  if ( (nRet == 0) & (altnode != gs.node_id) ) 
                  {
                    if ((gns.protocol_support >> 24) >= MoCA_VERSION_11)
                        req.wave0Nodemask |= (1 << altnode); 
                 }
              }
            }
        req.entryNodeId  = gs.node_id;    
        req.resetTimer   = resetTmr;
        req.nonDefSeqNum = 0xFFFF;
        req.resetStatus  = 0;
        nRet = moca_set_mr_request(ctx, &req);
        if (nRet != 0)
        {
           printf("%s: moca_set_mr_request returned %d\n",
                          __FUNCTION__, nRet);
           return (CMSRET_INTERNAL_ERROR);
         }

         moca_wait_for_event(ctx, event_thread); 
         print_mr_info(ctx, numOfrequestedNodes);
   }
    MoCACtl_Close(ctx);

    return(0);
}
