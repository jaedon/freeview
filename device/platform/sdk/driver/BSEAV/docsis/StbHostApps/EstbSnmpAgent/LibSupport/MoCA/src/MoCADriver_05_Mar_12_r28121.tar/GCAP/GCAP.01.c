#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>


#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

char *chipId = NULL;    // -i option
int interval = 0;
int duration = 0;
int endless = 0;

void showUsage()
{
    printf("Usage: GCAP.01 [-i <polling interval>] [-t <polling duration>] [-h]\n\
Report time-stamps whenever key exchanges happen between nodes.\n\
\n\
Options:\n\
  -i   Set polling interval in number of seconds (default 1 second)\n\
  -t   Set polling duration in number of minutes (default forever until\n\
       Ctrl-C to break)\n\
  -e   Allow polling to continue if link goes down (default polling\n\
       stops when MoCA link goes down)\n\
  -h   Display this help and exit\n");
}

void callback(void * userarg, struct moca_key_changed * out)
{
    time_t t;
    struct tm *timex;
   
    t=time(NULL);
    timex=localtime(&t);
    
    printf("%02d:%02d:%02d %s Changed to %s\n", 
        timex->tm_hour, timex->tm_min, timex->tm_sec, 
        out->tekpmk?"PMK":"TEK", out->evenodd?"ODD":"EVEN");
}


void link_cb(void * userarg, uint32_t status)
{
    if (status == 0)
    {
        printf("Error! No Link\n");
        exit(0);
    }
}


int main(int argc, char **argv)
{
    int ret;
    
    MoCA_CONFIG_PARAMS configParms;
    MoCA_INITIALIZATION_PARMS moCAInitParms;
    unsigned long long configMask;
    
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_STATUS status;
    void *ctx;
    
    memset (&configParms, 0x00, sizeof(configParms)) ;
    configMask = 0x0LL ;

    moca_gcap_init();

    // ----------- Parse parameters
    
    opterr = 0;
    
    while((ret = getopt(argc, argv, "hex:i:t:")) != -1) 
    {
        switch(ret)
        {
        case 'e':
            endless = 1;
            break;
        case 'x':
            chipId = optarg;
            break;            
        case 'i':
            interval = atoi(optarg);
            break;
        case 't':
            duration = atoi(optarg);
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Get info
    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        return(-4);
    }  

    cmsret = MoCACtl2_GetInitParms(ctx, &moCAInitParms);

    if (moCAInitParms.privacyEn != MoCA_PRIVACY_ENABLED)
    {
        fprintf(stderr, "Error! Privacy is not enabled!\n");
        return(-5); 
    }
    
    printf("Waiting for Privacy key exchange\n");

    moca_register_key_changed_cb(ctx, callback, ctx);

    if (endless == 0)
       moca_register_link_up_state_cb(ctx, link_cb, ctx);
      
    if (duration)
        alarm(duration*60);

    MoCACtl2_EventLoop(ctx);

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}


