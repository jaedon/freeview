#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

char *chipId = NULL;    // -i option

void showUsage()
{
    printf("Usage: GCAP.05 [-h]\n\
Report backup NC node ID and MAC address.\n\
\n\
Options:\n\
  -h   Display this help and exit\n");
}

void printNodeInfo(void *ctx, int node)
{
    MoCA_NODE_STATUS_ENTRY nodestatus;
    CmsRet cmsret = CMSRET_SUCCESS;
    MAC_ADDRESS macAddr;

    nodestatus.nodeId = node;
    cmsret = MoCACtl2_GetNodeStatus(ctx, &nodestatus);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure 2\n");
        exit(-6);
    }

    moca_u32_to_mac(macAddr, nodestatus.eui[0], nodestatus.eui[1]);
    printf("Node ID: %2d Node MAC Address: %02X:%02X:%02X:%02X:%02X:%02X\n", node,
        macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5] );
}

int main(int argc, char **argv)
{
    int ret;
    
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_STATUS status;
    void *ctx;
    
    int bncnode;

    // ----------- Parse parameters
    opterr = 0;
    
    while((ret = getopt(argc, argv, "hi:")) != -1) 
    {
        switch(ret)
        {
        case 'i':
            chipId = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Get info

    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        return(-4);
    }
        
    bncnode = status.generalStatus.backupNcId;
    
    printf("Backup NC ");    
    printNodeInfo(ctx, bncnode);    

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}



