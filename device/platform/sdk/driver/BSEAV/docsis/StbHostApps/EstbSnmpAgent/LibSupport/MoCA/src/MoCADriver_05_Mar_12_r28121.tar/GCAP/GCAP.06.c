#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

char *chipId = NULL;    // -i option
MoCA_NODE_COMMON_STATUS_ENTRY nodeCommonStatus ;

void showUsage()
{
    printf("Usage: GCAP.06 [-h]\n\
Report PHY bit rates between the GN & other nodes.\n\
\n\
Options:\n\
  -h   Display this help and exit\n");
}

void printNodeRateInfo(void *ctx, int node)
{
    MoCA_NODE_STATUS_ENTRY nodestatus;
    CmsRet cmsret = CMSRET_SUCCESS;
    MAC_ADDRESS macAddr;
    
    nodestatus.nodeId = node;
    cmsret = MoCACtl2_GetNodeStatus(ctx, &nodestatus);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure 2\n");
        exit(-6);
    }

    moca_u32_to_mac(macAddr, nodestatus.eui[0], nodestatus.eui[1]);
    printf("%3d      %02X:%02X:%02X:%02X:%02X:%02X %11d %11d %12d %13d\n", node,
        macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5],
        nodestatus.maxPhyRates.txUcPhyRate, nodestatus.maxPhyRates.rxUcPhyRate, 
        nodeCommonStatus.maxCommonPhyRates.txBcPhyRate, nodestatus.maxPhyRates.rxBcPhyRate );
}

int main(int argc, char **argv)
{
    int ret;
    
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_STATUS status;
    void *ctx;
    UINT32   tblSize ;
    MoCA_NODE_STATUS_ENTRY nodeStatus [MoCA_MAX_NODES] ;
    int altnode;
    int altnodemask;

    // ----------- Parse parameters
    opterr = 0;
    
    while((ret = getopt(argc, argv, "hi:")) != -1) 
    {
        switch(ret)
        {
        case 'i':
            chipId = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Get info

    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        return(-4);
    }  
    
    cmsret = MoCACtl2_GetNodeTblStatus( ctx, &nodeStatus [0], &nodeCommonStatus, &tblSize ) ;

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error! GetNodeTblStatus failure\n");
        return(-5);
    }

    altnode = 0;
    altnodemask = status.generalStatus.connectedNodes;

    printf("Management GN Node ID= %d\n",status.generalStatus.nodeId);
    printf("PHY BitRate Information:\n");
    printf("------------------------------------------------------------------------------\n");
    printf("Node ID  MAC Addr           Tx bit rate  Rx bit rate  GCD Tx rate  GCD Rx rate\n");

    while (altnode < 16)
    {
        if ((altnodemask &(1<<altnode)) != 0)
        {
           printNodeRateInfo(ctx, altnode);
        }

        altnode++;
    }

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}
