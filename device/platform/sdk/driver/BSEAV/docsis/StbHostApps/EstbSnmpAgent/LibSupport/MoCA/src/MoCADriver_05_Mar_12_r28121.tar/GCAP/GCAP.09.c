#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static char *chipId = NULL;    // -i option
static int persistent = 0;     // -M option
static int reset = 0;          // -r option

void showUsage()
{
    printf("Usage: GCAP.09 [-h] [-M] [-r] [tabooLeftMask tabooRightMask]\n\
Report or Set Taboo frequency mask.\n\
\n\
Options:\n\
  -h             Display this help and exit\n\
  -M             Make configuration changes permanent\n\
  -r             Reset SoC to make configuration changes effective\n\
  tabooLeftMask  Taboo mask on left side of current channel\n\
                 bit n -> lof-25Mhz*(n+1)\n\
  tabooRightMask Taboo mask on right side of current channel\n\
                 bit n -> lof+25Mhz*(32-n))\n\
  \n\
  tabooLeftMask and tabooRightMask in hex.  e.g. GCAP.09 0x7 0xe0000000\n");
}

int main(int argc, char **argv)
{
    int ret;
    
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_STATUS status;
    void *ctx;
    UINT32 tabooLeftMask = 0;
    UINT32 tabooRightMask = 0;
    UINT32 tabooLeftMaskSet = 0;
    UINT32 tabooRightMaskSet = 0;    
    int i;
    MoCA_INITIALIZATION_PARMS reInitParms;    
    
    memset(&reInitParms, 0x00, sizeof(reInitParms));

    char *end;
    
    // ----------- Parse parameters
    opterr = 0;
    
    while((ret = getopt(argc, argv, "hMri:")) != -1)
    {
        switch(ret)
        {
        case 'i':
            chipId = optarg;
            break;
        case 'M':
            persistent = 1;
            break;            
        case 'r':
            reset = 1;
            break;            
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;            
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }


    // ----------- Initialize


    for(i=1;i<argc;i++)
    {
        if (argv[i][0] == '0')
        {
            if (argv[i][1] != 'x')
            {
                fprintf(stderr, "Error! Invalid parameter\n");
                return(-1);
            }
            
            if (!tabooLeftMaskSet)
            {
                tabooLeftMask = strtoul(argv[i], &end, 16);
                tabooLeftMaskSet = 1;
            }
            else if (!tabooRightMaskSet)
            {
                tabooRightMask = strtoul(argv[i], &end, 16);
                tabooRightMaskSet = 1;
            }
            else
            {
                fprintf(stderr, "Error! Invalid parameter\n");
                return(-3);
            }
            
            if (*end != '\0')
            {
                fprintf(stderr, "Error!  Invalid parameter\n");
                return(-4);
            }
        }
        else if (argv[i][0] != '-')
        {
            fprintf(stderr, "Error! Invalid parameter\n");
            return(-4);
        }
    }

    if (tabooLeftMaskSet ^ tabooRightMaskSet)
    {
        fprintf(stderr, "Error! Insufficient arguments\n");
        return(-5);        
    }

    
    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    if (tabooLeftMaskSet)
    {
        MoCACtl2_GetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS));

        reInitParms.tabooLeftMask = tabooLeftMask & MoCA_VALID_TABOO_LEFT_MASK;
        reInitParms.tabooRightMask = tabooRightMask & MoCA_VALID_TABOO_RIGHT_MASK;

        cmsret = MoCACtl2_SetInitParms(ctx, &reInitParms, 
            MoCA_INIT_PARAM_TABOO_LEFT_MASK_MASK | MoCA_INIT_PARAM_TABOO_RIGHT_MASK_MASK);
        
        if (cmsret != CMSRET_SUCCESS)
        {
            MoCACtl_Close(ctx);
            fprintf(stderr, "Error!  SetInitParms\n");
            return(-6);
        }

        if (persistent)
        {
            cmsret = MoCACtl2_SetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS));
            if (cmsret != CMSRET_SUCCESS)
            {
                MoCACtl_Close(ctx);
                fprintf(stderr, "Error!  Unable to save parameters to nvram\n");
                return(-7);
            }            
        }

        if (reset)
        {
            cmsret=MoCACtl2_ReInitialize( 
                ctx,
                &reInitParms, 
                MoCA_INIT_PARAM_TABOO_LEFT_MASK_MASK | MoCA_INIT_PARAM_TABOO_RIGHT_MASK_MASK,
                NULL,
                0);

            if (cmsret != CMSRET_SUCCESS)
            {
                MoCACtl_Close(ctx);
                fprintf(stderr, "Error!  Reinitialize\n");
                return(-8);
            }
            
        }
    }
    else
    {
        // ----------- Get info

        cmsret = MoCACtl2_GetStatus(ctx, &status);

        if (cmsret != CMSRET_SUCCESS)
        {            
            fprintf(stderr, "Error!  Mocactl failure\n");
            MoCACtl_Close(ctx);
            return(-9);
        }

        if (status.generalStatus.linkStatus != MoCA_LINK_UP)
        {
            fprintf(stderr, "Error! No Link\n");
            MoCACtl_Close(ctx);
            return(-10);
        }

        printf("TABOO_CHANNEL_MASK  = 0x%06x\n",status.generalStatus.networkTabooMask);
        printf("TABOO_MASK_START    = %d\n",status.generalStatus.networkTabooStart);    
    }
    
    // ----------- Finish
    MoCACtl_Close(ctx);

    return(0);
}



