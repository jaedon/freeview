#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

char *chipId = NULL;    // -i option
int interval = 0;
int endless = 0;

void showUsage()
{
    printf("Usage: GCAP.15 [-t <polling duration>] [-h]\n\
Report the time it takes to complete LMO cycle with a DUT.\n\
\n\
Options:\n\
  -t    Set polling duration in number of minutes (default forever until\n\
        Ctrl-C to break)\n\
  -e    Allow polling to continue if link goes down (default polling\n\
        stops when MoCA link goes down)\n\
  -h    Display this help and exit\n");
}

void callback(void *userarg, struct moca_lmo_info *out)
{
    MoCA_NODE_STATUS_ENTRY nodestatus;
    CmsRet cmsret;
    void *ctx = userarg;
    MAC_ADDRESS macAddr;
    
    nodestatus.nodeId = out->lmo_node_id;
    cmsret = MoCACtl2_GetNodeStatus(ctx, &nodestatus);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure 2\n");
        exit(-6);
    }

    moca_u32_to_mac(macAddr, nodestatus.eui[0], nodestatus.eui[1]);
    printf("LMO node %2d MAC Address=%02x:%02x:%02x:%02x:%02x:%02x  Duration=%2ds  %s\n",
        out->lmo_node_id, 
        macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5],
        out->lmo_duration_sec,
        out->is_lmo_success?"LMO Success":"LMO_Timeout");
}


void link_cb(void * userarg, uint32_t status)
{
    if (status == 0)
    {
        printf("Error! No Link\n");
        exit(0);
    }
}


int main(int argc, char **argv)
{
    int ret;
    
    MoCA_CONFIG_PARAMS configParms;
    unsigned long long configMask;
    
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_STATUS status;
    void *ctx;
    
    memset (&configParms, 0x00, sizeof(configParms)) ;
    configMask = 0x0LL ;

    moca_gcap_init();

    // ----------- Parse parameters
    
    opterr = 0;
    
    while((ret = getopt(argc, argv, "hei:t:")) != -1) 
    {
        switch(ret)
        {
        case 'e':
            endless = 1;
            break;
        case 'i':
            chipId = optarg;
            break;
        case 't':
            interval = atoi(optarg);
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Get info
    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        return(-4);
    }  
    
    printf("Management GN Node ID= %d\n",status.generalStatus.nodeId);
    
    moca_register_lmo_info_cb(ctx, callback, ctx);

    if (endless == 0)
       moca_register_link_up_state_cb(ctx, link_cb, ctx);

    if (interval)
        alarm(interval*60);

    MoCACtl2_EventLoop(ctx);

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}

