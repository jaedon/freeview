#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static int persistent = 0;     // -M option
static int reset = 0;          // -r option
static char *chipId = NULL;    // -i option
static int privacy=0;
char * password="99999999988888888";

void showUsage()
{
    printf("Usage: GCAP.16 [-p <enable/disable>] [--Pswd <17 digit password>] [-M] [-r] [-h]\n\
Enable/disable privacy and set the password.\n\
Default values will be used if parameters are not supplied.\n\
Note that resetting SoC is required for configuration to take affect.\n\
If multiple configuration parameters are being changed, -r option can be\n\
used in the last command.\n\
\n\
Options:\n\
  -p      To 'enable' OR 'disable' Privacy (default 'disable')\n\
  --Pswd  Set privacy password up to 17 digits (default '99999999988888888')\n\
  -M      Make configuration changes permanent\n\
  -r      Reset SoC to make configuration changes effective\n\
  -h      Display this help and exit\n");
}

int main(int argc, char **argv)
{
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;
    int i;
    
    UINT64 reInitMask = 0;
    MoCA_INITIALIZATION_PARMS reInitParms;    

    memset(&reInitParms, 0x00, sizeof(reInitParms));

    // ----------- Parse parameters

    for(i=1;i<argc;i++)
    {
        if (argv[i][0] == '-')
        {
            switch(argv[i][1])
            {
            case 'i':
                if (i+1 < argc)
                {
                    i++;
                    chipId = argv[i];
                }
                else
                {
                    chipId = "";
                }
                break;
            case 'M':
                persistent = 1;
                break;
            case 'r':
                reset = 1;
                break;
            case 'p':
                if ((i+1 < argc) && (argv[i+1][0] != '-'))
                {
                    if (strcmp(argv[i+1],"enable")==0)
                    {
                        privacy = 1;
                    }
                    else if (strcmp(argv[i+1],"disable")==0)
                    {
                        privacy = 0;
                    }
                    else
                    {
                        fprintf(stderr, "Error!  Invalid parameter\n");
                        return(-1);                     
                    }

                    i++;
                }
                else
                {
                    fprintf(stderr, "Error!  Missing parameter %s\n", &argv[i][2]);
                    return(-2);                     
                }
                break;        
            case '-':
                if (argv[i][2] != 'P')
                {
                    fprintf(stderr, "Error!  Invalid option - %s\n", &argv[i][2]);
                    return(-3);
                }

                if (i+1 < argc)
                {
                    i++;
                    password=argv[i];
                }
                else
                {
                    password = "";
                }
                break;           
            case 'h':
                showUsage();
                return(0); 
                break;
            default:
                fprintf(stderr, "Error!  Invalid option - %s\n", &argv[i][1]);
                return(-4);
            }
        }
    }


    if ((strlen(password) < MoCA_MIN_PASSWORD_LEN) ||
        (strlen(password) > MoCA_MAX_PASSWORD_LEN)) {
        fprintf(stderr, "Error!  Invalid password\n");
        return(-5);
    }

    /* The password must be all decimal characters */
    for ( i = 0; i < strlen(password); i++ ) {
        if ( (password [i] < '0') || (password [i] > '9') ) {
            fprintf(stderr, "Error!  Invalid password\n");
            return(-6);
        }
    }

    // ----------- Initialize
    
    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-7);
    }

    // ----------- Save Settings 
   
    if (MoCACtl2_GetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS)) <= 0)
    {
        MoCACtl_Close(ctx);
        fprintf(stderr, "Error!  GetInitParms\n");
        return(-8);
    }

    reInitMask |= MoCA_INIT_PARAM_PRIVACY_MASK; 
    if (privacy)
        reInitParms.privacyEn = MoCA_PRIVACY_ENABLED;
    else
        reInitParms.privacyEn = MoCA_PRIVACY_DISABLED;

    reInitMask |= MoCA_INIT_PARAM_PASSWORD_MASK;
    strncpy((char*)reInitParms.password, password, MoCA_MAX_PASSWORD_LEN);
    reInitParms.passwordSize = strlen((const char *)reInitParms.password);

    cmsret = MoCACtl2_SetInitParms(ctx, &reInitParms, reInitMask);
    if (cmsret != CMSRET_SUCCESS)
    {
        MoCACtl_Close(ctx);
        fprintf(stderr, "Error!  SetInitParms\n");
        return(-9);
    }

    if (persistent)
    {
        cmsret = MoCACtl2_SetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS));
        if (cmsret != CMSRET_SUCCESS)
        {
            MoCACtl_Close(ctx);
            fprintf(stderr, "Error!  SetInitParms\n");
            return(-10);
        }
    }
        
    // ----------- Activate Settings   

    if (reset)
    {
        cmsret=MoCACtl2_ReInitialize( 
            ctx,
            &reInitParms, 
            reInitMask,
            NULL,
            0);
    }
    
    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Invalid password\n");
        MoCACtl_Close(ctx);
        return(-11);
    }

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}

