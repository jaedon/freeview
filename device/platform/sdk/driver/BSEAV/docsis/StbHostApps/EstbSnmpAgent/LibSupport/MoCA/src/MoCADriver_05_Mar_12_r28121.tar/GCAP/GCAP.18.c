#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

char *chipId = NULL;    // -i option

void showUsage()
{
    printf("Usage: GCAP.18 [-h]\n\
Report the Privacy Status and the password on the node's MoCA interface.\n\
\n\
Options:\n\
  -h   Display this help and exit\n");
}

int main(int argc, char **argv)
{
    int ret;
    
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_INITIALIZATION_PARMS init;
    void *ctx;
    
    // ----------- Parse parameters
    opterr = 0;
    
    while((ret = getopt(argc, argv, "hi:")) != -1) 
    {
        switch(ret)
        {
        case 'i':
            chipId = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Get info

    cmsret = MoCACtl2_GetInitParms(ctx, &init);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        return(-3);
    }

    printf("MoCA Privacy %s\n", (init.privacyEn == MoCA_PRIVACY_ENABLED) ? "enabled" : "disabled" );
    printf("MoCA Privacy Password %s\n", init.password );

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}


