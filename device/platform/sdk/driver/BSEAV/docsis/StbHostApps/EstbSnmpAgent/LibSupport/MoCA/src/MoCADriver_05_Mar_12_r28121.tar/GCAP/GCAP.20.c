#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>
#include <pthread.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

#include "GCAP_Common.h"

static char *chipId = NULL;    // -i option
static MAC_ADDRESS bcast_mac = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
static MAC_ADDRESS bcast_pqos_mac = {0x3f, 0x00, 0x00, 0x00, 0x00, 0x00};

struct query_rsp_cb_arg
{
   void * ctx;
   struct moca_pqos_query_response * rsp;
};

static void pqos_query_response_copy_cb(void *arg, struct moca_pqos_query_response *in)
{
   if (arg != NULL)
   {
      memcpy(((struct query_rsp_cb_arg *)arg)->rsp, in, 
         sizeof(struct moca_pqos_query_response));
   }

   pqos_callback_return(((struct query_rsp_cb_arg *)arg)->ctx);
}

static void pqos_create_response_cb(void *arg, struct moca_pqos_create_response *in)
{
   if (in->decision == 0x1)
      printf(" DECISION      : ");
   else
      printf("Error! ");

   printf("%s\n", moca_decision_string(in->decision));
   printf(" AVAILABLE BW : %d kbps\n", in->maxpeakdatarate);
   printf(" POST_STPS    : %d\n", in->totalstps);
   printf(" POST_TXPS    : %d\n", in->totaltxps);

   pqos_callback_return(arg);
}


static void pqos_update_response_cb(void *arg, struct moca_pqos_update_response *in)
{
   if (in->decision == 0x1)
      printf(" DECISION      : ");
   else
      printf("Error! ");

   printf("%s\n", moca_decision_string(in->decision));
   printf(" AVAILABLE BW : %d kbps\n", in->maxpeakdatarate);
   printf(" POST_STPS    : %d\n", in->totalstps);
   printf(" POST_TXPS    : %d\n", in->totaltxps);

   pqos_callback_return(arg);
}


void showUsage()
{
   printf("Usage: GCAP.20 <create/update> [peak=#] [psize=#] [burst=#]\n\
   [time=#] [flowtag=#] [flow_id=xx:xx:xx:xx:xx:xx] ig=yy:yy:yy:yy:yy:yy\n\
   eg=zz:zz:zz:zz:zz:zz [-h]\n\
\n\
Parameters:\n\
 create/update  Create PQoS flows or Update PQoS flows\n\
 peak           Peak date rate in kbps, default value is 1000 kbps\n\
 psize          Packet size in bytes, default value is 800 bytes\n\
 burst          Burst count, number of packets over which to measure\n\
                bursts, default value is 2 packets\n\
 time           Lease Time in seconds, infinite lease time if 0\n\
                default value is 0\n\
 flowtag        Flow Tag, default value is 0x0\n\
 flow_id        Flow ID in MAC address format, default value is 01:00:5e:00:01:00\n\
 ig             Ingress Node MAC address, must be supplied for creating a PQoS\n\
                flow in MAC address format(01:23:45:67:89:ab). Not required for\n\
                updating flows.\n\
 eg             Egress Node MAC address, must be supplied for creating a PQoS\n\
                flow in MAC address format(01:23:45:67:89:ab). Not required for\n\
                updating flows.\n\
\n\
 -h   Display this help and exit\n");
}

int main(int argc, char **argv)
{
   int ret;
   void *ctx;
   CmsRet cmsret = CMSRET_SUCCESS;
   int create = 0;
   MoCA_CREATE_PQOS_PARAMS pqosc ;
   MoCA_UPDATE_PQOS_PARAMS pqosu ;
   MoCA_STATUS status;
   UINT32 *pulValue ;
   MAC_ADDRESS *pmacAddr;
   MAC_ADDRESS macAddr;
   UBOOL8   igPresent = FALSE;
   UBOOL8   egPresent = FALSE;
   UBOOL8   igFound = FALSE;
   UBOOL8   egFound = FALSE;
   pthread_t pqos_thread;
   int   i;
   char * pStrVal;
   char * pStrOption;
   struct moca_gen_node_status gns;


   moca_gcap_init();

   // ----------- Parse parameters
   opterr = 0;

   if (argc < 2)
   {
     fprintf(stderr, "Error!  Missing parameter - create/update\n");
     return(-1);
   }

   while((ret = getopt(argc, argv, "hi:")) != -1) 
   {
      switch(ret) 
      {
         case 'i':
            chipId = optarg;
            break;
         case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-2);
            break;
         case 'h':            
         default:
            showUsage();
            return(0); 
      }
   }

   // ----------- Initialize

   ctx=MoCACtl_Open(chipId);

   if (!ctx)
   {
      fprintf(stderr, "Error!  Unable to connect to moca instance\n");
      return(-3);
   }

    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        MoCACtl_Close(ctx);
        return(-4);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        MoCACtl_Close(ctx);
        return(-5);
    }

   if (strcmp(argv[1], "create") == 0)
   {
      create = 1;
      memset (&pqosc, 0x00, sizeof(MoCA_CREATE_PQOS_PARAMS)) ;
      pqosc.peak_rate = MoCA_PQOS_PEAK_RATE_DEFAULT;
      pqosc.packet_size = MoCA_PQOS_PACKET_SIZE_DEFAULT;
      pqosc.burst_count = MoCA_PQOS_BURST_COUNT_DEFAULT;
      pqosc.lease_time = MoCA_PQOS_LEASE_TIME_DEFAULT;
      pqosc.vlan_id = MoCA_PQOS_VLAN_ID_DEFAULT;
      pqosc.vlan_prio = MoCA_PQOS_VLAN_PRIO_DEFAULT;
      pqosc.packet_da[0] = 0x01;
      pqosc.packet_da[1] = 0x00;
      pqosc.packet_da[2] = 0x5E;
      pqosc.packet_da[3] = 0x00;
      pqosc.packet_da[4] = 0x01;
      pqosc.packet_da[5] = 0x00;
   }
   else if (strcmp(argv[1], "update") == 0)
   {
      MoCA_QUERY_PQOS_PARAMS query;
      struct moca_pqos_query_response query_rsp;
      struct query_rsp_cb_arg query_cb_arg;
      
      create = 0;
      memset(&pqosu, 0x0, sizeof(MoCA_UPDATE_PQOS_PARAMS));

      // Find the flow_id and query the existing flow
      i = 2;
      while (i < argc)
      {
         pStrVal = NULL;
         
         if (!strcmp(argv[i], "flow_id"))
         {
            i++;
            pStrVal = argv[i];
         }
         else if ((strstr(argv[i], "flow_id") != NULL) &&
                  (strchr(argv[i], '=') != NULL))
         {
            pStrVal = strchr(argv[i], '=') + 1;
         }
         
         if (pStrVal != NULL)
         { 
            if ( ParseMacAddress ( pStrVal, &query.flow_id) != 0 )
            {
               fprintf(stderr,"Error!  Invalid parameter - flow_id\n");
               MoCACtl_Close(ctx);
               return(-6);
            }
            else
            {
               query_cb_arg.ctx = ctx;
               query_cb_arg.rsp = &query_rsp;

               memcpy(pqosu.flow_id, query.flow_id, sizeof(MAC_ADDRESS));

               cmsret = moca_start_event_loop(ctx, &pqos_thread);
               if (cmsret == CMSRET_SUCCESS)
               {
                  moca_register_pqos_query_response_cb(ctx, 
                     &pqos_query_response_copy_cb, &query_cb_arg);
                  cmsret = MoCACtl2_QueryPQoSFlow(ctx, &query);
                  if (cmsret == CMSRET_SUCCESS)
                  {
                     moca_wait_for_event(ctx, pqos_thread);
                  }
               }
            
               if ((query_rsp.responsecode == MOCA_L2_SUCCESS) &&
                   ((query_rsp.packetda[0] != 0) ||
                    (query_rsp.packetda[1] != 0) ||
                    (query_rsp.packetda[2] != 0) ||
                    (query_rsp.packetda[3] != 0) ||
                    (query_rsp.packetda[4] != 0) ||
                    (query_rsp.packetda[5] != 0)))
               {
                  pqosu.burst_count = query_rsp.tburstsize;
                  pqosu.flow_tag = query_rsp.flowtag;
                  if (query_rsp.leasetimeleft != 0xFFFFFFFF)
                     pqosu.lease_time = query_rsp.leasetimeleft;
                  pqosu.packet_size = query_rsp.tpacketsize;
                  pqosu.peak_rate = query_rsp.tpeakdatarate;
                  memcpy(pqosu.packet_da, query_rsp.packetda, 
                     sizeof(pqosu.packet_da));
               }
               else
               {
                  fprintf(stderr,"Error!  Flow ID does not exist\n");
                  MoCACtl_Close(ctx);
                  return(-7);
               }
            }
            break;
         }

         i++;
      }
   }
   else
   {
      fprintf(stderr,"Error!  Invalid parameter - %s\n",argv[1]);
      MoCACtl_Close(ctx);
      return(-8);
   }
        
   i = 2;
   while( cmsret == CMSRET_SUCCESS && (i < argc) )
   {
      pulValue = NULL;
      pmacAddr = NULL;
      pStrOption = argv[i];

      if( !strcmp(argv[i], "ig") ) 
      {
         igPresent = TRUE;
         pmacAddr = &pqosc.ingress_node;
         i++;
         pStrVal = argv[i];
      }
      else if (strstr(argv[i], "ig=") != NULL)
      {
         igPresent = TRUE;
         pmacAddr = &pqosc.ingress_node;
         pStrVal = strchr(argv[i], '=') + 1;
      }
      else if( !strcmp(argv[i], "eg") )
      {
         egPresent = TRUE;
         pmacAddr = &pqosc.egress_node;
         i++;
         pStrVal = argv[i];
      }
      else if (strstr(argv[i], "eg=") != NULL)
      {
         egPresent = TRUE;
         pmacAddr = &pqosc.egress_node;
         pStrVal = strchr(argv[i], '=') + 1;
      }
      else if( !strcmp(argv[i], "flow_id") )
      {
         // Will already be set for update operation
         pmacAddr = &pqosc.packet_da;
         i++;
         pStrVal = argv[i];
      }
      else if (strstr(argv[i], "flow_id=") != NULL)
      {
         pmacAddr = &pqosc.packet_da;
         pStrVal = strchr(argv[i], '=') + 1;
      }
      else if( !strcmp(argv[i], "peak") )
      {
         pulValue = create ? &pqosc.peak_rate : &pqosu.peak_rate;
         i++;
         pStrVal = argv[i];
      }
      else if (strstr(argv[i], "peak=") != NULL)
      {
         pulValue = create ? &pqosc.peak_rate : &pqosu.peak_rate;
         pStrVal = strchr(argv[i], '=') + 1;
      }
      else if( !strcmp(argv[i], "psize") )
      {
         pulValue = create ? &pqosc.packet_size : &pqosu.packet_size;
         i++;
         pStrVal = argv[i];
      }
      else if (strstr(argv[i], "psize=") != NULL)
      {
         pulValue = create ? &pqosc.packet_size : &pqosu.packet_size;
         pStrVal = strchr(argv[i], '=') + 1;
      }
      else if( !strcmp(argv[i], "burst") )
      {
         pulValue = create ? &pqosc.burst_count : &pqosu.burst_count;
         i++;
         pStrVal = argv[i];
      }
      else if (strstr(argv[i], "burst=") != NULL)
      {
         pulValue = create ? &pqosc.burst_count : &pqosu.burst_count;
         pStrVal = strchr(argv[i], '=') + 1;
      }
      else if( !strcmp(argv[i], "time") )
      {
         pulValue = create ? (UINT32 *)&pqosc.lease_time : (UINT32 *)&pqosu.lease_time;
         i++;
         pStrVal = argv[i];
      }
      else if (strstr(argv[i], "time=") != NULL)
      {
         pulValue = create ? (UINT32 *)&pqosc.lease_time : (UINT32 *)&pqosu.lease_time;
         pStrVal = strchr(argv[i], '=') + 1;
      }
      else if( !strcmp(argv[i], "flowtag") )
      {
         pulValue = create ? &pqosc.flow_tag : &pqosu.flow_tag;
         i++;
         pStrVal = argv[i];
      }
      else if (strstr(argv[i], "flowtag=") != NULL)
      {
         pulValue = create ? &pqosc.flow_tag : &pqosu.flow_tag;
         pStrVal = strchr(argv[i], '=') + 1;
      }
      else 
      {
         cmsret = CMSRET_INVALID_ARGUMENTS;

         fprintf(stderr,"Error!  Invalid parameter - %s\n",argv[i]);
         MoCACtl_Close(ctx);
         return(-9);
      }

      if ( pmacAddr )
      {
         if ( ParseMacAddress ( pStrVal, pmacAddr) != 0 )
         {
            fprintf( stderr, "Error!  Invalid parameter for option %s\n", 
               pStrOption ) ;
            cmsret = CMSRET_INVALID_ARGUMENTS ;
         }

         i++;
      }
      if ( pulValue )
      {
         /* Convert the value for a particular option to an integer. */
         char *pszEnd = NULL;

         if (pulValue)
            *pulValue = (long) strtol( pStrVal, &pszEnd, 0 ) ;

         if( *pszEnd != '\0' )
         {
            cmsret = CMSRET_INVALID_ARGUMENTS;
            fprintf( stderr, "Error!  Invalid parameter for option %s\n", 
               pStrOption ) ;
         }

         i++;
      }
   }

   if( cmsret == CMSRET_SUCCESS ) {

      if (create && !(egPresent && igPresent))
      {
         cmsret = CMSRET_INVALID_ARGUMENTS;
         fprintf( stderr, "Error!  Missing mandatory parameter eg or ig\n");
      }
      else if (create)
      {
         /* Make sure that the egress MAC addr exists on the network or 
            that it is the broadcast mac addr of 3f:00:00:00:00:00. */
         if ((memcmp(&bcast_mac, &pqosc.egress_node, sizeof(MAC_ADDRESS)) == 0) ||
             (memcmp(&bcast_pqos_mac, &pqosc.egress_node, sizeof(MAC_ADDRESS)) == 0))
         {
            egFound = TRUE;
         }

         for (i = 0; 
              status.generalStatus.connectedNodes; 
              status.generalStatus.connectedNodes >>= 1, i++)
         {
            if (status.generalStatus.connectedNodes & 0x1)
            {
               pmacAddr = NULL;
               
               if (status.generalStatus.nodeId == i) 
               {
                  pmacAddr = &status.miscStatus.macAddr;
               }
               else
               {
                  memset(&gns, 0, sizeof(gns));
                  if (moca_get_gen_node_status(ctx, i, &gns) == 0)
                  {
                     moca_u32_to_mac(macAddr, gns.eui_hi, gns.eui_lo);
                     pmacAddr = &macAddr;
                  }
               }

               if (pmacAddr != NULL)
               {
                  if(memcmp(pmacAddr, &pqosc.egress_node, sizeof(MAC_ADDRESS)) == 0)
                  {
                     egFound = TRUE;
                  }
                  if(memcmp(pmacAddr, &pqosc.ingress_node, sizeof(MAC_ADDRESS)) == 0)
                  {
                     igFound = TRUE;
                  }
               }
            }
         }

         if (!igFound)
         {
            fprintf( stderr, "Error!  No such ingress node MAC address\n");
            MoCACtl_Close(ctx);
            return(-10);
         }

         if (!egFound)
         {
            fprintf( stderr, "Error!  No such egress node MAC address\n");
            MoCACtl_Close(ctx);
            return(-11);
         }

         cmsret = moca_start_event_loop(ctx, &pqos_thread);
         if (cmsret == CMSRET_SUCCESS)
         {
            moca_register_pqos_create_response_cb(ctx, &pqos_create_response_cb, ctx);
            cmsret = MoCACtl2_CreatePQoSFlow(ctx, &pqosc);
            if (cmsret == CMSRET_SUCCESS)
               moca_wait_for_event(ctx, pqos_thread);
            else if (cmsret == CMSRET_INVALID_ARGUMENTS)
               fprintf( stderr, "Error!  Invalid ingress node ID\n");
            else if (cmsret == CMSRET_INTERNAL_ERROR)
               fprintf( stderr, "Error!  Unable to create\n");
         }
      }
      else
      {
         cmsret = moca_start_event_loop(ctx, &pqos_thread);
         if (cmsret == CMSRET_SUCCESS)
         {
            moca_register_pqos_update_response_cb(ctx, &pqos_update_response_cb, ctx);
            cmsret = MoCACtl2_UpdatePQoSFlow(ctx, &pqosu);
            if (cmsret == CMSRET_SUCCESS)
               moca_wait_for_event(ctx, pqos_thread);
         }
      }
   }


   // ----------- Finish
   if (cmsret == CMSRET_SUCCESS)
   {
      pthread_join(pqos_thread, NULL); /* Allow event loop to be cancelled */
   }

   MoCACtl_Close(ctx);

   return(0);
}
