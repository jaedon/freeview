#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>
#include <pthread.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

struct pqos_list_cb_arg {
   void * ctx;
   uint32_t flow_id[32][2];
};

static char *chipId = NULL;    // -i option

void showUsage()
{
    printf("Usage: GCAP.21 <flow ID> [-h]\n\
Delete PQoS flow on any node in the network.\n\
\n\
Options:\n\
 <flow ID>  Flow ID in MAC Address format (default 01:00:5e:00:01:00)\n\
  -a   Delete all PQoS flows in the network\n\
  -h   Display this help and exit\n");
}

static void pqos_delete_response_cb(void *arg, struct moca_pqos_delete_response *in)
{
   if (in->responsecode != MOCA_L2_SUCCESS)
      printf("Error! %s\n", moca_l2_error_name(in->responsecode));

   pqos_callback_return(arg);
}


static void pqos_list_response_cb(void *arg, struct moca_pqos_list_response *in)
{
   int i, j;
   uint32_t *flowid;
   struct pqos_list_cb_arg * parg = (struct pqos_list_cb_arg *)arg;

   flowid = &in->flowid0_hi;
   j = 0;
   
   for (i = 0; i < 32; i++)
   {
      if (flowid[i*2] != 0 || flowid[i*2+1] != 0)
      {
         parg->flow_id[j][0] = flowid[i*2];
         parg->flow_id[j][1] = flowid[i*2+1];
         j++;
      }
   }

   pqos_callback_return(parg->ctx);
}




int main(int argc, char **argv)
{
   int ret;
   void *ctx;
   CmsRet cmsret = CMSRET_SUCCESS;
   MoCA_DELETE_PQOS_PARAMS pqos_del ;
   MoCA_LIST_PQOS_PARAMS pqos_list ;
   pthread_t pqos_thread;
   MoCA_STATUS status;
   int delete_all = 0;
   int i, j;
   MAC_ADDRESS *pmacAddr;
   MAC_ADDRESS macAddr;
   MoCA_NODE_STATUS_ENTRY node_status;
   struct pqos_list_cb_arg pqos_list_arg;
   unsigned int delcount = 0;
   unsigned int flow_id_hi;
   unsigned int flow_id_lo;
   
   memset (&pqos_del, 0x00, sizeof(MoCA_DELETE_PQOS_PARAMS)) ;
   memset (&pqos_list, 0x00, sizeof(MoCA_LIST_PQOS_PARAMS)) ;

   moca_gcap_init();

   // ----------- Parse parameters
   opterr = 0;

   while((ret = getopt(argc, argv, "hai:")) != -1) 
   {
      switch(ret) 
      {
      case 'a':
         delete_all = 1;
         break;
      case 'i':
         chipId = optarg;
         break;
      case '?':
         fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
         return(-1);
         break;
      case 'h':            
      default:
         showUsage();
         return(0); 
      }
   }


   if ((argc < 2) ||
       (ParseMacAddress ( argv[1], &pqos_del.flow_id) != 0 ))
   {
      // Use the default value
      pqos_del.flow_id[0] = 0x01;
      pqos_del.flow_id[1] = 0x00;
      pqos_del.flow_id[2] = 0x5E;
      pqos_del.flow_id[3] = 0x00;
      pqos_del.flow_id[4] = 0x01;
      pqos_del.flow_id[5] = 0x00;      
   }
   
   moca_mac_to_u32(&flow_id_hi, &flow_id_lo, pqos_del.flow_id);

   // ----------- Initialize

   ctx=MoCACtl_Open(chipId);

   if (!ctx)
   {
      fprintf(stderr, "Error!  Unable to connect to moca instance\n");
      return(-2);
   }

   cmsret = MoCACtl2_GetStatus(ctx, &status);

   if (cmsret != CMSRET_SUCCESS)
   {
      fprintf(stderr, "Error!  Mocactl failure\n");
      MoCACtl_Close(ctx);
      return(-3);
   }

   if (status.generalStatus.linkStatus != MoCA_LINK_UP)
   {
      fprintf(stderr, "Error! No Link\n");
      MoCACtl_Close(ctx);
      return(-4);
   }

   /* Get the number of total nodes and loop through them all */
   if (cmsret == CMSRET_SUCCESS)
   {
      moca_register_pqos_list_response_cb(ctx, &pqos_list_response_cb, ctx);
 
      for (i = 0; 
           status.generalStatus.connectedNodes; 
           status.generalStatus.connectedNodes >>= 1, i++)
      {
         pmacAddr = NULL;
         if (status.generalStatus.connectedNodes & 0x1)
         {
            if (status.generalStatus.nodeId == i) 
            {
               pmacAddr = &status.miscStatus.macAddr;
            }
            else
            {
               node_status.nodeId = i;
               cmsret = MoCACtl2_GetNodeStatus(ctx, &node_status);
               if (cmsret == CMSRET_SUCCESS)
               {
                  moca_u32_to_mac(macAddr, node_status.eui[0], node_status.eui[1]);
                  pmacAddr = &macAddr;
               }
            }
         }
 
         if (pmacAddr != NULL)
         {
            memset(&pqos_list, 0x00, sizeof(MoCA_LIST_PQOS_PARAMS));
            memcpy(pqos_list.ingress_mac, pmacAddr, sizeof(MAC_ADDRESS));
            ret = moca_start_event_loop(ctx, &pqos_thread);
            if (ret == 0) {
               memset(&pqos_list_arg, 0, sizeof(pqos_list_arg));
               pqos_list_arg.ctx = ctx;
               moca_register_pqos_list_response_cb(ctx, &pqos_list_response_cb, &pqos_list_arg);
               cmsret = MoCACtl2_ListPQoSFlow(ctx, &pqos_list);
               if (cmsret == CMSRET_SUCCESS)
               {
                  moca_wait_for_event(ctx, pqos_thread);
 
                  for (j = 0; j < 32; j++)
                  {
                     if (pqos_list_arg.flow_id[j][0] == 0 && 
                         pqos_list_arg.flow_id[j][1] == 0)
                     {
                        break;
                     }
                     else
                    {
                        if (((pqos_list_arg.flow_id[j][0] == flow_id_hi) && 
                             (pqos_list_arg.flow_id[j][1] == flow_id_lo)) ||
                            (delete_all==1))
                        {
                           delcount++;
                           memset (&pqos_del, 0x00, sizeof(MoCA_DELETE_PQOS_PARAMS)) ;
                           moca_u32_to_mac(pqos_del.flow_id, 
                              pqos_list_arg.flow_id[j][0], 
                              pqos_list_arg.flow_id[j][1]);
                           cmsret = moca_start_event_loop(ctx, &pqos_thread);
                           if (cmsret == CMSRET_SUCCESS)
                           {
                              moca_register_pqos_delete_response_cb(ctx, &pqos_delete_response_cb, ctx);
                              cmsret = MoCACtl2_DeletePQoSFlow(ctx, &pqos_del);
                              if (cmsret == CMSRET_SUCCESS)
                              {
                                 moca_wait_for_event(ctx, pqos_thread);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   if ((delcount == 0) && (delete_all != 1))
   {
      fprintf(stderr, "Error! DECISION_FLOW_NOT_FOUND\n");
   }
   
   // ----------- Finish
   if (cmsret == CMSRET_SUCCESS)
   {
      pthread_join(pqos_thread, NULL); /* Allow event loop to be cancelled */
   }

   MoCACtl_Close(ctx);

   return(0);
}
