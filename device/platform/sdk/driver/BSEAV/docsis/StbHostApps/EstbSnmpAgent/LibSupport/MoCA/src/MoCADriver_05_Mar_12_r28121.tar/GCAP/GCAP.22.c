#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>
#include <pthread.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

static char *chipId = NULL;    // -i option

struct list_rsp_cb_arg
{
   void * ctx;
   uint32_t * count;
};


void showUsage()
{
    printf("Usage: GCAP.22 <ingress node> [-a] [-h]\n\
Display all existing PQoS Flows on any node in the network\n\
for which the node is the ingress node.\n\
\n\
Options:\n\
 <ingress node>  Ingress node MAC Address (12:34:56:78:9a:bc)\n\
                 must be supplied unless -a option is used\n\
  -a   Display all existing PQoS flows on all nodes\n\
  -h   Display this help and exit\n");
}

static void pqos_list_response_cb(void *arg, struct moca_pqos_list_response *in)
{
   int i;
   uint32_t *flowid;
   uint32_t number_of_flows = 0;

   flowid = &in->flowid0_hi;

   for (i = 0; i < 32; i++)
   {
      if (flowid[i*2] != 0 || flowid[i*2+1] != 0)
      {
         number_of_flows++;
      }
   }

   if (((struct list_rsp_cb_arg *)arg)->count != NULL)
   {
      *(((struct list_rsp_cb_arg *)arg)->count) += number_of_flows;

      printf("   Flows:  %u\n", number_of_flows);

      for (i = 0; i < 32; i++)
      {
         if (flowid[i*2] != 0 || flowid[i*2+1] != 0)
         {
            printf("   Flow_ID: %02x:%02x:%02x:%02x:%02x:%02x\n", 
               (flowid[i*2] >> 24) & 0xFF,
               (flowid[i*2] >> 16) & 0xFF,
               (flowid[i*2] >>  8) & 0xFF,
               (flowid[i*2] >>  0) & 0xFF,
               (flowid[i*2+1] >> 24) & 0xFF,
               (flowid[i*2+1] >> 16) & 0xFF);
         }
      }
   }
   else
   {
      printf("   Number of Flows:  %u\n", number_of_flows);
      number_of_flows = 0;
      for (i = 0; i < 32; i++)
      {
         if (flowid[i*2] != 0 || flowid[i*2+1] != 0)
         {
            printf("   Flow_ID (%2i):     %02x:%02x:%02x:%02x:%02x:%02x\n", 
               number_of_flows, 
               (flowid[i*2] >> 24) & 0xFF,
               (flowid[i*2] >> 16) & 0xFF,
               (flowid[i*2] >>  8) & 0xFF,
               (flowid[i*2] >>  0) & 0xFF,
               (flowid[i*2+1] >> 24) & 0xFF,
               (flowid[i*2+1] >> 16) & 0xFF);
            number_of_flows++;
         }
      }
   }
   pqos_callback_return((((struct list_rsp_cb_arg *)arg)->ctx));
}




int main(int argc, char **argv)
{
   int ret;
   void *ctx;
   CmsRet cmsret = CMSRET_SUCCESS;
   MoCA_LIST_PQOS_PARAMS pqos ;
   MAC_ADDRESS *pmacAddr;
   MAC_ADDRESS macAddr;
   struct list_rsp_cb_arg cb_arg;
   uint32_t total_flows = 0;
   int display_all = 0;
   MoCA_STATUS status;
   MoCA_NODE_STATUS_ENTRY node_status;
   int i;
   pthread_t pqos_thread;


   moca_gcap_init();

   // ----------- Parse parameters
   opterr = 0;

   while((ret = getopt(argc, argv, "ahi:")) != -1) 
   {
      switch(ret) 
      {
      case 'i':
         chipId = optarg;
         break;
      case 'a':
         display_all = 1;
         break;
      case '?':
         fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
         return(-1);
         break;
      case 'h':            
      default:
         showUsage();
         return(0); 
      }
   }

   memset (&pqos, 0x00, sizeof(MoCA_LIST_PQOS_PARAMS)) ;

   if (display_all == 0)
   {
      if (argc >= 2)
      {
         if ( ParseMacAddress ( argv[ 1 ], &pqos.ingress_mac) != 0 )
         {
            fprintf( stderr, "Error!  invalid parameter for ingress node\n");
            return(-1);
         }
      }
      else
      {
         fprintf( stderr, "Error!  Missing parameter\n") ;
         return(-2);
      }
   }

   // ----------- Initialize

   ctx=MoCACtl_Open(chipId);

   if (!ctx)
   {
      fprintf(stderr, "Error!  Unable to connect to moca instance\n");
      return(-3);
   }

    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        MoCACtl_Close(ctx);
        return(-4);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        MoCACtl_Close(ctx);
        return(-5);
    }


   if (display_all == 0)
   {
      printf("Ingress Node MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n",
         pqos.ingress_mac[0], pqos.ingress_mac[1], pqos.ingress_mac[2],
         pqos.ingress_mac[3], pqos.ingress_mac[4], pqos.ingress_mac[5]);

      cmsret = moca_start_event_loop(ctx, &pqos_thread);
      if (cmsret == CMSRET_SUCCESS)
      {
         cb_arg.ctx = ctx;
         cb_arg.count = NULL;
         moca_register_pqos_list_response_cb(ctx, &pqos_list_response_cb, (void *)&cb_arg);
         cmsret = MoCACtl2_ListPQoSFlow(ctx, &pqos);
         if (cmsret == CMSRET_SUCCESS)
         {
            moca_wait_for_event(ctx, pqos_thread);
         }
         else
         {
            fprintf( stderr, "Error!  No such ingress node MAC address\n");
         }
      }
   }
   else if (display_all == 1)
   {
      /* Get the number of total nodes and loop through them all */
      if (cmsret == CMSRET_SUCCESS)
      {
         cb_arg.ctx = ctx;
         cb_arg.count = &total_flows;
         moca_register_pqos_list_response_cb(ctx, &pqos_list_response_cb, (void *)&cb_arg);

         for (i = 0; 
              status.generalStatus.connectedNodes; 
              status.generalStatus.connectedNodes >>= 1, i++)
         {
            pmacAddr = NULL;
            if (status.generalStatus.connectedNodes & 0x1)
            {
               if (status.generalStatus.nodeId == i) 
               {
                  pmacAddr = &status.miscStatus.macAddr;
               }
               else
               {
                  node_status.nodeId = i;
                  cmsret = MoCACtl2_GetNodeStatus(ctx, &node_status);
                  if (cmsret == CMSRET_SUCCESS)
                  {
                     moca_u32_to_mac(macAddr, node_status.eui[0], node_status.eui[1]);
                     pmacAddr = &macAddr;
                  }
               }
            }

            if (pmacAddr != NULL)
            {
               pqos.node_id = i;
               printf("Ingress Node MAC Address: %02x:%02x:%02x:%02x:%02x:%02x",
                  (*pmacAddr)[0], (*pmacAddr)[1], (*pmacAddr)[2],
                  (*pmacAddr)[3], (*pmacAddr)[4], (*pmacAddr)[5]);

               ret = moca_start_event_loop(ctx, &pqos_thread);
               if (ret == 0) {
                  moca_register_pqos_list_response_cb(ctx, &pqos_list_response_cb, (void *)&cb_arg);
                  cmsret = MoCACtl2_ListPQoSFlow(ctx, &pqos);
                  if (cmsret == CMSRET_SUCCESS)
                  {
                     moca_wait_for_event(ctx, pqos_thread);
                  }
                  else
                  {
                     fprintf( stderr, "\nError!  Unable to list Node\n");
                  }
                  
               }
            }
         }

         printf("\nTotal existing Flows:  %u\n", total_flows);
      }
   }
     
   // ----------- Finish
   if (cmsret == CMSRET_SUCCESS)
   {
      pthread_join(pqos_thread, NULL); /* Allow event loop to be cancelled */
   }

   MoCACtl_Close(ctx);

   return(0);
}
