#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>
#include <pthread.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

static char *chipId = NULL;    // -i option

void showUsage()
{
    printf("Usage: GCAP.23 <flow ID> [-h]\n\
Query any PQoS flow in the network and display TSPEC parameters \n\
and flow attributes of the flow..\n\
\n\
Options:\n\
 <flow ID>  Flow ID in MAC Address format (default 01:00:5e:00:01:00)\n\
  -h   Display this help and exit\n");
}

static void pqos_query_response_print_cb(void *arg, struct moca_pqos_query_response *in)
{
   MAC_ADDRESS ingr_mac = {0};
   MAC_ADDRESS egr_mac;
   struct moca_gen_status gs;
   struct moca_gen_node_status gsn;
   struct moca_init_time init;
   int egr_mac_found = 0, ingr_mac_found = 0;
   int ret;
   
   /* get node bitmask */
   moca_get_gen_status(arg, &gs);

   if((gs.node_id == in->ingressnodeid) ||
      (gs.node_id == in->egressnodeid)) 
   {
      moca_get_init_time(arg, &init);
      if (gs.node_id == in->ingressnodeid)
      {
         ingr_mac_found = 1;
         moca_u32_to_mac(ingr_mac, init.mac_addr_hi, init.mac_addr_lo);
      }
      else
      {
         egr_mac_found = 1;
         moca_u32_to_mac(egr_mac, init.mac_addr_hi, init.mac_addr_lo);
      }
   }
   if (ingr_mac_found == 0)
   {
      ret = moca_get_gen_node_status(arg, in->ingressnodeid, &gsn);
      if (ret == 0)
         moca_u32_to_mac(ingr_mac, gsn.eui_hi, gsn.eui_lo);
      else
         printf("Error!  moca_get_gen_node_status returned %d for ingr node %d\n",
            ret, in->ingressnodeid);
   }
   if (egr_mac_found == 0)
   {
      /* check for broadcast node id */
      if (in->egressnodeid == 0x3f)
         memset(egr_mac, 0xff, sizeof(MAC_ADDRESS));
      else
      {
         ret = moca_get_gen_node_status(arg, in->egressnodeid, &gsn);
         if (ret == 0)
            moca_u32_to_mac(egr_mac, gsn.eui_hi, gsn.eui_lo);
         else
            printf("Error!  moca_get_gen_node_status returned %d for egr node %d\n",
               ret, in->egressnodeid);
      }
   }


   if ((in->packetda[0] != 0) ||
       (in->packetda[1] != 0) ||
       (in->packetda[2] != 0) ||
       (in->packetda[3] != 0) ||
       (in->packetda[4] != 0) ||
       (in->packetda[5] != 0))
   {
      printf(" FLOW_ID          : %02x:%02x:%02x:%02x:%02x:%02x\n", 
         in->flowid[0], in->flowid[1], in->flowid[2],
         in->flowid[3], in->flowid[4], in->flowid[5]);
      printf(" INGRESS_NODE     : %02x:%02x:%02x:%02x:%02x:%02x\n", 
         ingr_mac[0], ingr_mac[1], ingr_mac[2], ingr_mac[3], 
         ingr_mac[4], ingr_mac[5]);
      printf(" EGRESS_NODE      : %02x:%02x:%02x:%02x:%02x:%02x\n", 
         egr_mac[0], egr_mac[1], egr_mac[2], egr_mac[3], 
         egr_mac[4], egr_mac[5]);
      printf(" T_PACKET_SIZE    : %d\n", in->tpacketsize);
      printf(" T_PEAK_DATA_RATE : %d kbps\n", in->tpeakdatarate);
      printf(" T_BURST_SIZE     : %d\n", in->tburstsize);
      printf(" T_LEASE_TIME     : %d\n", in->tleasetime);
      printf(" FLOW_TAG         : 0x%08x\n", in->flowtag);
   }
   else
   {
      printf("Error!  Flow does not exist\n");
   }

   pqos_callback_return(arg);
}


int main(int argc, char **argv)
{
   int ret;
   void *ctx;
   CmsRet cmsret = CMSRET_SUCCESS;
   MoCA_QUERY_PQOS_PARAMS pqos ;
   pthread_t pqos_thread;
   MoCA_STATUS status;
   
   memset (&pqos, 0x00, sizeof(MoCA_QUERY_PQOS_PARAMS)) ;

   moca_gcap_init();

   // ----------- Parse parameters
   opterr = 0;

   while((ret = getopt(argc, argv, "hi:")) != -1) 
   {
      switch(ret) 
      {
      case 'i':
         chipId = optarg;
         break;
      case '?':
         fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
         return(-1);
         break;
      case 'h':            
      default:
         showUsage();
         return(0); 
      }
   }

   if ((argc < 2) || (ParseMacAddress ( argv[1], &pqos.flow_id) != 0) )
   {
      // Use the default value
      pqos.flow_id[0] = 0x01;
      pqos.flow_id[1] = 0x00;
      pqos.flow_id[2] = 0x5E;
      pqos.flow_id[3] = 0x00;
      pqos.flow_id[4] = 0x01;
      pqos.flow_id[5] = 0x00;
   }
 

   // ----------- Initialize

   ctx=MoCACtl_Open(chipId);

   if (!ctx)
   {
      fprintf(stderr, "Error!  Unable to connect to moca instance\n");
      return(-2);
   }

    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        MoCACtl_Close(ctx);
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        MoCACtl_Close(ctx);
        return(-4);
    }


   cmsret = moca_start_event_loop(ctx, &pqos_thread);
   if (cmsret == CMSRET_SUCCESS)
   {
      moca_register_pqos_query_response_cb(ctx, &pqos_query_response_print_cb, ctx);
      cmsret = MoCACtl2_QueryPQoSFlow(ctx, &pqos);
      if (cmsret == CMSRET_SUCCESS)
      {
         moca_wait_for_event(ctx, pqos_thread);
      }
   }
     

   // ----------- Finish
   if (cmsret == CMSRET_SUCCESS)
   {
      pthread_join(pqos_thread, NULL); /* Allow event loop to be cancelled */
   }

   MoCACtl_Close(ctx);

   return(0);
}
