#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static char *chipId = NULL;    // -i option

void showUsage()
{
    printf("Usage: GCAP.24 [-r] [-h]\n\
Report packet aggregation statistics.\n\
\n\
Options:\n\
  -r   Reset aggregation statistics\n\
  -h   Display this help and exit\n");
}



int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_STATUS status;
    MoCA_STATISTICS stats;
    int reset_stats = 0;
    int count;

    // ----------- Parse parameters

    opterr = 0;
    
    while((ret = getopt(argc, argv, "rhi:")) != -1) 
    {
        switch(ret)
        {
        case 'r':
            reset_stats = 1;
            break;
        case 'i':
            chipId = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Obtain statistics 

    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        MoCACtl_Close(ctx);
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        MoCACtl_Close(ctx);
        return(-4);
    }
    
    cmsret = MoCACtl2_GetStatistics(ctx, &stats, reset_stats);
    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        MoCACtl_Close(ctx);
        return(-5);
    }

    // ----------- Output Data   

    printf ("Aggregation Statistics:\n\n");
    printf ("ECL Stats:\n");
    printf ("TX Pkts        : %8u   ", 
      (stats.generalStats.inUcPkts + stats.generalStats.inUnKnownPkts +
       stats.generalStats.inMcPkts + stats.generalStats.inBcPkts) ) ;
    printf ("RX Pkts        : %8u   \n\n", 
      (stats.generalStats.outUcPkts + stats.generalStats.outBcPkts) ) ;
    printf ("Aggregation Stats:\n\n");

    for (count = 0; count < 10; count++) {
       if (count == 0)
       {
          printf ("TX Pkts ( non - aggr): %8u   ", stats.generalStats.aggrPktStatsTx[count]) ;
          printf ("RX Pkts ( non - aggr): %8u\n", stats.generalStats.aggrPktStatsRx[count]) ;
       }
       else
       {
          printf ("TX Pkts (%2u-pkt aggr): %8u   ", (count+1), stats.generalStats.aggrPktStatsTx[count]*(count+1)) ;
          printf ("RX Pkts (%2u-pkt aggr): %8u\n", (count+1), stats.generalStats.aggrPktStatsRx[count]*(count+1)) ;
       }
    }
    
    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}

