#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>
#include <pthread.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

static char *chipId = NULL;    // -i option
static char *nodeMac = NULL;   // -s option

struct list_rsp_cb_arg
{
   void * ctx;
   uint32_t * count;
};


void showUsage()
{
    printf("Usage: GCAP.25 [-s node_addr] [-h]\n\
Initiate an FMR request and report back OFDMb values received \n\
in response to the FMR request.\n\
\n\
Options:\n\
 [-s node_addr] Specific node MAC Address (12:34:56:78:9a:bc)\n\
                If not specified, all nodes information will be\n\
                displayed.\n\
  -h   Display this help and exit\n");
}


static int mocacli_list_active_nodes( void * ctx )
{
   int i;
   struct moca_gen_status gs;
   struct moca_gen_node_status gsn;
   struct moca_init_time init;
   MAC_ADDRESS  mac;

   /* get node bitmask */
   moca_get_gen_status(ctx, &gs);

   /* get status entry for each node */
   printf("Node ID   MAC Addr\n");
   for(i = 0; i < MOCA_MAX_NODES; i++) {
      if(! (gs.connected_nodes & (1 << i)))
         continue;
      if(gs.node_id == i) 
      {
         moca_get_init_time(ctx, &init);
         moca_u32_to_mac(mac, init.mac_addr_hi, init.mac_addr_lo);
         printf ("%2i        %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\n",
               i, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
      }
      else
      {
         moca_get_gen_node_status(ctx, i, &gsn);
         moca_u32_to_mac(mac, gsn.eui_hi,gsn.eui_lo);
         printf ("%2i        %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\n",
               i, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

      }
   }

   printf("----------------------------\n");
   printf("Management GN Node ID = %u\n", gs.node_id);

   return 0;
}

static uint16_t fmrinfo[MOCA_MAX_NODES][MOCA_MAX_NODES];

static void fmr_response_cb(void *arg, struct moca_fmr_response *in)
{
   int i, j;
   uint32_t *responded_node;
   uint16_t *fmrinfo_node;

   for (i = 0; i < 9; i++)
   {
      responded_node = (void *)&in->responded_node_0 + ((sizeof(in->responded_node_0)*i) + (sizeof(in->fmrinfo_node_0)*i));
      fmrinfo_node = (uint16_t *)(responded_node + 1);
      if (*responded_node != 0xFF)
      {
         for (j = 0; j < MOCA_MAX_NODES; j++ )
         {
            fmrinfo[*responded_node][j] = fmrinfo_node[j];
         }
      }
   }

   pqos_callback_return(arg);
}

static void print_fmr_info(void * ctx, uint32_t connectedNodes)
{
   int i, j;

   printf("----------------------------\n");
   mocacli_list_active_nodes(ctx);

   printf("OFDMb/GAP\n");
   printf("Tx\\Rx     0        1        2        3        4        5        6        7");
   for (i = 0; i < MOCA_MAX_NODES; i++)
   {
      if (connectedNodes & (1 << i))
      {
         printf("\n  %2d", i);
         for (j = 0; j < 8; j++ )
         {
            printf("  %4d/%-2d", fmrinfo[i][j] & 0x7FF, fmrinfo[i][j] >> 11);
         }
      }
   }

   printf("\n          8        9       10       11       12       13        14      15");
   for (i = 0; i < MOCA_MAX_NODES; i++)
   {
      if (connectedNodes & (1 << i))
      {
         printf("\n  %2d", i);
         for (j = 8; j < 16; j++ )
         {
            printf("  %4d/%-2d", fmrinfo[i][j] & 0x7FF, fmrinfo[i][j] >> 11);
         }
      }
   }
   printf("\n");

}


int main(int argc, char **argv)
{
   int                           ret;
   void                          *ctx;
   CmsRet                        cmsret = CMSRET_SUCCESS;
   pthread_t                     event_thread;
   MoCA_STATUS                   status;
   MAC_ADDRESS                   mac;
   uint32_t                      mac_hi_lo[2] = {0, 0};
   struct moca_gen_node_status   node_status;
   struct moca_fmr_request       req;
   uint32_t                      fmr_nodemask = 0;
   int                           i;

   moca_gcap_init();

   // ----------- Parse parameters
   opterr = 0;
 
   while((ret = getopt(argc, argv, "hi:s:")) != -1) 
   {
      switch(ret) 
      {
      case 'i':
         chipId = optarg;
         break;
      case 's':
         nodeMac = optarg;
         break;
      case '?':
         fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
         return(-1);
         break;
      case 'h':            
      default:
         showUsage();
         return(0); 
      }
   }

   memset (&fmrinfo, 0x00, sizeof(fmrinfo));

   if (nodeMac != NULL)
   {
      if ( ParseMacAddress ( nodeMac, &mac) != 0 )
      {        
         fprintf( stderr, "Error!  invalid parameter for node_addr\n");
         return(-1);
      }
      
      moca_mac_to_u32(&mac_hi_lo[0], &mac_hi_lo[1], mac);
   }
   else if ((argc >= 2) && (argv[argc-2][0] != '-'))
   {
      fprintf( stderr, "Error!  No option\n");
      return(-1);
   }

   // ----------- Initialize

   ctx = MoCACtl_Open(chipId);

   if (!ctx)
   {
      fprintf(stderr, "Error!  Unable to connect to moca instance\n");
      return(-2);
   }

    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        MoCACtl_Close(ctx);
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        MoCACtl_Close(ctx);
        return(-4);
    }


   if ((mac_hi_lo[0] == 0) && (mac_hi_lo[1] == 0))
   {
      // Do FMR for all addresses
      fmr_nodemask = status.generalStatus.connectedNodes;
   }
   else
   {
      /* get status entry for each node */
      for(i = 0; i < MOCA_MAX_NODES; i++) 
      {        
         if(! (status.generalStatus.connectedNodes & (1 << i)))
             continue;
         ret = moca_get_gen_node_status(ctx, i, (struct moca_gen_node_status *)&node_status);
         moca_u32_to_mac(mac, node_status.eui_hi, node_status.eui_lo);
         if ((ret == 0) &&           
             (node_status.eui_hi == mac_hi_lo[0]) &&
             (node_status.eui_lo == mac_hi_lo[1]) &&
             ((node_status.protocol_support >> 24) == MoCA_VERSION_11))
         {           
             fmr_nodemask = (1 << i);
             break;
         }
      }  
   }

   /* Might have to get the FMR data in two reads since only 9 entries 
      can be returned at a time */
   if (fmr_nodemask & 0xff)
   {
      cmsret = moca_start_event_loop(ctx, &event_thread);

      if (cmsret == CMSRET_SUCCESS) 
      {
         moca_register_fmr_response_cb(ctx, &fmr_response_cb, ctx);

         memset(&req, 0, sizeof(req));
         req.wave0Nodemask = fmr_nodemask & 0xff;
         cmsret = moca_set_fmr_request(ctx, &req);

         if (cmsret == 0) {
            moca_wait_for_event(ctx, event_thread);
            cmsret = CMSRET_SUCCESS;
         }
         else {
             fprintf( stderr, "Error!  Unable to get FMR\n" ) ;
             MoCACtl_Close(ctx);
             return(-5);
         }
      }

      // ----------- Finish
      if (cmsret == CMSRET_SUCCESS)
      {
         pthread_join(event_thread, NULL); /* Allow event loop to be cancelled */
      }
   }

   if (fmr_nodemask & 0xff00)
   {
      cmsret = moca_start_event_loop(ctx, &event_thread);

      if (cmsret == CMSRET_SUCCESS) 
      {
         moca_register_fmr_response_cb(ctx, &fmr_response_cb, ctx);

         memset(&req, 0, sizeof(req));
         req.wave0Nodemask = fmr_nodemask & 0xff00;
         cmsret = moca_set_fmr_request(ctx, &req);

         if (cmsret == 0) {
            moca_wait_for_event(ctx, event_thread);
            cmsret = CMSRET_SUCCESS;
         }
         else {
             fprintf( stderr, "Error!  Unable to get FMR\n" ) ;
             MoCACtl_Close(ctx);
             return(-6);
         }
      }

      // ----------- Finish
      if (cmsret == CMSRET_SUCCESS)
      {
         pthread_join(event_thread, NULL); /* Allow event loop to be cancelled */
      }
   }

   print_fmr_info(ctx, fmr_nodemask);

   MoCACtl_Close(ctx);

   return(0);
}
