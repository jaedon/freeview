#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

static char *chipId = NULL;    // -i option

void showUsage()
{
    printf("Usage: GCAP.27 <node_addr> [-h]\n\
Trigger Out-of-Order LMO requests for a specified node in the network.\n\
\n\
Options:\n\
 <node_addr>  Node MAC Address format for which Out-of-Order LMO\n\
              is requested (01:23:45:67:89:ab)\n\
  -h   Display this help and exit\n");
}


int main(int argc, char **argv)
{
   int ret;
   void *ctx;
   CmsRet cmsret = CMSRET_SUCCESS;
   MAC_ADDRESS  mac_addr;
   UINT32 node_id;
   MoCA_STATUS status;
   MoCA_CONFIG_PARAMS config;

   // ----------- Parse parameters
   opterr = 0;
   
   while((ret = getopt(argc, argv, "hi:")) != -1) 
   {
      switch(ret) 
      {
      case 'i':
         chipId = optarg;
         break;
      case '?':
         fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
         return(-1);
         break;
      case 'h':            
      default:
         showUsage();
         return(0); 
      }
   }


   if (argc < 2)
   {
      fprintf(stderr, "Error!  Missing parameter node_addr\n");
      return(-2);
   }
   else if(ParseMacAddress(argv[1], &mac_addr) != 0)
   {
      fprintf(stderr, "Error!  Invalid node_addr\n");
      return(-3);
   }


   // ----------- Initialize

   ctx=MoCACtl_Open(chipId);

   if (!ctx)
   {
      fprintf(stderr, "Error!  Unable to connect to moca instance\n");
      return(-4);
   }

    cmsret = MoCACtl2_GetStatus(ctx, &status);

   if (cmsret != CMSRET_SUCCESS)
   {
      fprintf(stderr, "Error!  Mocactl failure\n");
      MoCACtl_Close(ctx);
      return(-5);
   }

   if (status.generalStatus.linkStatus != MoCA_LINK_UP)
   {
      fprintf(stderr, "Error! No Link\n");
      MoCACtl_Close(ctx);
      return(-6);
   }
    
   ret = moca_mac_to_node_id(ctx, &mac_addr, &node_id);
   if (ret == 0)
   {
      memset(&config, 0x0, sizeof(MoCA_CONFIG_PARAMS));
      config.outOfOrderLmo = node_id;
      cmsret = MoCACtl2_SetCfg(ctx, &config, MoCA_CFG_PARAM_OUT_OF_ORDER_LMO_MASK);
      if (cmsret != CMSRET_SUCCESS)
      {
         fprintf(stderr, "Error!  Mocactl failure\n");
         MoCACtl_Close(ctx);
         return(-7);
      }
   }
   else
   {
      fprintf(stderr, "Error!  No such node MAC address\n");
      MoCACtl_Close(ctx);
      return(-8);
   }


   // ----------- Finish

   MoCACtl_Close(ctx);

   return(0);
}
