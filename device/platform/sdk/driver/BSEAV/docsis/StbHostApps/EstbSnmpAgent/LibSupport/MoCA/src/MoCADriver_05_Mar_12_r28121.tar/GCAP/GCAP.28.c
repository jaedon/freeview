#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static char *chipId = NULL;    // -i option
static char *on_off = NULL; 

void showUsage()
{
    printf("Usage: GCAP.28 <ON/OFF> [-h]\n\
Continuously insert Protocol IEs and Time IEs in every MAP.\n\
\n\
Options:\n\
 <ON/OFF>  Turn ON or OFF insertion of Protocol IEs and Time\n\
           IEs in every MAP. Default: ON.\n\
  -h   Display this help and exit\n");
}


int main(int argc, char **argv)
{
   int ret;
   void *ctx;
   CmsRet cmsret = CMSRET_SUCCESS;
   MoCA_STATUS status;
   MoCA_CONFIG_PARAMS config;

   // ----------- Parse parameters
   opterr = 0;
   
   while((ret = getopt(argc, argv, "hi:")) != -1) 
   {
      switch(ret) 
      {
      case 'i':
         chipId = optarg;
         break;
      case '?':
         fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
         return(-1);
         break;
      case 'h':            
      default:
         showUsage();
         return(0); 
      }
   }


   if (argc >= 2)
   {
      on_off = argv[1];
   }


   // ----------- Initialize

   ctx=MoCACtl_Open(chipId);

   if (!ctx)
   {
      fprintf(stderr, "Error!  Unable to connect to moca instance\n");
      return(-2);
   }

    cmsret = MoCACtl2_GetStatus(ctx, &status);

   if (cmsret != CMSRET_SUCCESS)
   {
      fprintf(stderr, "Error!  Mocactl failure\n");
      MoCACtl_Close(ctx);
      return(-3);
   }

   if (status.generalStatus.linkStatus != MoCA_LINK_UP)
   {
      fprintf(stderr, "Error! No Link\n");
      MoCACtl_Close(ctx);
      return(-4);
   }

   if (status.generalStatus.nodeId !=
       status.generalStatus.ncNodeId )
   {
      fprintf(stderr, "Error! Not an NC node\n");
      MoCACtl_Close(ctx);
      return(-5);
   }
    
   memset(&config, 0x0, sizeof(MoCA_CONFIG_PARAMS));

   if( (on_off != NULL) && !strcmp( on_off, "OFF" ) )
      config.continuousIEMapInsert = MoCA_CONTINUOUS_IE_MAP_INSERT_OFF ;
   else
      config.continuousIEMapInsert = MoCA_CONTINUOUS_IE_MAP_INSERT_ON ;

   cmsret = MoCACtl2_SetCfg(ctx, &config, MoCA_CFG_PARAM_CONT_IE_MAP_INS_MASK );
   if (cmsret != CMSRET_SUCCESS)
   {
      fprintf(stderr, "Error!  Mocactl failure\n");
      MoCACtl_Close(ctx);
      return(-6);
   }

   // ----------- Finish

   MoCACtl_Close(ctx);

   return(0);
}
