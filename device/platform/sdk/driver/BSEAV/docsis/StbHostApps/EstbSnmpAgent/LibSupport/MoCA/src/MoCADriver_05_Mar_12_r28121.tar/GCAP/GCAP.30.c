#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

char *chipId = NULL;    // -i option
int interval = 0;
int duration = 0;
int endless = 0;
int g_active_nodes = 0;


MAC_ADDRESS nodemacs[16];

void showUsage()
{
    printf("Usage: GCAP.30 [-i <polling interval>] [-t <polling duration>] [-h]\n\
Report time-stamps whenever MoCA network version changes or when nodes \n\
join in or drop out .\n\
\n\
Options:\n\
  -i   Set polling interval in number of seconds (default 1 second)\n\
  -t   Set polling duration in number of minutes (default forever until\n\
       Ctrl-C to break)\n\
  -e   Allow polling to continue if link goes down (default polling\n\
       stops when MoCA link goes down)\n\
  -h   Display this help and exit\n");
}

void version_callback(void * userarg, unsigned int newversion)
{
    time_t t;
    struct tm *timex;

    t=time(NULL);
    timex=localtime(&t);
    
    printf("%02d:%02d:%02d MOCA_VERSION changed to 0x%x\n", 
        timex->tm_hour, timex->tm_min, timex->tm_sec, newversion);
}

void callback(void *userarg, uint32_t active_nodes)
{
    time_t t;
    struct tm *timex;
    MoCA_NODE_STATUS_ENTRY nodestatus;
    CmsRet cmsret;
    void *ctx = userarg;
    int nodeid;
    int joined;

    for (nodeid = 0; nodeid < MoCA_MAX_NODES; nodeid++)
    {
        if ((g_active_nodes & (1 << nodeid)) !=
            (active_nodes & (1 << nodeid)))
        {           
            joined = (active_nodes >> nodeid) & 0x1;        
        
            if (joined)
            {
                nodestatus.nodeId = nodeid;
                cmsret = MoCACtl2_GetNodeStatus(ctx, &nodestatus);

                if (cmsret != CMSRET_SUCCESS)
                {
                    fprintf(stderr, "Error!  Mocactl failure 2\n");
                    exit(-6);
                }
                moca_u32_to_mac((uint8_t *)&nodemacs[nodeid], nodestatus.eui[0], nodestatus.eui[1]);
            }
            t=time(NULL);
            timex=localtime(&t);
            printf("%02d:%02d:%02d Node %2d [%02x:%02x:%02x:%02x:%02x:%02x] %s\n", 
                timex->tm_hour, timex->tm_min, timex->tm_sec, nodeid,
                nodemacs[nodeid][0], nodemacs[nodeid][1], nodemacs[nodeid][2],
                nodemacs[nodeid][3], nodemacs[nodeid][4], nodemacs[nodeid][5],
                joined?"JOINED":"DROPPED");
        }
    }
    g_active_nodes = active_nodes;
}


void link_cb(void * userarg, uint32_t status)
{
    if (status == 0)
    {
        printf("Error! No Link\n");
        exit(0);
    }
}


int main(int argc, char **argv)
{
    int ret;
        
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_STATUS status;
    MoCA_NODE_STATUS_ENTRY nodestatus;
    int i;
    void *ctx;
    time_t t;
    struct tm *timex;    
    

    moca_gcap_init();

    // ----------- Parse parameters
    
    opterr = 0;
    
    while((ret = getopt(argc, argv, "hex:i:t:")) != -1) 
    {
        switch(ret)
        {
        case 'e':
            endless = 1;
            break;
        case 'x':
            chipId = optarg;
            break;            
        case 'i':
            interval = atoi(optarg);
            break;
        case 't':
            duration = atoi(optarg);
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Get info
    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        MoCACtl_Close(ctx);
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        MoCACtl_Close(ctx);
        return(-4);
    }  

    t=time(NULL);
    timex=localtime(&t);

    g_active_nodes = status.generalStatus.connectedNodes;
    
    
    printf("%02d:%02d:%02d Moca Monitoring STARTED. MOCA_VERSION=0x%x\n", 
      timex->tm_hour, timex->tm_min, timex->tm_sec, 
      status.generalStatus.networkVersionNumber);

    moca_register_topology_changed_cb(ctx, callback, ctx);
    moca_register_moca_version_changed_cb(ctx, version_callback, ctx);

    if (endless == 0)
       moca_register_link_up_state_cb(ctx, link_cb, ctx);

    // read in the mac addresses so we remember them when a node drops off
    for (i=0;i<16;i++)
    {
        nodestatus.nodeId = i;
        cmsret = MoCACtl2_GetNodeStatus(ctx, &nodestatus);

        if (cmsret != CMSRET_SUCCESS)
        {
            fprintf(stderr, "Error!  Mocactl failure 2\n");
            MoCACtl_Close(ctx);
            exit(-6);
        }
        moca_u32_to_mac((uint8_t *)&nodemacs[i], nodestatus.eui[0], nodestatus.eui[1]);
    }

    if (duration)
        alarm(duration*60);

    MoCACtl2_EventLoop(ctx);

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}



