#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static char *chipId = NULL;    // -i option
static char *on_off = NULL; 
static char *str_node_id = NULL; 
static char *constellation = NULL;

void showUsage()
{
    printf("Usage: GCAP.32 <ON|OFF> <ivalue> <nodeid> [-h]\n\
Persistently enforce an upper limit of a the constellation for \n\
all carriers reported in Type I Probe Report and GCD type I \n\
Probe Report to a single node.\n\
\n\
Options:\n\
 <ON|OFF>     Turn ON or OFF constellation limit.\n\
 <ivalue>     Constellation size (1-10)\n\
 <node_id>    Node ID to limit.\n\
  -h          Display this help and exit\n");
}


int main(int argc, char **argv)
{
   int ret;
   void *ctx;
   CmsRet cmsret = CMSRET_SUCCESS;
   UINT32 node_id;
   MoCA_STATUS status;
   MoCA_CONFIG_PARAMS config;

   // ----------- Parse parameters
   opterr = 0;

   if (argc > 1)
   {
      on_off = argv[1];

      if (strcmp(on_off, "ON") == 0)
      {
         if (argc != 4)
         {
            fprintf(stderr, "Error!  Missing parameter <ivalue> or <node_id>\n");
            return(-2);
         }
         
         str_node_id = argv[3];
         constellation = argv[2];
         
      }
      else if ((on_off[0] != '-') && (strcmp(on_off, "OFF") != 0))
      {
         fprintf(stderr, "Error!  Invalid paramters - %s\n", on_off);
         return(-3);
      }
   } 
   else
   {
       fprintf(stderr, "Error!  Missing parameter <ON|OFF>, <ivalue> or <node_id>\n");
       return(-4);    
   }

   while((ret = getopt(argc, argv, "hi:")) != -1) 
   {
      switch(ret) 
      {
      case 'i':
         chipId = optarg;
         break;
      case '?':
         fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
         return(-1);
         break;
      case 'h':            
      default:
         showUsage();
         return(0); 
      }
   }

   // ----------- Initialize

   ctx=MoCACtl_Open(chipId);

   if (!ctx)
   {
      fprintf(stderr, "Error!  Unable to connect to moca instance\n");
      return(-5);
   }

   cmsret = MoCACtl2_GetStatus(ctx, &status);

   if (cmsret != CMSRET_SUCCESS)
   {
      fprintf(stderr, "Error!  Mocactl failure\n");
      MoCACtl_Close(ctx);
      return(-6);
   }

   if (status.generalStatus.linkStatus != MoCA_LINK_UP)
   {
      fprintf(stderr, "Error! No Link\n");
      MoCACtl_Close(ctx);
      return(-7);
   }

   memset(&config, 0x0, sizeof(MoCA_CONFIG_PARAMS));
   node_id = strtoul(str_node_id, NULL, 0);

   if (node_id >= MoCA_MAX_NODES)
   {
      fprintf(stderr, "Error! Invalid Node ID %u\n", node_id);
      MoCACtl_Close(ctx);
      return(-8);
   }

   /* Non-zero enables max constellation */
   if( strcmp( on_off, "ON" ) == 0)
   {
      if (!constellation)
      {
         fprintf(stderr, "Error! Invalid parameter\n");
         MoCACtl_Close(ctx);         
         return(-9);
      }
      
      config.constellation[node_id] = strtoul(constellation, NULL, 0);
      if (config.constellation[node_id] >= MAX_CONSTELLATION)
      {
         fprintf(stderr, "Error! Invalid constellation value %u\n", config.constellation[node_id]);
         MoCACtl_Close(ctx);
         return(-10);
      }
   }
   else
   {
      config.constellation[node_id] = MoCA_DEF_CONSTELLATION_INFO;
   }

   cmsret = MoCACtl2_SetCfg(ctx, &config, MoCA_CFG_PARAM_MAX_CONSTELLATION_MASK );
   if (cmsret != CMSRET_SUCCESS)
   {
      fprintf(stderr, "Error!  Mocactl failure\n");
      MoCACtl_Close(ctx);
      return(-11);
   }

   cmsret = MoCACtl2_SetPersistent(ctx, "MoCACFGPARMS", (char *) &config, sizeof (MoCA_CONFIG_PARAMS)) ;

   if (cmsret != CMSRET_SUCCESS)
   {
      fprintf(stderr, "Error!  Mocactl SetPersistent\n");
      MoCACtl_Close(ctx);
      return(-12);
   }

   // ----------- Finish

   MoCACtl_Close(ctx);

   return(0);
}
