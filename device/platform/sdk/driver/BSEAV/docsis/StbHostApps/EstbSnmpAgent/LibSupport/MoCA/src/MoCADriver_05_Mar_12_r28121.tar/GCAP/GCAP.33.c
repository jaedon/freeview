#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>
#include <pthread.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"
#include "GCAP_Common.h"

static char *chipId = NULL;    // -i option

void showUsage()
{
    printf("Usage: GCAP.33 [-h]\n\
Report Summed up STPS and TXPS in the network.\n\
\n\
Options:\n\
  -h   Display this help and exit\n");
}



static void pqos_create_response_status_cb(void *arg, struct moca_pqos_create_response *in)
{
   printf("Summed up STPS :   %u\n", in->totalstps);
   printf("Summed up TXPS :   %u\n", in->totaltxps);
   printf("QOS STPS       :   %u\n", in->flowstps);
   printf("QOS TXPS       :   %u\n", in->flowtxps);

   pqos_callback_return(arg);
}


int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_STATUS status;
    pthread_t pqos_thread;

    moca_gcap_init();

    // ----------- Parse parameters

    opterr = 0;
    
    while((ret = getopt(argc, argv, "hi:")) != -1) 
    {
        switch(ret)
        {
        case 'i':
            chipId = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Obtain statistics 

    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        MoCACtl_Close(ctx);
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        MoCACtl_Close(ctx);
        return(-4);
    }
    

    cmsret = moca_start_event_loop(ctx, &pqos_thread);
    if (cmsret == CMSRET_SUCCESS)
    {
        moca_register_pqos_create_response_cb(ctx, &pqos_create_response_status_cb, ctx);
        cmsret = MoCACtl2_GetPQoSStatus(ctx);
        if (cmsret == CMSRET_SUCCESS)
        {
            moca_wait_for_event(ctx, pqos_thread);
        }
    }

    // ----------- Finish
    if (cmsret == CMSRET_SUCCESS)
    {
        pthread_join(pqos_thread, NULL); /* Allow event loop to be cancelled */
    }

    MoCACtl_Close(ctx);

    return(0);
}

