#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static char *chipId = NULL;    // -i option
static char *on_off = NULL; 
static char *aggr_level = NULL; 
static char *packet_rate = NULL;

void showUsage()
{
    printf("Usage: GCAP.34 <ON/OFF> <rate> <aggr_level> [-h]\n\
Set the maximum aggregation level on this node. Turning OFF sets\n\
the aggregation level to the default value of 6\n\
\n\
Options:\n\
 <ON/OFF>     Turn ON or OFF aggregation limit.\n\
 <rate>       Packet rate (1 Mbps or 64 Mbps)\n\
 <aggr_level> Number of packets to aggregate (1-10).\n\
  -h   Display this help and exit\n");
}


int main(int argc, char **argv)
{
   int ret;
   void *ctx;
   CmsRet cmsret = CMSRET_SUCCESS;
   MoCA_CONFIG_PARAMS config;
   uint32_t rate;

   // ----------- Parse parameters
   opterr = 0;
   
   while((ret = getopt(argc, argv, "hi:")) != -1) 
   {
      switch(ret) 
      {
      case 'i':
         chipId = optarg;
         break;
      case '?':
         fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
         return(-1);
         break;
      case 'h':            
      default:
         showUsage();
         return(0); 
      }
   }


   if (argc < 2)
   {
      fprintf(stderr, "Error!  Missing parameter <ON/OFF>\n");
      return(-2);
   }
   else
   {
      on_off = argv[1];
   }

   if (argc >= 2)
   {
      packet_rate = argv[2];
   }

   if (argc >= 3)
   {
      aggr_level = argv[3];
   }
   

   // ----------- Initialize

   ctx=MoCACtl_Open(chipId);

   if (!ctx)
   {
      fprintf(stderr, "Error!  Unable to connect to moca instance\n");
      return(-3);
   }

   memset(&config, 0x0, sizeof(MoCA_CONFIG_PARAMS));

   if( !strcmp( on_off, "ON" ) )
   {
      if (aggr_level == NULL)
      {
         config.maxPktAggr = MoCA_DEF_PKT_AGGR;
      }
      else
      {
         config.maxPktAggr = strtoul(aggr_level, NULL, 0);
         if ((config.maxPktAggr < MoCA_MIN_PKT_AGGR) ||
             (config.maxPktAggr > MoCA_MAX_PKT_AGGR))
         {
            fprintf(stderr, "Error! Invalid aggr_level %u\n", config.maxPktAggr);
            MoCACtl_Close(ctx);
            return(-4);
         }
      }
      /* Performing minAggrWaitTime calculation after maxPktAggr because
       * maxPktAggr is needed to determine minAggrWaitTime value. */
      if (packet_rate == NULL)
      {
         config.minAggrWaitTime = MOCA_DEF_MIN_AGGR_WAIT_TIME;
      }
      else
      {
         rate = strtoul(packet_rate, NULL, 0);
         if ((rate != 64) && (rate != 1))
         {
            fprintf(stderr, "Error! Invalid packet rate %u\n", rate);
            MoCACtl_Close(ctx);
            return(-5);            
         }

         /* When the GCAP.34 is ON the MIN_AGGR_WAITING_TIME = MAX_AGGR_PACKETS*1/(RATE/8/PACKET_SIZE).
          * At RATE=1 Mbps, thePACKET_SIZE=64 Bytes (GCAP.34 definition)
          *    MIN_AGGR_WAITING_TIME = MAX_AGGR_PACKETS * 512 usec
          * At RATE=64 Mbps, the PACKET_SIZE=800 bytes (GCAP.34 definition)
          *    MIN_AGGR_WAITING_TIME = MAX_AGGR_PACKETS * 100 usec 
          */
         if (rate == 1)
         {
            config.minAggrWaitTime = config.maxPktAggr * 512;
         }
         else if (rate == 64)
         {
            config.minAggrWaitTime = config.maxPktAggr * 100;
         }
      }
   }
   else if( !strcmp( on_off, "OFF" ) )
   {
      config.maxPktAggr = 1;
      config.minAggrWaitTime = 0;
   }
   else
   {
      fprintf(stderr, "Error! Invalid parameter %s\n", on_off);
      MoCACtl_Close(ctx);
      return(-6);
   }

   cmsret = MoCACtl2_SetCfg(ctx, &config, 
      (MoCA_CFG_PARAM_MAX_PKT_AGGR_MASK | MoCA_CFG_PARAM_MIN_AGGR_WAIT_TIME_MASK));
   if (cmsret != CMSRET_SUCCESS)
   {
      fprintf(stderr, "Error!  Mocactl failure\n");
      MoCACtl_Close(ctx);
      return(-7);
   }

   // ----------- Finish

   MoCACtl_Close(ctx);

   return(0);
}
