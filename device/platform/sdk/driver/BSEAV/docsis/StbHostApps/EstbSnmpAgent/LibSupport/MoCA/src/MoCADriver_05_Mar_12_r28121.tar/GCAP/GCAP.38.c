#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static int persistent = 0;     // -M option
static int reset = 0;          // -r option
static char *chipId = NULL;    // -i option
static char *onoff = NULL;


void showUsage()
{
    printf("Usage: GCAP.38 <[ON]/OFF> [-M] [-r] [-h]\n\
Set Golden Node to operate in CW mode at the\n\
DirecTv default channel (M4).\n\
Default values will be used if parameters are not supplied.\n\
Note that resetting SoC is required for configuration to take affect.\n\
If multiple configuration parameters are being changed, -r option can be\n\
used in the last command.\n\
\n\
Options:\n\
 ON/OFF Turn ON or OFF the continuous power TX mode (default ON)\n\
        OFF - permanently, '-M' can be omitted.\n\
  -M    Make configuration changes permanent\n\
  -r    Reset SoC to make configuration changes effective\n\
  -h    Display this help and exit\n");
}

int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;

    UINT64 reInitMask = 0;
    MoCA_INITIALIZATION_PARMS reInitParms;    
    

    // ----------- Parse parameters
    opterr = 0;

    if ((argc < 2) || (argv[1] == NULL) || (argv[1][0] == '-'))
    {
        onoff = "ON";
    }
    else
    {
        onoff = argv[1];
    }
    
    while((ret = getopt(argc, argv, "Mrhi:")) != -1) 
    {
        switch(ret) 
        {
        case 'i':
            chipId = optarg;
            break;
        case 'M':
            persistent = 1;
            break;
        case 'r':
            reset = 1;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':            
        default:
            showUsage();
            return(0); 
        }
    }

    

    if ((strcmp(onoff, "ON") != 0) && (strcmp(onoff, "OFF") != 0))
    {
        fprintf(stderr,"Error!  Invalid parameter - %s\n",onoff);
        return(-2);
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Save Settings 
    
    if (MoCACtl2_GetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS)) <= 0)
    {
        MoCACtl_Close(ctx);
        fprintf(stderr, "Error!  GetInitParms\n");
        return(-3);
    }

    if (strcmp(onoff, "ON") == 0)
    {
        reInitParms.constTransmitMode = MoCA_CONTINUOUS_TX_CW;
        if ( !reInitParms.nvParams.lastOperFreq )
        {
            reInitMask |= MoCA_INIT_PARAM_NV_PARAMS_LOF_MASK;
            reInitParms.nvParams.lastOperFreq = 575;
        }
    }
    else
    {
        reInitParms.constTransmitMode = MoCA_NORMAL_OPERATION;
    }


    reInitMask |= MoCA_INIT_PARAM_CONST_TRANSMIT_MODE_MASK;

    cmsret = MoCACtl2_SetInitParms(ctx, &reInitParms, reInitMask);
    if (cmsret != CMSRET_SUCCESS)
    {
        MoCACtl_Close(ctx);
        fprintf(stderr, "Error!  SetInitParms\n");
        return(-4);
    }

    if (persistent)
    {
        MoCACtl2_SetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS));
    }

    // ----------- Activate Settings   
    
    if (reset)
    {
        cmsret=MoCACtl2_ReInitialize( 
            ctx,
            &reInitParms, 
            reInitMask,
            NULL,
            0);
    }
    
    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Unable to go to continuous TX mode\n");
        return(-5);
    }

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}


