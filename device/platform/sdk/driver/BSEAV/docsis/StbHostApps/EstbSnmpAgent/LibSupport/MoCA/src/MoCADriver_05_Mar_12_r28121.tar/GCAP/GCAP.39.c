#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "mocalib-cli.h"
#include "cms_psp.h"

char *chipId = NULL;    // -i option
MoCA_NODE_STATUS_ENTRY nodestatus[MoCA_MAX_NODES];
MoCA_NODE_COMMON_STATUS_ENTRY nodeCommonStatus;

void showUsage()
{
    printf("Usage: GCAP.39 [nodeId] [-h]\n\
Report PHY bit rates between the GN & other nodes.\n\
\n\
Options:\n\
  [nodeId]  Node Id\n\
  -h   Display this help and exit\n");
}

void printNodeProfileInfo(void *ctx, int node)
{    
    printf("\nNodeID: %3d\n", nodestatus[node].nodeId);
    printf("---------------------------------------------------------------------------\n");    
    printf("TxUC: %9d                            RxUC: %9d\n", nodestatus[node].maxPhyRates.txUcPhyRate, nodestatus[node].maxPhyRates.rxUcPhyRate);   
    mocacli_display_bit_loading (&nodestatus[node].txUc.bitLoading[0], &nodestatus[node].rxUc.bitLoading[0]) ;
    printf("\nRxBC: %9d\n", nodestatus[node].maxPhyRates.rxBcPhyRate);   
    mocacli_display_bit_loading (&nodestatus[node].rxBc.bitLoading[0], NULL) ;    
}

int main(int argc, char **argv)
{
    int ret;
    
    CmsRet cmsret = CMSRET_SUCCESS;
    MoCA_STATUS status;
    void *ctx;

    int nodeid = -1;
    int altnode;
    unsigned int tblsize;

    // ----------- Parse parameters
    opterr = 0;

    if (argc == 2)
        nodeid = atoi(argv[1]);    
    
    while((ret = getopt(argc, argv, "hi:")) != -1) 
    {
        switch(ret)
        {
        case 'i':
            chipId = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Get info

    cmsret = MoCACtl2_GetStatus(ctx, &status);

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure\n");
        return(-3);
    }

    if (status.generalStatus.linkStatus != MoCA_LINK_UP)
    {
        fprintf(stderr, "Error! No Link\n");
        return(-4);
    }  

    altnode = 0;

    cmsret = MoCACtl2_GetNodeTblStatus( ctx, &nodestatus[0], &nodeCommonStatus, &tblsize );
    
    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Mocactl failure getting status\n");
        return(-4);
    }

    tblsize /= sizeof(MoCA_NODE_STATUS_ENTRY);
    for (altnode = 0; altnode < tblsize; altnode++)
    {
        if (nodestatus[altnode].nodeId != status.generalStatus.nodeId)
        {            
            if ((nodestatus[altnode].nodeId==nodeid) || (nodeid == -1))
                printNodeProfileInfo(ctx, altnode);
        }
    }

    printf("\nAll Nodes:\n");
    printf("---------------------------------------------------------------------------\n");        
    printf("TxBC: %9d\n",nodeCommonStatus.maxCommonPhyRates.txBcPhyRate);
    
    mocacli_display_bit_loading (&nodeCommonStatus.txBc.bitLoading[0], NULL);

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}
