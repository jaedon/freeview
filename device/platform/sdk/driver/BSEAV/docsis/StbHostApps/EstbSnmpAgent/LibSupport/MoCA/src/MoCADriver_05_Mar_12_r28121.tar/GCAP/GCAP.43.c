#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static int persistent = 0;          // -M option
static int reset = 0;               // -r option
static char *chipId = NULL;         // -i option
static char *backoffIndex = NULL;   // -s option


void showUsage()
{
    printf("Usage: GCAP.43 [-s <Beacon Backoff index>] [-M] [-r] [-h] \n\
Set Golden Node to operate with beacon backoff enabled.\n\
If no options are specified this command will display the Beacon \n\
Backoff value set in the local node. Setting to 0 will disable.\n\
Note that resetting SoC is required for configuration to take affect.\n\
\n\
Options:\n\
  -s     Set the Beacon Backoff value set in the local node\n\
  -M     Make configuration changes permanent\n\
  -r     Reset SoC to make configuration changes effective\n\
  -h     Display this help and exit\n\
\n\
Beacon Backoff Index Values:\n\
  0 (-0 db)\n\
  1 (-3 dB)\n\
  2 (-6 dB)\n\
  3 (-9 dB)\n\
  4 (-12 dB)\n\
  5 (-15 dB)\n");
}

int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;

    UINT64 initMask = 0;
    MoCA_INITIALIZATION_PARMS initParms;    


    // ----------- Parse parameters
    opterr = 0;

    while((ret = getopt(argc, argv, "Mrhi:s:")) != -1) 
    {
        switch(ret) 
        {
        case 'i':
            chipId = optarg;
            break;
        case 'M':
            persistent = 1;
            break;
        case 'r':
            reset = 1;
            break;
        case 's':
            backoffIndex = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':            
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Save Settings 
    
    MoCACtl2_GetPersistent(ctx, "MoCAINITPARMS", (char *) &initParms, sizeof (MoCA_INITIALIZATION_PARMS));

    if (backoffIndex != NULL)
    {
        initParms.beaconPwrReduction = atoi(backoffIndex);
        if ((initParms.beaconPwrReduction < 0) || (initParms.beaconPwrReduction > 5))
        {
            fprintf(stderr, "Error!  Invalid backoff index value.\n");
            MoCACtl_Close(ctx);
            return(-1);
        }

        initParms.beaconPwrReduction *= 3;
    }

    /* If there are no parameters, just print out the current setting */
    if (argc == 1)
    {
        if (initParms.beaconPwrReductionEn)
        {
            fprintf(stderr, "Beacon Backoff set to %d (-%d dB).\n",
                (initParms.beaconPwrReduction/3), initParms.beaconPwrReduction);
        }
        else
        {
            fprintf(stderr, "Beacon Backoff disabled.\n");
        }
    }
    else
    {
        initParms.beaconPwrReductionEn = (initParms.beaconPwrReduction == 0) ? 0 : 1;

        initMask |= (MoCA_INIT_PARAM_BEACON_PWR_REDUCTION_EN_MASK | MoCA_INIT_PARAM_BEACON_PWR_REDUCTION_MASK);

        cmsret = MoCACtl2_SetInitParms(ctx, &initParms, initMask);
        if (cmsret != CMSRET_SUCCESS)
        {
            MoCACtl_Close(ctx);
            fprintf(stderr, "Error!  SetInitParms\n");
            return(-3);
        }

        if (persistent)
        {
            MoCACtl2_SetPersistent(ctx, "MoCAINITPARMS", (char *) &initParms, sizeof (MoCA_INITIALIZATION_PARMS));
        }

        // ----------- Activate Settings   
        
        if (reset)
        {
            cmsret=MoCACtl2_ReInitialize( 
                ctx,
                &initParms, 
                initMask,
                NULL,
                0);
        }
        
        if (cmsret != CMSRET_SUCCESS)
        {
            fprintf(stderr, "Error!  Unable to set Beacon Backoff power\n");
            MoCACtl_Close(ctx);
            return(-4);
        }
    }
    
    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}


