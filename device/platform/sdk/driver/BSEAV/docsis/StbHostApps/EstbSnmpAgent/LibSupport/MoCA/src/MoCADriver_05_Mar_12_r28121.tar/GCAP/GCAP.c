#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>

#include "devctl_moca.h"

char *chipId = NULL;    // -i option
static int show_version = 0; // -v option

static int print_version(void * ctx)
{
   CmsRet cmsRet;
   MoCA_VERSION MoCAVersion;
   UINT32 coreversionMajor, coreversionMinor, coreversionBuild;

   cmsRet = MoCACtl2_GetVersion(ctx, &MoCAVersion);
   if (cmsRet != CMSRET_SUCCESS) 
   {
      fprintf( stderr, "GetVersion error\n");
      return(-1);
   }
   else {
      coreversionMajor = MoCAVersion.coreSwVersion >> 28;
      coreversionMinor = (MoCAVersion.coreSwVersion << 4) >> 28;
      coreversionBuild = (MoCAVersion.coreSwVersion << 8) >> 8;
      printf ("\n MoCA Version                 \n");
      printf (" ----------------------             \n");
      printf ("MoCA coreHWVersion   : 0x%x \n", MoCAVersion.coreHwVersion);
      printf ("MoCA coreSWVersion   : %d.%d.%d \n", coreversionMajor, coreversionMinor,
            coreversionBuild);
      printf ("MoCA selfVersion    : 0x%x \n", MoCAVersion.selfVersion);
      printf ("MoCA Driver Version  : %d.%d.%x \n", MoCAVersion.drvMjVersion, MoCAVersion.drvMnVersion,
            MoCAVersion.drvBuildVersion);
      printf (" -----------------------            \n");
   }

   return(0);
} /* VersionHandler */

int main(int argc, char **argv)
{
   int ret;
   void * ctx;

   while((ret = getopt(argc, argv, "vi:")) != -1) 
   {
      switch(ret) 
      {
         case 'i':
            chipId = optarg;
            break;
         case 'v':
            show_version = 1;
            break;
         case '?':
            return(-1);
            break;
         default:
            break;
      }
   }

   if (show_version)
   {
      ctx = MoCACtl_Open(chipId);

      if (!ctx)
      {
         fprintf(stderr, "Error!  Unable to connect to moca instance\n");
         return(-2);
      }

      ret = print_version(ctx);
      MoCACtl_Close(ctx);
      return(ret);
   }
   else
   {
      printf(
      "Summary of GCAP Commands\n"\
      "=========================================================================\n"\
      "GCAP.01 - Report time-stamps whenever key exchanges happen between nodes.\n"\
      "GCAP.02 - Set Golden Node to operate at a single frequency.\n"\
      "GCAP.03 - Set Golden Node to operate in continuous power TX mode.\n"\
      "GCAP.04 - Report NC node ID and MAC address.\n"\
      "GCAP.05 - Report backup NC node ID and MAC address.\n"\
      "GCAP.06 - Report bit rates between the GN & other nodes.\n"\
      "GCAP.08 - Set/Clear LOF (Last Operational Frequency).\n"\
      "GCAP.09 - Report Taboo frequency mask\n"\
      "GCAP.10 - Display the current tuned frequency of the Link.\n"\
      "GCAP.13 - Report Node ID, MAC address and total number of nodes in the network.\n"\
      "GCAP.14 - Report frequency offset between Golden Node & DUT.\n"\
      "GCAP.15 - Report the time it takes to complete LMO cycle with a DUT.\n"\
      "GCAP.16 - Enable/Disable privacy and set the password.\n"\
      "GCAP.17 - Report time-stamps whenever nodes join in or drop out.\n"\
      "GCAP.18 - Read back the privacy password.\n"\
      "GCAP.19 - Reset to default configuration.\n"\
      "GCAP.20 - Create/Update PQoS flows on any node.\n"\
      "GCAP.21 - Delete PQoS flows on any node.\n"\
      "GCAP.22 - Display all existing PQoS flows on any node.\n"\
      "GCAP.23 - Query any PQoS flow in the network.\n"\
      "GCAP.24 - Report packet aggregation statistic.\n"\
      "GCAP.25 - Report all nodes' or specific node's OFDMb and GAP on the Network.\n"\
      "GCAP.26 - Display the current network (Beacon) MoCA version.\n"\
      "GCAP.27 - Transmit an Out-of-Order Request Protocol IE.\n"\
      "GCAP.28 - Insert Protocol IEs and Time IEs in each MAP continuously.\n"\
      "GCAP.29 - Disable PQoS flow automatic creation.\n"\
      "GCAP.30 - Report time-stamps whenever Network MoCA version changes happen.\n"\
      "GCAP.32 - Set/Cancel the upper limit of the constellation of a particular Node.\n"\
      "GCAP.33 - Report Summed up STPS and TXPS in the network.\n"\
      "GCAP.34 - Set Highest Aggregation Level.\n"\
      "GCAP.36 - Insert 1 Protocol IE in every Reservation Request.\n"\
      "GCAP.37 - Turn ON/OFF Preferred NC mode.\n"\
      "GCAP.38 - Set Golden Node to operate in continuous power TX mode\n"\
      "GCAP.39 - Report bit rates and modulation profiles between GN & other nodes\n"\
      "GCAP.40 - Initiate an MR transaction Request to the specified nodes.\n"\
      "GCAP.41 - Turn ON/OFF Not Transmitting Mode.\n"\
      "GCAP.42 - Turn ON/OFF the Receive Level Added PHY Margin (RLAPM) profile table.\n"\
      "GCAP.43 - Set Golden Node to operate with beacon backoff enabled.\n"\
      "GCAP.44 - Set T50 timer min and max values.\n"\
      "=========================================================================\n");
   }

   return(0);
}


