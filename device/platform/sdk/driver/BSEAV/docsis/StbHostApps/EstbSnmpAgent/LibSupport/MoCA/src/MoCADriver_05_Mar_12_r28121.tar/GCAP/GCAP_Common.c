#include <pthread.h>
#include <sys/time.h>
#include <errno.h>
#include <signal.h>

#include "devctl_moca.h"
#include "mocalib.h"

static pthread_cond_t pqos_cond;
static pthread_mutex_t pqos_mutex;


void pqos_callback_return(void * arg)
{
   moca_cancel_event_loop(arg);
   pthread_mutex_lock(&pqos_mutex);
   pthread_cond_signal(&pqos_cond);
   pthread_mutex_unlock(&pqos_mutex);
}

CmsRet moca_start_event_loop(void * ctx, pthread_t * thread)
{
   int ret;

   pthread_mutex_init(&pqos_mutex, NULL);
   pthread_cond_init(&pqos_cond, NULL);

   ret = pthread_create(thread, NULL, (void *)moca_event_loop, ctx);
   if (ret != 0) {
      fprintf( stderr, "pthread_create returned %d\n", ret);
      return(CMSRET_INTERNAL_ERROR);
   }

   /* Give the thread a chance to run */
   usleep(1000);

   /* Lock the mutex so that the event can't be triggered before
      we moca_wait_for_event() is called */
   pthread_mutex_lock(&pqos_mutex);

   return(CMSRET_SUCCESS);
}

int moca_wait_for_event(void * ctx, pthread_t thread)
{
   struct timeval now;
   struct timespec timeout;
   int ret;

   gettimeofday(&now, NULL);
   timeout.tv_sec = now.tv_sec + 5; /* wait 5 seconds for pqos response */
   timeout.tv_nsec = now.tv_usec * 1000;

   ret = pthread_cond_timedwait(&pqos_cond, &pqos_mutex, &timeout);
   pthread_mutex_unlock(&pqos_mutex);

   if (ret == ETIMEDOUT)
      printf("Operation timed out.\n");

   pthread_cond_destroy(&pqos_cond);
   pthread_mutex_destroy(&pqos_mutex);
   return(ret);
}

char * moca_decision_string(UINT32 value)
{
   static char buf[11];
   
   switch (value)
   {
      case 0x1:
         return "DECISION_SUCCESS";
         break;
      case 0x3:
         return "DECISION_FLOW_EXISTS";
         break;
      case 0x4:
         return "DECISION_INSUF_INGR_BW";
         break;
      case 0x5: 
         return "DECISION_INSUF_EGR_BW"; 
         break;
      case 0x6: 
         return "DECISION_TOO_MANY_FLOWS"; 
         break;
      case 0x8: 
         return "DECISION_INVALID_TSPEC"; 
         break;
      case 0x9: 
         return "DECISION_INVALID_DA"; 
         break;
      case 0xA: 
         return "DECISION_LEASE_EXPIRED"; 
         break;
      case 0xB:
         return "DECISION_INVALID_BURST_SIZE";
         break;
      case 0x10: 
         return "DECISION_FLOW_NOT_FOUND"; 
         break;
      case 0x11: 
         return "DECISION_INSUF_AGGR_STPS"; 
         break;
      case 0x12: 
         return "DECISION_INSUF_AGGR_TXPS"; 
         break; 
      default:
         snprintf(buf, sizeof(buf), "0x%x", value);
         return buf;
         break;
   }
}

int moca_mac_to_node_id (void * ctx, MAC_ADDRESS * mac, UINT32 * node_id)
{
   int ret;
   struct moca_gen_status gs;
   struct moca_gen_node_status gns;
   int i;
   int node_found = 0;
   MAC_ADDRESS tmpMac;
   
   if (ctx == NULL || mac == NULL || node_id == NULL)
   {
      return(-1);
   }

   /* get node bitmask */
   moca_get_gen_status(ctx, &gs);

   /* find node id */
   for(i = 0; i < MOCA_MAX_NODES; i++)
   {
      if(! (gs.connected_nodes & (1 << i)))
         continue;
      ret = moca_get_gen_node_status(ctx, i, (void *)&gns);
      if (ret == 0)
      {
         moca_u32_to_mac(tmpMac, gns.eui_hi, gns.eui_lo);
         if (!memcmp(tmpMac, mac, sizeof(MAC_ADDRESS)))
         {
            node_found = 1;
            break;
         }
      }
   }

   if (node_found)
   {
      *node_id = i;
      return(0);
   }
   else
   {
      return(-2);
   }
}

// The alarm handler is here simply to prevent the default alarm handler from 
// printing "Alarm clock" when it goes off
void alarmHandler()
{
    exit(0);
}

void moca_gcap_init()
{
    signal(SIGALRM, alarmHandler); 
    signal(SIGINT, alarmHandler);
}

