int ParseMacAddress ( char * macAddrString, MAC_ADDRESS * pMacAddr );

void pqos_callback_return(void * arg);

CmsRet moca_start_event_loop(void * ctx, pthread_t * thread);

int moca_wait_for_event(void * ctx, pthread_t thread);

char * moca_decision_string(UINT32 value);

int moca_mac_to_node_id (void * ctx, MAC_ADDRESS * mac, UINT32 * node_id);

void moca_gcap_init();

