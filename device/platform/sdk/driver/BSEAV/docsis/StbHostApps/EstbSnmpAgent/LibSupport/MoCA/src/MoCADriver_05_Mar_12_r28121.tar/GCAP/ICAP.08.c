#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static int persistent = 0;     // -M option
static int reset = 0;          // -r option
static char *chipId = NULL;    // -i option
static char *lof = NULL;

static int isValidFrequency( UINT32 freq )
{
    switch(freq)
    {
        // Valid frequencies are from Band A to Band D
        case 500:
        case 525:
        case 550:
        case 575:
        case 600:
        case 675:
        case 700:
        case 725:
        case 750:
        case 775:
        case 800:
        case 825:
        case 850:
        case 975:
        case 1000:
        case 1025:
        case 1150:
        case 1200:
        case 1250:
        case 1300:
        case 1350:
        case 1400:
        case 1450:
        case 1500:
            return 1;
        default:
            return 0;
    }
}


void showUsage()
{
    printf("Usage: ICAP.08 <LOF> [-M] [-r] [-h]\n\
Set and clear LOF. Does not affect current channel of operation.\n\
\n\
Options:\n\
 <LOF> Last Frequency of Operation in MHz, MoCA A or D band.\n\
       or -1 to clear the LOF.\n\
  -M   Make configuration changes permanent\n\
  -r   Reset SoC to make configuration changes effective\n\
  -h   Display this help and exit\n");
}

int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;
    
    UINT64 reInitMask = 0;
    MoCA_INITIALIZATION_PARMS reInitParms;    

    memset(&reInitParms, 0x00, sizeof(reInitParms));

    // ----------- Parse parameters
    opterr = 0;

    lof = argv[1];
    
    while((ret = getopt(argc, argv, "Mrh1i:")) != -1) 
    {
        switch(ret) 
        {
        case 'i':
            chipId = optarg;
            break;
        case 'M':
            persistent = 1;
            break;
        case 'r':
            reset = 1;
            break;
        case '1':
            // Do nothing, -1 is a valid value
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':            
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }
        
    // ----------- Save Settings 
    
    MoCACtl2_GetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS));


    if (argc < 2)
    {
        printf( "Current LOF = %d\n", reInitParms.nvParams.lastOperFreq);
        MoCACtl_Close(ctx);
        return(0);
    }

    if (atoi(lof) == -1)
    {
        reInitParms.nvParams.lastOperFreq = 0; 
    }
    else
    {
        reInitParms.nvParams.lastOperFreq = atol(lof);         

        if (!isValidFrequency(reInitParms.nvParams.lastOperFreq))
        {
            MoCACtl_Close(ctx);
            fprintf(stderr, "Error!  Invalid parameter - LOF\n");
            return(-3);
        }        
    }    

    cmsret = MoCACtl2_SetInitParms(ctx, &reInitParms, MoCA_INIT_PARAM_NV_PARAMS_LOF_MASK);
    if (cmsret != CMSRET_SUCCESS)
    {
        MoCACtl_Close(ctx);
        fprintf(stderr, "Error!  SetInitParms\n");
        return(-4);
    }

    if (persistent)
    {
        MoCACtl2_SetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS));        
        MoCACtl2_SetPersistent(ctx, "MoCALOF", (char *) &reInitParms.nvParams.lastOperFreq, sizeof (UINT32));
    }

     reInitMask |= MoCA_INIT_PARAM_NV_PARAMS_LOF_MASK;

    // ----------- Activate Settings   

    if (reset)
    {
        cmsret=MoCACtl2_ReInitialize( 
            ctx,
            &reInitParms, 
            reInitMask,
            NULL,
            0);
    }
    
    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Invalid parameter - LOF\n");
        return(-5);
    }

    printf("New LOF = %d\n", reInitParms.nvParams.lastOperFreq);

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}
