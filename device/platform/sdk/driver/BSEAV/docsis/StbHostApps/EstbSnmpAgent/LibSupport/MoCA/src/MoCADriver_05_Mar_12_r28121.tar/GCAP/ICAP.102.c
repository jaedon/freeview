#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static int reset = 0;          // -r option
static char *chipId = NULL;    // -i option
static char *onoff = "OFF";
static int onoff_set = 0;

void showUsage()
{
    printf("Usage: ICAP.102 <ON/[OFF]> [-r] [-h]\n\
Turn Golden Node transmitting mode ON or OFF.\n\
\n\
Options:\n\
 ON/OFF To turn 'ON' OR 'OFF'\n\
  -r    Reset SoC to make configuration changes effective\n\
  -h    Display this help and exit\n");
}

int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;
    int i;

    UINT64 reInitMask = 0;
    MoCA_INITIALIZATION_PARMS reInitParms;   
    MoCA_CONFIG_PARAMS configParms;
    unsigned long long configMask = 0;

    // ----------- Parse parameters
    opterr = 0;

    for (i=1;i < argc;i++)
    {
        if ((strcmp(argv[i], "ON")==0) || (strcmp(argv[i], "OFF")==0))
        {
            if (onoff_set)
            {
                fprintf(stderr, "Error! Invalid option (duplicate) %s\n", argv[i]);
                return(-2);
            }
            onoff = argv[i];
            onoff_set = 1;
        }
        else if (argv[i][0] != '-')
        {
            fprintf(stderr, "Error! Invalid option %s\n", argv[i]);
            return(-3);
        }
    }

    while((ret = getopt(argc, argv, "rhi:")) != -1) 
    {
        switch(ret) 
        {
        case 'i':
            chipId = optarg;
            break;
        case 'r':
            reset = 1;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-5);
            break;
        case 'h':            
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-7);
    }

    if (MoCACtl2_GetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof(reInitParms)) <= 0)
    {
        MoCACtl_Close(ctx);
        fprintf(stderr, "Error!  GetInitParms\n");
        return(-8);
    }

    
    if (strcmp(onoff, "ON") == 0)
    {
        reInitParms.constTransmitMode = MoCA_CONTINUOUS_RX_LO_ON ;
    }
    else
    {
        reInitParms.constTransmitMode = MoCA_NORMAL_OPERATION ;
    }

    reInitMask = MoCA_INIT_PARAM_CONST_TRANSMIT_MODE_MASK;

    cmsret = MoCACtl2_SetInitParms(ctx, &reInitParms, reInitMask);
    if (cmsret != CMSRET_SUCCESS)
    {
        MoCACtl_Close(ctx);
        fprintf(stderr, "Error!  SetInitParms\n");
        return(-9);
    }

    MoCACtl2_SetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof(reInitParms));

    // ----------- Activate Settings
    
    if (reset)
    {
        cmsret=MoCACtl2_ReInitialize( 
            ctx,
            &reInitParms,
            reInitMask,
            &configParms,
            configMask);
    }
    
    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Unable to set rx mode\n");
        MoCACtl_Close(ctx);
        return(-10);
    }

    // ----------- Finish

    MoCACtl_Close(ctx);
    
    return(0);
}





