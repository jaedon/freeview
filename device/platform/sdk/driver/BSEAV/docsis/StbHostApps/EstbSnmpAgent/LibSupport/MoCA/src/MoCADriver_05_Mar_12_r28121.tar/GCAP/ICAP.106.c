#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static int reset = 0;          // -r option
static char *chipId = NULL;    // -i option
static char *onoff = NULL;

void showUsage()
{
    printf("Usage: ICAP.106 <[ON]/OFF> [ARPL Threshold] [-r] [-h]\n\
Set SAPM table on or off.\n\
\n\
Options:\n\
 ON/OFF To turn 'ON' OR 'OFF'\n\
        Subcarrier Added PHY Margin\n\
 ARPL Threshold\n\
        value in -dBm with the minus sign\n\
  -r    Reset SoC to make configuration changes effective\n\
  -h    Display this help and exit\n");
}

int main(int argc, char **argv)
{
    int ret;
    int i;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;
    int argstart;

    UINT64 reInitMask = 0;
    MoCA_INITIALIZATION_PARMS reInitParms;   
    MoCA_CONFIG_PARAMS configParms;
    unsigned long long configMask = 0;

    // ----------- Parse parameters
    opterr = 0;

    if ((argc < 2) || (argv[1] == NULL) || (argv[1][0] == '-'))
    {
        argstart = 1;
        onoff = "OFF";
    }
    else
    {
        argstart = 2;
        onoff = argv[1];
    }
    if ((strcmp(onoff, "ON") != 0) && (strcmp(onoff, "OFF") != 0))
    {
        fprintf(stderr,"Error!  Invalid parameter - %s\n",onoff);
        return(-3);
    }

    if ((argstart < argc) && (argv[argstart][0] == '-'))
    {
        if ((argv[argstart][1] >= '0') && (argv[argstart][1] <= '9'))
        {
            configParms.arplTh = atoi(argv[argstart]);
            configMask |= MoCA_CFG_PARAM_ARPL_TH_MASK;
            argv[argstart][0] = 'a'; // so getopt doesn't parse it
        }
    }    

    while((ret = getopt(argc, argv, "rhi:")) != -1)
    {
        switch(ret)
        {
        case 'i':
            chipId = optarg;
            break;
        case 'r':
            reset = 1;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    if (strcmp(onoff, "ON") == 0)
    {
        configParms.sapmEn = 1;

        for (i=0 ; i < MoCA_MAX_SAPM_TBL_INDEX; i++) 
        {
            if ((i >40-4) && (i < 49-4))
                configParms.sapmTable.sapmTableLo[i] = 4 * 2;
            else if ((i >48-4) && (i < 57-4))
                configParms.sapmTable.sapmTableLo[i] = 7 * 2;
            else if ((i >56-4) && (i < 61-4))
                configParms.sapmTable.sapmTableLo[i] = 60 * 2;
            else
                configParms.sapmTable.sapmTableLo[i] = 0;

            configParms.sapmTable.sapmTableHi[i] = 0;
        }
    }
    else
    {
        configParms.sapmEn = 0;

        for (i=0 ; i < MoCA_MAX_SAPM_TBL_INDEX; i++) 
        {
            configParms.sapmTable.sapmTableLo[i] = 0;
            configParms.sapmTable.sapmTableHi[i] = 0;
        }
    }

    configMask |= MoCA_CFG_PARAM_SAPM_EN_MASK | MoCA_CFG_PARAM_SAPM_TABLE_MASK;

    // ----------- Activate Settings   
    
    if (reset)
    {
        cmsret=MoCACtl2_ReInitialize( 
            ctx,
            &reInitParms, 
            reInitMask,
            &configParms,
            configMask);
    }
    else
    {
        cmsret=MoCACtl2_SetCfg(ctx, &configParms, configMask);
    }
    
    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Unable to set SAPM EN\n");
        MoCACtl_Close(ctx);
        return(-4);
    }

    cmsret=MoCACtl2_GetCfg(ctx, &configParms, MoCA_CFG_PARAM_SAPM_EN_MASK|
        MoCA_CFG_PARAM_ARPL_TH_MASK|MoCA_CFG_PARAM_SAPM_TABLE_MASK);
    

    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Unable to get SAPM settings\n");
        MoCACtl_Close(ctx);
        return(-5);
    }

    printf("SAPM: %s\n", configParms.sapmEn?"ON":"OFF");
    printf("ARPL Threshold: %d\n", configParms.arplTh);
    printf("SAPM Table:");
    for (i=0;i<MoCA_MAX_SAPM_TBL_INDEX * 2;i++)
    {
       if (i%8 == 0)
           printf("\n");
    
       if (i < MoCA_MAX_SAPM_TBL_INDEX)
           printf ("[%3d=%4.01f]", i+4, configParms.sapmTable.sapmTableLo[i]/2.0);
       else
           printf ("[%3d=%4.01f]", i+141-MoCA_MAX_SAPM_TBL_INDEX, configParms.sapmTable.sapmTableHi[i-MoCA_MAX_SAPM_TBL_INDEX]/2.0);
    }
    
    printf("\n");

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}


