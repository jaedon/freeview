#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static int persistent = 0;     // -M option
static int reset = 0;          // -r option
static char *chipId = NULL;    // -i option
static int freq = -2;

static int isValidFrequency( UINT32 rfType, UINT32 freq )
{
    if (rfType == MoCA_RF_TYPE_F_BAND)
    {
        switch (freq)
        {
            case 675:
            case 700:                
            case 725:
            case 750:
            case 775:
            case 800:
            case 825:
            case 850:                
                return(1);
            default:
                return(0);
        }
    }
    else if (rfType == MoCA_RF_TYPE_H_BAND)
    {
        switch (freq)
        {
            case 975:
            case 1000:
            case 1025:
                return(1);
            default:
                return(0);
        }
    }
    else if (rfType == MoCA_RF_TYPE_E_BAND)
    {
        switch (freq)
        {
            case 500:
            case 525:
            case 550:
            case 575:
            case 600:
                return(1);
            default:
                return(0);
        }
    }
    return(0);
}


void showUsage()
{
    printf("Usage: ICAP.108 <Beacon Frequency> [-M] [-r] [-h]\n\
Sets the beacon frequency.\n\
\n\
Options:\n\
 <Beacon Frequency> Frequency to send beacons on.\n\
       or -1 to clear the LOF.\n\
  -M   Make configuration changes permanent\n\
  -r   Reset SoC to make configuration changes effective\n\
  -h   Display this help and exit\n");
}

int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;
    
    UINT64 reInitMask = 0;
    MoCA_INITIALIZATION_PARMS reInitParms;    

    memset(&reInitParms, 0x00, sizeof(reInitParms));

    // ----------- Parse parameters
    opterr = 0;

    if (argc < 2)
    {
        freq = -2;
    } 
    else if ((argv[1][0] >= '0') && (argv[1][0] <= '9'))
    {
        freq = atoi(argv[1]);
    }
    
    while((ret = getopt(argc, argv, "Mrh1i:")) != -1) 
    {
        switch(ret) 
        {
        case 'i':
            chipId = optarg;
            break;
        case 'M':
            persistent = 1;
            break;
        case 'r':
            reset = 1;
            break;
        case '1':
            freq = -1;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':
        default:
            showUsage();
            return(0); 
        }
    }
   

    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }
        
    // ----------- Save Settings 
    
    if (MoCACtl2_GetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS)) <= 0)
    {
        MoCACtl_Close(ctx);
        fprintf(stderr, "Error!  GetInitParms\n");
        return(-3);
    }
    
    if ((freq != -2) && (freq != -1) && (!isValidFrequency(reInitParms.rfType, freq)))
    {
        fprintf(stderr, "Error!  Invalid parameter - <Beacon Frequency>\n");
        return(-3);
    }  
    
    if (freq != -2)
    {
        reInitParms.beaconChannel = freq;
        reInitMask = MoCA_INIT_PARAM_BEACON_CHANNEL_MASK;

        cmsret = MoCACtl2_SetInitParms(ctx, &reInitParms, reInitMask);
        if (cmsret != CMSRET_SUCCESS)
        {
            MoCACtl_Close(ctx);
            fprintf(stderr, "Error!  SetInitParms\n");
            return(-4);
        }

        if (persistent)
        {
            MoCACtl2_SetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS));
        }

        // ----------- Activate Settings   

        if (reset)
        {
            cmsret=MoCACtl2_ReInitialize( 
                ctx,
                &reInitParms, 
                reInitMask,
                NULL,
                0);
        }
    
        if (cmsret != CMSRET_SUCCESS)
        {
            fprintf(stderr, "Error!  Invalid parameter - <Beacon Frequency>\n");
            return(-5);
        }
    }

    printf("%d\n", reInitParms.beaconChannel);

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}
