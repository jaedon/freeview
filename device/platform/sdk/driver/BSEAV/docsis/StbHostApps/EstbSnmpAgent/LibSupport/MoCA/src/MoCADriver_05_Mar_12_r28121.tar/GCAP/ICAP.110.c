#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static char *chipId = NULL;    // -i option
static char plusminus = '+';


void showUsage()
{
    printf("Usage: ICAP.110 [+/-] [-r] [-h]\n\
Apply +xtalpull or -xtalpull\n\
\n\
Options:\n\
  [+/-] To turn 'ON' OR 'OFF' (default is +xtalpull)\n\
  -h    Display this help and exit\n");
}

int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;
   
    MoCA_CONFIG_PARAMS configParms;
    unsigned long long configMask;
    

    // ----------- Parse parameters
    opterr = 0;

    if ((argc < 2) || (argv[1] == NULL) || (argv[1][0] == '+'))
    {
        plusminus = '+';
    }
    else if ((argc >= 2) && (argv[1][0] == '-') && (argv[1][1] == '\0'))
    {
        plusminus = '-';
    }
    else if ((argv[1][1] != 'h') && (argv[1][1] != 'i'))
    {
        fprintf(stderr,"Error!  Invalid option - %s\n", argv[1]);
        return(-1);
    }


    while((ret = getopt(argc, argv, "hi:")) != -1) 
    {
        switch(ret) 
        {
        case 'i':
            chipId = optarg;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-2);
            break;
        case 'h':            
        default:
            showUsage();
            return(0); 
        }
    }


    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-3);
    }

    if (plusminus == '+')
    {
        configParms.freqShiftMode = 1;
    }
    else
    {
        configParms.freqShiftMode = 2;
    }

    configMask = MoCA_CFG_PARAM_FREQ_SHIFT_MASK;

    // ----------- Activate Settings   
    
    cmsret=MoCACtl2_SetCfg(ctx, &configParms, configMask);
    
    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Unable to set freqShiftMode\n");
        MoCACtl_Close(ctx);
        return(-4);
    }

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}


