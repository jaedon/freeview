#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include <mocalib.h>
#include "devctl_moca.h"
#include "cms_psp.h"

static int persistent = 0;     // -M option
static int reset = 0;          // -r option
static char *chipId = NULL;    // -i option
static char *onoff = NULL;


void showUsage()
{
    printf("Usage: ICAP.37 <[ON]/OFF> [-M] [-r] [-h]\n\
Set Golden Node to operate in Preferred NC mode.\n\
Default values will be used if parameters are not supplied.\n\
Note that resetting SoC is required for configuration to take affect.\n\
\n\
Options:\n\
 ON/OFF Turn ON or OFF the Preferred NC mode (default OFF)\n\
  -M    Make configuration changes permanent\n\
  -r    Reset SoC to make configuration changes effective\n\
  -h    Display this help and exit\n");
}

int main(int argc, char **argv)
{
    int ret;
    void *ctx;
    CmsRet cmsret = CMSRET_SUCCESS;

    UINT64 reInitMask = 0;
    MoCA_INITIALIZATION_PARMS reInitParms;    
    

    // ----------- Parse parameters
    opterr = 0;

    if ((argc < 2) || (argv[1] == NULL) || (argv[1][0] == '-'))
    {
        onoff = "ON";
    }
    else
    {
        onoff = argv[1];
    }
    if ((strcmp(onoff, "ON") != 0) && (strcmp(onoff, "OFF") != 0))
    {
        fprintf(stderr,"Error!  Invalid parameter - %s\n",onoff);
        return(-3);
    }

    while((ret = getopt(argc, argv, "Mrhi:")) != -1) 
    {
        switch(ret) 
        {
        case 'i':
            chipId = optarg;
            break;
        case 'M':
            persistent = 1;
            break;
        case 'r':
            reset = 1;
            break;
        case '?':
            fprintf(stderr, "Error!  Invalid option - %c\n", optopt);
            return(-1);
            break;
        case 'h':            
        default:
            showUsage();
            return(0); 
        }
    }


    // ----------- Initialize

    ctx=MoCACtl_Open(chipId);

    if (!ctx)
    {
        fprintf(stderr, "Error!  Unable to connect to moca instance\n");
        return(-2);
    }

    // ----------- Save Settings 
    
    MoCACtl2_GetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS));

    if (strcmp(onoff, "ON") == 0)
    {
        reInitParms.preferedNC = MoCA_PREFERED_NC_MODE;
    }
    else
    {
        reInitParms.preferedNC = MoCA_NO_PREFERED_NC_MODE;
    }

    reInitMask |= MoCA_INIT_PARAM_PREFERED_NC_MASK;

    cmsret = MoCACtl2_SetInitParms(ctx, &reInitParms, reInitMask);
    if (cmsret != CMSRET_SUCCESS)
    {
       MoCACtl_Close(ctx);
       fprintf(stderr, "Error!  SetInitParms\n");
       return(-4);
    }

    if (persistent)
    {
        MoCACtl2_SetPersistent(ctx, "MoCAINITPARMS", (char *) &reInitParms, sizeof (MoCA_INITIALIZATION_PARMS));
    }

    // ----------- Activate Settings   
    
    if (reset)
    {
        cmsret=MoCACtl2_ReInitialize( 
            ctx,
            &reInitParms, 
            reInitMask,
            NULL,
            0);
    }
    
    if (cmsret != CMSRET_SUCCESS)
    {
        fprintf(stderr, "Error!  Unable to set Preferred NC mode\n");
        MoCACtl_Close(ctx);
        return(-5);
    }

    // ----------- Finish

    MoCACtl_Close(ctx);

    return(0);
}


