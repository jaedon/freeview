#!/usr/bin/perl -w

require "parse_moca_api.pm";

my(%use_struct, %u32_struct, %ie_nums);
my $cb_tbl = "";

sub gen_get($)
{
	my($x) = @_;
	my $proto;
	my @f = @{$$x{'field_list'}};
	my $num_fields = $#f + 1;
	my @fi = @{$$x{'fields_in'}};
	my $num_fields_in = $#fi + 1;
	my $vi = undef;
	my $getfunc = "moca_get";
	my $iename = "IE_$$x{'ucname'}";
	my($h, $c) = ("", "");
	my $private = 0;

	if(defined($$x{'flags'}{'private'})) {
		$proto = "int __moca_get_$$x{'name'}(void *vctx";
		$private = 1;
	} else {
		$proto = "int moca_get_$$x{'name'}(void *vctx";
		$private = 0;
	}

	if($num_fields == 0) {
		die "GET function $$x{'name'} with NONE in args";
	}
	foreach my $fl (keys(%{$$x{'flags'}})) {
		if($fl eq "indexed") {
			$proto .= ", uint32_t idx";
			$iename .= " + idx";
		} elsif($fl eq "private") {
			# no operation
		} else {
			die "unsupported flag $fl in $$x{'name'}\n";
		}
	}
	if($num_fields_in > 0) {
		if(($num_fields_in > 1) || ($fi[0]{'type'} !~ m/32/)) {
			die "fields_in must be a single u32 in $$x{'name'}";
		}
		$vi = $fi[0];
		$proto .= ", $$vi{'type'} $$vi{'name'}";
		$getfunc = "moca_get_inout";
	}

	if(! $use_struct{"$$x{'name'}-get"}) {
		# GET returns single u32
		my $v = $f[0];
		if($$v{'type'} !~ m/32/) {
			die "Single arg must be u32 in $$x{'name'}";
		}
		$proto .= ", $$v{'type'} *$$v{'name'})";
		$h .= "$proto;\n";
		$c .= "$proto\n{\n";
		$c .= "\treturn(${getfunc}(vctx, $iename, ";
		if($num_fields_in > 0) {
			$c .= "&$$vi{'name'}, sizeof($$vi{'name'}), ";
		}
		$c .= "$$v{'name'}, sizeof(*$$v{'name'})));\n";
		$c .= "}\n\n";
	} elsif($u32_struct{"$$x{'name'}-get"}) {
		# GET returns struct of u32's only
		$proto .= ", struct moca_$$x{'name'} *out)";
		$h .= "$proto;\n";
		$c .= "$proto\n{\n";
		$c .= "\treturn(${getfunc}(vctx, $iename, ";
		if($num_fields_in > 0) {
			$c .= "&$$vi{'name'}, sizeof($$vi{'name'}), ";
		}
		$c .= "out, sizeof(*out)));\n";
		$c .= "}\n\n";
	} else {
		# GET returns mixed struct
		$proto .= ", struct moca_$$x{'name'} *out)";
		$h .= "$proto;\n";
		$c .= "$proto\n{\n";
		$c .= "\tint ret;\n";

		if($num_fields_in == 0) {
			$c .= "\tret = moca_get_noswap(vctx, $iename, ".
				"out, sizeof(*out));\n";
		} else {
			$c .= "\tret = moca_get_inout_noswap(vctx, $iename, ".
				"&$$vi{'name'}, sizeof($$vi{'name'}), ".
				"out, sizeof(*out));\n";
		}
		foreach my $y (@{$$x{'field_list'}}) {
			my($type, $name, $val) =
				($$y{'type'}, $$y{'name'}, $$y{'val'});
			if($name =~ m/^RES/) {
				next;
			}
			if($type =~ m/64/) {
				$c .= "\tout->$name = BE64(out->$name);\n";
			} elsif($type =~ m/32/) {
				$c .= "\tout->$name = BE32(out->$name);\n";
			} elsif($type =~ m/16/) {
				$c .= "\tout->$name = BE16(out->$name);\n";
			}
		}
		$c .= "\treturn(ret);\n";
		$c .= "}\n\n";
	}
	if($private) {
		print INT $h;
	} else {
		print H $h;
	}
	print C $c;
}

sub gen_set($)
{
	my($x) = @_;
	my $proto;
	my @f = @{$$x{'field_list'}};
	my $num_fields = $#f + 1;
	my($h, $c) = ("", "");
	my $private = 0;

	foreach my $fl (keys(%{$$x{'flags'}})) {
		if($fl eq "private") {
			$private = 1;
		} else {
			die "unsupported flag $fl in $$x{'name'}\n";
		}
	}
	if($private) {
		$proto = "int __moca_set_$$x{'name'}(void *vctx";
	} else {
		$proto = "int moca_set_$$x{'name'}(void *vctx";
	}

	if($num_fields == 0) {
		$proto .= ")";
		$h .= "$proto;\n";
		$c .= "$proto\n{\n";
		$c .= "\treturn(moca_set(vctx, IE_$$x{'ucname'}, ";
		$c .= "NULL, 0));\n";
		$c .= "}\n\n";
	} elsif(! $use_struct{"$$x{'name'}-set"}) {
		my $v = $f[0];
		if($$v{'type'} !~ m/32/) {
			die "Single arg must be u32 in $$x{'name'}";
		}
		$proto .= ", $$v{'type'} $$v{'name'})";
		$h .= "$proto;\n";
		$c .= "$proto\n{\n";
		$c .= "\treturn(moca_set(vctx, IE_$$x{'ucname'}, ";
		$c .= "&$$v{'name'}, sizeof($$v{'name'})));\n";
		$c .= "}\n\n";
	} elsif($u32_struct{"$$x{'name'}-set"}) {
		$proto .= ", const struct moca_$$x{'name'} *in)";
		$h .= "$proto;\n";
		$c .= "$proto\n{\n";
		$c .= "\treturn(moca_set(vctx, IE_$$x{'ucname'}, ";
		$c .= "in, sizeof(*in)));\n";
		$c .= "}\n\n";
	} else {
		my @varlist;
		my $res_num = 0;

		$proto .= ", struct moca_$$x{'name'} *out)";
		$h .= "$proto;\n";
		$c .= "$proto\n{\n";
		$c .= "\tstruct moca_$$x{'name'} tmp = *out;\n";
		foreach my $y (@{$$x{'field_list'}}) {
			my($type, $name, $val) =
				($$y{'type'}, $$y{'name'}, $$y{'val'});
			if($name =~ m/^RES/ ||
			   (defined($val) && $val eq "AUTO")) {
				my $res = "reserved_".$res_num;
				$name =~ s/^RES/$res/;
				$res_num++;
			}

			if($val eq "auto") {
				next;
			}
			if($name =~ m/^(\S+)\[([0-9]+)\]/) {
				@varlist = ( );
				for($i = 0; $i < $2; $i++) {
					push(@varlist, $1."[$i]");
				}
			} else {
				@varlist = ( $name );
			}
			foreach my $var (@varlist) {
				my $preset = 0;
				my $assign;

				if($val eq "undef") {
					$assign = "tmp.$var";
				} else {
					$assign = $val;
					$preset = 1;
				}
				if($type =~ m/64/) {
					$c .= "\ttmp.$var = BE64($assign);\n";
				} elsif($type =~ m/32/) {
					$c .= "\ttmp.$var = BE32($assign);\n";
				} elsif($type =~ m/16/) {
					$c .= "\ttmp.$var = BE16($assign);\n";
				} elsif($preset == 1) {
					$c .= "\ttmp.$var = $assign;\n";
				}
			}
		}
		$c .= "\treturn(moca_set_noswap(vctx, IE_$$x{'ucname'}, ";
		$c .= "&tmp, sizeof(tmp)));\n";
		$c .= "}\n\n";
	}
	if($private) {
		print INT $h;
	} else {
		print H $h;
	}
	print C $c;
}

sub gen_table($$)
{
	my($x, $action) = @_;
	my $proto;
	my @f = @{$$x{'field_list'}};
	my $num_fields = $#f + 1;

	if($num_fields == 0) {
		die "Missing fields for table operation $$x{'name'}";
	}
	foreach my $fl (keys(%{$$x{'flags'}})) {
		die "unsupported flag $fl in $$x{'name'}\n";
	}
	if(! $u32_struct{"$$x{'name'}-$action"}) {
		die "Non-mixed struct required for table operation $$x{'name'}";
	}

	if($action eq "get_table") {
		$proto = "int moca_get_$$x{'name'}(void *vctx, ".
			"struct moca_$$x{'name'} *out, int max_out_len)";
		print H "$proto;\n";

		print C "$proto\n".
			"{\n".
			"\treturn(moca_${action}(vctx, IE_$$x{'ucname'}, ".
			"out, sizeof(*out), max_out_len));\n".
			"}\n\n";
	} elsif($action =~ m/(...)_entry/) {
		my $shortaction = $1;
		my $m = "MOCA_MSG_${shortaction}_ENTRY";
		$m =~ tr/a-z/A-Z/;

		$proto = "int moca_${shortaction}_$$x{'name'}(void *vctx, ".
			"const struct moca_$$x{'name'} *entry)";
		print H "$proto;\n";

		print C "$proto\n".
			"{\n".
			"\treturn(moca_table_op(vctx, $m, IE_$$x{'ucname'}, ".
			"entry, sizeof(*entry)));\n".
			"}\n\n";
	}
}

sub gen_event($)
{
	my($x) = @_;
	my $proto = "void moca_register_$$x{'name'}_cb(void *vctx, ".
		"void (*callback)(void *userarg";
	my @f = @{$$x{'field_list'}};
	my $num_fields = $#f + 1;
	my $iename = "IE_$$x{'ucname'}";
	my $intproto;

	my $len_chk =
		"\tif(in_len != sizeof(*in))\n".
		"\t\treturn(-1);\n";

	foreach my $fl (keys(%{$$x{'flags'}})) {
		if($fl eq "var_len") {
			$len_chk =
				"\tif(in_len > sizeof(*in))\n".
				"\t\treturn(-2);\n";
		} else {
			die "unsupported flag $fl in $$x{'name'}\n";
		}
	}

	print C "static inline int mocalib_handle_$$x{'name'}".
			"(void *vctx, void *vin, int in_len)\n".
		"{\n".
		"\tstruct moca_ctx *ctx = (struct moca_ctx*) vctx;\n";

	if($num_fields == 0) {
		# no args, event notification only
		$intproto = "(*$$x{'name'}_cb)(void *);";

		$proto .= "), void *userarg)";

		print C "\tif(ctx->cb.$$x{'name'}_cb == NULL)\n".
				"\t\treturn(-3);\n".
				"\tctx->cb.$$x{'name'}_cb(ctx->cb.$$x{'name'}_userarg);\n";
	} elsif(! $use_struct{"$$x{'name'}-event"}) {
		# one non-struct arg
		my $v = $f[0];
		if($$v{'type'} !~ m/32/) {
			die "Single arg must be u32 in $$x{'name'}";
		}
		$intproto = "(*$$x{'name'}_cb)(void *, ".
			"$$v{'type'} $$v{'name'});";
		$proto .= ", $$v{'type'} $$v{'name'}), void *userarg)";

		print C "\t$$v{'type'} *in = ($$v{'type'} *)vin;\n".
			$len_chk.
			"\tif(ctx->cb.$$x{'name'}_cb == NULL)\n".
			"\t\treturn(-3);\n".
			"\tctx->cb.$$x{'name'}_cb(ctx->cb.$$x{'name'}_userarg, BE32(*in));\n";
	} elsif($u32_struct{"$$x{'name'}-event"}) {
		# struct of u32's only
		$intproto = "(*$$x{'name'}_cb)(void *, ".
			"struct moca_$$x{'name'} *);";
		$proto .= ", struct moca_$$x{'name'} *out), void *userarg)";

		print C "\tstruct moca_$$x{'name'} *in = (struct moca_$$x{'name'} *)vin;\n".
			$len_chk.
			"\t__moca_copy_be32(in, in, sizeof(*in));\n".
			"\tif(ctx->cb.$$x{'name'}_cb == NULL)\n".
			"\t\treturn(-4);\n".
			"\tctx->cb.$$x{'name'}_cb(ctx->cb.$$x{'name'}_userarg, in);\n";
	} else {
		# mixed struct
		$intproto = "(*$$x{'name'}_cb)(void *, ".
			"struct moca_$$x{'name'} *);";
		$proto .= ", struct moca_$$x{'name'} *out), void *userarg)";

		# add "int i" if any of the >8-bit fields is an array
		my $need_int_i = 0;
		foreach my $y (@{$$x{'field_list'}}) {
			my($type, $name, $val) =
				($$y{'type'}, $$y{'name'}, $$y{'val'});
			if($type =~ m/(64)|(32)|(16)/ &&
					$name =~ m/(\S+)\[(\d+)\]/) {
				$need_int_i = 1;
			}
		}
		if($need_int_i) {
			print C "\tint i;\n";
		}

		# declare output struct; add in_len check
		print C "\tstruct moca_$$x{'name'} *in = (struct moca_$$x{'name'} *)vin;\n".
			$len_chk;

		# endian translation for each field
		foreach my $y (@{$$x{'field_list'}}) {
			my($type, $name, $val) =
				($$y{'type'}, $$y{'name'}, $$y{'val'});
			my $trans = "";

			if($name =~ m/^RES/) {
				next;
			}
			if($type =~ m/64/) {
				$trans = "BE64";
			} elsif($type =~ m/32/) {
				$trans = "BE32";
			} elsif($type =~ m/16/) {
				$trans = "BE16";
			} else {
				# no translation
				next;
			}
			if($name =~ m/(\S+)\[(\d+)\]/) {
				# array
				my($var, $sub) = ($1, $2);
				print C "\tfor(i = 0; i < $sub; i++)\n";
				print C "\t\tin->${var}[i] = ".
					"${trans}(in->${var}[i]);\n";
			} else {
				print C "\tin->$name = ${trans}(in->$name);\n";
			}
		}

		print C "\tif(ctx->cb.$$x{'name'}_cb == NULL)\n";
		print C "\t\treturn(-5);\n";

		print C "\tctx->cb.$$x{'name'}_cb(ctx->cb.$$x{'name'}_userarg, in);\n";
	}

	print C "\treturn(0);\n".
		"}\n\n";

	$cb_tbl .= "\tvoid\t\t\t$intproto\n";
	$cb_tbl .= "\tvoid\t\t\t*$$x{'name'}_userarg;\n\n";

	print H "$proto;\n";
	print C "$proto\n{\n";
	print C "\tstruct moca_ctx *ctx = (struct moca_ctx *)vctx;\n";
	print C "\tctx->cb.$$x{'name'}_cb = callback;\n";
	print C "\tctx->cb.$$x{'name'}_userarg = userarg;\n";
	print C "}\n\n";
}


sub tab($$$)
{
	my($i0, $i1, $col) = @_;
	my($i);

	$col--;

	$i = length($i0);
	do {
		$i0 .= "\t";
		$i += 8 - ($i % 8);
	} while($i < $col);
	$i0 .= $i1;
	return($i0);
}

#
# MAIN
#

my($parser)=new parse_moca_api;
my @ie_list = @{$parser->Run};

umask(0022);

open(H, ">mocalib-gen.h") or die;
open(C, ">mocalib-gen.c") or die;
open(INT, ">mocaint-gen.h") or die;
open(MMPDUMP, ">mmpdump-gen.c") or die;

print MMPDUMP
"/***************************************************************************\n".
" *\n".
" *     Copyright (c) 2011, Broadcom Corporation\n".
" *     All Rights Reserved\n".
" *     Confidential Property of Broadcom Corporation\n".
" *\n".
" *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE\n".
" *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR\n".
" *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.\n".
" *\n".
" *  Description: Generated mmp utility functions - DO NOT EDIT\n".
" *\n".
" ***************************************************************************/\n".
"\n".
"#include <string.h>\n".
"\n".
"#include \"mocalib.h\"\n".
"#include \"mocaint.h\"\n\n";

print C
"/***************************************************************************\n".
" *\n".
" *     Copyright (c) 2008-2009, Broadcom Corporation\n".
" *     All Rights Reserved\n".
" *     Confidential Property of Broadcom Corporation\n".
" *\n".
" *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE\n".
" *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR\n".
" *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.\n".
" *\n".
" *  Description: Generated libmoca functions - DO NOT EDIT\n".
" *\n".
" ***************************************************************************/\n".
"\n";

print C "const char *moca_ie_name(uint16_t ie_type)\n";
print C "{\n";
print C "\tswitch(ie_type) {\n";

my $last_ie_num = -1;

# IE #define's and ascii translation

foreach my $x (@ie_list)
{
	my $name = $$x{"name"};
	$name =~ tr/a-z/A-Z/;
	$$x{'ucname'} = $name;

	if(defined($ie_nums{$name})) {
		if($ie_nums{$name} ne $$x{'ie_num'}) {
			die "duplicate IE name: $name";
		}
	} else {
		print INT tab("#define IE_$name", $$x{'ie_num'}, 41)."\n";
		if($$x{'ie_num'} ne $last_ie_num) {
			print C "\t\tcase IE_$name:\n\t\t\treturn(\"$name\");\n";
		}
		$last_ie_num = $$x{'ie_num'};
		$ie_nums{$name} = $$x{'ie_num'};
	}
}

print C "\t}\n";
print C "\treturn(NULL);\n";
print C "}\n";
print C "\n";


# get IE from name
print MMPDUMP "unsigned int moca_name_ie(const char *name)\n";
print MMPDUMP "{\n";

$last_ie_num = -1;

foreach my $x (@ie_list)
{
	my $name = $$x{"name"};
	$name =~ tr/a-z/A-Z/;
	$$x{'ucname'} = $name;

	if($$x{'ie_num'} ne $last_ie_num) {	    
		print MMPDUMP "\tif (strcasecmp(\"$name\", name)==0) return IE_$name;\n";
	}
	$last_ie_num = $$x{'ie_num'};
	$ie_nums{$name} = $$x{'ie_num'};
}

print MMPDUMP "\treturn(-1);\n";
print MMPDUMP "}\n";
print MMPDUMP "\n";


print MMPDUMP "#define OFFSET_OF(STRUCT,MEMBER) ((unsigned int)&((struct moca_##STRUCT *)0)->MEMBER)\n\n";
print MMPDUMP "unsigned int moca_field_offset(const char *name)\n";
print MMPDUMP "{\n";

print INT "\n";

# struct for each IE type

foreach my $x (@ie_list)
{
	my $list = $$x{'field_list'};
	my $elem = $#{$list} + 1;
	my $f0name = $elem > 0 ? ${$$list[0]}{'name'} : "";
	my $is_u32 = 1;
	my $struct = "";

	#print "$$x{'name'} $elem $f0name\n";

	if(($elem > 1) ||
	   ($elem == 1 && $f0name =~ m/\[/)) {
		my $offset = 0;
		my $res_num = 0;
		$struct .= "struct moca_$$x{'name'} \{\n";
		foreach my $y (@{$$x{'field_list'}}) {
			my($name, $type, $val) =
				($$y{'name'}, $$y{'type'}, $$y{'val'});
			my $elements = 1;



			if($name =~ m/^RES/ ||
			   (defined($val) && $val eq "AUTO")) {
				my $res = "reserved_".$res_num;
				$name =~ s/^RES/$res/;
				$res_num++;
				print MMPDUMP "\tif (strcasecmp(\"$$x{'name'}.$res\",name)==0) return OFFSET_OF($$x{'name'},$res);\n";
			} else {			
				print MMPDUMP "\tif (strcasecmp(\"$$x{'name'}.$$y{'name'}\",name)==0) return OFFSET_OF($$x{'name'},$$y{'name'});\n";
			}	

			if($name =~ m/\[([0-9]+)\]/) {
				$elements = $1;
			}
			if($type =~ m/64/) {
				if($offset & 7) {
					die "unaligned u64 $name on '$$x{'name'}";
				}
				$is_u32 = 0;
				$offset += 8 * $elements;
			} elsif($type =~ m/32/) {
				if($offset & 3) {
					die "unaligned u32 $name on '$$x{'name'}";
				}
				$offset += 4 * $elements;
			} elsif($type =~ m/16/) {
				if($offset & 1) {
					die "unaligned u16 $name on '$$x{'name'}";
				}
				$is_u32 = 0;
				$offset += 2 * $elements;
			} elsif($type =~ m/8/) {
				$is_u32 = 0;
				$offset += 1 * $elements;
			} else {
				die "unknown type $type";
			}
			$struct .= "\t".tab($type, "$name;\n", 25);
		}
		$struct .= "\} __attribute__((packed,aligned(4)));\n\n";

		foreach my $y (@{$$x{'action_list'}}) {
			$use_struct{$$x{'name'}.'-'.$y} = 1;
			$u32_struct{$$x{'name'}.'-'.$y} = $is_u32;
		}

		if(defined($$x{'flags'}{'private'})) {
			print INT $struct;
		} else {
			print H $struct;
		}
	}
}

print MMPDUMP "\treturn(-1);\n";
print MMPDUMP "}\n";
print MMPDUMP "\n";


my @events = ( );

$cb_tbl = "struct mocalib_cb_tbl {\n";

my $last_name = "";

foreach my $x (@ie_list)
{
	if(defined($$x{'flags'}{'private'})) {
		foreach my $y (@{$$x{'action_list'}}) {
			if($y eq "get") {
				gen_get($x);
			}
			if($y eq "set") {
				gen_set($x);
			}
		}
		next;
	}

	if($last_name ne "" && $$x{'name'} ne $last_name) {
		print H "\n";
	}
	$last_name = $$x{'name'};

	foreach my $y (@{$$x{'action_list'}}) {
		if($y eq "get") {
			gen_get($x);
		}
		if($y eq "set") {
			gen_set($x);
		}
		if($y eq "get_table" || $y eq "add_entry" || $y eq "del_entry") {
			gen_table($x, $y);
		}
		if($y eq "event") {
			# generates cb table entry
			gen_event($x);
			push(@events, $x);
		}
	}
}

$cb_tbl .= "};\n";

print INT "\n";
print INT $cb_tbl;

print C "static inline int mocalib_dispatch_event(void *vctx, uint16_t ".
	"ie_type, void *vin, int in_len)\n".
	"{\n".
	"\tswitch(ie_type) {\n";

foreach my $x (@events) {
	print C "\t\tcase IE_$$x{'ucname'}:\n".
		"\t\t\treturn(mocalib_handle_$$x{'name'}(vctx, vin, in_len));\n";
}

print C "\t}\n".
	"\treturn(-6);\n".
	"}\n\n";


# get function from IE
print MMPDUMP "void *moca_get_fn(unsigned int ie)\n";
print MMPDUMP "{\n";
printf MMPDUMP "\tswitch(ie)\n";
printf MMPDUMP "\t{\n";

$last_ie_num = -1;

foreach my $x (@ie_list)
{
	my $name = $$x{"name"};
	$name =~ tr/a-z/A-Z/;
	$$x{'ucname'} = $name;

	if($$x{'ie_num'} ne $last_ie_num) {	    
		foreach my $y (@{$$x{'action_list'}}) {
			if($y eq "get") {
				print MMPDUMP "\t\tcase IE_$name: return &moca_get_$$x{'name'};\n";
			}
			if($y eq "get_table") {
				print MMPDUMP "\t\tcase IE_$name: return &moca_get_$$x{'name'};\n";
			}
		}
	}
	$last_ie_num = $$x{'ie_num'};
	$ie_nums{$name} = $$x{'ie_num'};
}

print MMPDUMP "\t}\n";
print MMPDUMP "\treturn(NULL);\n";
print MMPDUMP "}\n";
print MMPDUMP "\n";

# get function type from IE
print MMPDUMP "int moca_indexed_fn(unsigned int ie)\n";
print MMPDUMP "{\n";
printf MMPDUMP "\tswitch(ie)\n";
printf MMPDUMP "\t{\n";

$last_ie_num = -1;

foreach my $x (@ie_list)
{
	my $name = $$x{"name"};
	$name =~ tr/a-z/A-Z/;
	$$x{'ucname'} = $name;

	$indexed="0";
	
	if($$x{'ie_num'} ne $last_ie_num) {	    
		foreach my $fl (keys(%{$$x{'flags'}})) {
			if($fl eq "indexed") {
				$indexed="1";
			} 
		}

		print MMPDUMP "\t\tcase IE_$name: return $indexed;\n";
	}
	$last_ie_num = $$x{'ie_num'};
	$ie_nums{$name} = $$x{'ie_num'};
}

print MMPDUMP "\t}\n";
print MMPDUMP "\treturn(-1);\n";
print MMPDUMP "}\n";
print MMPDUMP "\n";
	

#system("indent -npro -kr -i8 -ip8 -l78 -ts8 -sob -ss -ncs -cp1 moca{lib,int}-gen.[ch]");
