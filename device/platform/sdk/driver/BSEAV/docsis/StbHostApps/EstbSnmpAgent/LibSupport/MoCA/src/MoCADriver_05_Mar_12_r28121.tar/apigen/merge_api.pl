#!/usr/bin/perl -w
use File::Copy;

if($#ARGV != 1) {
	die "usage: merge_api.pl <mocalib.h> <mocalib-gen.h>";
}

$nongen = $ARGV[0];
$gen = $ARGV[1];
$nongen_new = $ARGV[0].".new";

open(IN0, "<$nongen") or die "can't open $nongen: $!";
open(IN1, "<$gen") or die "can't open $gen: $!";
open(OUT, ">$nongen_new") or die "can't open $nongen_new: $!";

while(<IN0>) {
	print OUT $_;
	if(m/GENERATED .*DO NOT EDIT/) {
		print OUT "\n";
		while(<IN1>) {
			print OUT $_;
		}
		while(<IN0>) {
			if(m/GENERATED .*DO NOT EDIT/) {
				print OUT "\n";
				print OUT $_;
				last;
			}
		}
	}
}

close(IN0) || warn "close $nongen failed: $!";
close(IN1) || warn "close $gen failed: $!";
close(OUT) || warn "close $nongen_new failed: $!";

move($nongen_new, $nongen) or die "can't overwrite old copy of $nongen: $!";
exit 0;
