####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package parse_moca_api;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
use Parse::Yapp::Driver;



sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			'T_IE' => 3
		},
		GOTOS => {
			'ie' => 1,
			'input' => 2
		}
	},
	{#State 1
		DEFAULT => -1
	},
	{#State 2
		ACTIONS => {
			'' => 5,
			'T_IE' => 3
		},
		GOTOS => {
			'ie' => 4
		}
	},
	{#State 3
		ACTIONS => {
			'NUM' => 6
		}
	},
	{#State 4
		DEFAULT => -2
	},
	{#State 5
		DEFAULT => 0
	},
	{#State 6
		ACTIONS => {
			'T_WORD' => 7
		}
	},
	{#State 7
		ACTIONS => {
			'T_ACTIONS' => 8
		}
	},
	{#State 8
		ACTIONS => {
			'T_EVENT' => 11,
			'T_SET_NV' => 9,
			'T_ADD_ENTRY' => 13,
			'T_GET_TABLE' => 10,
			'T_DEL_ENTRY' => 17,
			'T_SET' => 16,
			'T_GET' => 15,
			'T_GET_INDEXED' => 18
		},
		GOTOS => {
			'actionlist' => 12,
			'action' => 14
		}
	},
	{#State 9
		DEFAULT => -11
	},
	{#State 10
		DEFAULT => -7
	},
	{#State 11
		DEFAULT => -10
	},
	{#State 12
		ACTIONS => {
			'T_SET_NV' => 9,
			'T_GET_TABLE' => 10,
			'T_FLAGS' => 19,
			'T_EVENT' => 11,
			'T_ADD_ENTRY' => 13,
			'T_GET' => 15,
			'T_DEL_ENTRY' => 17,
			'T_SET' => 16,
			'T_GET_INDEXED' => 18
		},
		DEFAULT => -35,
		GOTOS => {
			'opt_flags' => 20,
			'action' => 21
		}
	},
	{#State 13
		DEFAULT => -8
	},
	{#State 14
		DEFAULT => -13
	},
	{#State 15
		DEFAULT => -4
	},
	{#State 16
		DEFAULT => -6
	},
	{#State 17
		DEFAULT => -9
	},
	{#State 18
		DEFAULT => -5
	},
	{#State 19
		ACTIONS => {
			'T_NONE' => 24,
			'T_WORD' => 23
		},
		GOTOS => {
			'flags' => 22,
			'flaglist' => 25
		}
	},
	{#State 20
		ACTIONS => {
			'T_FIELDS_IN' => 27
		},
		DEFAULT => -36,
		GOTOS => {
			'opt_fields_in' => 26
		}
	},
	{#State 21
		DEFAULT => -12
	},
	{#State 22
		ACTIONS => {
			'T_WORD' => 28
		},
		DEFAULT => -33
	},
	{#State 23
		DEFAULT => -30
	},
	{#State 24
		DEFAULT => -32
	},
	{#State 25
		DEFAULT => -34
	},
	{#State 26
		ACTIONS => {
			'T_FIELDS' => 31,
			'T_FIELDS_OUT' => 30
		},
		GOTOS => {
			'opt_fields_out' => 29
		}
	},
	{#State 27
		ACTIONS => {
			'T_U32' => 33,
			'T_S64' => 32,
			'T_U64' => 35,
			'T_S16' => 34,
			'T_U8' => 36,
			'T_NONE' => 38,
			'T_S32' => 40,
			'T_U16' => 42,
			'T_S8' => 43
		},
		DEFAULT => -22,
		GOTOS => {
			'fields' => 39,
			'type' => 41,
			'field' => 44,
			'fieldlist' => 37
		}
	},
	{#State 28
		DEFAULT => -31
	},
	{#State 29
		DEFAULT => -3
	},
	{#State 30
		ACTIONS => {
			'T_U32' => 33,
			'T_S64' => 32,
			'T_U64' => 35,
			'T_S16' => 34,
			'T_U8' => 36,
			'T_NONE' => 38,
			'T_S32' => 40,
			'T_U16' => 42,
			'T_S8' => 43
		},
		DEFAULT => -22,
		GOTOS => {
			'fields' => 39,
			'type' => 41,
			'field' => 44,
			'fieldlist' => 45
		}
	},
	{#State 31
		ACTIONS => {
			'T_U32' => 33,
			'T_S64' => 32,
			'T_U64' => 35,
			'T_S16' => 34,
			'T_U8' => 36,
			'T_NONE' => 38,
			'T_S32' => 40,
			'T_U16' => 42,
			'T_S8' => 43
		},
		DEFAULT => -22,
		GOTOS => {
			'fields' => 39,
			'type' => 41,
			'field' => 44,
			'fieldlist' => 46
		}
	},
	{#State 32
		DEFAULT => -18
	},
	{#State 33
		DEFAULT => -15
	},
	{#State 34
		DEFAULT => -20
	},
	{#State 35
		DEFAULT => -14
	},
	{#State 36
		DEFAULT => -17
	},
	{#State 37
		DEFAULT => -37
	},
	{#State 38
		DEFAULT => -28
	},
	{#State 39
		ACTIONS => {
			'T_U32' => 33,
			'T_S64' => 32,
			'T_WORD' => -22,
			'T_U64' => 35,
			'T_S16' => 34,
			'T_U8' => 36,
			'T_S32' => 40,
			'T_U16' => 42,
			'T_S8' => 43
		},
		DEFAULT => -29,
		GOTOS => {
			'type' => 41,
			'field' => 47
		}
	},
	{#State 40
		DEFAULT => -19
	},
	{#State 41
		ACTIONS => {
			'T_WORD' => 48
		}
	},
	{#State 42
		DEFAULT => -16
	},
	{#State 43
		DEFAULT => -21
	},
	{#State 44
		DEFAULT => -26
	},
	{#State 45
		DEFAULT => -39
	},
	{#State 46
		DEFAULT => -38
	},
	{#State 47
		DEFAULT => -27
	},
	{#State 48
		ACTIONS => {
			'T_EQUAL' => 49
		},
		DEFAULT => -23
	},
	{#State 49
		ACTIONS => {
			'NUM' => 51,
			'T_AUTO' => 50
		}
	},
	{#State 50
		DEFAULT => -25
	},
	{#State 51
		DEFAULT => -24
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'input', 1,
sub
#line 3 "parse_moca_api.yp"
{ [ $_[1] ]; }
	],
	[#Rule 2
		 'input', 2,
sub
#line 4 "parse_moca_api.yp"
{ push(@{$_[1]}, $_[2]); $_[1]; }
	],
	[#Rule 3
		 'ie', 8,
sub
#line 10 "parse_moca_api.yp"
{
                                  {
                                    name        => $_[3],
                                    ie_num      => $_[2],
                                    action_list => $_[5],
                                    flags       => $_[6],
                                    fields_in   => $_[7],
                                    field_list  => $_[8],
                                  };
                                }
	],
	[#Rule 4
		 'action', 1,
sub
#line 22 "parse_moca_api.yp"
{ "get"; }
	],
	[#Rule 5
		 'action', 1,
sub
#line 23 "parse_moca_api.yp"
{ "get_indexed"; }
	],
	[#Rule 6
		 'action', 1,
sub
#line 24 "parse_moca_api.yp"
{ "set"; }
	],
	[#Rule 7
		 'action', 1,
sub
#line 25 "parse_moca_api.yp"
{ "get_table"; }
	],
	[#Rule 8
		 'action', 1,
sub
#line 26 "parse_moca_api.yp"
{ "add_entry"; }
	],
	[#Rule 9
		 'action', 1,
sub
#line 27 "parse_moca_api.yp"
{ "del_entry"; }
	],
	[#Rule 10
		 'action', 1,
sub
#line 28 "parse_moca_api.yp"
{ "event"; }
	],
	[#Rule 11
		 'action', 1,
sub
#line 29 "parse_moca_api.yp"
{ "set_nv"; }
	],
	[#Rule 12
		 'actionlist', 2,
sub
#line 32 "parse_moca_api.yp"
{ push(@{$_[1]}, $_[2]); $_[1]; }
	],
	[#Rule 13
		 'actionlist', 1,
sub
#line 33 "parse_moca_api.yp"
{ [ $_[1] ]; }
	],
	[#Rule 14
		 'type', 1,
sub
#line 36 "parse_moca_api.yp"
{ "uint64_t"; }
	],
	[#Rule 15
		 'type', 1,
sub
#line 37 "parse_moca_api.yp"
{ "uint32_t"; }
	],
	[#Rule 16
		 'type', 1,
sub
#line 38 "parse_moca_api.yp"
{ "uint16_t"; }
	],
	[#Rule 17
		 'type', 1,
sub
#line 39 "parse_moca_api.yp"
{ "uint8_t"; }
	],
	[#Rule 18
		 'type', 1,
sub
#line 40 "parse_moca_api.yp"
{ "int64_t"; }
	],
	[#Rule 19
		 'type', 1,
sub
#line 41 "parse_moca_api.yp"
{ "int32_t"; }
	],
	[#Rule 20
		 'type', 1,
sub
#line 42 "parse_moca_api.yp"
{ "int16_t"; }
	],
	[#Rule 21
		 'type', 1,
sub
#line 43 "parse_moca_api.yp"
{ "int8_t"; }
	],
	[#Rule 22
		 'type', 0,
sub
#line 44 "parse_moca_api.yp"
{ "uint32_t"; }
	],
	[#Rule 23
		 'field', 2,
sub
#line 47 "parse_moca_api.yp"
{
                                          {
                                            'type' => $_[1],
                                            'name' => $_[2],
                                            'val' => "undef",
                                          };
                                        }
	],
	[#Rule 24
		 'field', 4,
sub
#line 54 "parse_moca_api.yp"
{
                                          {
                                            'type' => $_[1],
                                            'name' => $_[2],
                                            'val' => $_[4],
                                          };
                                        }
	],
	[#Rule 25
		 'field', 4,
sub
#line 61 "parse_moca_api.yp"
{
                                          {
                                            'type' => $_[1],
                                            'name' => $_[2],
                                            'val' => "auto",
                                          };
                                        }
	],
	[#Rule 26
		 'fields', 1,
sub
#line 70 "parse_moca_api.yp"
{ [ $_[1] ]; }
	],
	[#Rule 27
		 'fields', 2,
sub
#line 71 "parse_moca_api.yp"
{ push(@{$_[1]}, $_[2]); $_[1]; }
	],
	[#Rule 28
		 'fieldlist', 1,
sub
#line 74 "parse_moca_api.yp"
{ [ ]; }
	],
	[#Rule 29
		 'fieldlist', 1,
sub
#line 75 "parse_moca_api.yp"
{ $_[1]; }
	],
	[#Rule 30
		 'flags', 1,
sub
#line 78 "parse_moca_api.yp"
{ { "$_[1]" => 1 }; }
	],
	[#Rule 31
		 'flags', 2,
sub
#line 79 "parse_moca_api.yp"
{ ${$_[1]}{$_[2]} = 1; $_[1]; }
	],
	[#Rule 32
		 'flaglist', 1,
sub
#line 82 "parse_moca_api.yp"
{ { }; }
	],
	[#Rule 33
		 'flaglist', 1,
sub
#line 83 "parse_moca_api.yp"
{ $_[1]; }
	],
	[#Rule 34
		 'opt_flags', 2,
sub
#line 86 "parse_moca_api.yp"
{ $_[2]; }
	],
	[#Rule 35
		 'opt_flags', 0,
sub
#line 87 "parse_moca_api.yp"
{ { }; }
	],
	[#Rule 36
		 'opt_fields_in', 0,
sub
#line 90 "parse_moca_api.yp"
{ [ ]; }
	],
	[#Rule 37
		 'opt_fields_in', 2,
sub
#line 91 "parse_moca_api.yp"
{ $_[2]; }
	],
	[#Rule 38
		 'opt_fields_out', 2,
sub
#line 95 "parse_moca_api.yp"
{ $_[2]; }
	],
	[#Rule 39
		 'opt_fields_out', 2,
sub
#line 96 "parse_moca_api.yp"
{ $_[2]; }
	]
],
                                  @_);
    bless($self,$class);
}

#line 99 "parse_moca_api.yp"


sub _Error {
    die "Syntax error";
}

sub _Lexer {
    my($parser)=shift;
    my $in;

    while(1) {
            $parser->YYData->{INPUT}
        or  $parser->YYData->{INPUT} = <>
        or  return('',undef);

        $parser->YYData->{INPUT} =~ s/#.*//;
        $parser->YYData->{INPUT} =~ s/^\s+//;

        if($parser->YYData->{INPUT} =~ s/^(\S+)//) {
            $in = $1;
            last;
        }
    }
    #print "TOKEN: '$in'\n";

    if($in =~ m/^(0x[0-9a-f]+)$/i) {    return('NUM', $in);
    } elsif($in =~ m/^([0-9]+)$/i) {    return('NUM', $in);
    } elsif($in eq "ie:") {             return('T_IE', $in);
    } elsif($in eq "actions:") {        return('T_ACTIONS', $in);
    } elsif($in eq "fields:") {         return('T_FIELDS', $in);
    } elsif($in eq "fields_in:") {      return('T_FIELDS_IN', $in);
    } elsif($in eq "fields_out:") {     return('T_FIELDS_OUT', $in);
    } elsif($in eq "flags:") {          return('T_FLAGS', $in);
    } elsif($in eq "=") {               return('T_EQUAL', $in);
    } elsif($in eq "u64") {             return('T_U64', $in);
    } elsif($in eq "u32") {             return('T_U32', $in);
    } elsif($in eq "u16") {             return('T_U16', $in);
    } elsif($in eq "u8") {              return('T_U8', $in);
    } elsif($in eq "s64") {             return('T_S64', $in);
    } elsif($in eq "s32") {             return('T_S32', $in);
    } elsif($in eq "s16") {             return('T_S16', $in);
    } elsif($in eq "s8") {              return('T_S8', $in);
    } elsif($in eq "get") {             return('T_GET', $in);
    } elsif($in eq "get_indexed") {     return('T_GET_INDEXED', $in);
    } elsif($in eq "set") {             return('T_SET', $in);
    } elsif($in eq "get_table") {       return('T_GET_TABLE', $in);
    } elsif($in eq "add_entry") {       return('T_ADD_ENTRY', $in);
    } elsif($in eq "del_entry") {       return('T_DEL_ENTRY', $in);
    } elsif($in eq "event") {           return('T_EVENT', $in);
    } elsif($in eq "set_nv") {          return('T_SET_NV', $in);
    } elsif($in eq "AUTO") {            return('T_AUTO', $in);
    } elsif($in eq "NONE") {            return('T_NONE', $in);
    } else {                            return('T_WORD', $in);
    }
}

sub Run {
    my($self)=shift;
    $self->YYParse( yylex => \&_Lexer, yyerror => \&_Error );
}

1;

1;
