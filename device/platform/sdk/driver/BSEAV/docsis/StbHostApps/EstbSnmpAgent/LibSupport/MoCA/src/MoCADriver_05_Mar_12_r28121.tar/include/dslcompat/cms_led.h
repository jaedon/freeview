/***********************************************************************
 *
 *  Copyright (c) 2006-2007  Broadcom Corporation
 *  All Rights Reserved
 *
<:license-public
 *
 ************************************************************************/

#ifndef __CMS_LED_H__
#define __CMS_LED_H__


/*!\file cms_led.h
 * \brief Header file for the CMS LED API.
 *  This is in the cms_util library.
 *
 */

#include "cms.h"


void cmsLed_setPppConnected(void);

void cmsLed_setPppDisconnected(void);

void cmsLed_setPppFailed(void);


#endif /* __CMS_LED_H__ */
