/******************************************************************************
 *
 *  Copyright (c) 2010  Broadcom Corporation
 *  All Rights Reserved
 *
<:license-private
 *
 ************************************************************************/

/***************************************************************************
 *
 *     Copyright (c) 2010, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *  Description: MoCA OS Abstraction Layer
 *
 ***************************************************************************/

#ifndef __MOCA_OS_H__
#define __MOCA_OS_H__

#include <stdint.h>

typedef uintptr_t MoCAOS_Handle;
typedef uintptr_t MoCAOS_ClientHandle;
typedef uintptr_t MoCAOS_MutexHandle;
typedef uintptr_t MoCAOS_ThreadHandle;

typedef void (*MoCAOS_ThreadEntry)(void *);

#define MoCAOS_TIMEOUT_INFINITE 0xFFFFFFFF

#define MoCAOS_CLIENT_NULL      (MoCAOS_ClientHandle)0xFFFFFFFF
#define MoCAOS_CLIENT_TIMEOUT   (MoCAOS_ClientHandle)0xFFFFFFFE
#define MoCAOS_CLIENT_CORE      (MoCAOS_ClientHandle)0xFFFFFFFD
#define MoCAOS_CLIENT_BROADCAST (MoCAOS_ClientHandle)0xFFFFFFFC
#define MoCAOS_CLIENT_NL        (MoCAOS_ClientHandle)0xFFFFFFFB

#define MoCAOS_CLIENT_TOP       (MoCAOS_ClientHandle)0xFFFFFFFA
#define MoCAOS_CLIENT_BASE      (MoCAOS_ClientHandle)0

#define MOCAOS_INVALID_THREAD   ((MoCAOS_ThreadHandle)0)
#define MoCAOS_IFNAMSIZE        16

#if (!defined(_GNU_SOURCE) && !defined(DSL_MOCA))
#define __attribute__(x)   
#endif

typedef struct _MoCAOS_DrvInfo {
    unsigned int version;
    unsigned int build_number;
    unsigned int builtin_fw;

    unsigned int hw_rev;
    unsigned int rf_band;

    unsigned int uptime;
    int refcount;
    unsigned int gp1;

    char enet_name[MoCAOS_IFNAMSIZE];
    unsigned int enet_id;

    unsigned int macaddr_hi;
    unsigned int macaddr_lo;

    unsigned int phy_freq;
    unsigned int cpu_freq;

    unsigned int chip_id;
} MoCAOS_DrvInfo;


MoCAOS_Handle MoCAOS_Init(const char *chardev, char *ifname, const char *workdir, int daemon);

MoCAOS_ClientHandle MoCAOS_WaitForRequest(MoCAOS_Handle handle, unsigned int timeout_sec);
int MoCAOS_SendMMP(MoCAOS_Handle handle, MoCAOS_ClientHandle client, const unsigned char *IE, int len);
int MoCAOS_ReadMMP(MoCAOS_Handle handle, MoCAOS_ClientHandle client, 
    unsigned int timeout_sec, unsigned char *IE, int *len);  // return 0 timeout, <0 failure, >0 success
int MoCAOS_ReadMem(MoCAOS_Handle handle, unsigned char *buf, int len, unsigned char *addr);
int MoCAOS_WriteMem(MoCAOS_Handle handle, unsigned char *buf, int len, unsigned char *addr);
int MoCAOS_StartCore(MoCAOS_Handle handle, unsigned char *fw_img, int fw_len, 
    unsigned int cont_tx_mode, unsigned char **strings_cpu0, int *strings_size_cpu0,
    unsigned char **strings_cpu1, int *strings_size_cpu1);
int MoCAOS_StopCore(MoCAOS_Handle handle);
int MoCAOS_GetDriverInfo(MoCAOS_Handle handle, MoCAOS_DrvInfo *kdrv_info);
int MoCAOS_WolCtrl(MoCAOS_Handle handle, int enable);
unsigned char *MoCAOS_GetFw(MoCAOS_Handle handle, unsigned char *filename, int *fw_len);
void MoCAOS_Printf(MoCAOS_Handle handle, const char *fmt, ...);
void MoCAOS_EnableDataIf(MoCAOS_Handle handle, char *ifname, int enable);
void MoCAOS_CloseClient(MoCAOS_Handle handle, MoCAOS_ClientHandle client);
MoCAOS_ClientHandle MoCAOS_ConnectToMocad(MoCAOS_Handle handle, const char *fmt, char *ifname);

MoCAOS_MutexHandle MoCAOS_MutexInit();
void MoCAOS_MutexLock(MoCAOS_MutexHandle x);
void MoCAOS_MutexUnlock(MoCAOS_MutexHandle x);
void MoCAOS_MutexClose(MoCAOS_MutexHandle x);

int MoCAOS_MemAlign(void **memptr, int alignment, int size);
unsigned int MoCAOS_AllocPhysMem(unsigned int size, unsigned int **paddr);
void MoCAOS_MSleep(int msec);
void MoCAOS_GetTimeOfDay(unsigned int *sec, unsigned int *usec);

MoCAOS_ThreadHandle MoCAOS_CreateThread(MoCAOS_ThreadEntry func, void *arg);

#ifdef DSL_MOCA
int MoCAOS_FindBrName(MoCAOS_Handle handle);
int MoCAOS_AddBrEntries(MoCAOS_Handle handle, const unsigned char *pMac, int numEntries);
int MoCAOS_DelBrEntries(MoCAOS_Handle handle, const unsigned char *pMac, int numEntries);
int MoCAOS_HandleNlNotify( MoCAOS_Handle handle );
#endif


#endif

