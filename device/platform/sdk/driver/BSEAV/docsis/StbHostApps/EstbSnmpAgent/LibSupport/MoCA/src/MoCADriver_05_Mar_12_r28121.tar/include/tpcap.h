/***********************************************************************
 *
 *  Copyright (c) 2006-2007  Broadcom Corporation
 *  All Rights Reserved
 *
<:license-private
 *
 ************************************************************************/


#ifndef __TPCAP_H__
#define __TPCAP_H__

unsigned int TPCAP_ReadMem(unsigned int paddr);
void TPCAP_Start(unsigned int probe_sel, unsigned int port, unsigned int num_samples, 
    unsigned int dest_addr, unsigned int macphy_tp, unsigned int rate, unsigned int clock,
    unsigned int lpbk, unsigned int wait);


void TPCAP_Init(unsigned int chipid);

#endif
