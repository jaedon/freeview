#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/module.h>
#if defined(DSL_MOCA)
#else
#include <asm/brcmstb/common/bcmspi.h>
#endif

#define printf printk
#define strerror(x) "unknown"

static int spi_xfer(int fd, u8 *tx_buf, int tx_len, u8 *rx_buf, int rx_len)
{
	struct bcmspi_parms p = bcmspi_default_parms_cs1;

	return(bcmspi_simple_transaction(&p, tx_buf, tx_len, rx_buf, rx_len));
}

static int spi_setup_addr(int fd, uint32_t addr, int len)
{
	uint8_t buf[7];
	static uint32_t last_addr = 0xffffffff, last_be = 0;
	uint8_t offs;
	int be;

	if(len == 4)
		be = 0x2f;
	else
		be = ((1 << len) - 1) << ((4 - len) - (addr & 3));

	offs = addr & 0xff;
	addr &= 0xffffff00;
	if((addr == last_addr) && (be == last_be))
		return(0);
	
	buf[0] = 0x11;
	buf[1] = 0x01;
	buf[2] = be;
	buf[3] = addr >> 0;
	buf[4] = addr >> 8;
	buf[5] = addr >> 16;
	buf[6] = addr >> 24;

	if(spi_xfer(fd, buf, 7, NULL, 0) < 0)
	{
		printf("ioctl error: %s\n", strerror(errno));
		return(-1);
	}
	last_addr = addr;
	last_be = be;

#if 1
	/* address counter can get corrupted at the end of a 256-byte page */
	if(offs >= 0xfc)
#endif
		last_addr = 0xffffffff;
	return(0);
}

static int spi_read_status(int fd, uint8_t *data)
{
	uint8_t read_status[] = "\x10\x00";
	uint8_t buf[1];

	if(spi_xfer(fd, read_status, 2, buf, 1) < 0)
	{
		printf("ioctl error: %s\n", strerror(errno));
		return(-1);
	}
	*data = buf[0];
	return(0);
}

int spi_read_reg(int fd, uint32_t addr, uint32_t *data, int len)
{
	uint8_t read_core[] = "\x12\x00";
	uint8_t buf[4] = { 0, 0, 0, 0 };

	if(spi_setup_addr(fd, addr, len) == -1)
		return(-1);

	read_core[1] = addr & 0xff;

	if(spi_xfer(fd, read_core, 2, &buf[4 - len], len) < 0)
	{
		printf("ioctl error: %s\n", strerror(errno));
		return(-1);
	}

	*data = (buf[0] << 24) | (buf[1] << 16) | (buf[2] << 8) | buf[3];

	if((spi_read_status(fd, buf) == -1) || (buf[0] & 0x0f)) {
		printf("spi_read_status returned %02x\n", buf[0]);
		return(-1);
	}
	
	return(0);
}
EXPORT_SYMBOL(spi_read_reg);

int spi_write_reg(int fd, uint32_t addr, uint32_t data, int len)
{
	uint8_t buf[6];

	if(spi_setup_addr(fd, addr, len) == -1)
		return(-1);
	
	data <<= 8 * (4 - len);

	buf[0] = 0x13;
	buf[1] = addr & 0xff;
	buf[2] = data >> 24;
	buf[3] = data >> 16;
	buf[4] = data >> 8;
	buf[5] = data >> 0;

	if(spi_xfer(fd, buf, 2 + len, NULL, 0) < 0)
	{
		printf("ioctl error: %s\n", strerror(errno));
		return(-1);
	}

	if((spi_read_status(fd, buf) == -1) || (buf[0] & 0x0f)) {
		printf("spi_read_status returned %02x\n", buf[0]);
		return(-1);
	}

	return(0);
}
EXPORT_SYMBOL(spi_write_reg);

static int spi_init(int fd)
{
	uint8_t init_seq[] = "\x11\x01\xfc";
	uint8_t init_csr[] = "\x11\x01\x0f\x00\x00\x00\x10\x00";
	int tries = 2;

	while(tries)
	{
		uint32_t data;

		if(spi_xfer(fd, init_seq, 3, NULL, 0) < 0)
		{
			printf("ioctl error: %s\n", strerror(errno));
			return(-1);
		}

		if(spi_xfer(fd, init_csr, 8, NULL, 0) < 0)
		{
			printf("ioctl error: %s\n", strerror(errno));
			return(-1);
		}

		/* read chip ID */
		if((spi_read_reg(fd, 0x10000000, &data, 4) == -1) ||
		   (data == 0) || (data == 0xffffffff))
			continue;

		printf("Chip ID: %08x\n", data);
		return(0);
	}

	printf("Error initializing SPI interface\n");
	return(-1);
}

#define DEBUG		0

int spi6816_read(u32 addr)
{
	u32 data;
	BUG_ON(addr & 2);
	addr &= 0x1fffffff;
	if(spi_read_reg(0, addr, &data, 4) < 0)
		printk("warning: can't read %08x\n", addr);
#if DEBUG
	printk("spi6816_rd: %08x = %08x\n", addr, data);
#endif
	return(data);
}
EXPORT_SYMBOL(spi6816_read);

void spi6816_write(u32 addr, u32 data)
{
	BUG_ON(addr & 2);
	addr &= 0x1fffffff;
#if DEBUG
	if((addr < 0x10d00010) || (addr > 0x10d30f00)) {
		printk("spi6816_wr: %08x = %08x\n", addr, data);
	}
	if(addr == 0x10d00010)
		printk("...\n");
#endif
	if(spi_write_reg(0, addr, data, 4) < 0)
		printk("warning: can't write %08x (data %08x)\n", addr, data);
}
EXPORT_SYMBOL(spi6816_write);

static int spi6816_init(void)
{
	spi_init(0);

	return(0);
}

static void spi6816_exit(void)
{
}

module_init(spi6816_init);
module_exit(spi6816_exit);
