/******************************************************************************
 *
 *  Copyright (c) 2010  Broadcom Corporation
 *  All Rights Reserved
 *
<:license-private
 *
 ************************************************************************/

/***************************************************************************
 *
 *     Copyright (c) 2010, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *  Description: MoCA OS Abstraction -- Linux implementation
 *
 ***************************************************************************/
#include <fcntl.h>
#include <unistd.h>
#include <moca_os.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <stdarg.h>
#include <time.h>
#include <signal.h>
#include <glob.h>
#include <malloc.h>
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <sys/mman.h>
#include <sys/time.h>

#include <linux/types.h>
#include <linux/sockios.h>
#include <linux/ethtool.h>
#include <linux/if.h>
#include <linux/if_bridge.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>

#include "mocalib.h"
#include "mocaint.h"

#if defined(DSL_MOCA)
#include <bmoca.h>
#include <ethswctl_api.h>

/* cannot incldue both net/if.h and linux/if.h due to conflicts
   extern fucntions from net/if.h here instead */
extern unsigned int if_nametoindex (__const char *__ifname) __THROW;
extern char *if_indextoname (unsigned int __ifindex, char *__ifname) __THROW;

#define BRCTL_ADD_FDB_ENTRIES 25
#define BRCTL_DEL_FDB_ENTRIES 26

#else
#include <linux/bmoca.h>
#endif

#define MAX(x, y)   (((x) > (y)) ? (x) : (y))

typedef struct
{
    int cmd_sock_port;
    int evt_sock_port;
    int dev_sock_port;

    int cmd_listen_fd;
    int evt_listen_fd;

    int device_fd;

    fd_set select_fdset;
    int select_maxfd;
    fd_set evt_fdset;
    int evt_maxfd;

    unsigned char *fw_img;
    int fw_len;

    char ifname[MoCAOS_IFNAMSIZE];

    int roundrobin;  // index for processing multiple simultaneous clients in a round-robin fashion

    char brname[MoCAOS_IFNAMSIZE];
    int  nl_listen_fd;
    struct sockaddr_nl nl_sockaddr; 

    MoCAOS_DrvInfo kdrv_info;

    pthread_t printfthread;
    int pipefd[2];

    int daemon;
} LinuxOS_Context;

LinuxOS_Context g_context;
MoCAOS_Handle g_handle = (MoCAOS_Handle) &g_context;

static int mocaos_OpenListener(char *sockname)
{
    int fd = socket(AF_UNIX, SOCK_SEQPACKET, 0);
    struct sockaddr_un unix_addr;

    if(fd < 0)
    {
        MoCAOS_Printf(g_handle, "can't open socket: %s\n", strerror(errno));
        exit(-1);
    }
    
    memset(&unix_addr, 0, sizeof(unix_addr));
    unix_addr.sun_family = AF_UNIX;
    strcpy(unix_addr.sun_path, sockname);

    if(bind(fd, (const struct sockaddr *)&unix_addr, sizeof(unix_addr)) < 0)
    {
        MoCAOS_Printf(g_handle, "can't bind: %s\n", strerror(errno));
        exit(-1);
    }
    if(listen(fd, 8) < 0)
    {
        MoCAOS_Printf(g_handle, "can't listen: %s\n", strerror(errno));
        exit(-1);
    }
    if(fcntl(fd, F_SETFL, O_NONBLOCK) < 0)
    {
        MoCAOS_Printf(g_handle, "can't fcntl: %s\n", strerror(errno));
        exit(-1);
    }
 
    return(fd);
}

static int mocaos_Accept(MoCAOS_Handle handle, int listen_fd)
{
    int newfd;

    newfd = accept(listen_fd, NULL, NULL);
    if(newfd < 0) {
        MoCAOS_Printf(handle, "warning: accept() failed: %s\n",
            strerror(errno));
        return(-1);
    } else {
        if(fcntl(newfd, F_SETFL, O_NONBLOCK) < 0)
        {
            MoCAOS_Printf(handle, "can't fcntl: %s\n", strerror(errno));            
            exit(-1);
        }
    }

    return(newfd);
}

static int mocaos_FindIFName(MoCAOS_Handle handle, MoCAOS_DrvInfo *kdrv_info, const char *ifname)
{
    glob_t g;
    int ret = -1, i, match = -1, fd;

    strcpy((char *)ifname, "unknown");
    ret = glob(IFNAME_GLOB, 0, NULL, &g);
    if(ret == GLOB_NOMATCH) {
        MoCAOS_Printf(handle, "can't find network interface list "
            "under %s\n", IFNAME_GLOB);
        return(-1);
    }
    if(ret != 0) {
        MoCAOS_Printf(handle, "error listing %s\n", IFNAME_GLOB);
        return(-1);
    }

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(fd < 0) {
        MoCAOS_Printf(handle, "can't open ethtool socket\n");
        goto out;
    }

    for(i = 0; i < g.gl_pathc; i++) {
        struct ifreq ifr;
        struct ethtool_drvinfo drvinfo;
        char *t_ifname;
        int err;

        t_ifname = strrchr(g.gl_pathv[i], '/');
        if(t_ifname)
            t_ifname++;
        else
            t_ifname = g.gl_pathv[i];

        memset(&ifr, 0, sizeof(ifr));
        memset(&drvinfo, 0, sizeof(drvinfo));

        drvinfo.cmd = ETHTOOL_GDRVINFO;
        ifr.ifr_data = (caddr_t)&drvinfo;
        strcpy(ifr.ifr_name, t_ifname);

        err = ioctl(fd, SIOCETHTOOL, &ifr) < 0;

        if(err)
        {
            fprintf(stderr,"Error finding IFNAME\n");
            continue;
        }
        if(strcmp(drvinfo.driver,
                (char *)kdrv_info->enet_name) == 0) {
            match++;
            if(kdrv_info->enet_id == match) {
                strcpy((char *)ifname, t_ifname);
                ret = 0;
                goto out2;
            }
        }
    }

out2:
    close(fd);
out:
    globfree(&g);
    return(ret);
}


#if !defined(DSL_MOCA)
void mocaos_setLinkStatus(MoCAOS_Handle handle, int status)
{
    int fd;
    struct ifreq ifr;
    struct ethtool_cmd ethcmd;
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;    
    int err;
    
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(fd < 0) 
    {
        perror("can't open ethtool socket ");
        return;
    }

    memset(&ifr, 0, sizeof(ifr));
    memset(&ethcmd, 0, sizeof(ethcmd));

    ethcmd.cmd = ETHTOOL_GSET;
    ifr.ifr_data = (caddr_t)&ethcmd;
    strcpy(ifr.ifr_name, ctx->ifname);

    err = ioctl(fd, SIOCETHTOOL, &ifr) < 0;

    if(err)
    {
        close(fd);
        return;
    }

    ethcmd.cmd = ETHTOOL_SSET;
    ethcmd.autoneg = status;  // we override the autoneg meaning for link up/down in the genet driver
    ifr.ifr_data = (caddr_t)&ethcmd;
    strcpy(ifr.ifr_name, ctx->ifname);

    err = ioctl(fd, SIOCETHTOOL, &ifr) < 0;
    
    if(err)
    {
        close(fd);
        return;
    }
    close(fd);
}

#endif

static int mocaos_OpenDev(MoCAOS_Handle handle, const char *chardev)
{
    int fd, major, minor;
    char filename[MOCA_FILENAME_LEN], devnum[16];

    if (strlen(chardev) > (MOCA_FILENAME_LEN - 1))
    {
        MoCAOS_Printf(handle, "filename is too long: '%s'\n", chardev);
        exit(-1);
    }

    fd = open(chardev, O_RDWR | O_NONBLOCK);
    if (fd >= 0)
        return(fd);
    
    if (errno != ENOENT)
        goto bad;

    /* find "root" device name */

#if defined(DSL_MOCA) /* DSL Code */
    chardev = strstr(chardev, "bcmmoca");
#else
    chardev = strstr(chardev, "bmoca");
#endif

    if(! chardev || (strlen(chardev) > 16))
        goto bad;

    /* try to find major/minor number */

    sprintf(filename, DEVNAME_FMT, chardev);
    fd = open(filename, O_RDONLY);
    if (fd < 0)
        goto bad;
    if (read(fd, devnum, sizeof(devnum)) <= 0)
        goto bad;
    if (sscanf(devnum, "%d:%d", &major, &minor) != 2)
        goto bad;
 
    sprintf(filename, "/tmp/%s", chardev);
    unlink(filename);
    if (mknod(filename, 0600 | S_IFCHR, makedev(major, minor)) < 0)
        goto bad;

    fd = open(filename, O_RDWR | O_NONBLOCK);

    if(fd >= 0)
        return(fd);

bad:
    MoCAOS_Printf(handle, "can't open MoCA device: %s\n", strerror(errno));
    exit(-1);
    
    return(-1);
}

static void mocaos_Close(MoCAOS_Handle handle, int fd)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;

    close(fd);
    FD_CLR(fd, &ctx->select_fdset);
    FD_CLR(fd, &ctx->evt_fdset);
    if(fd == ctx->select_maxfd) {
        fd_set fds = ctx->select_fdset;
        FD_SET(ctx->cmd_listen_fd, &fds);
        FD_SET(ctx->device_fd, &fds);
        while(! FD_ISSET(ctx->select_maxfd, &fds))
            ctx->select_maxfd--;
    }
}

static int mocaos_CheckForData(MoCAOS_Handle handle)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
    int ret;

    if (ioctl(ctx->device_fd, MOCA_IOCTL_CHECK_FOR_DATA, &ret) < 0) // this will fail on older kernels
        return(0);

    return(ret);
}

#ifdef DSL_MOCA
int mocaos_OpenNetlinkListener( struct sockaddr_nl *pNlSockAddr) 
{
   int ret;
   struct sockaddr_nl snl;
   int sock;

   sock = socket (AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
   if (sock < 0)
   {
      return -1;
   }

   ret = fcntl (sock, F_SETFL, O_NONBLOCK);
   if (ret < 0)
   {
      close (sock);
      return -1;
   }

   memset (&snl, 0, sizeof snl);
   snl.nl_family = AF_NETLINK;
   snl.nl_groups = RTMGRP_LINK;

   /* Bind the socket to the netlink structure for anything. */
   ret = bind (sock, (struct sockaddr *) &snl, sizeof snl);
   if (ret < 0)
   {
      close (sock);
      return -1;
   }

   memcpy( pNlSockAddr, &snl, sizeof(struct sockaddr_nl));
   return sock;
}
#endif

void *mocaos_printfthread(void *x)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)x;
    char *buf;
    unsigned char msgbuf[sizeof(struct moca_mocad_printf) + sizeof(struct mmp_msg_hdr) + sizeof(struct mmp_ie_hdr)];
    struct mmp_msg_hdr *mh;
    struct mmp_ie_hdr *ih;
    int fd;

    mh = (struct mmp_msg_hdr *)msgbuf;
    mh->msg_type = MOCA_MSG_TRAP;
    mh->msg_id = 0;
    mh->num_ies = BE16(1);

    ih = (struct mmp_ie_hdr *)(mh + 1);
    ih->ie_type = BE16(IE_MOCAD_PRINTF);
    ih->ie_len = BE16(sizeof(struct moca_mocad_printf));

		buf = (char *) (ih+1);

    fd = open("/dev/console", O_WRONLY);

    if (!fd)
    {
        stdout = stderr;
        return NULL;
    }

    while(1)
    {
        int co;
        co = read(ctx->pipefd[0], buf, sizeof(struct moca_mocad_printf)-1);

        if (co > 0)
        {
            if (ctx->daemon)
                write(fd, buf, co);
            else
                fwrite(buf, co, 1, stderr);

            buf[co] = '\0';
            MoCAOS_SendMMP((MoCAOS_Handle)ctx, MoCAOS_CLIENT_BROADCAST, msgbuf, sizeof(msgbuf));
        }
    }

    return(NULL);
}

MoCAOS_Handle MoCAOS_Init(const char *chardev, char *ifname, const char *workdir, int daemon)
{    
    char cmd_sockname[MOCA_FILENAME_LEN];
    char evt_sockname[MOCA_FILENAME_LEN];
    char defsock[MOCA_FILENAME_LEN];

    signal(SIGPIPE, SIG_IGN);

    if (chdir (workdir))
    {
        printf("WARNING: unable to change dir to %s, trying /etc/moca\n", workdir);
        if (chdir ("/etc/moca"))
        {
            printf("WARNING: unable to change dir to /etc/moca, using current dir\n");
        }
    }

    memset(&g_context, 0, sizeof(g_context));

    g_context.daemon = daemon;
    g_context.device_fd = mocaos_OpenDev((MoCAOS_Handle)&g_context, chardev);

    if (MoCAOS_GetDriverInfo((MoCAOS_Handle)&g_context, &g_context.kdrv_info) != 0)
    {
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "Kernel/mocad version mismatch.  Ensure kernel and mocad versions are compatible\n");
        exit(-1);
    }

    if(g_context.kdrv_info.refcount != 1)
    {
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "nonzero refcount (%d); is another mocad running?\n", g_context.kdrv_info.refcount);
        exit(-1);
    }

    /* get ifname and use it to name the sockets */
    if (ifname[0] == 0x00)
        mocaos_FindIFName((MoCAOS_Handle)&g_context, &g_context.kdrv_info, ifname);

    strncpy(g_context.ifname, ifname, MoCAOS_IFNAMSIZE);
    sprintf(cmd_sockname, MOCA_CMD_SOCK_FMT, ifname);
    sprintf(evt_sockname, MOCA_EVT_SOCK_FMT, ifname);

    unlink(cmd_sockname);
    unlink(evt_sockname);

    /* create symlinks making this the default moca interface */

    sprintf(defsock, MOCA_CMD_SOCK_FMT, MOCA_DEFAULT_IFNAME);
    unlink(defsock);
    symlink(cmd_sockname, defsock);

    sprintf(defsock, MOCA_EVT_SOCK_FMT, MOCA_DEFAULT_IFNAME);
    unlink(defsock);
    symlink(evt_sockname, defsock);

    g_context.cmd_listen_fd = mocaos_OpenListener(cmd_sockname);
    g_context.evt_listen_fd = mocaos_OpenListener(evt_sockname);
    
    FD_ZERO(&g_context.select_fdset);
    FD_SET(g_context.device_fd, &g_context.select_fdset);
    FD_SET(g_context.cmd_listen_fd, &g_context.select_fdset);
    FD_SET(g_context.evt_listen_fd, &g_context.select_fdset);

    g_context.select_maxfd = MAX(g_context.device_fd,
                                 MAX(g_context.cmd_listen_fd, 
                                     g_context.evt_listen_fd));

#ifdef DSL_MOCA
    g_context.nl_listen_fd  = mocaos_OpenNetlinkListener(&g_context.nl_sockaddr);
    FD_SET(g_context.nl_listen_fd, &g_context.select_fdset);
    g_context.select_maxfd = MAX( g_context.nl_listen_fd, g_context.select_maxfd );
#endif

    if(daemon) 
    {
        pid_t pid = fork();
        if(pid < 0) 
        {
            MoCAOS_Printf((MoCAOS_Handle)&g_context, "can't fork: %s\n", strerror(errno));
            exit(-1);
        }
        if(pid > 0) 
        {
            /* parent */
            exit(0);
        }
        setsid();
    }

    if (pipe(&g_context.pipefd[0]) != 0)
    {
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "WARNING: unable to create pipe for debug prints: %s\n", strerror(errno));
    }
    else
    {
        fcntl(g_context.pipefd[1], F_SETFL, O_NONBLOCK);
        stdout = fdopen(g_context.pipefd[1], "w");

        if (!stdout)
            stdout = stderr;
        else
            pthread_create(&g_context.printfthread, NULL, mocaos_printfthread, (void *)&g_context);
    }
    setvbuf(stdout, (char *)NULL, _IONBF, (size_t)0);  // turn off buffering on stdout

    return (MoCAOS_Handle)&g_context;
}

MoCAOS_ClientHandle MoCAOS_WaitForRequest(MoCAOS_Handle handle, unsigned int timeout_sec)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
    fd_set fds = ctx->select_fdset;
    int ret, i;
    struct timeval tv;
    
    tv.tv_sec = timeout_sec;
    tv.tv_usec = 0;

    ret = select(ctx->select_maxfd + 1, &fds, NULL, NULL, &tv);

    if(ret < 0)
       MoCAOS_Printf(handle, "warning: select() failed: %s\n",
            strerror(errno));

    // when the CPU is loaded, make sure we timed out because
    // of a lack of data, not a lack of CPU time
    if ( (ret == 0) && FD_ISSET(ctx->device_fd, &ctx->select_fdset) && mocaos_CheckForData(handle) )
    {
        return(MoCAOS_CLIENT_CORE);
    }

    if(ret == 0)
    {
        return MoCAOS_CLIENT_TIMEOUT;
    }

    if(FD_ISSET(ctx->cmd_listen_fd, &fds)) 
    {
        int newfd = mocaos_Accept(handle, ctx->cmd_listen_fd);
        if(newfd >= 0) 
        {
            FD_SET(newfd, &ctx->select_fdset);
            ctx->select_maxfd =
                MAX(ctx->select_maxfd, newfd);
        }
        if(ret-- == 0)
            return(MoCAOS_CLIENT_NULL);
        FD_CLR(ctx->cmd_listen_fd, &fds);
    }
    if(FD_ISSET(ctx->evt_listen_fd, &fds)) 
    {
        int newfd = mocaos_Accept(handle, ctx->evt_listen_fd);

        if(newfd >= 0) 
        {
            FD_SET(newfd, &ctx->evt_fdset);
            ctx->evt_maxfd = MAX(ctx->evt_maxfd, newfd);

            FD_SET(newfd, &ctx->select_fdset);
            ctx->select_maxfd =
                MAX(ctx->select_maxfd, newfd);
        }
        if(ret-- == 0)
            return(MoCAOS_CLIENT_NULL);
        FD_CLR(ctx->evt_listen_fd, &fds);
    }

    for(i = 0; ret && (i <= ctx->select_maxfd); i++) 
    {
        if(FD_ISSET(i, &fds))
        {
            if(FD_ISSET(i, &ctx->evt_fdset))
            {                
                mocaos_Close(handle, i);
                ret--;                
            }             
        }
    }
    
    if(FD_ISSET(ctx->device_fd, &fds))
    {
        return MoCAOS_CLIENT_CORE;
    }

#ifdef DSL_MOCA
    if(FD_ISSET(ctx->nl_listen_fd, &fds)) 
    {
        return MoCAOS_CLIENT_NL;
    }
#endif

    if (ctx->roundrobin > ctx->select_maxfd)
        ctx->roundrobin = 0;

    for(i = ctx->roundrobin; ret; i++) 
    {
        if(FD_ISSET(i, &fds)) 
        {
            return(MoCAOS_ClientHandle)i;
        }

        if (i == ctx->select_maxfd)
            i = 0;
    }

    return(MoCAOS_CLIENT_NULL);
}

int MoCAOS_SendMMP(MoCAOS_Handle handle, MoCAOS_ClientHandle client, const unsigned char *IE, int len)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
    int ret;
    int fd;
    int i;

    if (client == MoCAOS_CLIENT_BROADCAST)
    {
        /* broadcast event to all evt clients */
        for(i = 0; i <= ctx->evt_maxfd; i++)
        {
            if(FD_ISSET(i, &ctx->evt_fdset))
            {
                ret = write(i, IE, len);
                if (ret != len)
                {
                    MoCAOS_Printf(handle, "Warning: short write (%d, %d)\n", ret, len);
                }
            }
        }
        return(0);
    }

    if (client == MoCAOS_CLIENT_CORE)
        fd = ctx->device_fd;
    else
        fd = (int) client;

    ret = write(fd, IE, len);

    if (ret != len)
    {
        MoCAOS_Printf(handle, "warning: short write fd=%d (%d, %d, %s)\n", fd, ret, len, strerror(errno));
        return(-1);
    }
    
    return(0);
}

int MoCAOS_ReadMMP(MoCAOS_Handle handle, MoCAOS_ClientHandle client, 
    unsigned int timeout_sec, unsigned char *IE, int *len)  // return 0 timeout, <0 failure, >0 success
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
    int ret;
    fd_set fds;
    int fd;
    struct timeval tv;

    if (!ctx)
        ctx = &g_context;

    if (client == MoCAOS_CLIENT_CORE)
        fd = ctx->device_fd;
    else
        fd = (int) client;

    if (timeout_sec != MoCAOS_TIMEOUT_INFINITE)
    {
        FD_ZERO(&fds);
        FD_SET(fd, &fds);
        
        tv.tv_sec = timeout_sec;
        tv.tv_usec = 0;
        
        ret = select(fd+1, &fds, NULL, NULL, &tv);

        if(ret < 0)
        {
            MoCAOS_Printf(handle, "warning: select() failed: %s\n",
                strerror(errno));
            return(-1);
        }

        // when the CPU is loaded, make sure we timed out because
        // of a lack of data, not a lack of CPU time
        if ( (ret == 0) && FD_ISSET(ctx->device_fd, &ctx->select_fdset) && mocaos_CheckForData(handle) )
        {
            ret = 1;
        }

        if(ret == 0)
        {
            return 0;
        }
    }

    while (1)
    {
        *len = read(fd, IE, *len);
        if (*len < 0) 
        {
            if (errno == EINTR)
                continue;

            if (errno != ECONNRESET)
                MoCAOS_Printf(handle, "warning: read failed: %s\n", strerror(errno));
            else
                mocaos_Close((MoCAOS_Handle)ctx, fd);  // for traps, the event loop will close the other end of the pipe when terminated.  This is normal.

            return(-1);
        } 
        else if ((*len == 0) && (client != MoCAOS_CLIENT_CORE))
        {
            /* closed connection */
            mocaos_Close((MoCAOS_Handle)ctx, fd);
            return(-2);
        }
        else
        {
            break;
        }
    }

    return (1);
}

int MoCAOS_ReadMem(MoCAOS_Handle handle, unsigned char *buf, int len, unsigned char *addr)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
    struct moca_xfer x;
    
    x.buf = (unsigned long)buf;
    x.len = len;
    x.moca_addr = (unsigned int)addr;

    if (ioctl(ctx->device_fd, MOCA_IOCTL_READMEM, &x) < 0)
        return(errno);
    
    return(0);
}


int MoCAOS_WriteMem(MoCAOS_Handle handle, unsigned char *buf, int len, unsigned char *addr)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
    struct moca_xfer x;
    
    x.buf = (unsigned long)buf;
    x.len = len;
    x.moca_addr = (unsigned int)addr;

    if (ioctl(ctx->device_fd, MOCA_IOCTL_WRITEMEM, &x) < 0)
        return(errno);
    
    return(0);
}



int MoCAOS_StartCore(MoCAOS_Handle handle, unsigned char *fw_img, int fw_len,
    unsigned int cont_tx_mode, unsigned char **strings_cpu0, int *strings_size_cpu0,
    unsigned char **strings_cpu1, int *strings_size_cpu1)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;    
    struct moca_start start;
    int img_length;
    int core_id;
    
    if (fw_len < 64)  
    {
        MoCAOS_Printf(handle, "Error, firmware image too short\n");
        return(-1);
    }

    // check the "hw_ver" field to determine the file type
    if (( BE32(*((unsigned int *)fw_img+5)) == 0x02 ) ||
        ( BE32(*((unsigned int *)fw_img)) == 0xAAAAAAAA))
    {
        // new style multi-core image, loop through the images                    
        while (fw_len > 0)
        {
            if (fw_len < 8)
            {
                MoCAOS_Printf(handle, "Error, invalid firmware image\n");
                return(-1);                
            }            

            if ((BE32(*((unsigned int *)fw_img)) == 0xAAAAAAAA))  
            {
                // Strings section
                fw_img += 4;
                fw_len -= 4;
                img_length =  BE32(*((unsigned int *)fw_img));
                fw_img += 4;
                fw_len -= 4;
                core_id = BE32(*((unsigned int *)fw_img));
                fw_img += 4;
                fw_len -= 4;
                if (fw_len < img_length)
                {
                   fprintf(stderr,"ERROR: strings section length (%d) exceeds file size\n", img_length);
                   return(-1);
                }
                
                if (core_id == 0)
                {
                   *strings_size_cpu0 = img_length;
                   *strings_cpu0 = fw_img;
                }
                else if (core_id == 1)
                {
                   *strings_size_cpu1 = img_length;
                   *strings_cpu1 = fw_img;
                }
                else
                {
                   fprintf(stderr,"ERROR: invalid CPU id: %X\n", core_id);
                   return(-1);
                }

                fw_len -= img_length;
                fw_img += img_length;
            }
            else
            {
                // Firmware section
                if (fw_len < 64)
                {
                    MoCAOS_Printf(handle, "Error, invalid firmware image\n");
                    return(-1);
                }
                
                img_length = BE32(*((unsigned int *)fw_img+2));
                core_id = BE32(*((unsigned int *)fw_img+3));

                if ((core_id != 0) && (core_id != 1))
                {
                    MoCAOS_Printf(handle, "Error, invalid core_id in firmware image: %d\n", core_id);
                    return(-1);
                }

                if (fw_len < img_length)
                {
                    MoCAOS_Printf(handle, "Error, invalid firmware image, core image too short\n");
                    return(-1);
                }

                start.x.buf = (unsigned long)fw_img;
                start.x.len = (img_length + 3) & ~3;
                start.x.moca_addr = 0;
                start.continuous_power_tx_mode = cont_tx_mode;
 
                if (ioctl(ctx->device_fd, MOCA_IOCTL_START, (void *)&start) < 0)
                {
                    MoCAOS_Printf(handle, "Error starting core %d\n", core_id);
                    return(errno);
                }

                fw_img += img_length;
                fw_len -= img_length;
            }
        }
    }
    else
    {
        start.x.buf = (unsigned long)fw_img;
        start.x.len = (fw_len + 3) & ~3;
        start.x.moca_addr = 0;
        start.continuous_power_tx_mode = cont_tx_mode;

        if (ioctl(ctx->device_fd, MOCA_IOCTL_START, (void *)&start) < 0)
            return(errno);
    }

    return(0);
}

int MoCAOS_StopCore(MoCAOS_Handle handle)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
    
    if (ioctl(ctx->device_fd, MOCA_IOCTL_STOP, NULL) < 0)
        return(errno);

    return(0);
}

int MoCAOS_WolCtrl(MoCAOS_Handle handle, int enable)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;

    if (ioctl(ctx->device_fd, MOCA_IOCTL_WOL, (void*)enable) < 0)
        return(errno);

    return(0);
}

MoCAOS_ThreadHandle MoCAOS_CreateThread(MoCAOS_ThreadEntry func, void *arg)
{
    pthread_t thread = 0;
    if (0 != pthread_create(&thread, NULL, (void * (*)(void *))func, arg))
    {
        fprintf(stderr,"ERROR: Unable to create thread\n");
    }
    return((MoCAOS_ThreadHandle)thread);
}

void MoCAOS_GetTimeOfDay(unsigned int *sec, unsigned int *usec)
{
   struct timeval tv;
   gettimeofday(&tv, NULL);
   if (sec)
      *sec = tv.tv_sec;
   if (usec)
      *usec = tv.tv_usec;
}

int MoCAOS_GetDriverInfo(MoCAOS_Handle handle, MoCAOS_DrvInfo *kdrv_info)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
    int rc;
    int oldkernel = 0;
    
    memset (kdrv_info, 0, sizeof(MoCAOS_DrvInfo));
    
    rc = ioctl(ctx->device_fd, MOCA_IOCTL_GET_DRV_INFO, kdrv_info);

    if ((rc >= 0) && (kdrv_info->chip_id == 0))
    {        
        // the ioctl worked, but chipid returned was invalid.  This can
        // occur with kernels that have the new bmoca driver but older kernel.
        oldkernel = 1;
    }

    if ((rc < 0) || (oldkernel))
    {
        if ((rc < 0) && (ioctl(ctx->device_fd, MOCA_IOCTL_GET_DRV_INFO_V2, kdrv_info) < 0))
        {
            return(errno);
        }

        // in this version of ioctl, the chip_id was returned in the hw_rev field        
        kdrv_info->chip_id = kdrv_info->hw_rev;
        
        // chip_id not set by kernel
        // Determing MoCA hw_rev from chip id
        switch(kdrv_info->chip_id & 0xFFFF0000)
        {
            case 0x74200000:
            case 0x74100000:
            case 0x33200000:
            case 0x73400000:
            case 0x73420000:
            case 0x71250000:
            case 0x74180000:
                kdrv_info->hw_rev = MOCA_CHIP_11;
                break;
            case 0x74080000:
                kdrv_info->hw_rev = MOCA_CHIP_11_LITE;
                break;
            default:
                kdrv_info->hw_rev = MOCA_CHIP_11_PLUS;
        }
    }   

    return(0);
}

unsigned char *MoCAOS_GetFw(MoCAOS_Handle handle, unsigned char *filename, int *fw_len)
{
    LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
    int fd;

    do
    {
        if(filename)
        {
            fd = open((char *)filename, O_RDONLY);
            if(fd < 0) 
            {
                MoCAOS_Printf(handle, "can't open %s: %s\n", filename,
                    strerror(errno));
                exit(-1);
            }
            break;
        }
        
        fd = open(MOCACORE_PATH_0, O_RDONLY);
        if(fd >= 0)
            break;
        fd = open(MOCACORE_PATH_1, O_RDONLY);
        if(fd >= 0)
            break;        

        if ((ctx->kdrv_info.hw_rev == MOCA_CHIP_11) ||
            (ctx->kdrv_info.hw_rev == MOCA_CHIP_11_LITE))
        {
            fd = open(MOCACORE_PATH_GEN_1, O_RDONLY);
            if(fd >= 0)
                break;
        }
        else if (ctx->kdrv_info.hw_rev == MOCA_CHIP_20)
        {
            fd = open(MOCACORE_PATH_GEN_3, O_RDONLY);
            if(fd >= 0)
                break;
        }
        else
        {
            fd = open(MOCACORE_PATH_GEN_2, O_RDONLY);
            if(fd >= 0)
                break;                        
        }
        
        MoCAOS_Printf(handle, "can't find firmware image\n");
        exit(-1);
    } while(0);

    /* Free any previously mapped memory */
    if (ctx->fw_img != NULL)
    {
        if (munmap(ctx->fw_img, ctx->fw_len) != 0)
            MoCAOS_Printf(handle, "unmap failed (%s)\n", strerror(errno));
    }

    ctx->fw_len = lseek(fd, 0, SEEK_END);
    ctx->fw_img = mmap(NULL, ctx->fw_len, PROT_READ, MAP_SHARED, fd, 0);
    
    if (ctx->fw_img == NULL)
    {
        MoCAOS_Printf(handle, "can't mmap firmware image\n");
        exit(-1);
    }
    
    close(fd);

    *fw_len = ctx->fw_len;

    return(ctx->fw_img);
}


void MoCAOS_Printf(MoCAOS_Handle handle, const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);

    vprintf(fmt, ap);

    fflush(stdout);
    
    va_end(ap);
}

void MoCAOS_EnableDataIf(MoCAOS_Handle handle, char *ifname, int enable)
{
    char cli[64];

    // disable only TX, leave RX for WOL
    if (enable == 1)
    {
       sprintf(cli,"/sbin/ifconfig %s txqueuelen 0", ifname);
       system(cli);
    }
    else if (enable == 2)
    {
#ifdef DSL_MOCA
       if (strcmp(ifname, "moca0")==0)
          bcm_set_linkstatus(0x5, 0, 1000, 1);
       else
          bcm_set_linkstatus(0x85, 0, 1000, 1);
#else
       mocaos_setLinkStatus(handle, 0);
#endif
    }
    else
    {
#ifdef DSL_MOCA
       if (strcmp(ifname, "moca0")==0)
          bcm_set_linkstatus(0x5, 1, 1000, 1);
       else
          bcm_set_linkstatus(0x85, 1, 1000, 1);
#else
       mocaos_setLinkStatus(handle, 1);
#endif
    }
}

// Try to allocate contiguous physical memory using the 'allocmem' kernel module
static unsigned int mocaos_AllocPhysMem1(unsigned int size, unsigned int **paddr)
{
    int rc;
    int file;

    // try a few locations
    system("insmod memalloc.ko > /dev/null 2>&1");
    system("insmod /lib/modules/memalloc.ko > /dev/null 2>&1");
    system("insmod /memalloc.ko > /dev/null 2>&1");
    system("insmod /mnt/memalloc.ko > /dev/null 2>&1");     
    system("mknod /dev/memalloc c 112 0 > /dev/null 2>&1");

    file = open("/dev/memalloc", O_NONBLOCK);

    if (!file)
    {
        return(1);
    }

    rc = ioctl(file, 0, &size);

    close(file);

    if (rc <= 0)
    {
        return(1);
    }

    *paddr = (unsigned int *)rc;
    
    return(0);
}

// try to alloc contiguous physical memory using the malloc/crossed fingers method 
static unsigned int mocaos_AllocPhysMem2(unsigned int size, unsigned int **paddr)
{
    int i, j;
    volatile unsigned int *x;
    volatile unsigned int *buffers[32];
    unsigned int *virtaddr;
    int k;

    /* We can't really allocate a chunk of physical memory in Linux userspace,
       but since this is only for a debug feature, it only needs to work
       "most of the time".  

       We allocate virtual memory via malloc.  The kernel will put it somewhere in
       physical memory.  If we are lucky, it will all be contiguous in memory.  We
       write a pattern to memory, and then read from /dev/mem (addressed via physical
       address), to match the pattern and figure out where the kernel put our block in
       physical memory.

       A few things can go wrong here:  
       1) The block may not be contiguous in memory.  In this case we allocate another
          block and try again.  We do this up to 32 times.
       2) The kernel may reallocate physical memory and move our buffer somewhere else.  In this
          case we're screwed, we can't lock the buffer in physical memory.  If you're running
          other programs that are allocating and deallocating memory, you have a greater risk
          of this happening.
    */
    
    int fd = open("/dev/mem", O_RDWR | O_SYNC);

    if (fd < 0)
    {
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "Unable to alloc physical memory!\n");
        return(1);
    }

    x  = mmap(NULL, 0x20000000, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    if ((unsigned int) x == (unsigned int)-1)
    {
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "Unable to map physical memory!\n");
        return(1);        
    }

    for (k=0;k<32;k++)
    {
        buffers[k] = virtaddr = (unsigned int *)malloc(size);
 
        // initialize buffer with some pattern
        for (i=0; i<(int)size/4;i++)
        {
            (virtaddr)[i] = i^0x12345679;
        }        

        (virtaddr)[size/4-1] = k;
    }

    // check all memory locations for that pattern
    for (i=0; i<0x10000000/4; i++)
    {
        for (j=0;j<(int)size/4-1;j++)
        {
            if (x[i+j] != (unsigned int)(j^0x12345679))
            {
                break;
            }
            x[i+j] = 0xAAAAAAAA;
        }
        if (j == (int)size/4-1) // found a match
            break;
    }

    k = x[i+j];
    
    if (j != (int)size/4-1) // found a match
    {
        i = 0;
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "Unable to allocate contiguous physical memory.  Reboot and try again. (%d, %d)\n",j,k);
    }

    for (j=0;j<32;j++)
    {
        if (j != k)
            free((void *)buffers[j]);
    }

    x[0x102a212c/sizeof(unsigned int)] = (i*4+256) & 0xFFFFFF00; // save address in MOCA_HOSTMISC_MMP_HOST_MMP15
    
    munmap((void *)x, 0x20000000);

    close(fd);

    *paddr = (unsigned int *)(i*4);
    
    return(0);
}

unsigned int MoCAOS_AllocPhysMem(unsigned int size, unsigned int **paddr)
{
    // try two different ways of allocating contiguous virtual memory.    
    if (mocaos_AllocPhysMem1(size, paddr) == 0)
        return(0);
    if (mocaos_AllocPhysMem2(size, paddr) == 0)
        return(0);    

    return(1);
}


MoCAOS_ClientHandle MoCAOS_ConnectToMocad(MoCAOS_Handle handle, const char *fmt, char *ifname)
{
    int fd;
    struct sockaddr_un unix_addr;
    char sockname[MOCA_FILENAME_LEN];
    int retVal;

    sprintf(sockname, fmt, ifname);

    fd = socket(AF_UNIX, SOCK_SEQPACKET, 0);

    if(fd < 0)
        return(MoCAOS_CLIENT_NULL);
    
    memset(&unix_addr, 0, sizeof(unix_addr));
    unix_addr.sun_family = AF_UNIX;
    strcpy(unix_addr.sun_path, sockname);
    retVal = connect(fd, (const struct sockaddr *)&unix_addr,
            sizeof(unix_addr));

    if(retVal < 0)
    {
        close(fd);
        return(MoCAOS_CLIENT_NULL);
    }

    return((MoCAOS_ClientHandle)fd);
}

void MoCAOS_CloseClient(MoCAOS_Handle handle, MoCAOS_ClientHandle client)
{
    close((int)client);
}

MoCAOS_MutexHandle MoCAOS_MutexInit()
{   
    pthread_mutex_t *x; 

    x = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
    
    pthread_mutex_init(x, NULL);
    
    return((MoCAOS_MutexHandle) x); return 0;
}

void MoCAOS_MutexLock(MoCAOS_MutexHandle x)
{
    pthread_mutex_lock((pthread_mutex_t *)x);
}

void MoCAOS_MutexUnlock(MoCAOS_MutexHandle x)
{
    pthread_mutex_unlock((pthread_mutex_t *)x);
}

int MoCAOS_MemAlign(void **memptr, int alignment, int size)
{
#if (defined(_POSIX_C_SOURCE) && _POSIX_C_SOURCE >= 200112L ) || (defined(_XOPEN_SOURCE) &&  _XOPEN_SOURCE >= 600)
// normally used posix_memalign
		if (posix_memalign(memptr, alignment, size) < 0)
			return -1;
#else
// use memalign if posix_memalign not available
		*memptr = memalign(alignment, size);
		if (*memptr == 0)
			return -1;
#endif

	return(0);
}

void MoCAOS_MSleep(int msec)
{
   usleep(msec*1000);
}

#ifdef DSL_MOCA
int MoCAOS_FindBrName(MoCAOS_Handle handle)
{
	LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
	struct ifreq     ifr;
	int              inetSock;
	int              num;
	int              err;
	int              brCount;
	int              portCount;
	char             brName[IFNAMSIZ];
	char             portName[IFNAMSIZ];
	int              brIfindices[16]; /* assume less than 16 bridges */
	int              portIfindices[32]; /* assume less than 32 ports per bridge */
	unsigned long    args[3] = { BRCTL_GET_BRIDGES, 
	                             (unsigned long)brIfindices, 16 };

	memset(&ctx->brname, 0, MoCAOS_IFNAMSIZE);
	if ((inetSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		MoCAOS_Printf(handle, "Error cannot open AF_INET socket\n");
		return -1;
	}

	/* get a list of bridges */
	memset((char *)brIfindices, 0, sizeof(brIfindices));
	num = ioctl(inetSock, SIOCGIFBR, args);
	if (num < 0)
	{
		MoCAOS_Printf(handle, "Get bridge indices failed: %s\n", strerror(errno));
		close(inetSock);
		return -1;
	}

	for (brCount = 0; brCount < num; brCount++)
	{
		if (!if_indextoname(brIfindices[brCount], &brName[0]))
		{
			MoCAOS_Printf(handle, " cannot convert bridge if index to ifname\n");
		}
		else
		{
			//printf("ifName - %s\n", brName);
			memset((char *)portIfindices, 0, sizeof(portIfindices));
			strncpy(ifr.ifr_name, brName, IFNAMSIZ);
			args[0] = BRCTL_GET_PORT_LIST;
			args[1] = (unsigned long)portIfindices;
			args[2] = 32;
			args[3] = 0;
			ifr.ifr_data = (char *) &args[0];

			err = ioctl(inetSock, SIOCDEVPRIVATE, &ifr);
			if (err < 0)
			{
				MoCAOS_Printf(handle, "list ports for bridge:'%s' failed: %s\n",
				          brName, strerror(errno));
				close(inetSock);
				return -1;
			}
         
			for (portCount = 0; portCount < 32; portCount++)
			{
				if (!portIfindices[portCount])
					continue;

				if (!if_indextoname(portIfindices[portCount], portName))
				{
					MoCAOS_Printf(handle, "can't find name for ifindex:%d\n",
					          portIfindices[portCount]);
					continue;
				}
				else
				{
					//printf("ifName - %s\n", portName);
					if (strlen(portName) >= strlen(ctx->ifname) )
					{
						if( 0 == strncmp(portName, ctx->ifname, strlen(ctx->ifname)) )
						{
							//printf("matching ifName %s, %s\n", ctx->ifname, portName);
							strcpy(&ctx->brname[0], brName);
						}
					}
				}
			}
		}
	}
	close(inetSock);
	return 0;
}

int MoCAOS_AddBrEntries(MoCAOS_Handle handle, const unsigned char *pMac,
                        int numEntries)
{
	LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
	int              err;
	struct ifreq     ifr;
	int              inetSock;
	int              ifIndex = if_nametoindex(ctx->ifname);
	unsigned long    args[4] = { BRCTL_ADD_FDB_ENTRIES, 
	                              (unsigned long)pMac, 
	                              numEntries, ifIndex };
	
	/* if moca is not part of a bridge just return */
	if (strlen(ctx->brname) <= 0 )
	    return 0;
	
	if (ifIndex == 0) 
		return -ENODEV;

	if ((inetSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) 
	{
		MoCAOS_Printf(handle, "Error cannot open AF_INET socket\n");
		return -1;
	}

	strncpy(ifr.ifr_name, ctx->brname, IFNAMSIZ);
	ifr.ifr_data = (char *) args;

	err = ioctl(inetSock, SIOCDEVPRIVATE, &ifr);

	close(inetSock);
   
	return err < 0 ? errno : 0;

}

int MoCAOS_DelBrEntries(MoCAOS_Handle handle, const unsigned char *pMac, 
                        int numEntries)
{
	LinuxOS_Context *ctx = (LinuxOS_Context *)handle;
	int              err;
	struct ifreq     ifr;
	int              inetSock;
	int              ifIndex = if_nametoindex(ctx->ifname);
	unsigned long    args[4] = { BRCTL_DEL_FDB_ENTRIES, 
                                 (unsigned long)pMac, 
                                 numEntries, ifIndex };

	/* if moca is not part of a bridge just return */
	if (strlen(ctx->brname) <= 0 )
	    return 0;

	if (ifIndex == 0) 
		return -ENODEV;

	if ((inetSock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) 
	{
		MoCAOS_Printf(handle, "Error cannot open AF_INET socket\n");
		return -1;
	}

	strncpy(ifr.ifr_name, ctx->brname, IFNAMSIZ);
	ifr.ifr_data = (char *) args;

	err = ioctl(inetSock, SIOCDEVPRIVATE, &ifr);

	close(inetSock);
   
	return err < 0 ? errno : 0;

}

int MoCAOS_HandleNlNotify( MoCAOS_Handle handle )
{
	LinuxOS_Context  *ctx = (LinuxOS_Context *)handle;
	int               recvLen;
	char              buf[4096];
	struct iovec      iov = { buf, sizeof buf };
	struct msghdr     msg ;
	struct nlmsghdr  *nl_msgHdr;
	int               len;
	struct ifinfomsg *ifi;
	struct rtattr    *tb[IFLA_MAX + 1];
	struct rtattr    *rta;
	char             *name;
	unsigned char     state = 0;
	int               ret = 0;

	memset(&msg,0,  sizeof(struct msghdr));
	msg.msg_name    = (void*)&ctx->nl_sockaddr;
	msg.msg_namelen = sizeof(ctx->nl_sockaddr);
	msg.msg_iov     = &iov;
	msg.msg_iovlen  = 1 ;

	recvLen = recvmsg(ctx->nl_listen_fd, &msg, 0);
	if(recvLen < 0)
	{
		if (errno == EWOULDBLOCK || errno == EAGAIN)
			return 0;

		/* Anything else is an error */
		return -1;
	}

	if(recvLen == 0)
	{
		MoCAOS_Printf(handle, "read_netlink: EOF\n");
		return 0;
	}

	/* There can be more than one message per recvmsg */
	for(nl_msgHdr = (struct nlmsghdr *) buf; NLMSG_OK (nl_msgHdr, (unsigned int)recvLen);
	      nl_msgHdr = NLMSG_NEXT (nl_msgHdr, recvLen))
	{
		/* Finish reading */
		if (nl_msgHdr->nlmsg_type == NLMSG_DONE)
			return ret;

		/* Message is some kind of error */
		if (nl_msgHdr->nlmsg_type == NLMSG_ERROR)
		{
			continue;
		}

		/* make sure the message is from kernel */
		if(nl_msgHdr->nlmsg_pid !=0)
		{
			//printf("netlink message source(%d)is not kernel",nl_msgHdr->nlmsg_pid);
			return 0;
		}

		switch (nl_msgHdr->nlmsg_type)
		{
			case RTM_NEWLINK:
			case RTM_DELLINK:
				ifi = NLMSG_DATA (nl_msgHdr);
				len = nl_msgHdr->nlmsg_len - NLMSG_LENGTH (sizeof (struct ifinfomsg));
				if (len < 0)
					return -2;

				/* if it is not fromthe bridge we don't care */
				if ( AF_BRIDGE != ifi->ifi_family )
					continue;
 
				/* If the message does not include the interface name then ignore */
				memset (tb, 0, sizeof tb);
				rta = IFLA_RTA(ifi);
				while( RTA_OK(rta, len) )
				{
					if (rta->rta_type <= IFLA_MAX)
						tb[rta->rta_type] = rta;
					rta = RTA_NEXT(rta,len);
				}

				if (tb[IFLA_IFNAME] == NULL)
					break;          
            
				name = (char *)RTA_DATA(tb[IFLA_IFNAME]);
				if ( strlen(ctx->ifname) <= strlen(name) )
				{              
					if ( 0 == strncmp(ctx->ifname, name, strlen(ctx->ifname)))
					{
						if (RTM_DELLINK == nl_msgHdr->nlmsg_type)
						{
							ret |= 1;
						}
						else
						{
							/* we may have been added to a bridge - add ucFwd 
							   entries to the FDB. Make sure operstatus is up */
							if (tb[IFLA_OPERSTATE])
							{
								state = *(__u8 *)RTA_DATA(tb[IFLA_OPERSTATE]);
								if ( IF_OPER_UP == state )
								{
									ret |= 2;
								}
							}   
						}                  
					}
				}
				break;
            
			default:
				//printf(" Unknown netlink nlmsg_type %d, %d, %d\n",
				//       nl_msgHdr->nlmsg_type, RTM_NEWLINK, RTM_DELLINK);
				break;
		}
	}

	return ret;
}
#endif
