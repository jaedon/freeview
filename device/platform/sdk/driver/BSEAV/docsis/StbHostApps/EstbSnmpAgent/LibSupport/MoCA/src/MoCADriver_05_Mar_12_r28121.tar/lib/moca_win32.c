/******************************************************************************
 *
 *  Copyright (c) 2010  Broadcom Corporation
 *  All Rights Reserved
 *
<:license-private
 *
 ************************************************************************/

/***************************************************************************
 *
 *     Copyright (c) 2010, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *  Description: MoCA OS Abstraction -- Win32 implementation
 *
 ***************************************************************************/

#include <fcntl.h>
#include <moca_os.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <time.h>
#include <malloc.h>

#if defined(WIN32)
#include <winsock2.h>
#include <io.h>
#include <direct.h>
#define chdir _chdir
#else
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <stdarg.h>
#include <unistd.h>
#include <pthread.h>
#include <netinet/tcp.h>
#define SOCKET int
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1

#endif

#include "mocalib.h"
#include "mocaint.h"

// Temporary: Fix compilation error (r19571) - To be reomved
#ifdef WIN32
#define __EMU_LOGI__
#endif


#if !defined (__EMU_LOGI__)
#include "COMMON_Project_11.h"
#endif

#define MAX_X(x, y)   (((x) > (y)) ? (x) : (y))

#define CMD_PORT_BASE 0x4500
#define CMD_PORT (CMD_PORT_BASE + g_context.nodeid)
#define EVT_PORT (0x4600 + g_context.nodeid)
#define MOCAD_PORT (0x4700 + g_context.nodeid)
#define FIRMWARE_PORT (0x4800 + g_context.nodeid)

typedef struct
{
    int cmd_sock_port;
    int evt_sock_port;
    int dev_sock_port;

    SOCKET cmd_listen_fd;
    SOCKET evt_listen_fd;

    SOCKET device_fd_in;
    SOCKET device_fd_out;

    fd_set select_fdset;
    int select_maxfd;
    fd_set evt_fdset;
    int evt_maxfd;

    unsigned char *fw_img;
    int fw_len;

    char ifname[MoCAOS_IFNAMSIZE];

    int roundrobin;  // index for processing multiple simultaneous clients in a round-robin fashion

    MoCAOS_DrvInfo kdrv_info;

#if defined(WIN32)
    WSADATA wsaData;
#endif

    struct sockaddr_in firmware_addr;

    int nodeid;

    int daemon;
} WIN32OS_Context;

WIN32OS_Context g_context;
MoCAOS_Handle g_handle = (MoCAOS_Handle) &g_context;

static SOCKET mocaos_OpenListener(char *sockname, int udp)
{
    SOCKET s;
    struct sockaddr_in local;

    local.sin_family = AF_INET;
    local.sin_addr.s_addr = inet_addr( "127.0.0.1" );
    local.sin_port = htons( atoi(sockname) );

   if (udp)
      s = socket( AF_INET, SOCK_DGRAM, 0 );
   else
   {
       int on = 1;
       s = socket( AF_INET, SOCK_STREAM, 0 );
       setsockopt (s, IPPROTO_TCP, TCP_NODELAY, (const char *)&on, sizeof (on));
   }
   
    if (s == INVALID_SOCKET)
    {
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "Unable to open socket: %s\n", strerror(errno));
        exit(-1);
    }

    if(bind( s, (struct sockaddr *)&local, sizeof(local) ) < 0)
    {
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "can't bind: %s\n", strerror(errno));
        exit(-1);
    }
    if (!udp)
    {
       if(listen( s, 8 ) < 0)
       {
           MoCAOS_Printf((MoCAOS_Handle)&g_context, "can't listen: %s\n", strerror(errno));
           exit(-1);
       }
    }
 
    return(s);
}

static SOCKET mocaos_Accept(MoCAOS_Handle handle, SOCKET listen_fd)
{
    SOCKET newfd;

    newfd = accept(listen_fd, NULL, NULL);
    if(newfd < 0) {
        MoCAOS_Printf(handle, "warning: accept() failed: %s\n",
            strerror(errno));
        return(-1);
    }

    return(newfd);
}

MoCAOS_ClientHandle mocaos_ConnectToFirmware(MoCAOS_Handle handle, unsigned int port, struct sockaddr_in *firmware_addr)
{
   SOCKET s;

    firmware_addr->sin_family = AF_INET;
    firmware_addr->sin_addr.s_addr = inet_addr( "127.0.0.1" );
    firmware_addr->sin_port = htons( port );

    s = socket( AF_INET, SOCK_DGRAM, 0 );

    if (s == INVALID_SOCKET)
    {
        MoCAOS_Printf(handle, "Unable to open socket\n");
        exit(-1);
    }
   return (MoCAOS_ClientHandle) s;
}

static void mocaos_Close(MoCAOS_Handle handle, SOCKET fd)
{
    WIN32OS_Context *ctx = (WIN32OS_Context *)handle;
    
#ifdef WIN32    
    closesocket((SOCKET)fd);
#endif
    
#ifdef __gnu_linux__
    close((int)fd);
#endif

    FD_CLR(fd, &ctx->select_fdset);
    FD_CLR(fd, &ctx->evt_fdset);
    if(fd == ctx->select_maxfd) {
        fd_set fds = ctx->select_fdset;
        FD_SET(ctx->cmd_listen_fd, &fds);
        FD_SET(ctx->device_fd_in, &fds);
        while(! FD_ISSET(ctx->select_maxfd, &fds))
            ctx->select_maxfd--;
        }
}

static SOCKET mocaos_OpenDev(MoCAOS_Handle handle, const char *chardev)
{
   char dev_sockname[MOCA_FILENAME_LEN];
   sprintf(dev_sockname, "%d", MOCAD_PORT);

   return(mocaos_OpenListener(dev_sockname,1));
}

MoCAOS_Handle MoCAOS_Init(const char *chardev, char *ifname, const char *workdir, int daemon)
{
    char cmd_sockname[MOCA_FILENAME_LEN];
    char evt_sockname[MOCA_FILENAME_LEN];

    if (workdir)
    {       
        if ((workdir[0] != '\0') && (chdir (workdir)))
        {
            printf("WARNING: unable to change dir to %s\n", workdir);
        }
    }

    memset(&g_context, 0, sizeof(g_context));

   if (ifname)
      sscanf(ifname, "%d", &g_context.nodeid);

   g_context.device_fd_in = mocaos_OpenDev((MoCAOS_Handle)&g_context, chardev);
   g_context.device_fd_out = mocaos_ConnectToFirmware((MoCAOS_Handle)&g_context, FIRMWARE_PORT, &g_context.firmware_addr);
// g_context.device_fd_listen = mocaos_OpenDev((MoCAOS_Handle)&g_context, chardev);
//  printf("Waiting for firmware to connect\n");
//  g_context.device_fd = mocaos_Accept((MoCAOS_Handle)&g_context, g_context.device_fd_listen);
//  printf("Connected!\n");

    if (MoCAOS_GetDriverInfo((MoCAOS_Handle)&g_context, &g_context.kdrv_info) != 0)
    {
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "Kernel/mocad version mismatch.  Ensure kernel and mocad versions are compatible\n");
        exit(-1);
    }

    if(g_context.kdrv_info.refcount != 1)
    {
        MoCAOS_Printf((MoCAOS_Handle)&g_context, "nonzero refcount (%d); is another mocad running?\n", g_context.kdrv_info.refcount);
        exit(-1);
    }

    sprintf(cmd_sockname, "%d", CMD_PORT);
    sprintf(evt_sockname, "%d", EVT_PORT);

    g_context.cmd_listen_fd = mocaos_OpenListener(cmd_sockname,0);
    g_context.evt_listen_fd = mocaos_OpenListener(evt_sockname,0);
    
    FD_ZERO(&g_context.select_fdset);
    FD_SET(g_context.device_fd_in, &g_context.select_fdset);
    FD_SET(g_context.cmd_listen_fd, &g_context.select_fdset);
    FD_SET(g_context.evt_listen_fd, &g_context.select_fdset);

    g_context.select_maxfd = (int)MAX_X(g_context.device_fd_in,
                                 MAX_X(g_context.cmd_listen_fd, 
                                     g_context.evt_listen_fd));

    return (MoCAOS_Handle)&g_context;
}

MoCAOS_ClientHandle MoCAOS_WaitForRequest(MoCAOS_Handle handle, unsigned int timeout_sec)
{
    WIN32OS_Context *ctx = (WIN32OS_Context *)handle;
    fd_set fds = ctx->select_fdset;
    int i;
    int ret;
    struct timeval tv;
    
    tv.tv_sec = timeout_sec;
    tv.tv_usec = 0;

    ret = select(ctx->select_maxfd + 1, &fds, NULL, NULL, &tv);

    if(ret < 0)
        MoCAOS_Printf(handle,"warning: select() failed: %s\n",
            strerror(errno));
/*
    if ( (ret == 0) && FD_ISSET(ctx->device_fd_in, &ctx->select_fdset) )
    {
        return(MoCAOS_CLIENT_CORE);
    } */

    if(ret == 0)
    {
        return MoCAOS_CLIENT_TIMEOUT;
    }

    if(FD_ISSET(ctx->cmd_listen_fd, &fds)) 
    {
        SOCKET newfd = mocaos_Accept(handle, ctx->cmd_listen_fd);
        if(newfd >= 0) 
        {
            FD_SET(newfd, &ctx->select_fdset);
            ctx->select_maxfd = (int)
                MAX_X((SOCKET)ctx->select_maxfd, newfd);
        }
        if(--ret == 0)
            return(MoCAOS_CLIENT_NULL);
        FD_CLR(ctx->cmd_listen_fd, &fds);
    }

    if(FD_ISSET(ctx->evt_listen_fd, &fds)) 
    {
        SOCKET newfd = mocaos_Accept(handle, ctx->evt_listen_fd);

        if(newfd >= 0) 
        {
            FD_SET(newfd, &ctx->evt_fdset);
            ctx->evt_maxfd = (int)MAX_X((SOCKET)ctx->evt_maxfd, newfd);

            FD_SET(newfd, &ctx->select_fdset);
            ctx->select_maxfd = (int)
                MAX_X((SOCKET)ctx->select_maxfd, newfd);
        }
        if(ret-- == 0)
            return(MoCAOS_CLIENT_NULL);
        FD_CLR(ctx->evt_listen_fd, &fds);
    }

    for(i = 0; ret && (i <= ctx->select_maxfd); i++) 
    {
        if(FD_ISSET(i, &fds))
        {
            if(FD_ISSET(i, &ctx->evt_fdset))
            {                
                mocaos_Close(handle, i);
                ret--;                
            }             
        }
    }
    
    if(FD_ISSET(ctx->device_fd_in, &fds))
    {
        return MoCAOS_CLIENT_CORE;
    }

#ifdef DSL_MOCA
    if(FD_ISSET(ctx->nl_listen_fd, &fds)) 
    {
        return MoCAOS_CLIENT_NL;
    }
#endif

    if (ctx->roundrobin > ctx->select_maxfd)
        ctx->roundrobin = 0;

    for(i = ctx->roundrobin; ret; i++) 
    {
        if(FD_ISSET(i, &fds)) 
        {
            return(MoCAOS_ClientHandle)i;
        }

        if (i == ctx->select_maxfd)
            i = 0;
    }

    return(MoCAOS_CLIENT_NULL);
}

int MoCAOS_SendMMP(MoCAOS_Handle handle, MoCAOS_ClientHandle client, const unsigned char *IE, int len)
{
    WIN32OS_Context *ctx = (WIN32OS_Context *)handle;
    int ret;
    SOCKET fd=0;
    int i;
    
    if (client == MoCAOS_CLIENT_BROADCAST)
    {
        /* broadcast event to all evt clients */
        for(i = 0; i <= ctx->evt_maxfd; i++)
        {
            if(FD_ISSET(i, &ctx->evt_fdset))
            {
                ret = send(i, (const char *)IE, len, 0);
                if (ret != len)
                {
                    MoCAOS_Printf(handle, "Warning: short write (%d, %d)\n", ret, len);
                }
            }
        }
        return(0);
    }

    // in emulation, firmware is a connectionless UDP socket
    if (client == MoCAOS_CLIENT_CORE)
    {
       fd = ctx->device_fd_out;
       ret = sendto(ctx->device_fd_out, (const char *)IE, len, 0, (struct sockaddr *)&ctx->firmware_addr, sizeof(ctx->firmware_addr));
    }
    else
    {
      ret = send(client, (const char *)IE, len, 0);
    }

    if (ret != len)
    {
        MoCAOS_Printf(handle, "warning: short write fd=%d (%d, %d, %s)\n", fd, ret, len, strerror(errno));
        return(-1);
    }
    
    return(0);
}

int MoCAOS_ReadMMP(MoCAOS_Handle handle, MoCAOS_ClientHandle client, 
    unsigned int timeout_sec, unsigned char *IE, int *len)  // return 0 timeout, <0 failure, >0 success
{
    WIN32OS_Context *ctx = (WIN32OS_Context *)handle;
    int ret;
    fd_set fds;
    SOCKET fd;
    struct timeval tv;

    if (!ctx)
        ctx = &g_context;

    if (client == MoCAOS_CLIENT_CORE)
        fd = ctx->device_fd_in;
    else
        fd = (SOCKET) client;

    if (timeout_sec != MoCAOS_TIMEOUT_INFINITE)
    {
        FD_ZERO(&fds);
        FD_SET(fd, &fds);
        
        tv.tv_sec = timeout_sec;
        tv.tv_usec = 0;
        
        ret = select((int)fd+1, &fds, NULL, NULL, &tv);

        if(ret < 0)
        {
           MoCAOS_Printf(handle, "warning: select() failed: %s\n",
                strerror(errno));
            return(-1);
        }

        // when the CPU is loaded, make sure we timed out because
        // of a lack of data, not a lack of CPU time
        if ( (ret == 0) && FD_ISSET(ctx->device_fd_in, &ctx->select_fdset) )
        {
            ret = 1;
        }

        if(ret == 0)
        {
            return 0;
        }
    }

    while (1)
    {
        *len = recv(fd, (char *)IE, *len, 0);

        if ((*len < 0) && (client != MoCAOS_CLIENT_CORE))
        {
            mocaos_Close(handle, fd);  // for traps, the event loop will close the other end of the pipe when terminated.  This is normal.
            return(-1);
        } 
        else if ((*len == 0) && (client != MoCAOS_CLIENT_CORE))
        {
            /* closed connection */
            mocaos_Close(handle, fd);
            return(-2);
        }
        else
        {
            break;
        }
    }

    if (client == MoCAOS_CLIENT_CORE)
    {
       *len = (*((unsigned int *)IE + 1) & 0xFFFF) + 8;  // including 8 byte mmp header
    }

    return (1);
}

int MoCAOS_ReadMem(MoCAOS_Handle handle, unsigned char *buf, int len, unsigned char *addr)
{
    //tbd
    return(-1);
}

int MoCAOS_WriteMem(MoCAOS_Handle handle, unsigned char *buf, int len, unsigned char *addr)
{
    // tbd
    return(-1);
}

int MoCAOS_StartCore(MoCAOS_Handle handle, unsigned char *fw_img, int fw_len, 
    unsigned int cont_tx_mode, unsigned char **strings_cpu0, int *strings_size_cpu0,
    unsigned char **strings_cpu1, int *strings_size_cpu1)
{
    // tbd

    return(0);
}

int MoCAOS_StopCore(MoCAOS_Handle handle)
{
    // tbd

    return(0);
}

int MoCAOS_GetDriverInfo(MoCAOS_Handle handle, MoCAOS_DrvInfo *kdrv_info)
{
    WIN32OS_Context *ctx = (WIN32OS_Context *)handle;
    
    memset (kdrv_info, 0, sizeof(MoCAOS_DrvInfo));
    
    kdrv_info->chip_id = 0x74250000;  // tbd
    
    // chip_id not set by kernel
    // Determing MoCA hw_rev from chip id
    switch(kdrv_info->chip_id & 0xFFFF0000)
    {
        case 0x74200000:
        case 0x74100000:
        case 0x33200000:
        case 0x73400000:
        case 0x73420000:
        case 0x71250000:
        case 0x74180000:
            kdrv_info->hw_rev = MOCA_CHIP_11;
            break;
        case 0x74080000:
            kdrv_info->hw_rev = MOCA_CHIP_11_LITE;
            break;
        case 0x74250000:
            kdrv_info->hw_rev = MOCA_CHIP_20;
            break;
        default:
            kdrv_info->hw_rev = MOCA_CHIP_11_PLUS;
    }

    kdrv_info->rf_band = 0; // MOCA_BAND_HIGHRF;
    kdrv_info->refcount = 1;
    
    kdrv_info->macaddr_hi = 0x000000FE;
    kdrv_info->macaddr_lo = ctx->nodeid;

    return(0);
}

unsigned char *MoCAOS_GetFw(MoCAOS_Handle handle, unsigned char *filename, int *fw_len)
{
    WIN32OS_Context *ctx = (WIN32OS_Context *)handle;

    // in the emulator, we don't have a firmware image
    return(ctx->fw_img);
}


void MoCAOS_Printf(MoCAOS_Handle handle, const char *fmt, ...)
{
#if !defined (__EMU_LOGI__)
    static char string[1024];
#endif
    va_list ap;

    va_start(ap, fmt);
#if defined (__EMU_LOGI__)
    vprintf(fmt, ap);

    fflush(stdout);
#else
    vsprintf(string, fmt, ap);
    LOG_I(ALWAYS_PRINT_TRACE, string);
#endif     
    va_end(ap);
}

void MoCAOS_EnableDataIf(MoCAOS_Handle handle, char *ifname, int enable)
{
    // tbd
    return;
}


unsigned int MoCAOS_AllocPhysMem(unsigned int size, unsigned int **paddr)
{
    // tbd
    return(1);
}


MoCAOS_ClientHandle MoCAOS_ConnectToMocad(MoCAOS_Handle handle, const char *fmt, char *ifname)
{
    SOCKET s;
    struct sockaddr_in local;
    int retVal;
    int nodenum = 0;
    int on = 1;
    int a,b;

    if (ifname)
    {
       if (strchr(ifname, ':'))
       {
          sscanf(ifname, "%d:%d",&a,&b);
          nodenum = a + (b<<12);
       }
       else
          nodenum = atoi(ifname);
    }

#if defined(WIN32)
    {
       static int first = 1;
       WSADATA wsaData;

       if (first)
       {
         // Initialize Winsock.  Needed in mocactl
         WSAStartup(MAKEWORD(2,2), &wsaData);
         first = 0;
       }
    }
#endif

    local.sin_family = AF_INET;
    local.sin_addr.s_addr = inet_addr( "127.0.0.1" );

    local.sin_port = htons( CMD_PORT_BASE + nodenum );

    s = socket( AF_INET, SOCK_STREAM, 0 );

    if (s == INVALID_SOCKET)
    {
        MoCAOS_Printf(handle, "Unable to open socket\n");
        exit(-1);
    }

    setsockopt (s, IPPROTO_TCP, TCP_NODELAY, (const char *)&on, sizeof (on));

    retVal = connect(s, (const struct sockaddr *)&local,
            sizeof(struct sockaddr_in));

    if(retVal == SOCKET_ERROR)
    {
#ifdef WIN32    
        closesocket((SOCKET)s);
#endif
        
#ifdef __gnu_linux__
        close((int)s);
#endif
        return(MoCAOS_CLIENT_NULL);
    }
    
    return((MoCAOS_ClientHandle)s);
}

void MoCAOS_CloseClient(MoCAOS_Handle handle, MoCAOS_ClientHandle client)
{
#ifdef WIN32    
    closesocket((SOCKET)client);
#endif

#ifdef __gnu_linux__
    close((int)client);
#endif
}

MoCAOS_MutexHandle MoCAOS_MutexInit()
{   
#ifdef WIN32
    HANDLE mutex;

    mutex = CreateMutex( 
        NULL,              // default security attributes
        FALSE,             // initially not owned
        NULL);             // unnamed mutex

    if (mutex == NULL) 
    {
         MoCAOS_Printf(g_handle, "CreateMutex error: %d\n", GetLastError());
        exit(-1);
    }
    
    return((MoCAOS_MutexHandle) mutex); 
#endif

#ifdef __gnu_linux__
    pthread_mutex_t *x; 

    x = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));

    pthread_mutex_init(x, NULL);

    return((MoCAOS_MutexHandle) x);
#endif

    return((MoCAOS_MutexHandle)0);

}

void MoCAOS_MutexLock(MoCAOS_MutexHandle x)
{
#ifdef WIN32    
    WaitForSingleObject( 
            (HANDLE) x,   
            INFINITE);
#endif

#ifdef __gnu_linux__
    pthread_mutex_lock((pthread_mutex_t *)x);
#endif
}

void MoCAOS_MutexUnlock(MoCAOS_MutexHandle x)
{
#ifdef WIN32    
    ReleaseMutex((HANDLE)x);
#endif
#ifdef __gnu_linux__
    pthread_mutex_unlock((pthread_mutex_t *)x);
#endif
}

void MoCAOS_MutexClose(MoCAOS_MutexHandle x)
{
#ifdef WIN32     
    CloseHandle((HANDLE) x);
#endif
}

int MoCAOS_MemAlign(void **memptr, int alignment, int size)
{
	*memptr = malloc(size);
	return(0);
}

void MoCAOS_MSleep(int msec)
{
#ifdef WIN32    
    Sleep(msec);
#endif

#ifdef __gnu_linux__
    usleep(msec*1000);
#endif
}

MoCAOS_ThreadHandle MoCAOS_CreateThread(MoCAOS_ThreadEntry func, void *arg)
{
#ifdef WIN32    
    return((MoCAOS_ThreadHandle)CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) func, arg, 0, 0));
#endif

#ifdef __gnu_linux__
    static pthread_t thread;
    if (0 == pthread_create(&thread, NULL, (void* (*)(void*))func, arg))
        return((MoCAOS_ThreadHandle)thread);
#endif
    return(MoCAOS_ThreadHandle)0;
}

#define DELTA_EPOCH_IN_MICROSECS  11644473600000000ULL

void MoCAOS_GetTimeOfDay(unsigned int *sec, unsigned int *usec)
{
#ifdef WIN32    
  FILETIME ft;
  unsigned __int64 tmpres = 0;

  GetSystemTimeAsFileTime(&ft);
  
// The GetSystemTimeAsFileTime returns the number of 100 nanosecond 
// intervals since Jan 1, 1601 in a structure. Copy the high bits to 
// the 64 bit tmpres, shift it left by 32 then or in the low 32 bits.
   tmpres |= ft.dwHighDateTime;
   tmpres <<= 32;
   tmpres |= ft.dwLowDateTime;
 
// Convert to microseconds by dividing by 10
   tmpres /= 10;
 
// The Unix epoch starts on Jan 1 1970.  Need to subtract the difference 
// in seconds from Jan 1 1601.
   tmpres -= DELTA_EPOCH_IN_MICROSECS;
 
// Finally change microseconds to seconds and place in the seconds value. 
// The modulus picks up the microseconds.
   if (sec)
      *sec = (long)(tmpres / 1000000UL);

   if (usec)
      *usec = (long)(tmpres % 1000000UL);

#endif

#ifdef __gnu_linux__
   struct timeval tv;   
   gettimeofday(&tv, NULL);   
   if (sec)      
      *sec = tv.tv_sec;
   if (usec)
      *usec = tv.tv_usec;    
#endif
}

int MoCAOS_WolCtrl(MoCAOS_Handle handle, int enable)
{
   return(0);
}
