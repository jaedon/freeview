/******************************************************************************
 *
 * Copyright (c) 2009   Broadcom Corporation
 * All Rights Reserved
 *
<:license-private
 *
 ************************************************************************/
/***************************************************************************
 *
 *    Copyright (c) 2008-2009, Broadcom Corporation
 *    All Rights Reserved
 *    Confidential Property of Broadcom Corporation
 *
 * THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 * AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 * EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 * Description: MoCA userland daemon
 *
 ***************************************************************************/

#include "moca_os.h"

#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include <ctype.h>
#include <errno.h>
#include <stdint.h>


#if defined(WIN32)
#include <io.h>

#ifndef O_SYNC
#define O_SYNC 0
#endif

#define open _open
#define read _read
#define write _write
#define close _close


#else
#include <unistd.h>
#endif

#if defined(__EMU_HOST_11__)
#include "mocad.h"
#endif


#if defined(DSL_MOCA)
#include <cms_msg.h>
#include <cms_psp.h>
#include <ethswctl_api.h>
#endif


#include <mocalib.h>
#include "mocaint.h"

#include "devctl_moca.h"

#if !defined(__EMU_HOST_11__) && !defined(__EMU_HOST_20__)
#define STRING_DECL
#endif

#include "mocad_strings.h"

#define MOCA_BAND_HIGHRF   0
#define MOCA_BAND_MIDRF    1
#define MOCA_BAND_WANRF    2 
#define PACKETRAM_ADDR_REINIT       0xC420
#define MOCAD_FIRMWAREDATA_REINIT_LEN  (40 * 1024)
#define MOCAD_NUM_ERRORS   32

int mocad_keygen(uint8_t mmk[8], uint8_t pmki[8], const unsigned char *in);
int mocad_set_rlapm_en(void * vctx, uint32_t bool_val);
int mocad_set_rlapm_table(void * vctx, struct moca_rlapm_table * out);
int mocad_set_rlapm_cap(void * vctx, uint32_t cap);
int mocad_set_host_qos(void * vctx, uint32_t val);

struct mocad_trap_list {
   uint8_t * trap;
   uint32_t  len;
   struct mocad_trap_list * next;
};


typedef int(*moca_set_fn)(void *vctx, void *in);


struct mocad_any_time_locations
{
   uint32_t ie_type;
   uintptr_t offset;
   uint32_t len;
   uint32_t swap;
   moca_set_fn moca_set;
   uint32_t ptr;  // flag if arg to set function is ptr or int
};

struct accumulated_error_stats
{
   uint32_t       rx_uc_crc_error;
   uint32_t       rx_uc_timeout_error;
   uint32_t       rx_bc_crc_error;
   uint32_t       rx_bc_timoeut_error;
   uint32_t       rx_map_crc_error;
   uint32_t       rx_map_timeout_error;
   uint32_t       rx_beacon_crc_error;
   uint32_t       rx_beacon_timeout_error;
   uint32_t       rx_rr_crc_error;
   uint32_t       rx_rr_timeout_error;
   uint32_t       rx_lc_crc_error;
   uint32_t       rx_lc_timeout_error;
   uint32_t       rx_p1_error;
   uint32_t       rx_p2_error;
   uint32_t       rx_p3_error;
   uint32_t       rx_p1_gcd_error;  
};

struct mocad_egr_mc_addr_filter
{
   uint32_t valid;
   uint32_t addr_hi;
   uint32_t addr_lo;
};

#define MOCA_MAX_EGR_MC_FILTERS 32


// This is for the admission report.
struct moca_adm_info
{
   int32_t idcsave;
   int32_t qdcsavef;
   uint32_t ploft;
   int32_t asave;
   int32_t bsave;
   uint32_t piq;
   uint32_t outpwr;
   uint32_t outrefpwr;
   uint32_t delta;
   uint32_t pad_gc;
   uint32_t actualtxgaintblidx;
   uint32_t finalpwr;
   uint32_t cfo;
   uint32_t numsym;
   uint32_t cp;
   uint32_t numofpkts;
   uint32_t sc1;
   uint32_t sc2;
   uint32_t status;
   uint32_t teta;
   uint32_t rho;
   uint32_t scaleq;
   uint32_t numprobes;
   uint32_t score;
   uint32_t cfo2;
   uint32_t nbas2;
   uint32_t cp2;
   uint32_t pr2;
   uint32_t tpcbk2;
   uint32_t prf2;
   uint32_t nsym2;
   uint32_t gcdbm2;
   uint32_t cu2;
   uint32_t nbas3;
   uint32_t cp3;
   uint32_t pr3;
   uint32_t tpcbk3;
   uint32_t prf3;
   uint32_t nsym3;
   uint32_t gcdbm3;
   uint32_t cu3;
   uint32_t maxtpcadj;
   uint32_t bo;
   uint32_t agc;
   uint32_t total_gain;
   uint32_t rssi;
   uint32_t bo2;
   uint32_t agc2;
   uint32_t total_gain2;
   uint32_t rssi2;
   uint32_t a;
   uint32_t tg;
   uint32_t rs;
   uint32_t nbas10;
   uint32_t cp10;
   uint32_t ht10;
   uint32_t bo10;
   uint32_t profile10;
   uint32_t nsym10;
   uint32_t gcdbm10;
   
   uint32_t nbas11;
   uint32_t cp11;
   uint32_t ht11;
   uint32_t bo11;
   uint32_t profile11;
   uint32_t nsym11;
   uint32_t gcdbm11;

   uint32_t nbas12;
   uint32_t cp12;
   uint32_t ht12;
   uint32_t bo12;
   uint32_t profile12;
   uint32_t nsym12;
   uint32_t gcdbm12;

   uint32_t nbas13;
   uint32_t cp13;
   uint32_t ht13;
   uint32_t bo13;
   uint32_t profile13;
   uint32_t nsym13;
   uint32_t gcdbm13;

   uint32_t state;
   uint32_t nodeid;
};

struct moca_any_time {
   uint32_t    ooo_lmo;
   uint32_t    max_frame_size;
   uint32_t    max_transmit_time;
   uint32_t    min_bw_alarm_threshold;
   uint32_t    continuous_ie_rr_insert;
   uint32_t    continuous_ie_map_insert;
   uint32_t    max_pkt_aggr;   
   uint32_t    max_constellation[MOCA_MAX_NODES];
   uint32_t    pmk_exchange_interval;
   uint32_t    tek_exchange_interval;
   struct moca_priority_allocations priority_allocations;
   struct moca_snr_margin_table snr_margin_table;
   uint32_t    min_map_cycle;
   uint32_t    max_map_cycle;
   uint32_t    rx_tx_packets_per_qm;
   uint32_t    extra_rx_packets_per_qm;
   uint32_t    target_phy_rate_qam128;
   uint32_t    target_phy_rate_qam256;
   uint32_t    target_phy_rate_turbo;
   uint32_t    target_phy_rate_turbo_plus;    
   uint32_t    nbas_capping_en;    
   uint32_t    selective_rr;        
   uint32_t    loopback_en;    
   uint32_t    sapm_en;
   int32_t     arpl_th;
   struct moca_sapm_table sapm_table;
   uint32_t    rlapm_en;
   struct moca_rlapm_table rlapm_table;
   uint32_t    freq_shift_mode;
   uint32_t    pss_en;
   uint32_t    beacon_channel_set;
   struct moca_lab_iq_diagram_set lab_iq_diagram_set;
   uint32_t    lab_snr_graph_set;
   struct moca_lab_tpcap lab_tpcap;
   uint32_t    core_trace_enable;
   struct mocad_egr_mc_addr_filter egr_mc_addr_filter[MOCA_MAX_EGR_MC_FILTERS];
   int32_t     rx_power_tuning;   
   uint32_t    en_capable;
   uint32_t    res1;
   uint32_t    res2;
   uint32_t    res3;  
   uint32_t    min_aggr_wait_time;
   int32_t     diplexer;
   uint32_t    en_max_rate_in_max_bo;
   uint32_t    rlapm_cap;
   uint32_t    miscval;  // used for tpcap temporary address storage
   uint32_t    host_qos;
};

struct mocad_ctx {
   char        ifname[MoCAOS_IFNAMSIZE];
   MoCAOS_Handle os_handle;
   MoCAOS_DrvInfo kdrv_info;
   uint32_t    moca_sw_version;
   int         moca_running;
   int         restart;
   struct moca_init_time   init_time;  /* native endian order */
   struct moca_init_time_options init_time_options; /* native endian order */
   struct moca_password password;
   int         disk_lof;
   int         disk_nondefseqnum;
   int         link_state;
   time_t      core_uptime;   /* last time core came up */
   time_t      core_downtime; /* last time core went down */
   time_t      link_uptime;   /* last time link came up */
   time_t      link_downtime; /* last time link went down */

   uint8_t     sock_in[MOCA_BUF_LEN];
   uint8_t     sock_out[MOCA_BIG_BUF_LEN];
   uint8_t     drv_out[MOCA_BUF_LEN];
   uint8_t     drv_in[MOCA_BUF_LEN];
   uint8_t     trap_buf[MOCA_BUF_LEN];
   struct mocad_trap_list * trap_list;
   uint32_t    trap_count;
   uint32_t    trap_watermark;

   char        *fw_file;
   void        *fw_img;
   unsigned int fw_len;

   int         verbose;
   int         show_lab_printf;
   int         in_lab_printf;
   char        core_print_prefix[MoCAOS_IFNAMSIZE+4];
   int         lab_printf_wdog_count;
   struct moca_error_to_mask error_to_mask;

   /* any time parameters */
   struct moca_any_time any_time;

   /* local counters */
   uint64_t    in_octets;
   uint64_t    out_octets;
   struct moca_gen_stats   gen_stats;
   struct moca_ext_stats   ext_stats;
   struct moca_node_stats  node_stats[MOCA_MAX_NODES];
   struct moca_node_stats_ext node_stats_ext[MOCA_MAX_NODES];
   struct moca_pqos_table  pqos_table[MOCA_MAX_PQOS_ENTRIES];

   struct accumulated_error_stats acc_err_stats[MOCA_MAX_NODES];


   uint8_t     *cir_data[MOCA_MAX_NODES];

   time_t      tekTime;
   time_t      tekLastInterval;
   uint32_t    tekEvenOdd;
   time_t      pmkTime;
   time_t      pmkLastInterval;
   uint32_t    pmkEvenOdd;
   uint32_t    active_nodes;

#if defined(DSL_MOCA)
   void        *cmsMsgHandle;
   int         numUcFwdEntries;
   struct moca_uc_fwd ucFwdTable[128]; /* 128 matches MoCA_MAX_UC_FWD_ENTRIES */
#endif
   uint32_t    tpcapbufphys;
   uint32_t    rx_pkts;
   uint32_t    tx_pkts;
   uint32_t    bc_pkts;
   uint8_t     firmwareInitData[MOCAD_FIRMWAREDATA_REINIT_LEN];
   uint8_t     xfirmwareInitData[MOCAD_FIRMWAREDATA_REINIT_LEN];
   uint32_t    silentlyDropTraps;
   const char *workdir;
   struct moca_adm_info adm_info;
   uint32_t    prev_host_qos;
   unsigned int cpu_check_sec;
   int32_t     sizeofcpu0strings;
   unsigned char *cpu0strings;
   int32_t     sizeofcpu1strings;
   unsigned char *cpu1strings;

   int32_t  error_list[MOCAD_NUM_ERRORS];
   uint32_t error_index;
   uint32_t error_wrap;
};


#define ANYTIME_OFFS(MEMBER) ((uintptr_t) &((struct moca_any_time *)0)->MEMBER)
#define ANYTIME_SIZE(MEMBER) ((size_t) sizeof(((struct moca_any_time *)0)->MEMBER))

static struct mocad_any_time_locations g_AnyTimeLocations[] = 
{
   {IE_MAX_FRAME_SIZE, ANYTIME_OFFS(max_frame_size), ANYTIME_SIZE(max_frame_size), 1, 
      (moca_set_fn)moca_set_max_frame_size, 0},
   {IE_MAX_TRANSMIT_TIME, ANYTIME_OFFS(max_transmit_time), ANYTIME_SIZE(max_transmit_time), 1, 
      (moca_set_fn)moca_set_max_transmit_time, 0},
   {IE_MIN_BW_ALARM_THRESHOLD,  ANYTIME_OFFS(min_bw_alarm_threshold), ANYTIME_SIZE(min_bw_alarm_threshold), 1, 
      (moca_set_fn)moca_set_min_bw_alarm_threshold, 0},
   {IE_CONTINUOUS_IE_RR_INSERT, ANYTIME_OFFS(continuous_ie_rr_insert), ANYTIME_SIZE(continuous_ie_rr_insert), 1, 
      (moca_set_fn)moca_set_continuous_ie_rr_insert, 0},
   {IE_CONTINUOUS_IE_MAP_INSERT, ANYTIME_OFFS(continuous_ie_map_insert), ANYTIME_SIZE(continuous_ie_map_insert), 1, 
      (moca_set_fn)moca_set_continuous_ie_map_insert, 0},
   {IE_MAX_PKT_AGGR, ANYTIME_OFFS(max_pkt_aggr), ANYTIME_SIZE(max_pkt_aggr), 1, 
      (moca_set_fn)moca_set_max_pkt_aggr, 0},
   {IE_MAX_CONSTELLATION, 0xFFFFFFFF, 0, 0},  // handle manually
   {IE_PMK_EXCHANGE_INTERVAL, ANYTIME_OFFS(pmk_exchange_interval), ANYTIME_SIZE(pmk_exchange_interval), 1, 
      (moca_set_fn)moca_set_pmk_exchange_interval, 0},
   {IE_TEK_EXCHANGE_INTERVAL, ANYTIME_OFFS(tek_exchange_interval), ANYTIME_SIZE(tek_exchange_interval), 1, 
      (moca_set_fn)moca_set_tek_exchange_interval, 0},
   {IE_PRIORITY_ALLOCATIONS, ANYTIME_OFFS(priority_allocations), ANYTIME_SIZE(priority_allocations), 1, 
      (moca_set_fn)moca_set_priority_allocations, 1},
   {IE_SNR_MARGIN_TABLE, ANYTIME_OFFS(snr_margin_table), ANYTIME_SIZE(snr_margin_table), 0, 
      (moca_set_fn)moca_set_snr_margin_table, 1},
   {IE_MIN_MAP_CYCLE, ANYTIME_OFFS(min_map_cycle), ANYTIME_SIZE(min_map_cycle), 1, 
      (moca_set_fn)moca_set_min_map_cycle, 0},
   {IE_MAX_MAP_CYCLE, ANYTIME_OFFS(max_map_cycle), ANYTIME_SIZE(max_map_cycle), 1, 
      (moca_set_fn)moca_set_max_map_cycle, 0},
   {IE_RX_TX_PACKETS_PER_QM, ANYTIME_OFFS(rx_tx_packets_per_qm), ANYTIME_SIZE(rx_tx_packets_per_qm), 1, 
      (moca_set_fn)moca_set_rx_tx_packets_per_qm, 0},
   {IE_EXTRA_RX_PACKETS_PER_QM, ANYTIME_OFFS(extra_rx_packets_per_qm), ANYTIME_SIZE(extra_rx_packets_per_qm), 1, 
      (moca_set_fn)moca_set_extra_rx_packets_per_qm, 0},
   {IE_TARGET_PHY_RATE_QAM128, ANYTIME_OFFS(target_phy_rate_qam128), ANYTIME_SIZE(target_phy_rate_qam128), 1,
      (moca_set_fn)moca_set_target_phy_rate_qam128, 0},
   {IE_TARGET_PHY_RATE_QAM256, ANYTIME_OFFS(target_phy_rate_qam256), ANYTIME_SIZE(target_phy_rate_qam256), 1, 
      (moca_set_fn)moca_set_target_phy_rate_qam256, 0},
   {IE_TARGET_PHY_RATE_TURBO, ANYTIME_OFFS(target_phy_rate_turbo), ANYTIME_SIZE(target_phy_rate_turbo), 1,
      (moca_set_fn)moca_set_target_phy_rate_turbo, 0},
   {IE_TARGET_PHY_RATE_TURBO_PLUS, ANYTIME_OFFS(target_phy_rate_turbo_plus), ANYTIME_SIZE(target_phy_rate_turbo_plus), 1,
      (moca_set_fn)moca_set_target_phy_rate_turbo_plus, 0},
   {IE_NBAS_CAPPING_EN, ANYTIME_OFFS(nbas_capping_en), ANYTIME_SIZE(nbas_capping_en), 1,
      (moca_set_fn)moca_set_nbas_capping_en, 0},
   {IE_LOOPBACK_EN, ANYTIME_OFFS(loopback_en), ANYTIME_SIZE(loopback_en), 1,
      (moca_set_fn)moca_set_loopback_en, 0},
   {IE_SELECTIVE_RR, ANYTIME_OFFS(selective_rr), ANYTIME_SIZE(selective_rr), 1,
      (moca_set_fn)moca_set_selective_rr, 0},
   {IE_SAPM_EN, ANYTIME_OFFS(sapm_en), ANYTIME_SIZE(sapm_en), 1, 
      (moca_set_fn)moca_set_sapm_en, 0},
   {IE_ARPL_TH, ANYTIME_OFFS(arpl_th), ANYTIME_SIZE(arpl_th), 1, 
      (moca_set_fn)moca_set_arpl_th, 0},
   {IE_SAPM_TABLE, ANYTIME_OFFS(sapm_table), ANYTIME_SIZE(sapm_table), 0, 
      (moca_set_fn)moca_set_sapm_table, 1},
   {IE_RLAPM_EN, ANYTIME_OFFS(rlapm_en), ANYTIME_SIZE(rlapm_en), 1, 
      (moca_set_fn)mocad_set_rlapm_en, 0},
   {IE_RLAPM_TABLE, ANYTIME_OFFS(rlapm_table), ANYTIME_SIZE(rlapm_table), 0, 
      (moca_set_fn)mocad_set_rlapm_table, 1},
   {IE_BEACON_CHANNEL_SET, ANYTIME_OFFS(beacon_channel_set), ANYTIME_SIZE(beacon_channel_set), 1, 
      (moca_set_fn)moca_set_beacon_channel_set, 0},
   {IE_PSS_EN, ANYTIME_OFFS(pss_en), ANYTIME_SIZE(pss_en), 1, 
      (moca_set_fn)moca_set_pss_en, 0},
   {IE_FREQ_SHIFT, ANYTIME_OFFS(freq_shift_mode), ANYTIME_SIZE(freq_shift_mode), 1, 
      (moca_set_fn)moca_set_freq_shift, 0},
   {IE_EN_CAPABLE, ANYTIME_OFFS(en_capable), ANYTIME_SIZE(en_capable), 1, 
      (moca_set_fn)NULL, 1},
   {IE_CONFIG_RESERVED_1, ANYTIME_OFFS(res1), ANYTIME_SIZE(res1), 1, 
      (moca_set_fn)moca_set_config_reserved_1, 0},
   {IE_CONFIG_RESERVED_2, ANYTIME_OFFS(res2), ANYTIME_SIZE(res2), 1, 
      (moca_set_fn)moca_set_config_reserved_2, 0},
   {IE_CONFIG_RESERVED_3, ANYTIME_OFFS(res3), ANYTIME_SIZE(res3), 1, 
      (moca_set_fn)moca_set_config_reserved_3, 0},
   {IE_MIN_AGGR_WAITING_TIME, ANYTIME_OFFS(min_aggr_wait_time), ANYTIME_SIZE(min_aggr_wait_time), 1, 
      (moca_set_fn)moca_set_min_aggr_waiting_time, 0},
   {IE_EN_MAX_RATE_IN_MAX_BO, ANYTIME_OFFS(en_max_rate_in_max_bo), ANYTIME_SIZE(en_max_rate_in_max_bo), 1, 
      (moca_set_fn)moca_set_en_max_rate_in_max_bo, 0},    

   {0, 0, 0, 0, 0},  
   // Entries below this will not be sent during startup

   {IE_OOO_LMO, ANYTIME_OFFS(ooo_lmo), ANYTIME_SIZE(ooo_lmo), 1, 
      (moca_set_fn)moca_set_ooo_lmo, 0},
   {IE_LAB_TPCAP, ANYTIME_OFFS(lab_tpcap), ANYTIME_SIZE(lab_tpcap), 1, 
      (moca_set_fn)NULL, 0},
   {IE_LAB_IQ_DIAGRAM_SET, ANYTIME_OFFS(lab_iq_diagram_set), ANYTIME_SIZE(lab_iq_diagram_set), 1, 
      (moca_set_fn)moca_set_lab_iq_diagram_set, 1},
   {IE_LAB_SNR_GRAPH_SET, ANYTIME_OFFS(lab_snr_graph_set), ANYTIME_SIZE(lab_snr_graph_set), 1, 
      (moca_set_fn)moca_set_lab_snr_graph_set, 0},
   {IE_MOCA_CORE_TRACE_ENABLE, 0xFFFFFFFF, 0, 0, 0}, // handle manually
   {IE_EGR_MC_ADDR_FILTER, 0xFFFFFFFF, 0, 0, 0},
   {IE_DIPLEXER, ANYTIME_OFFS(diplexer), ANYTIME_SIZE(diplexer), 1, (moca_set_fn)NULL, 0},
   {IE_RX_POWER_TUNING, ANYTIME_OFFS(rx_power_tuning), ANYTIME_SIZE(rx_power_tuning), 1, 
      (moca_set_fn)NULL, 0},
   {IE_RLAPM_CAP, ANYTIME_OFFS(rlapm_cap), ANYTIME_SIZE(rlapm_cap), 1, 
      (moca_set_fn)mocad_set_rlapm_cap, 0},    
   {IE_MISCVAL, ANYTIME_OFFS(miscval), ANYTIME_SIZE(miscval), 1, 
      (moca_set_fn)NULL, 0},
   {IE_HOST_QOS, ANYTIME_OFFS(host_qos), ANYTIME_SIZE(host_qos), 1, 
      (moca_set_fn)mocad_set_host_qos, 0}
};

#define MOCA_REQ_TIMEOUT   2
#define MOCA_STAT_INTERVAL 20

#define LINK_STATE_DOWN    0
#define LINK_STATE_UP      1
#define LINK_STATE_DEBUG   -1

#define MOCA_TIME_EVENT_CORE_UP   0
#define MOCA_TIME_EVENT_CORE_DOWN 1
#define MOCA_TIME_EVENT_LINK_UP   2
#define MOCA_TIME_EVENT_LINK_DOWN 3

#define CPU_CHECK_INTERVAL        5   //every 5 seconds
#define CPU_CHECK_MARGIN_ERR      1   // Allow plus or minus 1 second difference

#define L_DEBUG         (1 << 0)
#define L_VERBOSE    (1 << 1)
#define L_INFO       (1 << 2)
#define L_WARN       (1 << 3)
#define L_ERR        (1 << 4)
#define L_TRAP       (1 << 5)
#define L_MMP_MSG    (1 << 6)

#define MOCA_INVALID_NODE_ID 0xFF

#define MOCAD_MAX_DEFERRED_TRAPS 100

#define MOCAD_PQOS_FILTER_HASH "801:"

#define MAX(x, y)    (((x) > (y)) ? (x) : (y))

typedef enum {
   MMP_PRINT_QUEUE_FULL_ERROR = 1,
   MMP_PRINT_BUFFER_FULL_ERROR   = 2,
   MMP_TRAP_QUEUE_FULL_ERROR  = 3,
   MMP_MOCA_CORE_ERROR_START  = 4,
   MMP_MOCA_DUPLICATE_ADDRESS_ERROR_NN = 64,
   MMP_MOCA_DUPLICATE_ADDRESS_ERROR_EN = 65,
   MMP_MOCA_DUPLICATE_ADDRESS_ERROR_NC = 67,
   MMP_MOCA_CORE_ERROR_END    = 1000,
   MMP_ASSERTION_ERROR     = 1001
} MMP_ERRORS_E;

typedef enum {
   MOCAD_PQOS_SWITCH_ADD,
   MOCAD_PQOS_SWITCH_DELETE
} MOCAD_PQOS_SWITCH_ACTIONS_E;

extern StringsArray_T moca_core_lab_strings[MOCA_STR_LAYER_LAST];

int mocad_cmd(void *ctx, uint8_t msg_type, uint16_t ie_type,
   const void *wr, int wr_len, void *rd, int rd_len, int flags);
int mocad_table_cmd(void *vctx, uint16_t ie_type, void **rd);
static void mocad_remove_pqos_flows(struct mocad_ctx *ctx);
static int mocad_set_all_anytime(struct mocad_ctx *ctx);
static int mocad_reg_write_multiple(
   struct mocad_ctx *ctx, uint32_t reg, uint32_t *val, uint32_t nwords);
int mocad_write_lof(struct mocad_ctx *ctx, int lof);
void mocad_init_forwarding(struct mocad_ctx *ctx);

#ifdef DSL_MOCA
static int mocad_find_brname(struct mocad_ctx *ctx);
static int mocad_update_br_entries(struct mocad_ctx *ctx, int delAll);
#endif

/*
 * CLI / LOGGING
 */

void mocad_usage(struct mocad_ctx *ctx)
{
   MoCAOS_Printf(ctx->os_handle, "usage: mocad [ -d <device> ] [ -w ] [ -f <firmware> ] [ -D ] "
      "[ -F <freq> ]\n"
      "         [ -q ] [ -v[v[v]] ] [ -P ]\n"
      "\n"
      "  -d <device>   Use <device> (default: /dev/bmoca0)\n"
      "  -w         Wait for START command (default: "
      "start MoCA immediately)\n"
      "  -f <firmware>   Use alternate firmware image "
      "(default: " MOCACORE_PATH_0 ")\n"
      "  -D         Run as a daemon (default: run in "
      "foreground)\n"
      "  -F <freq>     Force RF channel to <freq> Mhz "
      "(default: autoscan)\n"
      "\n"
      "Log levels:\n"
      "  (default)     Warnings, errors, major events\n"
      "  -q         Quiet: warnings and errors only\n"
      "  -v         Verbose: add minor socket hiccups\n"
      "  -vv           Debug: add debug messages\n"
      "  -vvv          Dump: add MMP hex dumps\n"
      "  -P         Enable lab_printf from core\n"
      "  -i         Specify MoCA interface name\n");
}

void die(const char *fmt, ...)
{
   va_list ap;

   va_start(ap, fmt);
   vfprintf(stderr, fmt, ap);
   va_end(ap);
    
//  exit(1);
}

int mocad_set_moca_core_trace_enable(struct mocad_ctx *ctx, uint32_t bool_val)
{
   int ret = 0;

   if (ctx->any_time.core_trace_enable != bool_val)
   {
      ret = moca_set_moca_core_trace_enable((void *)ctx, bool_val);

      if (ret == 0)
      {
         ctx->any_time.core_trace_enable = bool_val;
      }
   }

   return ret;
}

void mocad_dump_buf(struct mocad_ctx *ctx, const char *pfx,
   unsigned char *buf, int len)
{
   int i, j;

   if(ctx->in_lab_printf) {
      MoCAOS_Printf(ctx->os_handle, "\n");
      ctx->in_lab_printf = 0;
   }
   if(len < 0) {
      MoCAOS_Printf(ctx->os_handle, "%s < %d bytes truncated >\n", pfx, -len);
      return;
   }
   for(i = 0; i < len; i += 0x10) {
      MoCAOS_Printf(ctx->os_handle, "%s ", pfx); 
      for(j = 0; (j < 0x10) && ((i + j) < len); j += 4)
         MoCAOS_Printf(ctx->os_handle, "%02x%02x%02x%02x ",
            buf[i + j], buf[i + j + 1],
            buf[i + j + 2], buf[i + j + 3]);
      MoCAOS_Printf(ctx->os_handle, "\n"); 
   }
}

void mocad_lab_printf(struct mocad_ctx *ctx, char *msg)
{
   char *eol;
   const char *pfx;

   while(msg && *msg) {
      if(! ctx->in_lab_printf)
         pfx = ctx->core_print_prefix;
      else
         pfx = "";

      eol = strchr(msg, '\n');
      if(eol) {
         *eol = 0;
         if(ctx->in_lab_printf || msg != eol)
            MoCAOS_Printf(ctx->os_handle, "%s%s\n", pfx, msg);
         ctx->in_lab_printf = 0;
         msg = eol + 1;
      } else {
         MoCAOS_Printf(ctx->os_handle, "%s%s", pfx, msg);
         ctx->in_lab_printf = 1;
         msg = NULL;
      }
   }
}

void mocad_log(struct mocad_ctx *ctx, int lev, const char *fmt, ...)
{
   va_list ap;

   if((ctx->verbose & lev) == 0)
   {
      return;
   }

   va_start(ap, fmt);
   if(ctx->in_lab_printf) {
      MoCAOS_Printf(ctx->os_handle, "\n");
      ctx->in_lab_printf = 0;
   }
   if((strlen(ctx->ifname) > 6) || !ctx->ifname[0])
      MoCAOS_Printf(ctx->os_handle,"MOCA: ");
   else
      MoCAOS_Printf(ctx->os_handle,"%4s: ", ctx->ifname);

   vprintf(fmt, ap);
   va_end(ap);
}



int mocad_is64bitformat(char *x)
{
   x++;  // skip past %

   // skip past numbers
   while ((*x >= '0') && (*x <= '9')) x++;

   if ((*x == 'l') && (*(x+1) == 'l'))
      return(1);
   else
      return(0);
}


int checkPacketRam(struct mocad_ctx *ctx)
{
   int i;
   int rc = 0;

   if (ctx->kdrv_info.hw_rev != MOCA_CHIP_20)
   {
      MoCAOS_ReadMem(ctx->os_handle, ctx->xfirmwareInitData, MOCAD_FIRMWAREDATA_REINIT_LEN, (unsigned char *)PACKETRAM_ADDR_REINIT);

      for (i=0;i<MOCAD_FIRMWAREDATA_REINIT_LEN;i++)
      {
         if (ctx->xfirmwareInitData[i] != ctx->firmwareInitData[i])
         {
            rc = 1;
            mocad_log(ctx, L_ERR, "%04X: %02X\n", i, ctx->xfirmwareInitData[i]);
         }
      }
   }
   return(rc);
}

void mocad_print_adm(struct mocad_ctx * ctx)
{
    char str[256];
    unsigned char ncMacAddr[6];
    unsigned char macAddr[6];
    struct moca_gen_status gs;
    struct moca_gen_node_status gns;

    moca_get_gen_status(ctx, &gs);    
    
    moca_get_gen_node_status(ctx, gs.nc_node_id, &gns);
    moca_u32_to_mac(ncMacAddr, gns.eui_hi, gns.eui_lo);

    moca_u32_to_mac(macAddr, ctx->kdrv_info.macaddr_hi, ctx->kdrv_info.macaddr_lo);    


    sprintf(str, "+===========================================================================\n");
    mocad_lab_printf(ctx, str);
    sprintf(str, "TX_Calibration1       : IdcSave=%d, QdcSavef=%d, Ploft=%u, ASave=%d, BSave=%d, Piq=%u\n",
        (int)ctx->adm_info.idcsave, (int)ctx->adm_info.qdcsavef, (unsigned int)ctx->adm_info.ploft, (int)ctx->adm_info.asave, 
        (int)ctx->adm_info.bsave, (unsigned int)ctx->adm_info.piq);
    mocad_lab_printf(ctx, str);
    sprintf(str, "TX_Calibration2       : OutPwr=%u, OutRefPwr=%u, Delta=%u, Pad_gc=%u, ActualTxGainTblIdx=%u, FinalPwr=%x\n",
        (unsigned int)ctx->adm_info.outpwr, (unsigned int)ctx->adm_info.outrefpwr, (unsigned int)ctx->adm_info.delta, (unsigned int)ctx->adm_info.pad_gc, (unsigned int)ctx->adm_info.actualtxgaintblidx,
        (unsigned int)ctx->adm_info.finalpwr);
    mocad_lab_printf(ctx, str);
    sprintf(str, "RX_ProbeI_for_ProbeII : numSym=%u, cp=%u, NumOfPkts=%u, sc1=%u, sc2=%u, Status=%u\n",
        (unsigned int)ctx->adm_info.numsym, (unsigned int)ctx->adm_info.cp, (unsigned int)ctx->adm_info.numofpkts, (unsigned int)ctx->adm_info.sc1, (unsigned int)ctx->adm_info.sc2, (unsigned int)ctx->adm_info.status);
    mocad_lab_printf(ctx, str);
    sprintf(str, "RX_Probe_II_results   : teta=%u, rho=%x, scaleQ=%u, num_probes=%u, score=%08x, cfo=-%u\n",
        (unsigned int)ctx->adm_info.teta, (unsigned int)ctx->adm_info.rho, (unsigned int)ctx->adm_info.scaleq, (unsigned int)ctx->adm_info.numprobes,
        (unsigned int)ctx->adm_info.score, (unsigned int)ctx->adm_info.cfo2);
    mocad_lab_printf(ctx, str);
    sprintf(str, "-===========================================================================\n");
    mocad_lab_printf(ctx, str);
    
    sprintf(str, "+===========================================================================\n");
    mocad_lab_printf(ctx, str);
    sprintf(str, "Info                : Self_MAC=%02X:%02X:%02X:%02X:%02X:%02X, NC_MAC=%02X:%02X:%02X:%02X:%02X:%02X, ANB=%x\n",        
        macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5],
        ncMacAddr[0], ncMacAddr[1], ncMacAddr[2], ncMacAddr[3], ncMacAddr[4], ncMacAddr[5],
        (unsigned int)(gs.connected_nodes | (1<<gs.node_id)));
    mocad_lab_printf(ctx, str);
    sprintf(str, "Tx_Broadcast_Report : nbas=%u, cp=%u, pr=%u, tpcBk=%u, prf=%u, nsym=%u, gcdBM=%08x, CU=%u\n",
        (unsigned int)ctx->adm_info.nbas2, (unsigned int)ctx->adm_info.cp2, (unsigned int)ctx->adm_info.pr2, (unsigned int)ctx->adm_info.tpcbk2, (unsigned int)ctx->adm_info.prf2,
        (unsigned int)ctx->adm_info.nsym2, (unsigned int)ctx->adm_info.gcdbm2, (unsigned int)ctx->adm_info.cu2);
    mocad_lab_printf(ctx, str);
    sprintf(str, "Tx_Map_Report       : nbas=%u, cp=%u, pr=%u, tpcBk=%u, prf=%u, nsym=%u, gcdBM=%08x, CU=%u\n",
        (unsigned int)ctx->adm_info.nbas3, (unsigned int)ctx->adm_info.cp3, (unsigned int)ctx->adm_info.pr3, (unsigned int)ctx->adm_info.tpcbk3, (unsigned int)ctx->adm_info.prf3,
        (unsigned int)ctx->adm_info.nsym3, (unsigned int)ctx->adm_info.gcdbm3, (unsigned int)ctx->adm_info.cu3);
    mocad_lab_printf(ctx, str);
    sprintf(str, "-===========================================================================\n");
    mocad_lab_printf(ctx, str);
    
    
    sprintf(str, "+===========================================================================\n");
    mocad_lab_printf(ctx, str);

    sprintf(str, "Info            : Self_MAC=%02X:%02X:%02X:%02X:%02X:%02X, NC_MAC=%02X:%02X:%02X:%02X:%02X:%02X, LnID=%u, maxTpcAdj=%u, ANB=%x\n",
        macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5],
        ncMacAddr[0], ncMacAddr[1], ncMacAddr[2], ncMacAddr[3], ncMacAddr[4], ncMacAddr[5],
        (unsigned int)ctx->adm_info.nodeid, (unsigned int)ctx->adm_info.maxtpcadj, (unsigned int)(gs.connected_nodes | (1<<gs.node_id)));
    mocad_lab_printf(ctx, str);
    sprintf(str, "OpenLoop_Power  : BO=%u, agc=%u, total_gain=%u, rssi=%u\n",
        (unsigned int)ctx->adm_info.bo, (unsigned int)ctx->adm_info.agc, (unsigned int)ctx->adm_info.total_gain, (unsigned int)ctx->adm_info.rssi);
    mocad_lab_printf(ctx, str);
    sprintf(str, "OuterLoop_Power : BO=%u, agc=%u, total_gain=%u, rssi=%u\n",
        (unsigned int)ctx->adm_info.bo2, (unsigned int)ctx->adm_info.agc2, (unsigned int)ctx->adm_info.total_gain2, (unsigned int)ctx->adm_info.rssi2);
    mocad_lab_printf(ctx, str);
    sprintf(str, "Diversity       : a=%u, tg=%u, rs=%u\n",
        (unsigned int)ctx->adm_info.a, (unsigned int)ctx->adm_info.tg, (unsigned int)ctx->adm_info.rs);
    mocad_lab_printf(ctx, str);
    sprintf(str, "Rx_UC_Report    : nBas=%u, CP=%u, HT=%u, BO=%u, Profile=%u, nsym=%u, gcdBM=%u\n",
        (unsigned int)ctx->adm_info.nbas10, (unsigned int)ctx->adm_info.cp10, (unsigned int)ctx->adm_info.ht10, (unsigned int)ctx->adm_info.bo10,
        (unsigned int)ctx->adm_info.profile10, (unsigned int)ctx->adm_info.nsym10, (unsigned int)ctx->adm_info.gcdbm10);
    mocad_lab_printf(ctx, str);
    sprintf(str, "Tx_UC_Report    : nBas=%u, CP=%u, HT=%u, BO=%u, Profile=%u, nsym=%u, gcdBM=%u\n",
        (unsigned int)ctx->adm_info.nbas11, (unsigned int)ctx->adm_info.cp11, (unsigned int)ctx->adm_info.ht11, (unsigned int)ctx->adm_info.bo11,
        (unsigned int)ctx->adm_info.profile11, (unsigned int)ctx->adm_info.nsym11, (unsigned int)ctx->adm_info.gcdbm11);        
    mocad_lab_printf(ctx, str);
    sprintf(str, "Rx_BC_Report    : nBas=%u, CP=%u, HT=%u, BO=%u, Profile=%u, nsym=%u, gcdBM=%u\n",
        (unsigned int)ctx->adm_info.nbas12, (unsigned int)ctx->adm_info.cp12, (unsigned int)ctx->adm_info.ht12, (unsigned int)ctx->adm_info.bo12,
        (unsigned int)ctx->adm_info.profile12, (unsigned int)ctx->adm_info.nsym12, (unsigned int)ctx->adm_info.gcdbm12);        
    mocad_lab_printf(ctx, str);
    sprintf(str, "Rx_Map_Report   : nBas=%u, CP=%u, HT=%u, BO=%u, Profile=%u, nsym=%u, gcdBM=%u\n",
        (unsigned int)ctx->adm_info.nbas13, (unsigned int)ctx->adm_info.cp13, (unsigned int)ctx->adm_info.ht13, (unsigned int)ctx->adm_info.bo13,
        (unsigned int)ctx->adm_info.profile13, (unsigned int)ctx->adm_info.nsym13, (unsigned int)ctx->adm_info.gcdbm13);        
    mocad_lab_printf(ctx, str);
    sprintf(str, "-===========================================================================\n");
    mocad_lab_printf(ctx, str);   
}


void mocad_parse_adm_info(struct mocad_ctx *ctx, int layer, int string_id, const char *fmt, char *str)
{
   int a,b,c, d;       

   if (layer == 5) // dme
   {
      switch(string_id)
      {
         case 28:               
            sscanf(str, fmt, &ctx->adm_info.nodeid, &a, &b);
                
            mocad_print_adm(ctx);
                 
            break;
      }
   }
   else if (layer == 3) // phy
   {
      switch (string_id)
      {
         case 21: 
            sscanf(str, fmt, &ctx->adm_info.idcsave, &ctx->adm_info.qdcsavef, &ctx->adm_info.ploft);
            break;
         case 22:
            sscanf(str, fmt, &ctx->adm_info.asave, &ctx->adm_info.bsave, &ctx->adm_info.piq);
            break;
         case 17:
            sscanf(str, fmt, &ctx->adm_info.outpwr, &ctx->adm_info.outrefpwr, &ctx->adm_info.delta, 
               &ctx->adm_info.pad_gc, &ctx->adm_info.actualtxgaintblidx, &ctx->adm_info.finalpwr);
            break;
         case 7:
            sscanf(str, fmt, &ctx->adm_info.teta, &ctx->adm_info.rho, &ctx->adm_info.scaleq,
               &ctx->adm_info.numprobes, &a, &ctx->adm_info.score, &ctx->adm_info.cfo2);
            break;
      }
   }
   else if (layer == 1) // mlme
   {
      switch (string_id)
      {
         case 4:
         case 40:
            sscanf(str, fmt, &ctx->adm_info.numsym, &ctx->adm_info.cp, &ctx->adm_info.numofpkts,
                &ctx->adm_info.sc1, &ctx->adm_info.sc2, &ctx->adm_info.status);
            break;
         case 114:
         case 115:
         case 116:
         case 117:
         case 118:
         case 119:
         case 120:
         case 121:
         case 122:
         case 123:                
         case 124:
         case 125:     
            if (ctx->adm_info.state == 3)
               sscanf(str, fmt, &a, &b, &ctx->adm_info.nbas2, &ctx->adm_info.cp2, &ctx->adm_info.pr2, &ctx->adm_info.tpcbk2,
                  &ctx->adm_info.prf2, &ctx->adm_info.nsym2, &ctx->adm_info.gcdbm2, &ctx->adm_info.cu2, &c);
            else
               sscanf(str, fmt, &a, &b, &ctx->adm_info.nbas12, &ctx->adm_info.cp12, &ctx->adm_info.ht12,
                  &ctx->adm_info.bo12, &ctx->adm_info.profile12, &ctx->adm_info.nsym12, &ctx->adm_info.gcdbm12, &c, &d);
            break;
         case 90:
         case 91:
         case 92:
         case 93:
         case 94:
         case 95:
         case 96:
         case 97:
         case 98:
         case 99:
         case 100:
         case 101:  
            if (ctx->adm_info.state == 4)
               sscanf(str, fmt, &a, &b, &ctx->adm_info.nbas13, &ctx->adm_info.cp13, &ctx->adm_info.ht13,
                  &ctx->adm_info.bo13, &ctx->adm_info.profile13, &ctx->adm_info.nsym13, &ctx->adm_info.gcdbm13, &c, &d);     
            else
               sscanf(str, fmt, &a, &b, &ctx->adm_info.nbas3, &ctx->adm_info.cp3, &ctx->adm_info.pr3, &ctx->adm_info.tpcbk3,
                  &ctx->adm_info.prf3, &ctx->adm_info.nsym3, &ctx->adm_info.gcdbm3, &ctx->adm_info.cu3, &c);
            break;
         case 46:
            sscanf(str, fmt, &a, &b, &c, &ctx->adm_info.maxtpcadj);
            break;
         case 52:
            sscanf(str, fmt, &a, &ctx->adm_info.maxtpcadj);
            break;
         case 75:
            sscanf(str, fmt, &ctx->adm_info.bo, &ctx->adm_info.agc, &ctx->adm_info.total_gain,
               &ctx->adm_info.rssi);
            break;
         case 76:
            sscanf(str, fmt, &ctx->adm_info.bo2, &ctx->adm_info.agc2, &ctx->adm_info.total_gain2,
               &ctx->adm_info.rssi2);
            break;
         case 144:
            sscanf(str, fmt, &a, &ctx->adm_info.a, &ctx->adm_info.tg, &ctx->adm_info.rs);
            break;
         case 102:
         case 103:
         case 104:
         case 105:
         case 106:
         case 107:
         case 108:
         case 109:
         case 110:
         case 111:
         case 112:
         case 113: 
            if (ctx->adm_info.state == 1)
               sscanf(str, fmt, &a, &b, &ctx->adm_info.nbas10, &ctx->adm_info.cp10, &ctx->adm_info.ht10,
                  &ctx->adm_info.bo10, &ctx->adm_info.profile10, &ctx->adm_info.nsym10, &ctx->adm_info.gcdbm10, &c, &d);
            else
               sscanf(str, fmt, &a, &b, &ctx->adm_info.nbas11, &ctx->adm_info.cp11, &ctx->adm_info.ht11,                    
                  &ctx->adm_info.bo11, &ctx->adm_info.profile11, &ctx->adm_info.nsym11, &ctx->adm_info.gcdbm11, &c, &d);
            break;
         case 87:
            ctx->adm_info.state = 1;
            break;
         case 83:
            ctx->adm_info.state = 2;
            break;
         case 82:
            ctx->adm_info.state = 3;                
            break;
         case 86:
            ctx->adm_info.state = 4;
            break;          
      }                
   }
}

void mocad_string_formatting_2(struct mocad_ctx *ctx, char* string, unsigned int stringID,
        unsigned int numVars, unsigned int vars_array[])
{
   int i;
   char *strPtr = NULL;
   char tmpStr[400];
   unsigned long long val;
   unsigned char *fmtstring;
   unsigned int sectlen = 0;

   if ( stringID == 0xffffffff )
      return;

   // Top bit is used to identify new style vs old style mmp.  Not using old style in moca 2.0
   stringID = stringID & 0x7fffffff;

   if ((stringID >> 24) == 0)  // top 8 bits are the CPU ID of the string
   {
      if (!ctx->cpu0strings)
         fmtstring = NULL;
      else
         fmtstring = ctx->cpu0strings + (stringID & 0xFFFFFF); // bottom 24 bits are the offset of the string into the table
      sectlen = ctx->sizeofcpu0strings;
   }
   else if ((stringID >> 24) == 1)
   {
      if (!ctx->cpu1strings)
         fmtstring = NULL;
      else
         fmtstring = ctx->cpu1strings + (stringID & 0xFFFFFF);
      sectlen = ctx->sizeofcpu1strings;
   }
   else
   {
      fmtstring = NULL;
      sectlen = 0;
   }

   if ((!fmtstring) || ((stringID & 0xFFFFFF) > sectlen))
   {
      sprintf(string, "Invalid string ID (%8x).\n",
         stringID);
      return;
   }

   strncpy(string, (char *)fmtstring, MAX_STRING_LENGTH-100);

   string[MAX_STRING_LENGTH-100] = 0;

   if (numVars)
   {
      for (i=numVars-1; i>=0; i--)
      {
         strPtr = strrchr(string, '%');
         if (strPtr)
         {
            if (mocad_is64bitformat(strPtr))
            {
               if (i == 0)
               {
                  mocad_log(ctx, L_ERR,
                     "Invalid 64-bit printf\n");
               }
               else
               {
                  i--;
                  val = *((unsigned long long *)&vars_array[i]);
                  val = BE64( val );
                  sprintf(tmpStr, strPtr, val);
               }
            }
            else
            { //take care of %s
               char *strTmp = NULL;             
               unsigned char *fmtstring1 = NULL;
               unsigned int strStringId =0;

               strTmp = strPtr;
               strTmp++; //skip past %

               // flag exist
               if ( strTmp[0] == '-' )
               {
                  strTmp++;
               }              
               while( (strTmp[0] >='0') && (strTmp[0] <='9') )
               {// handle %8s ...
                  strTmp++;
               }
               switch (*strTmp)
               {
               case 's':           /* string */
                  strStringId = BE32(vars_array[i]);
                  strStringId = strStringId & 0x7fffffff;
                  if ((strStringId >> 24) == 0)  // top 8 bits are the CPU ID of the string
                  {
                     if (!ctx->cpu0strings)
                        fmtstring1 = NULL;
                     else
                        fmtstring1 = ctx->cpu0strings + (strStringId & 0xFFFFFF); // bottom 24 bits are the offset of the string into the table
                  }
                  else if ((strStringId >> 24) == 1)
                  {
                     if (!ctx->cpu1strings)
                        fmtstring1 = NULL;
                     else
                        fmtstring1 = ctx->cpu1strings + (strStringId & 0xFFFFFF);
                  }
                  if (!fmtstring1)
                  {
                     mocad_log(ctx, L_ERR, "Invalid String string ID (%8x).\n", strStringId);
                     return;
                  }
                  sprintf(tmpStr, strPtr, (char *)fmtstring1);
                  break;
               default:
                  sprintf(tmpStr, strPtr, BE32(vars_array[i]));
                  break;
               }
            }
            strcpy(strPtr, tmpStr);
         }
      }
   }
}


void mocad_string_formatting(struct mocad_ctx *ctx, char* string, unsigned int stringID, 
   unsigned int numVars, unsigned int vars_array[])
{
   int i;
// int paramInString;
   char *strPtr;
   char tmpStr[400];
   unsigned long long val;

   /* Sanity 1: Test on valid string ID in layer. */
   if (GET_MOCA_STRING_ID(stringID) >= moca_core_lab_strings[GET_MOCA_LAYER_ID(stringID)].string_array_size)
   {
      sprintf(string, "Invalid string ID (%d) in layer %d. Probably mocad_strings.h consistency.\n", 
         GET_MOCA_STRING_ID(stringID), GET_MOCA_LAYER_ID(stringID) );
      return;
   }
   /* Sanity 1: End */

   memcpy(string, 
      moca_core_lab_strings[GET_MOCA_LAYER_ID(stringID)].string_array[GET_MOCA_STRING_ID(stringID)], 
      MIN(MAX_STRING_LENGTH-100, 
      strlen(moca_core_lab_strings[GET_MOCA_LAYER_ID(stringID)].string_array[GET_MOCA_STRING_ID(stringID)])) );

   string[MIN(MAX_STRING_LENGTH-100, 
      strlen(moca_core_lab_strings[GET_MOCA_LAYER_ID(stringID)].string_array[GET_MOCA_STRING_ID(stringID)]))] = 0;

#if (0)
   /* Sanity 2: Verify enough % in string. If there are too few, add some.
     Ignore cases that the string does not contain any parameter and there is a single 
     input parameter. 
     This is because the printout from the ISRs always pass single parameter, even if 
     the string has none. */
   strPtr = string;
   paramInString = 0;
   do 
   {
      strPtr = strstr(strPtr, "%");
      if (strPtr)
      {
         paramInString++;
         strPtr++;
      }
   } while (strPtr);

   if (paramInString && (numVars > paramInString))
   {
      int i;

      /* Clear the \n. */ 
      strPtr = strstr(string, "\n");
      *strPtr = 0;

      /* Too few parameter in the original string. Add some %. */
      for (i=paramInString; i<numVars; i++)
      {
         strcat(string, " [%d]");
      }
      strcat(string, "==> Warning: string modified\n");
   }
   /* Sanity 2: End */
#endif

   if (numVars)
   {
      for (i=numVars-1; i>=0; i--)
      {
         strPtr = strrchr(string, '%');
         if (strPtr)
         {
            if (mocad_is64bitformat(strPtr))
            {
               if (i == 0)
               {
                  mocad_log(ctx, L_ERR, 
                     "Invalid 64-bit printf\n");
               }
               else
               {
                  i--;
                  val = *((unsigned long long *)&vars_array[i]);
                  val = BE64( val );
                  sprintf(tmpStr, strPtr, val);
               }
            }
            else
               sprintf(tmpStr, strPtr, BE32(vars_array[i]));

            strcpy(strPtr, tmpStr);
         }
      }
   }
   mocad_parse_adm_info(ctx, GET_MOCA_LAYER_ID(stringID), GET_MOCA_STRING_ID(stringID), 
      moca_core_lab_strings[GET_MOCA_LAYER_ID(stringID)].string_array[GET_MOCA_STRING_ID(stringID)],
      string);
}

void mocad_update_times(struct mocad_ctx *ctx, int event)
{
   time_t now = time(NULL);

   switch (event)
   {
      case MOCA_TIME_EVENT_CORE_UP:
         if (ctx->moca_running == 0)
            ctx->core_uptime = time(NULL);
         break;
      case MOCA_TIME_EVENT_CORE_DOWN:
         if (ctx->moca_running == 1)
         {
            ctx->core_downtime = time(NULL);
            if (ctx->link_state == LINK_STATE_UP)
               ctx->link_downtime = time(NULL);
         }
         break;
      case MOCA_TIME_EVENT_LINK_UP:
         ctx->link_uptime = now;
         break;
      case MOCA_TIME_EVENT_LINK_DOWN:
         ctx->link_downtime = now;
         break;
      default:
         mocad_log(ctx, L_WARN, "unknown time event %d\n", event);
         break;
   }
}


void mocad_get_core_times(struct mocad_ctx * ctx, 
   uint32_t * core_uptime, uint32_t * link_uptime)
{
   time_t last_time;
   time_t now = time(NULL);

   mocad_log(ctx, L_DEBUG, "Get Times:\n");
   mocad_log(ctx, L_DEBUG, "  Now    : %u s\n", now);
   mocad_log(ctx, L_DEBUG, "  Core Up  : %u s\n", ctx->core_uptime);
   mocad_log(ctx, L_DEBUG, "  Core Down: %u s\n", ctx->core_downtime);
   mocad_log(ctx, L_DEBUG, "  Link Up  : %u s\n", ctx->link_uptime);
   mocad_log(ctx, L_DEBUG, "  Link Down: %u s\n", ctx->link_downtime);

   if ((ctx->moca_running == 1) &&
       (ctx->link_state == LINK_STATE_UP))
      last_time = now;
   else
      last_time = ctx->link_downtime;

   if (last_time > ctx->link_uptime)
      *link_uptime = (uint32_t) BE32(last_time - ctx->link_uptime);
   else
      *link_uptime = (uint32_t)BE32((0xFFFFFFFF - ctx->link_uptime + 1) + last_time);

   if (ctx->moca_running == 1)
      last_time = now;
   else
      last_time = ctx->core_downtime;

   if (last_time > ctx->core_uptime)
      *core_uptime = (uint32_t)BE32(last_time - ctx->core_uptime);
   else
      *core_uptime = (uint32_t)BE32((0xFFFFFFFF - ctx->core_uptime + 1) + last_time);

}

void mocad_update_link_state(struct mocad_ctx *ctx, int new_state)
{
   struct moca_gen_status gs;
   int ret;
   int prev_link_state;

   prev_link_state = ctx->link_state;
   ctx->link_state = new_state;
   switch(new_state) {
      case LINK_STATE_UP:
         mocad_update_times(ctx, MOCA_TIME_EVENT_LINK_UP);

         ret = moca_get_gen_status(ctx, &gs);
         if (ret == 0) 
         {
            ctx->active_nodes = gs.connected_nodes;

            // Check for a change in the LOF in the small chance that 
            // we missed the LOF trap
            if ((gs.rf_channel*25) != (uint32_t) ctx->disk_lof)
            {
               mocad_write_lof(ctx, (gs.rf_channel*25));
            }
         }
         else 
         {
            mocad_log(ctx, L_ERR, 
               "mocad_get_gen_status ret %d\n", ret);
         }

         if (prev_link_state != new_state)
         {
            mocad_log(ctx, L_INFO, "MoCA link is up after %ds of downtime\n", time(NULL) - ctx->link_downtime );
#ifndef DSL_MOCA
            if (ctx->any_time.host_qos)
               mocad_init_forwarding(ctx);
#endif                
            MoCAOS_EnableDataIf(ctx->os_handle, ctx->ifname, 0);
         }

         if (!ctx->show_lab_printf)
         {
            mocad_set_moca_core_trace_enable(ctx,
               ctx->show_lab_printf);
         }
         break;
      case LINK_STATE_DOWN:
         mocad_update_times(ctx, MOCA_TIME_EVENT_LINK_DOWN);
         mocad_remove_pqos_flows(ctx);

         if (ctx->moca_running)
         {
            if (prev_link_state != new_state)
            {
               mocad_log(ctx, L_INFO, "MoCA link is down after %ds of uptime\n", time(NULL) - ctx->link_uptime );
               // ifdown
               MoCAOS_EnableDataIf(ctx->os_handle, ctx->ifname, 2);

               // In order release all the data buffers that already exist in the Packet RAM wait 20 Msec..
               MoCAOS_MSleep(20);                    
                    
               // copy data to packet ram
               if ((ctx->kdrv_info.hw_rev != MOCA_CHIP_20) && (0 !=MoCAOS_WriteMem(ctx->os_handle, ctx->firmwareInitData, MOCAD_FIRMWAREDATA_REINIT_LEN, (unsigned char *)PACKETRAM_ADDR_REINIT)))
               {                        
                  uint32_t i;
                  mocad_log(ctx, L_WARN, "Unable to write packet ram, using fallback.  Update kernel (bmoca) to remove this message.\n");

                  // this loop can take some time, and each reg_write may have a core trace.  Drop them silently
                  ctx->silentlyDropTraps = 1;
                  // 
                  for (i=0;i<MOCAD_FIRMWAREDATA_REINIT_LEN/sizeof(int)/48;i++)
                  {
                     mocad_reg_write_multiple(ctx, 0xBFC00000 + PACKETRAM_ADDR_REINIT + i*4*48,
                                 (uint32_t *)&ctx->firmwareInitData[i*4*48], 48);
                  }

                  // and the remainder
                  mocad_reg_write_multiple(ctx, 0xBFC00000 + PACKETRAM_ADDR_REINIT + i*4*48,
                                 (uint32_t *)&ctx->firmwareInitData[i*4*48], 
                                 (MOCAD_FIRMWAREDATA_REINIT_LEN-i*4*48)/4);
                  ctx->silentlyDropTraps = 0;
               }

               if (ctx->kdrv_info.hw_rev != MOCA_CHIP_20)
                  checkPacketRam(ctx);

               // ret = mocad_wr_result(wr, MOCA_MSG_ACK,   ie_type, 0);   I am not sure  that this command necessary

            }

            // send download done
            moca_set_download_to_packet_ram_done(ctx);

            if (!ctx->show_lab_printf)
            {
               mocad_set_moca_core_trace_enable(ctx,1);
            }
         }

         memset(ctx->node_stats, 0, sizeof(ctx->node_stats));
         memset(ctx->node_stats_ext, 0, sizeof(ctx->node_stats_ext));
         memset(ctx->acc_err_stats, 0, sizeof(ctx->acc_err_stats));
#ifdef DSL_MOCA
         mocad_update_br_entries(ctx, 1);
#endif
         ctx->active_nodes = 0;
         break;
      case LINK_STATE_DEBUG:
         mocad_log(ctx, L_INFO,
            "MoCA is in debug mode\n");
         break;
   }
}

/*
 * FILESYSTEM OPERATIONS
 */
#if defined(DSL_MOCA) /* DSL Code */
int mocad_read_reg(struct mocad_ctx * ctx, uint32_t addr)
{
   int fd, len;
   char buffer[64];

   fd = open("/proc/bcmlog", O_RDWR | O_NONBLOCK);

   if (fd < 0)
   {
      mocad_log(ctx, L_ERR, "%s: couldn't open bcmlog (%d)\n",
         __FUNCTION__, fd);
      return (fd);
   }

   len = sprintf(buffer, "m 0x%x 1 w", addr);

   if(write(fd, buffer, len) != len)
   {
      close(fd);
      mocad_log(ctx, L_ERR, "%s: couldn't write to bcmlog\n",
         __FUNCTION__);
      return (-1);
   }

   close(fd);

   return(0);
}

int mocad_write_reg(struct mocad_ctx * ctx, uint32_t addr, uint32_t val)
{
   int fd, len, wrlen;
   char buffer[64];

   fd = open("/proc/bcmlog", O_RDWR | O_NONBLOCK);

   if (fd < 0)
   {
      mocad_log(ctx, L_ERR, "%s: couldn't open bcmlog (%d)\n",
         __FUNCTION__, fd);
      return (fd);
   }

   len = sprintf(buffer, "w 0x%x 0x%x 1 w", addr, val);

   wrlen = write(fd, buffer, len);
   if( wrlen != len)
   {
      close(fd);
      mocad_log(ctx, L_ERR, "%s: couldn't write to bcmlog (%d vs. %d)\n",
         __FUNCTION__, wrlen, len);
      return (-1);
   }

   close(fd);

   return(0);
}

#if (0)
int mocad_read_rtt_from_ctrl_ram(struct mocad_ctx *ctx)
{
   uint32_t start_addr;
   uint32_t end_addr;
   void     *pMem;
   struct   moca_xfer x;
   uint32_t *temp_ptr;
   uint32_t *temp_ptr_kernel;

   /* Print the RTT buffer */
   start_addr = BE32(0x4C2CC);
   end_addr = start_addr + BE32(1500 * sizeof(uint32_t));

   mocad_log(ctx, L_ERR, "FOUND RTT DATA @ 0x%X\n", start_addr); 

   /* the memory transfer at the kernel layer might require 
   * 64-bit alignment */
   if (MoCAOS_MemAlign(&pMem, 64, (end_addr - (start_addr & 0xFFFFFFF8))) < 0)
     return;

   ret = MoCAOS_ReadMem((unsigned char *)pMem, (end_addr - (start_addr & 0xFFFFFFF8)),
      (start_addr & 0xFFFFFFF8) );

   if(ret != 0)
   {
     mocad_log(ctx, L_ERR, "Unable to read mem from kernel\n");
   }
   else
   {
     temp_ptr_kernel = pMem + (start_addr & 0x7);

//          mocad_log(ctx, L_ERR, "%08x %08x %08x\n", 
//            BE32(*(temp_ptr_kernel + 1500)),
//            BE32(*(temp_ptr_kernel + 1501)),
//            BE32(*(temp_ptr_kernel + 1502)));

     for (temp_ptr = (uint32_t*)start_addr; 
       (uint32_t)temp_ptr < end_addr-12; 
       temp_ptr += 10, temp_ptr_kernel += 10)
     {
       mocad_log(ctx, L_ERR, 
         "%08x %08x %08x %08x %08x %08x %08x %08x %08x %08x\n",
         BE32(*(temp_ptr_kernel + 0)), BE32(*(temp_ptr_kernel + 1)), 
         BE32(*(temp_ptr_kernel + 2)), BE32(*(temp_ptr_kernel + 3)), 
         BE32(*(temp_ptr_kernel + 4)), BE32(*(temp_ptr_kernel + 5)), 
         BE32(*(temp_ptr_kernel + 6)), BE32(*(temp_ptr_kernel + 7)),
         BE32(*(temp_ptr_kernel + 8)), BE32(*(temp_ptr_kernel + 9)));
     }
   }
   free(pMem);
}
#endif

int mocad_read_lof(struct mocad_ctx * ctx)
{
/*
   int ret;
   uint8_t    buf[sizeof(CmsMsgHeader) + CMS_IFNAME_LENGTH];
   CmsMsgHeader *pMsg = (CmsMsgHeader *)&buf[0];

   pMsg->type        = CMS_MSG_MOCA_READ_LOF;
   pMsg->src         = MAKE_SPECIFIC_EID(getpid(), EID_MOCAD);
   pMsg->dst         = EID_SSK;
   pMsg->flags_request = 1;          
   pMsg->dataLength  = CMS_IFNAME_LENGTH;
   strcpy((char*)(pMsg + 1), ctx->ifname);    

   ret = cmsMsg_sendAndGetReplyBuf(ctx->cmsMsgHandle, pMsg, &pMsg);
   if ( CMSRET_SUCCESS != ret )
   {
      mocad_log(ctx, L_WARN, "can't read LOF from CMS: error %d\n", ret);
      ctx->disk_lof = 0 ;
      return -1;
   }

   ctx->disk_lof = pMsg->wordData;
*/
   /* Don't do anything. CMS isn't ready for this message when we
    * send it. CMS will initialize MoCA with the proper parameters
    * prior to starting.
    */
   return(0);
}

int mocad_write_lof(struct mocad_ctx *ctx, int lof)
{
   int        ret;
   uint8_t    buf[sizeof(CmsMsgHeader) + CMS_IFNAME_LENGTH];
   CmsMsgHeader *pMsg = (CmsMsgHeader *)&buf[0];
   
   ctx->init_time.lof = lof;

   memset(&buf[0], 0x0, sizeof(buf));

   pMsg->type       = CMS_MSG_MOCA_WRITE_LOF;
   pMsg->src        = MAKE_SPECIFIC_EID(getpid(), EID_MOCAD);
   pMsg->dst        = EID_SSK;
   pMsg->flags_event = 1;
   pMsg->dataLength  = CMS_IFNAME_LENGTH;
   strcpy((char*)(pMsg + 1), ctx->ifname);
   pMsg->wordData   = lof;

   ret = cmsMsg_send(ctx->cmsMsgHandle, pMsg);
   if ( CMSRET_SUCCESS != ret )
   {
      mocad_log(ctx, L_WARN, "can't write LOF in CMS: error %d\n", ret);
      return -1;
   }

   ctx->disk_lof = lof;
   return 0;
}

int mocad_read_nondefseqnum (struct mocad_ctx * ctx)
{
/*
   CmsRet        ret;
   uint8_t    buf[sizeof(CmsMsgHeader) + CMS_IFNAME_LENGTH];
   CmsMsgHeader *pMsg = (CmsMsgHeader *)&buf[0];

   pMsg->type        = CMS_MSG_MOCA_READ_MRNONDEFSEQNUM;
   pMsg->src         = MAKE_SPECIFIC_EID(getpid(), EID_MOCAD);
   pMsg->dst         = EID_SSK;
   pMsg->flags_request = 1;          
   pMsg->dataLength  = CMS_IFNAME_LENGTH;
   strcpy((char*)(pMsg + 1), ctx->ifname);    

   ret = cmsMsg_sendAndGetReplyBuf(ctx->cmsMsgHandle, pMsg, &pMsg);
   if ( CMSRET_SUCCESS != ret )
   {
      mocad_log(ctx, L_WARN, 
         "can't read NONDEFSEQNUM from CMS: error %d\n", ret);
      ctx->disk_nondefseqnum = 0 ;
      return -1;
   }

   ctx->disk_nondefseqnum = pMsg->wordData;
*/
   /* Don't do anything. CMS isn't ready for this message when we
    * send it. CMS will initialize MoCA with the proper parameters
    * prior to starting.
    */
   return(0);

}

int mocad_write_nondefseqnum (struct mocad_ctx * ctx, int nondefseqnum)
{
   CmsRet ret;
   uint8_t    buf[sizeof(CmsMsgHeader) + CMS_IFNAME_LENGTH];
   CmsMsgHeader *pMsg = (CmsMsgHeader *)&buf[0];
   
   ctx->disk_nondefseqnum = nondefseqnum;

   memset(&buf[0], 0x0, sizeof(buf));

   pMsg->type       = CMS_MSG_MOCA_WRITE_MRNONDEFSEQNUM;
   pMsg->src        = MAKE_SPECIFIC_EID(getpid(), EID_MOCAD);
   pMsg->dst        = EID_SSK;
   pMsg->flags_event = 1;
   pMsg->dataLength  = CMS_IFNAME_LENGTH;
   strcpy((char*)(pMsg + 1), ctx->ifname);
   pMsg->wordData   = nondefseqnum;

   ret = cmsMsg_send(ctx->cmsMsgHandle, pMsg);
   if ( CMSRET_SUCCESS != ret )
   {
      mocad_log(ctx, L_WARN, 
         "can't write NONDEFSEQNUM in CMS: error %d\n", ret);
      return -1;
   }   

   ctx->disk_nondefseqnum = nondefseqnum;
   return 0;
}

int mocad_read_e2m(struct mocad_ctx *ctx)
{
   int tmp[3];
   char filename[MOCA_FILENAME_LEN], buf[36];

   sprintf(filename, "E2M%s", ctx->ifname);
   if (cmsPsp_get(filename, buf, sizeof(buf)) <= 0)
      goto bad;

   if(sscanf(buf, "%d %d %d", &tmp[0], &tmp[1], &tmp[2]) != 3)
      goto bad;

   mocad_log(ctx, L_DEBUG, "E2M data: %d %d %d\n", tmp[0], tmp[1], tmp[2]);
   memcpy(&ctx->error_to_mask, tmp, sizeof(ctx->error_to_mask));
   return(0);

bad:
   /* not a serious failure; it will be missing on the first run */
   mocad_log(ctx, L_VERBOSE, "can't read E2M file '%s'\n", filename);
   return(-1);
}

int mocad_write_e2m(struct mocad_ctx *ctx, struct moca_error_to_mask * e2m)
{
   int len;
   char filename[MOCA_FILENAME_LEN], buf[36];

   mocad_log(ctx, L_VERBOSE, "Saving new E2M %d %d %d\n", 
      e2m->error1, e2m->error2, e2m->error3);

   sprintf(filename, "E2M%s", ctx->ifname);
   len = sprintf(buf, "%d %d %d\n", e2m->error1, e2m->error2, e2m->error3);

   if (cmsPsp_set(filename, buf, len) != CMSRET_SUCCESS)
      goto bad;

   return(0);

bad:
   mocad_log(ctx, L_WARN, "can't write E2M file '%s'\n", filename);
   return(-1);
}

int mocad_send_notification(struct mocad_ctx * ctx, uint32_t id)
{
   CmsRet        ret;
   uint8_t       buf[sizeof(CmsMsgHeader) + CMS_IFNAME_LENGTH];
   CmsMsgHeader *pMsg = (CmsMsgHeader *)&buf[0];

   memset(&buf[0], 0x0, sizeof(buf));

   pMsg->type        = CMS_MSG_MOCA_NOTIFICATION;
   pMsg->src         = MAKE_SPECIFIC_EID(getpid(), EID_MOCAD);
   pMsg->dst         = EID_SSK;
   pMsg->flags_event = 1;
   pMsg->dataLength  = CMS_IFNAME_LENGTH;
   strcpy((char*)(pMsg + 1), ctx->ifname);
   pMsg->wordData    = id;

   ret = cmsMsg_send(ctx->cmsMsgHandle, pMsg);
   if ( CMSRET_SUCCESS != ret )
   {
      mocad_log(ctx, L_WARN, 
         "can't send notification %lu to CMS: error %d\n", id, ret);
      return -1;
   }

   return 0;
}

/* This function updates the ebtables so that PQoS flows are sent
 * to the MoCA core on the right queue. */
int mocad_update_pqos_flow_in_switch(struct mocad_ctx * ctx, 
   struct moca_pqos_table * r, MOCAD_PQOS_SWITCH_ACTIONS_E action,
   int index)
{
   static char command[256];
   uint8_t mac_addr[6];
   int ret = 0;
   char add_del;

   switch (action)
   {
      case MOCAD_PQOS_SWITCH_ADD:
         add_del = 'I';
         break;
      case MOCAD_PQOS_SWITCH_DELETE:
         add_del = 'D';
         break;
      default:
         mocad_log(ctx, L_ERR, "%s: Unknown action %d\n", 
            __FUNCTION__, action);
         return(-1);
   }
   
   moca_u32_to_mac(mac_addr, r->packet_da_hi, r->packet_da_lo);

   ret = sprintf(command, 
                 "ebtables -%c FORWARD %s-p 802_1Q "
                 "-d %02x:%02x:%02x:%02x:%02x:%02x/FF:FF:FF:FF:FF:FF "
                 "-j mark --mark-set 0x3 -o %s",
                 add_del, 
                 (action == MOCAD_PQOS_SWITCH_ADD ? "1 " : ""),
                 mac_addr[0], mac_addr[1], mac_addr[2], 
                 mac_addr[3], mac_addr[4], mac_addr[5],
                 ctx->ifname);

   if (r->vlan_id != 0xFFF)
   {
      ret += sprintf(&command[ret],
                     " --vlan-id %u",
                     r->vlan_id);
   }
   else if (r->vlan_prio != 0xFF)
   {
      ret += sprintf(&command[ret],
                     " --vlan-prio %u",
                     r->vlan_prio);
   }
   
   ret = system(command);

   mocad_log(ctx, L_DEBUG, "Command: %s\n", command);
   mocad_log(ctx, L_DEBUG, "Return value: %d\n", ret);

   return(ret);
}


/* Set up the forwarding tables in the switch so that traffic is routed to the
 * proper moca queues.
 */
void mocad_init_dsl(struct mocad_ctx *ctx)
{
   int i;
   char command[128];
   uint32_t queue_map[8] = {0, 0, 0, 0, 1, 1, 2, 2};

   for (i = 0; i < 8; i++)
   {
      sprintf(command, "ebtables -A FORWARD -p 802_1Q --vlan-prio %u -j mark --mark-set 0x%x -o %s",
              i, queue_map[i], ctx->ifname);

      system(command);
   }

   ctx->numUcFwdEntries = 0;
   memset(ctx->ucFwdTable, 0, sizeof(ctx->ucFwdTable));
}

#else
int mocad_read_lof(struct mocad_ctx *ctx)
{
   int fd, tmp;
   char filename[MOCA_FILENAME_LEN];
   char buf[16]={0};

   ctx->disk_lof = 0;

   sprintf(filename, LOF_PATH_FMT, ctx->ifname);
   fd = open(filename, O_RDONLY);
   if(fd < 0)
      goto bad;
   if(read(fd, buf, sizeof(buf)-1) <= 0)
      goto bad;
  buf[15] = '\0';
   if(sscanf(buf, "%d", &tmp) != 1)
      goto bad;
   mocad_log(ctx, L_INFO, "Using %d Mhz for LOF\n", tmp);
   ctx->disk_lof = tmp;
   return(0);

bad:
   /* not a serious failure; it will be missing on the first run */
   mocad_log(ctx, L_VERBOSE, "can't read LOF file '%s'\n", filename);
   if(fd >= 0)
      close(fd);
   return(-1);
}

int mocad_write_lof(struct mocad_ctx *ctx, int lof)
{
   int fd, len;
   char filename[MOCA_FILENAME_LEN], buf[16];

   if(ctx->disk_lof == lof)
      return(0);
   
   mocad_log(ctx, L_VERBOSE, "Saving new LOF %d\n", lof);

   ctx->init_time.lof = lof;

   sprintf(filename, LOF_PATH_FMT, ctx->ifname);
   fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC | O_SYNC, 0644);
   if(fd < 0)
      goto bad;
   len = sprintf(buf, "%d\n", lof);
   if(write(fd, buf, len) != len)
      goto bad;
   close(fd);

   ctx->disk_lof = lof;
   return(0);

bad:
   mocad_log(ctx, L_WARN, "can't write LOF file '%s'\n", filename);
   if(fd >= 0)
      close(fd);
   return(-1);
}


int mocad_read_nondefseqnum(struct mocad_ctx *ctx)
{
   int fd, tmp;
   char filename[MOCA_FILENAME_LEN], buf[16];

   ctx->disk_nondefseqnum = 0;

   sprintf(filename, NONDEFSEQNUM_PATH_FMT, ctx->ifname);
   fd = open(filename, O_RDONLY);
   if(fd < 0)
      goto bad;
   if(read(fd, buf, sizeof(buf)) <= 0)
      goto bad;
  buf[15] = '\0';
   if(sscanf(buf, "%d", &tmp) != 1)
      goto bad;

   ctx->disk_nondefseqnum = tmp;
   return(0);

bad:
        mocad_log(ctx, L_VERBOSE, "can't read nondefseqnum file '%s'.  Using default.\n", filename);
   /* not a serious failure; it will be missing on the first run */
   if(fd >= 0)
      close(fd);
   return(-1);
}

int mocad_write_nondefseqnum (struct mocad_ctx * ctx, int nondefseqnum)
{
   int fd, len;
   char filename[MOCA_FILENAME_LEN], buf[16];

   if(ctx->disk_nondefseqnum == nondefseqnum)
      return(0);

   ctx->init_time.mr_non_def_seq_num = nondefseqnum;

   sprintf(filename, NONDEFSEQNUM_PATH_FMT, ctx->ifname);
   fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC | O_SYNC, 0644);
   if(fd < 0)
      goto bad;
   len = sprintf(buf, "%d\n", nondefseqnum);
   if(write(fd, buf, len) != len)
      goto bad;
   close(fd);

   ctx->disk_nondefseqnum = nondefseqnum;
   return(0);

bad:
   mocad_log(ctx, L_WARN, "can't write NONDEFSEQNUM file '%s'\n", filename);
   if(fd >= 0)
      close(fd);
   return(-1);
}

int mocad_read_e2m(struct mocad_ctx *ctx)
{
   int fd, tmp[3];
   char filename[MOCA_FILENAME_LEN], buf[36];

   sprintf(filename, E2M_PATH_FMT, ctx->ifname);
   fd = open(filename, O_RDONLY);
   if(fd < 0)
      goto bad;
   if(read(fd, buf, sizeof(buf)) <= 0)
      goto bad;
  buf[15] = '\0';
   if(sscanf(buf, "%d %d %d", &tmp[0], &tmp[1], &tmp[2]) != 3)
      goto bad;
   mocad_log(ctx, L_DEBUG, "E2M data: %d %d %d\n", tmp[0], tmp[1], tmp[2]);
   memcpy(&ctx->error_to_mask, tmp, sizeof(ctx->error_to_mask));
   return(0);

bad:
   /* not a serious failure; it will be missing on the first run */
   mocad_log(ctx, L_VERBOSE, "can't read E2M file '%s'.  Using default.\n", filename);
   if(fd >= 0)
      close(fd);
   return(-1);
}

int mocad_write_e2m(struct mocad_ctx *ctx, struct moca_error_to_mask * e2m)
{
   int fd, len;
   char filename[MOCA_FILENAME_LEN], buf[36];

   mocad_log(ctx, L_VERBOSE, "Saving new E2M %d %d %d\n", 
      e2m->error1, e2m->error2, e2m->error3);

   sprintf(filename, E2M_PATH_FMT, ctx->ifname);
   fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC | O_SYNC, 0644);
   if(fd < 0)
      goto bad;
   len = sprintf(buf, "%i %i %i\n", (int)e2m->error1, (int)e2m->error2, (int)e2m->error3);
   if(write(fd, buf, len) != len)
      goto bad;
   close(fd);

   return(0);

bad:
   mocad_log(ctx, L_WARN, "can't write E2M file '%s'\n", filename);
   if(fd >= 0)
      close(fd);
   return(-1);
}

int mocad_send_notification(struct mocad_ctx * ctx, uint32_t id)
{
   /* Do nothing in STB case */
   return(0);
}

int mocad_update_pqos_flow_in_switch(struct mocad_ctx * ctx, 
   struct moca_pqos_table * r, MOCAD_PQOS_SWITCH_ACTIONS_E action,
   int index)
{
   int ret = 0;
#if defined(__gnu_linux__)
   static char command[256];
   uint8_t mac_addr[6];

   if (ctx->any_time.host_qos == 0)
      return(0);

   moca_u32_to_mac(mac_addr, r->packet_da_hi, r->packet_da_lo);

   switch (action)
   {
      case MOCAD_PQOS_SWITCH_ADD:
         ret = sprintf(command,
              "tc filter add dev %s parent 1: protocol 802.1q handle 0x%x "
              "pref 1 u32 ht %s: "
              "match u16 0x%02X%02X 0xFFFF at -10 "
              "match u16 0x%02X%02X 0xFFFF at -12 "
              "match u16 0x%02X%02X 0xFFFF at -14 action skbedit queue_mapping 1 2> /dev/null",
              ctx->ifname, (index + 1), MOCAD_PQOS_FILTER_HASH,
              mac_addr[4], mac_addr[5],
              mac_addr[2], mac_addr[3],
              mac_addr[0], mac_addr[1]);
          break;
      case MOCAD_PQOS_SWITCH_DELETE:
          // Need to specify the handle otherwise all rules for the protocol
          // will be deleted.
          ret = sprintf(command,
              "tc filter del dev %s parent 1: protocol 802.1q handle %s:%x "
              "pref 1 u32 2> /dev/null",
              ctx->ifname, MOCAD_PQOS_FILTER_HASH, (index + 1));
          break;
      default:
          mocad_log(ctx, L_ERR, "%s: Unknown action %d\n",
         __FUNCTION__, action);
          return(-1);
   }

   ret = system(command);

   mocad_log(ctx, L_DEBUG, "Command: %s\n", command);
   mocad_log(ctx, L_DEBUG, "Return value: %d\n", ret);
#endif
   return(ret);
}

void mocad_init_forwarding(struct mocad_ctx *ctx)
{
#if defined(__gnu_linux__)
   int i;
   char command[256];
   uint32_t queue_map[8] = {0, 0, 0, 0, 3, 3, 2, 2};  // genet driver maps queue 0 to ring 16
   int ret;
   static int once = 1;

   // delete any qos associated with the interface
   sprintf(command, "tc qdisc del dev %s root 2> /dev/null", ctx->ifname);
   ret = system(command);

   mocad_log(ctx, L_DEBUG, "Command: %s\n", command);
   mocad_log(ctx, L_DEBUG, "Return value: %d\n", ret);

   // root queueing discipline is PRIO queueing
   sprintf(command, "tc qdisc add dev %s root handle 1: multiq 2> /dev/null",
      ctx->ifname);
   ret = system(command);
   mocad_log(ctx, L_DEBUG, "Command: %s\n", command);
   mocad_log(ctx, L_DEBUG, "Return value: %d\n", ret);

   if ((ret) && (once))
   {
      mocad_log(ctx, L_WARN, 
         "Warning:  MoCA cannot configure host-side transmit queues for QOS.\n"
         "Continuing with non-compliant queuing behaviour.  Some CTPs may fail.\n"
         "The kernel must have QOS and MULTIQ configured, and the tc utility \n"
         "must be in the path for spec-compliant operation.\n"
         "See MoCA_Diagnostics.pdf for more details\n");
                once = 0;
      return;
   }

   // set up vlan priority filters
   for (i = 0; i < 8; i++)
   {
      if (queue_map[i] == 0) // The default is 0 anyways, no need to add an extra filter
         continue;
      
      sprintf(command, "tc filter add dev %s parent 1: protocol 802.1q pref 2 u32 match u8 0x%02X 0xe0 at 0 action skbedit queue_mapping %d",
        ctx->ifname, i << 5, (int)queue_map[i]);
      ret = system(command);
      mocad_log(ctx, L_DEBUG, "Command: %s\n", command);
      mocad_log(ctx, L_DEBUG, "Return value: %d\n", ret);
        }

   // Add a place holder entry so that the hash value is predictable (801)
   // Use our own MAC address as we should never have to send to it.
   // We need the hash value in order to be able to delete specific rules
   // only when PQOS flows are deleted.
   sprintf(command,
      "tc filter add dev %s parent 1: protocol 802.1q handle 0x%x "
      "pref 1 u32 ht %s: "
      "match u16 0x%02X%02X 0xFFFF at -10 "
      "match u16 0x%02X%02X 0xFFFF at -12 "
      "match u16 0x%02X%02X 0xFFFF at -14 action skbedit queue_mapping 1",
      ctx->ifname, (MOCA_MAX_PQOS_ENTRIES+1), MOCAD_PQOS_FILTER_HASH,
      (ctx->kdrv_info.macaddr_lo >> 24) & 0xff,
      (ctx->kdrv_info.macaddr_lo >> 16) & 0xff,
      (ctx->kdrv_info.macaddr_hi >>  8) & 0xff,
      (ctx->kdrv_info.macaddr_hi    ) & 0xff,
      (ctx->kdrv_info.macaddr_hi >> 24) & 0xff,
      (ctx->kdrv_info.macaddr_hi >> 16) & 0xff);

   mocad_log(ctx, L_DEBUG, "Command: %s\n", command);
   ret = system(command);
   mocad_log(ctx, L_DEBUG, "Return value: %d\n", ret);

   // set up pQoS priority filters
   for (i=0;i<MOCA_MAX_PQOS_ENTRIES;i++)
   {
      if ((ctx->pqos_table[i].flow_id_hi != 0) ||
         (ctx->pqos_table[i].flow_id_lo != 0))
         mocad_update_pqos_flow_in_switch(ctx, &ctx->pqos_table[i], MOCAD_PQOS_SWITCH_ADD, i);
   }
#endif    
}


#endif

int mocad_write_pidfile(struct mocad_ctx *ctx)
{
#if defined(__gnu_linux__)

#if defined(DSL_MOCA) /* DSL Code */
   return(0);
#else
   int fd, len, pid = getpid();
   char filename[MOCA_FILENAME_LEN], buf[16];

   sprintf(filename, PIDFILE_FMT, ctx->ifname);
   fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
   if(fd < 0)
      goto bad;
   len = sprintf(buf, "%d\n", pid);
   if(write(fd, buf, len) != len)
      goto bad;
   close(fd);

   return(0);

bad:
   mocad_log(ctx, L_WARN, "can't write PID file '%s': %s\n", filename,
      strerror(errno));
   if(fd >= 0)
      close(fd);
   return(-1);
#endif

#else
   return(0);
#endif
}

static void printNodeErrorInfo(struct mocad_ctx *ctx, int node)
{

   if (ctx->node_stats_ext[node].rx_beacon_crc_error ||
      ctx->node_stats_ext[node].rx_map_crc_error ||
      ctx->node_stats_ext[node].rx_rr_crc_error ||
      ctx->node_stats_ext[node].rx_lc_crc_error ||
      ctx->node_stats_ext[node].rx_uc_crc_error ||
      ctx->node_stats_ext[node].rx_bc_crc_error)
   {
      if (ctx->in_lab_printf)
      {
         MoCAOS_Printf(ctx->os_handle, "\n");
         ctx->in_lab_printf = 0;
      }
         
      MoCAOS_Printf(ctx->os_handle, "MOCA: @ CRC:  Node=%02d,Bcn=%02d,MAP=%02d,RR=%02d,LC=%02d,UC_Eth=%04d,BC_Eth=%04d\n",
         node, 
         ctx->node_stats_ext[node].rx_beacon_crc_error, 
         ctx->node_stats_ext[node].rx_map_crc_error,
         ctx->node_stats_ext[node].rx_rr_crc_error,
         ctx->node_stats_ext[node].rx_lc_crc_error,
         ctx->node_stats_ext[node].rx_uc_crc_error,
         ctx->node_stats_ext[node].rx_bc_crc_error);
   }
      
   if (ctx->node_stats_ext[node].rx_beacon_timeout_error ||
      ctx->node_stats_ext[node].rx_map_timeout_error ||
      ctx->node_stats_ext[node].rx_rr_timeout_error ||
      ctx->node_stats_ext[node].rx_lc_timeout_error ||
      ctx->node_stats_ext[node].rx_uc_timeout_error ||
      ctx->node_stats_ext[node].rx_bc_timeout_error ||
      ctx->node_stats_ext[node].rx_p1_error ||
      ctx->node_stats_ext[node].rx_p2_error ||
      ctx->node_stats_ext[node].rx_p3_error ||
      ctx->node_stats_ext[node].rx_p1_gcd_error)        
   {
      if (ctx->in_lab_printf)
      {
         MoCAOS_Printf(ctx->os_handle, "\n");
         ctx->in_lab_printf = 0;
      }
      MoCAOS_Printf(ctx->os_handle, "MOCA: @ TIMEOUT: Node=%02d,Bcn=%02d,MAP=%02d,RR=%02d,LC=%02d,UC_Eth=%04d,BC_Eth=%04d,P1=%02d,P2=%02d,P3=%02d,P1g=%02d\n",
         node, 
         ctx->node_stats_ext[node].rx_beacon_timeout_error,
         ctx->node_stats_ext[node].rx_map_timeout_error,
         ctx->node_stats_ext[node].rx_rr_timeout_error,
         ctx->node_stats_ext[node].rx_lc_timeout_error,
         ctx->node_stats_ext[node].rx_uc_timeout_error,
         ctx->node_stats_ext[node].rx_bc_timeout_error,
         ctx->node_stats_ext[node].rx_p1_error,      
         ctx->node_stats_ext[node].rx_p2_error,
         ctx->node_stats_ext[node].rx_p3_error,
         ctx->node_stats_ext[node].rx_p1_gcd_error);
   }
}


int mocad_accum_stats(struct mocad_ctx *ctx, uint16_t ie_type,
   void *wr, void *accum, int accum_len, int field_len)
{
   int ret, i;
   uint32_t *dst, *acc = (uint32_t *)accum;
   struct mmp_msg_hdr *mh;
   struct mmp_ie_hdr *ih;

   /* Don't bother trying to make a request to the core if it's not running */
   if(!ctx->moca_running)
      return(-1);

   mh = (struct mmp_msg_hdr *)wr;
   mh->msg_type = MOCA_MSG_GET_RESPONSE;
   mh->msg_id = 0;
   mh->num_ies = BE16(1);

   ih = (struct mmp_ie_hdr *)(mh + 1);
   ih->ie_type = BE16(ie_type);
   ih->ie_len = (uint16_t)BE16(accum_len);

   dst = (uint32_t *)(ih + 1);

   /* NOTE: no endian swap */
   ret = mocad_cmd(ctx, MOCA_MSG_GET, ie_type, NULL, 0,
      dst, accum_len, 0);
   if(ret < 0)
      return(ret);
   
   if(ie_type == IE_GEN_STATS) {
      struct moca_gen_stats *gs = (struct moca_gen_stats *)dst;

      ctx->rx_pkts = BE32(gs->out_bc_packets) + BE32(gs->out_uc_packets);
      ctx->tx_pkts = BE32(gs->in_bc_packets) + BE32(gs->in_mc_packets) + BE32(gs->in_uc_packets);
      ctx->bc_pkts = BE32(gs->in_bc_packets) + BE32(gs->out_bc_packets);
      ctx->in_octets += BE32(gs->in_octets);
      ctx->out_octets += BE32(gs->out_octets);
   }

   if (field_len == 4)
   {
      for(i = 0; i < (accum_len >> 2); i++, dst++, acc++) {
         *acc += BE32(*dst);
         *dst = BE32(*acc);
      }
   }
   else
   {
      uint8_t *dst8 = (uint8_t *)dst;
      uint8_t *acc8 = (uint8_t *)acc;
  
      for(i = 0; i < (accum_len); i++, dst8++, acc8++) {
         *acc8 += *dst8;
         *dst8 = *acc8;
      }      
   }
   return(accum_len + sizeof(*mh) + sizeof(*ih));
}

void mocad_accum_node_stats_ext(struct mocad_ctx *ctx, int altnodemask)
{
   int i, altnode;
   uint32_t * dst;
   uint8_t * src;

   altnode = 0;

   while (altnode < 16)
   {
      if ((altnodemask & (1<<altnode)) != 0) 
      {
         mocad_accum_stats(ctx, IE_NODE_STATS_EXT+altnode, ctx->sock_out, 
            &ctx->node_stats_ext[altnode], sizeof(ctx->node_stats_ext[0]), 1);

         if (ctx->show_lab_printf)
            printNodeErrorInfo(ctx, altnode);

         src = (uint8_t *)&ctx->node_stats_ext[altnode];
         dst = (uint32_t *)&ctx->acc_err_stats[altnode];

         for (i=0;i<(int)sizeof(ctx->node_stats_ext[altnode]);i++)
         {
            *dst++ += *src++;
         }
         memset((uint8_t *)&ctx->node_stats_ext[altnode], 0, 
            sizeof(ctx->node_stats_ext[altnode]));
      }

      altnode++;
   }
}

void mocad_reset_stats(struct mocad_ctx *ctx)
{
   int i;
   ctx->in_octets = 0;
   ctx->out_octets = 0;
   memset(&ctx->gen_stats, 0, sizeof(ctx->gen_stats));
   memset(&ctx->ext_stats, 0, sizeof(ctx->ext_stats));
   memset(&ctx->node_stats, 0, sizeof(ctx->node_stats));
   memset(&ctx->node_stats_ext, 0, sizeof(ctx->node_stats_ext));   
   memset(&ctx->acc_err_stats, 0, sizeof(ctx->acc_err_stats));
   for (i=0;i<MOCA_MAX_NODES;i++)
      memset(ctx->cir_data[i], 0, CIR_DATA_SIZE);
}

/*
 * MMP
 */
int mocad_handle_trap(struct mocad_ctx *ctx, int trap_len);

int mocad_add_trap(struct mocad_ctx *ctx, uint8_t * trap, int len)
{
   struct mmp_msg_hdr *mh = (struct mmp_msg_hdr *)trap;
   struct mmp_ie_hdr  *ih;
   struct mocad_trap_list * plist;
   struct mocad_trap_list * pnew;
   uint8_t * trap_buf;

   ih = (struct mmp_ie_hdr  *)(mh + 1);

   /* Handle traps that will reset the core immediately */
   switch (BE16(ih->ie_type))
   {
      case IE_ASSERT:
      case IE_MIPS_EXCEPTION:
      case IE_WDT:
         MoCAOS_EnableDataIf(ctx->os_handle, ctx->ifname, 2);
         memcpy(ctx->trap_buf, trap, len);
         mocad_log(ctx, L_DEBUG, "\n\nHandling trap 0x%x immediately\n\n\n",
            BE16(ih->ie_type));
         return(mocad_handle_trap(ctx, len));
      default:
         break;
   }
   
   if (ctx->trap_count >= MOCAD_MAX_DEFERRED_TRAPS) {
      if (!ctx->silentlyDropTraps)
         mocad_log(ctx, L_WARN, "Dropping trap 0x%x (len %u)\n",
            BE16(ih->ie_type), len);
      return(-1);
   }


   if (len > MOCA_BUF_LEN)
   {
      mocad_log(ctx, L_WARN, "%s: called with len %u\n",
         __FUNCTION__, len);
      return(-1);
   }

   trap_buf = (uint8_t * )malloc(len);

   if (trap_buf == NULL)
   {
      mocad_log(ctx, L_ERR, "%s: unable to allocate %u bytes\n",
         __FUNCTION__, len);
      return(-1);
   }

   pnew = (struct mocad_trap_list *)malloc(sizeof(struct mocad_trap_list));
   if (pnew == NULL)
   {
      mocad_log(ctx, L_ERR, "%s: unable to allocate list element\n",
         __FUNCTION__);
      free(trap_buf);

      return(-1);
   }

   /* Fill in new list entry */
   memcpy(trap_buf, trap, len);
   pnew->trap = trap_buf;
   pnew->len  = len;
   pnew->next = NULL;

   if (ctx->trap_list == NULL) {
      /* First element of the list */
      ctx->trap_list = pnew;
   }
   else {
      /* Add to tail */
      plist = ctx->trap_list;

      while (plist->next != NULL)
         plist = plist->next;

      plist->next = pnew;
   }

   ctx->trap_count++;

   if (ctx->trap_count > ctx->trap_watermark)
      ctx->trap_watermark = ctx->trap_count;

   mocad_log(ctx, L_DEBUG, 
      "Deferring trap 0x%x (len %d) - #%u (%u)\n",
      BE16(ih->ie_type), len, ctx->trap_count,
      ctx->trap_watermark);

   return(0);
}

struct mocad_trap_list * mocad_get_trap(struct mocad_ctx *ctx)
{
   struct mocad_trap_list * trap;

   trap = ctx->trap_list;

   if (trap != NULL) {
      ctx->trap_list = trap->next;
      ctx->trap_count--;
   }

   return(trap);
}

void mocad_free_trap(struct mocad_ctx * ctx, struct mocad_trap_list * trap)
{
   if (trap != NULL) {
      free(trap->trap);
      free(trap);
   }
   return;
}


int mocad_set_rlapm_table(void * vctx, struct moca_rlapm_table * in)
{
   struct mocad_ctx *ctx = (struct mocad_ctx *)vctx;
   struct moca_rlapm_table tbl;
   int ret = 0;
   int i;
   
   if (ctx->any_time.rlapm_en)
   {
      ret = moca_set_rlapm_table(vctx, in);
   }
   else
   {
      for (i = 0; 
           i < (int)(sizeof(tbl.rlapmtable)/sizeof(tbl.rlapmtable[0])); 
           i++)
      {
         tbl.rlapmtable[i] = MIN(in->rlapmtable[i], ctx->any_time.rlapm_cap);
      }

      ret = moca_set_rlapm_table(vctx, &tbl);
   }

   return ret;
}


int mocad_set_rlapm_en(void * vctx, uint32_t bool_val)
{
   struct mocad_ctx *ctx = (struct mocad_ctx *)vctx;
   int ret = 0;

   if ((ctx->init_time.rf_type == 0) || // MoCA_RF_TYPE_D_BAND - HI-RF
       (ctx->init_time.rf_type == 2) || // MoCA_RF_TYPE_F_BAND
         (ctx->init_time.rf_type == 3))   // MoCA_RF_TYPE_C4_BAND - WAN
      ret = moca_set_rlapm_en(vctx, bool_val);
   else
   {
      ret = moca_set_rlapm_en(vctx, 1);

      if (ret == 0)
      {
         ret = mocad_set_rlapm_table(vctx, &ctx->any_time.rlapm_table);
      }
   }
   return ret;
}

int mocad_set_rlapm_cap(void * vctx, uint32_t cap)
{
   struct mocad_ctx *ctx = (struct mocad_ctx *)vctx;
   int ret = 0;

   if (ctx->any_time.rlapm_en == 0)
   {
      ret = mocad_set_rlapm_table(vctx, &ctx->any_time.rlapm_table);
   }

   return ret;
}

int mocad_set_host_qos(void * vctx, uint32_t host_qos)
{

#if defined(__gnu_linux__) && !defined(DSL_MOCA)
   struct mocad_ctx *ctx = (struct mocad_ctx *)vctx;
   if (host_qos)
      mocad_init_forwarding(ctx);
   else if (ctx->prev_host_qos)
   {
      char cmd[64];

      sprintf(cmd, "tc qdisc del dev %s root 2> /dev/null", ctx->ifname);
      system(cmd);
   }

   ctx->prev_host_qos = host_qos;
#endif    
   return(0);
}

// restore init and anytime values to defaults, except turboEn and rfType
int mocad_restore_defaults(struct mocad_ctx *ctx, unsigned int freq, unsigned int waitmode)
{
   int i;
   int snrMarginOffset;
   unsigned int o_rftype;
   unsigned int o_terminalintermediate;
   unsigned int o_turboen;
    
   static uint32_t snr_def_table[12] = {
                              (int) (2 * 9.5),
                              (int) (2 * 12.5),
                              (int) (2 * 15.5),
                              (int) (2 * 19),
                              (int) (2 * 22.5),
                              (int) (2 * 25.5),
                              (int) (2 * 29.5),
                              (int) (2 * 34),
                              (int) (2 * 37),
                              (int) (2 * 40),
                              0,          // last two entries not used
                              0};

   o_turboen = ctx->init_time.turbo_en;
   o_terminalintermediate = ctx->init_time.terminal_intermediate_device;
   o_rftype = ctx->init_time.rf_type;

   memset(&ctx->init_time, 0, sizeof(ctx->init_time));
   memset(&ctx->init_time_options, 0, sizeof(ctx->init_time_options));    

   ctx->init_time.turbo_en = o_turboen;
   ctx->init_time.terminal_intermediate_device = o_terminalintermediate;
   ctx->init_time.rf_type = o_rftype;
   ctx->init_time.auto_network_search_en = 1;
   ctx->init_time.continuous_power_tx_mode = 0;
   ctx->init_time.continuous_rx_mode_attn  = MoCA_DEF_RX_MODE_ATTN;

#if defined(DSL_MOCA)
   snrMarginOffset = 4;  // 2 db
   ctx->init_time.flow_control_en = 1;
#else
   snrMarginOffset = 0;
#endif

   for (i = 0; 
       i < 10;
       i++) {
      ctx->any_time.snr_margin_table.mgntable[i] = snr_def_table[i] + snrMarginOffset;
   }

   ctx->any_time.snr_margin_table.mgntable[10] = snrMarginOffset;

   if((ctx->init_time.rf_type == 0) || // MoCA_RF_TYPE_D_BAND - HI-RF
      (ctx->init_time.rf_type == 3))   // MoCA_RF_TYPE_C4_BAND - WAN
   {
      ctx->init_time.tpc_en = 1;
      ctx->init_time.preferred_nc = 0;

      ctx->init_time.taboo_fixed_channel_mask = 0xf80000;
      ctx->init_time.taboo_fixed_mask_start = 41;

      ctx->any_time.rlapm_en = 0;
      ctx->init_time.beacon_channel = 0;
      
      ctx->init_time.flow_control_en = 0;

      if (ctx->init_time.rf_type == 3)
         ctx->init_time.auto_network_search_en = 2;

#if !defined(DSL_MOCA)
      if (ctx->kdrv_info.hw_rev == MOCA_CHIP_11)
         ctx->any_time.snr_margin_table.mgntable[7] += 4;
      switch(ctx->kdrv_info.chip_id & 0xFFFF0000)
      {
         case 0x74200000:
         case 0x74100000:
         case 0x73420000:
         case 0x71250000:
         ctx->any_time.snr_margin_table.mgntable[6] +=2;
         break;
      }
#endif
   }
   else
   {
      ctx->init_time.tpc_en = 0;
      
      if (ctx->init_time.terminal_intermediate_device == 1) // terminal
         ctx->init_time.preferred_nc = 1;
      else
         ctx->init_time.preferred_nc = 0;

      ctx->init_time.taboo_fixed_channel_mask = 0x000000;
      if (ctx->init_time.rf_type == 4) // H_BAND
         ctx->init_time.taboo_fixed_mask_start = 39;
      else
         ctx->init_time.taboo_fixed_mask_start = 17;
      ctx->any_time.rlapm_en = 1;
      if (ctx->init_time.rf_type == 1) // midlo
         ctx->init_time.beacon_channel = 575;
      else if (ctx->init_time.rf_type == 4) // H band
         ctx->init_time.beacon_channel = 1000;
      else
         ctx->init_time.beacon_channel = 800;

      if (ctx->init_time.rf_type == 4)
         ctx->init_time.auto_network_search_en = 2;

      if (!freq)
         freq = ctx->init_time.beacon_channel;
      ctx->init_time.flow_control_en = 1;
      
   }

   if (ctx->init_time.terminal_intermediate_device == 1) // terminal
   {
      if (ctx->init_time.rf_type == 2) // band F
      {
         ctx->init_time.t50_time_min = 16;
         ctx->init_time.t50_time_max = 35;
      }
      else
      {
         ctx->init_time.t50_time_min = 12;
         ctx->init_time.t50_time_max = 20;
      }
   }  
   else
   {
      if (ctx->init_time.rf_type == 2) // band F
      {
         ctx->init_time.t50_time_min = 213;
         ctx->init_time.t50_time_max = 260;
      }
      else
      {
         ctx->init_time.t50_time_min = 160;
         ctx->init_time.t50_time_max = 195;   
      }
   }

   ctx->init_time.mtm_en = 0;
   ctx->init_time.qam1024_en = 0;

   ctx->init_time.taboo_left_mask = 0x00FFFFFF;
   ctx->init_time.taboo_right_mask = 0xFFFFFF00;
   ctx->init_time.freq_mask = 0xFFFFFFFF;
   ctx->init_time.pns_freq_mask = 0xFFFFFFFF;
    

   if(freq == 0) {
      ctx->init_time.lof = ctx->disk_lof;
   } else {
      ctx->init_time.lof = freq;
   }

   mocad_read_nondefseqnum(ctx);

   ctx->init_time.max_tx_power_beacons = 3;
   ctx->init_time.max_tx_power_packets = 3;  
   ctx->init_time.led_settings = 0;
   ctx->init_time.mac_addr_hi = ctx->kdrv_info.macaddr_hi;
   ctx->init_time.mac_addr_lo = ctx->kdrv_info.macaddr_lo;
   ctx->init_time.multicast_mode = 1;

   ctx->init_time.qam256_capability = 1;
   ctx->init_time.otf_en = 0;
#if !defined(DSL_MOCA)
   ctx->init_time.pad_power = -7;
   ctx->init_time.low_pri_q_num = 0;
   ctx->init_time.beacon_pwr_reduction_en = 1;
#else
   ctx->init_time.pad_power = -10;
   ctx->init_time.low_pri_q_num = 2;
   ctx->init_time.beacon_pwr_reduction_en = 0;    
#endif


   ctx->init_time.beacon_pwr_reduction = 0;
   ctx->init_time_options.dont_start_moca = waitmode;
   ctx->init_time_options.const_tx_mode = 0;


   /* set default any_time parameters */
   ctx->any_time.max_frame_size = 6148;
   ctx->any_time.max_transmit_time = 400;
   ctx->any_time.min_bw_alarm_threshold = 100;
   ctx->any_time.continuous_ie_rr_insert = 0;
   ctx->any_time.continuous_ie_map_insert = 0;
   ctx->any_time.max_pkt_aggr = 10;
   if (ctx->init_time.rf_type == 2) // band F
      ctx->any_time.sapm_en = 1;
   else
      ctx->any_time.sapm_en = 0;
   ctx->any_time.arpl_th = -50;

   for (i=0 ; i < 112; i++) 
   {
      ctx->any_time.sapm_table.sapmtablelo[i] = 0;
      ctx->any_time.sapm_table.sapmtablehi[i] = 0;
   }

   for (i=0 ; i < 41; i++) 
   {
          ctx->any_time.rlapm_table.rlapmtable[i] = 0;
   }


   ctx->any_time.rlapm_table.rlapmtable[65]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[64]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[63]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[62]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[61]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[60]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[59]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[58]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[57]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[56]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[55]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[54]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[53]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[52]= (int)(16.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[51]= (int)(15.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[50]= (int)(15.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[49]= (int)(15.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[48]= (int)(14.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[47]= (int)(14.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[46]= (int)(13.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[45]= (int)(12.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[44]= (int)(11.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[43]= (int)(10.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[42]= (int)(10.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[41]= (int)(9.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[40]= (int)(8.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[39]= (int)(7.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[38]= (int)(6.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[37]= (int)(5.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[36]= (int)(4.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[35]= (int)(4.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[34]= (int)(3.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[33]= (int)(3.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[32]= (int)(2.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[31]= (int)(2.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[30]= (int)(1.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[29]= (int)(1.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[28]= (int)(1.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[27]= (int)(1.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[26]= (int)(1.0000*2);
   ctx->any_time.rlapm_table.rlapmtable[25]= (int)(0.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[24]= (int)(0.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[23]= (int)(0.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[22]= (int)(0.5000*2);
   ctx->any_time.rlapm_table.rlapmtable[21]= (int)(0.5000*2);

   for (i = 0; i < MOCA_MAX_NODES; i++)
      ctx->any_time.max_constellation[i] = 10;

   ctx->any_time.freq_shift_mode = 0;
   ctx->any_time.pmk_exchange_interval = 11 * 3600 * 1000;
   ctx->any_time.tek_exchange_interval = 9 * 60 * 1000;

   if (ctx->init_time.terminal_intermediate_device == 1) // terminal
   {
      ctx->any_time.priority_allocations.reservation_high = 1;
      ctx->any_time.priority_allocations.reservation_med = 1;
      ctx->any_time.priority_allocations.reservation_low = 1;
      ctx->any_time.priority_allocations.limitation_high = 300;
      ctx->any_time.priority_allocations.limitation_med = 300;
      ctx->any_time.priority_allocations.limitation_low = 300;
   }
   else  
   {
      ctx->any_time.priority_allocations.reservation_high = 9;
      ctx->any_time.priority_allocations.reservation_med = 64;
      ctx->any_time.priority_allocations.reservation_low = 64;
      ctx->any_time.priority_allocations.limitation_high = 300;
      ctx->any_time.priority_allocations.limitation_med = 300;
      ctx->any_time.priority_allocations.limitation_low = 300;
   }

   ctx->any_time.min_map_cycle = 809;
   ctx->any_time.max_map_cycle = 1800;
   ctx->any_time.rx_tx_packets_per_qm = 18;
   ctx->any_time.extra_rx_packets_per_qm = 6;
   ctx->any_time.target_phy_rate_qam128 = 245;
   ctx->any_time.target_phy_rate_qam256 = 275;
   ctx->any_time.target_phy_rate_turbo = 380;
   ctx->any_time.target_phy_rate_turbo_plus = 500;
   ctx->any_time.nbas_capping_en = 0;
   ctx->any_time.loopback_en = 0;    
   ctx->any_time.selective_rr = 3;    
   ctx->any_time.en_capable = 1;
   ctx->any_time.min_aggr_wait_time = 0;
   ctx->any_time.diplexer = 0;
   ctx->any_time.rlapm_cap = (3 * 2); // 3 dB
   ctx->any_time.en_max_rate_in_max_bo = 0;
   ctx->any_time.core_trace_enable = 0;

   if (ctx->kdrv_info.hw_rev >= MOCA_CHIP_20)
      ctx->any_time.host_qos = 1;
   else
      ctx->any_time.host_qos = 0;

   return 0;
}

int mocad_req(struct mocad_ctx *ctx, void *wr, int wr_len)
{
   int len;
   int ret;
   time_t start;   
   struct mmp_msg_hdr *mh = (struct mmp_msg_hdr *)ctx->drv_in;

   if(ctx->verbose & L_MMP_MSG)
         mocad_dump_buf(ctx, "REQ <", (unsigned char *)wr, wr_len);

   MoCAOS_SendMMP(ctx->os_handle, MoCAOS_CLIENT_CORE, (unsigned char *)wr, (unsigned int)wr_len);

   start = time(NULL);

   while (1)
   {
      len = MOCA_BUF_LEN;
      ret = MoCAOS_ReadMMP(ctx->os_handle, MoCAOS_CLIENT_CORE, 
         MOCA_REQ_TIMEOUT, ctx->drv_in, &len);  // return 0 timeout, <0 failure, >0 success

      if (ret == 0)
      {
         // Timeout
         mocad_update_times(ctx, MOCA_TIME_EVENT_CORE_DOWN);
         ctx->moca_running = 0;
         ctx->restart = 13;
         return(-1);
      }
      else if (ret < 0)
      {
         return(-2);
      }

      switch(mh->msg_type) {
         case MOCA_MSG_ACK:
         case MOCA_MSG_GET_RESPONSE:
            if(ctx->verbose & L_MMP_MSG)
               mocad_dump_buf(ctx, "RESP>",
                  ctx->drv_in, len);
            return(len);
         case MOCA_MSG_TRAP:
            /* While expecting a RSP from core, 
             * defer trap processing */
            mocad_add_trap(ctx, ctx->drv_in, len);
            break;
         default:
            mocad_log(ctx, L_WARN,
               "warning: unrecognized reply %d\n",
               mh->msg_type);
            return(-3);
      }

      if (time(NULL)-start > MOCA_REQ_TIMEOUT+1)
      {
         // overall loop timeout
         mocad_update_times(ctx, MOCA_TIME_EVENT_CORE_DOWN);
         ctx->moca_running = 0;
         ctx->restart = 14;
         return(-4);
      }        
   }
}


int mocad_cmd(void *vctx, uint8_t msg_type, uint16_t ie_type,
   const void *wr, int wr_len, void *rd, int rd_len, int flags)
{
   struct mocad_ctx *ctx = (struct mocad_ctx *)vctx;
   struct mmp_msg_hdr *mh;
   struct mmp_ie_hdr *ih;
   int ret;

   mh = (struct mmp_msg_hdr *)ctx->drv_out;
   mh->msg_type = msg_type;
   mh->msg_id = 0;
   mh->num_ies = BE16(1);

   ih = (struct mmp_ie_hdr *)(mh + 1);
   ih->ie_type = BE16(ie_type);
   ih->ie_len = (uint16_t)BE16(wr_len);

   if(wr_len) {
      if(flags & FL_SWAP_WR)
         __moca_copy_be32((void *)(ih + 1), wr, wr_len);
      else
         memcpy((void *)(ih + 1), wr, wr_len);
   }

   ret = mocad_req(ctx, ctx->drv_out, wr_len + sizeof(*mh) + sizeof(*ih));
   if(ret < 0)
      return(ret);

   mh = (struct mmp_msg_hdr *)ctx->drv_in;
   ih = (struct mmp_ie_hdr *)(mh + 1);

   if(BE16(mh->num_ies) != 1) {
      mocad_log(ctx, L_WARN, "warning: wrong num_ies in response\n");
      return(-1);
   }

   if(ret <= (int)(sizeof(*mh) + sizeof(*ih))) {
      mocad_log(ctx, L_WARN, "warning: short response\n");
      return(-2);
   }

   ret -= sizeof(*mh) + sizeof(*ih);

   if(ret > rd_len) {
      mocad_log(ctx, L_WARN,
         "warning: response size exceeds buffer len IE %04X, (%d %d)\n", ie_type, ret, rd_len);
      ret = rd_len;
   }
   if(ie_type != BE16(ih->ie_type)) {
      mocad_log(ctx, L_WARN,
         "warning: response IE mismatch, %x != %x\n",
         ie_type, BE16(ih->ie_type));
   }

   if(rd && ret) {
      if(flags & FL_SWAP_RD)
         __moca_copy_be32(rd, (void *)(ih + 1), ret);
      else
         memcpy(rd, (void *)(ih + 1), ret);
      }
   return(0);
}


int mocad_table_cmd(void *vctx, uint16_t ie_type, void **rd)
{
   struct mocad_ctx   *ctx = (struct mocad_ctx *) vctx;
   struct mmp_msg_hdr *mh;
   struct mmp_ie_hdr  *ih;
   int                 ret;

   mh = (struct mmp_msg_hdr *)ctx->drv_out;
   mh->msg_type = MOCA_MSG_GET_TABLE;
   mh->msg_id = 0;
   mh->num_ies = BE16(1);

   ih = (struct mmp_ie_hdr *)(mh + 1);
   ih->ie_type = BE16(ie_type);
   ih->ie_len = BE16(0);

   ret = mocad_req(ctx, ctx->drv_out, sizeof(*mh) + sizeof(*ih));
   if(ret < 0)
      return ret;

   mh = (struct mmp_msg_hdr *)ctx->drv_in;
   ih = (struct mmp_ie_hdr *)(mh + 1);
   *rd = ih;

   /* sanity checks on reply */

   if(BE16(mh->num_ies) < 1) {
      return -1;
   }

   if(ret < (int)(sizeof(*mh) + sizeof(*ih))) {
      return -2;
   }

   ret -= sizeof(*mh);

   if(ie_type == BE16(IE_ABORT)) {
      return -3;
   }

   return(ret);
}


static int mocad_add_pqos_entry(
   struct mocad_ctx * ctx, struct moca_pqos_table * r, int * index)
{
   int i;
   int first_empty = -1;
   int ret = 0;

   /* search for an empty entry in the table and add it */
   for (i = 0; i < MOCA_MAX_PQOS_ENTRIES; i++)
   {
      if ((first_empty < 0) &&
         (ctx->pqos_table[i].flow_id_hi == 0) &&
         (ctx->pqos_table[i].flow_id_lo == 0))
      {
         first_empty = i;
      }

      /* make sure that this entry doesn't already exist */
      if ((r->flow_id_hi == ctx->pqos_table[i].flow_id_hi) &&
          (r->flow_id_lo == ctx->pqos_table[i].flow_id_lo))
      {
         mocad_log(ctx, L_WARN, "%s: entry already exists %08x:%08x\n",
            __FUNCTION__, r->flow_id_hi, r->flow_id_lo);
         return(1);
      }
   }

   if (first_empty < 0)
   {
      mocad_log(ctx, L_WARN, "%s: Could not find free entry\n",
         __FUNCTION__);
      return(1);
   }

   if (index != NULL)
      *index = first_empty;

   ret = mocad_update_pqos_flow_in_switch(ctx, r, MOCAD_PQOS_SWITCH_ADD,first_empty);

   if (ret == 0)
   {
      memcpy(&ctx->pqos_table[first_empty], r, sizeof(*r));
      ctx->pqos_table[first_empty].create_time = (uint32_t)time(NULL);
   }

   return(ret);
}

static int mocad_del_pqos_entry(
   struct mocad_ctx * ctx, struct moca_pqos_table * r)
{
   int i;
   int entry_found = 0;
   int ret = 0;

   /* search for the matching entry in the table and delete it */
   for (i = 0; i < MOCA_MAX_PQOS_ENTRIES; i++)
   {
      if ((ctx->pqos_table[i].flow_id_hi == r->flow_id_hi) &&
          (ctx->pqos_table[i].flow_id_lo == r->flow_id_lo))
      {
         entry_found = 1;
         ret = mocad_update_pqos_flow_in_switch(ctx, &ctx->pqos_table[i],
               MOCAD_PQOS_SWITCH_DELETE, i);
         memset(&ctx->pqos_table[i], 0x0, sizeof(struct moca_pqos_table));
         break;
      }
   }

   if (entry_found)
   {
      return(0);
   }
   else
   {
      mocad_log(ctx, L_DEBUG, "%s: entry not found %08x:%08x\n", 
         __FUNCTION__, r->flow_id_hi, r->flow_id_lo);
      return(1);
   }
}


static void mocad_handle_pqos_create_rsp(struct mocad_ctx *ctx, 
   struct moca_pqos_create_response * pqosc_rsp)
{
   struct moca_gen_status gs;
   struct moca_pqos_ingr_add_flow req;
   uint32_t nodeId = 0;
   uint32_t egressnodebitmask;
   int ret, i;
   struct moca_pqos_table * p_table = NULL;
   struct moca_pqos_table pqos_table;

   if ((BE32(pqosc_rsp->responsecode) == MOCA_L2_SUCCESS) &&
       (BE32(pqosc_rsp->decision) == MOCA_PQOS_DECISION_SUCCESS))
   {
      ret = mocad_cmd(ctx, MOCA_MSG_GET, IE_GEN_STATUS, NULL, 0,
         &gs, sizeof(gs), 0);
      if (ret != 0)
      {
         mocad_log(ctx, L_ERR, "%s: get_gen_status failed %d\n",
            __FUNCTION__, ret);
         return;
      }

      mocad_log(ctx, L_DEBUG, "pqos create rsp node id %u (ours %u)\n",
         BE32(pqosc_rsp->ingressnodeid), BE32(gs.node_id));

      if (BE32(gs.node_id) == BE32(pqosc_rsp->ingressnodeid)) {
         /* There should be an entry for this flow in the context */
         for (i = 0; i < MOCA_MAX_PQOS_ENTRIES; i++)
         {
            if ((ctx->pqos_table[i].flow_id_hi == BE32(pqosc_rsp->flowid_hi)) 
                &&
                (ctx->pqos_table[i].flow_id_lo == BE32(pqosc_rsp->flowid_lo)))
            {
               p_table = &ctx->pqos_table[i];
               break;
            }
         }

         if (p_table == NULL)
         {
            mocad_log(ctx, L_DEBUG, "%s: Couldn't find entry in table\n",
               __FUNCTION__);
            return;
         }

         req.flowid_hi = BE32(pqosc_rsp->flowid_hi);
         req.flowid_lo = BE32(pqosc_rsp->flowid_lo);
         req.flowtag = BE32(pqosc_rsp->flowtag);
         req.qtag = i;
         req.tpeakdatarate = BE32(pqosc_rsp->maxpeakdatarate);
         req.tpacketsize = BE32(pqosc_rsp->tpacketsize);
         req.tburstsize = BE32(pqosc_rsp->maxburstsize);
         req.tleasetime = BE32(pqosc_rsp->tleasetime);
         egressnodebitmask = BE32(pqosc_rsp->egressnodebitmask);
         while (egressnodebitmask && (nodeId < MOCA_MAX_NODES))
         {
            if (egressnodebitmask & 0x01)
            {
               egressnodebitmask >>= 1;
               if (egressnodebitmask)
                  nodeId = 0x3f;
               break;
            }
            egressnodebitmask >>= 1;
            nodeId++;
         }
         req.egressnodeid = nodeId;
         req.flowsa_hi = p_table->talker_hi;
         req.flowsa_lo = p_table->talker_lo;
         req.flowda_hi = BE32(pqosc_rsp->flowda_hi);
         req.flowda_lo = BE32(pqosc_rsp->flowda_lo);
         req.flowvlanpri = p_table->vlan_prio;
         req.flowvlanid = p_table->vlan_id;
         req.committedstps = BE32(pqosc_rsp->flowstps);
         req.committedtxps = BE32(pqosc_rsp->flowtxps);

         ret = moca_set_pqos_ingr_add_flow(ctx, &req);
         if (ret != 0)
            mocad_log(ctx, L_ERR, 
               "Creating MoCA Ingress flow error! %d\n", ret);
      }
   }
   else
   {
      pqos_table.flow_id_hi = BE32(pqosc_rsp->flowid_hi);
      pqos_table.flow_id_lo = BE32(pqosc_rsp->flowid_lo);
      mocad_del_pqos_entry(ctx, &pqos_table);
   }
}


static void mocad_handle_pqos_create_cmp(struct mocad_ctx *ctx, 
   struct moca_pqos_create_complete * pqosc_cmp)
{
   struct moca_gen_status gs;
   struct moca_pqos_ingr_add_flow req;
   uint32_t nodeId = 0;
   uint32_t egressnodebitmask;
   int ret;
   struct moca_pqos_table p_table;

   if ((BE32(pqosc_cmp->responsecode) == MOCA_L2_SUCCESS) &&
       (BE32(pqosc_cmp->decision) == MOCA_PQOS_DECISION_SUCCESS))
   {
      ret = mocad_cmd(ctx, MOCA_MSG_GET, IE_GEN_STATUS, NULL, 0,
         &gs, sizeof(gs), 0);

      if (ret != 0)
      {
         mocad_log(ctx, L_ERR, "%s: get_gen_status failed %d\n",
            __FUNCTION__, ret);
         return;
      }

      mocad_log(ctx, L_DEBUG, "pqos create cmp node id %u (ours %u)\n",
         BE32(pqosc_cmp->ingressnodeid), BE32(gs.node_id)); 

      if (BE32(gs.node_id) == BE32(pqosc_cmp->ingressnodeid)) {
         /* Need to add an entry for this flow in the context */
         memset(&p_table, 0x0, sizeof(p_table));
         p_table.flow_id_hi = BE32(pqosc_cmp->flowid_hi);
         p_table.flow_id_lo = BE32(pqosc_cmp->flowid_lo);
         p_table.packet_da_hi = BE32(pqosc_cmp->flowda_hi);
         p_table.packet_da_lo = BE32(pqosc_cmp->flowda_lo);
         p_table.lease_time = BE32(pqosc_cmp->tleasetime);
         p_table.egress_node_mask = BE32(pqosc_cmp->egressnodebitmask);
         p_table.vlan_id = MoCA_PQOS_VLAN_ID_DEFAULT;
         p_table.vlan_prio = MoCA_PQOS_VLAN_PRIO_DEFAULT;
         
         ret = mocad_add_pqos_entry(ctx, &p_table, (int *)&req.qtag);
         if (ret != 0)
         {
            mocad_log(ctx, L_ERR, "%s: unable to add entry\n",
               __FUNCTION__);
            return;
         }

         req.flowid_hi = BE32(pqosc_cmp->flowid_hi);
         req.flowid_lo = BE32(pqosc_cmp->flowid_lo);
         req.flowtag = BE32(pqosc_cmp->flowtag);
         req.tpeakdatarate = BE32(pqosc_cmp->maxpeakdatarate);
         req.tpacketsize = BE32(pqosc_cmp->tpacketsize);
         req.tburstsize = BE32(pqosc_cmp->maxburstsize);
         req.tleasetime = BE32(pqosc_cmp->tleasetime);
         egressnodebitmask = BE32(pqosc_cmp->egressnodebitmask);
         while (egressnodebitmask && (nodeId < MOCA_MAX_NODES)) {
            if (egressnodebitmask & 0x01)
            {
               egressnodebitmask >>= 1;
               if (egressnodebitmask)
                  nodeId = 0x3f;
               break;
            }
            egressnodebitmask >>= 1;
            nodeId++;
         }
         req.egressnodeid = nodeId;
         req.flowsa_hi = p_table.talker_hi;
         req.flowsa_lo = p_table.talker_lo;
         req.flowda_hi = BE32(pqosc_cmp->flowda_hi);
         req.flowda_lo = BE32(pqosc_cmp->flowda_lo);
         req.flowvlanpri = p_table.vlan_prio;
         req.flowvlanid = p_table.vlan_id;
         req.committedstps = BE32(pqosc_cmp->flowstps);
         req.committedtxps = BE32(pqosc_cmp->flowtxps);

         ret = moca_set_pqos_ingr_add_flow(ctx, &req);
         if (ret != 0)
            mocad_log(ctx, L_ERR, 
               "Creating MoCA Ingress flow error! %d\n", ret);
      }
   }
}

static void mocad_handle_pqos_update_rsp(struct mocad_ctx *ctx, 
   struct moca_pqos_update_response * pqosu_rsp)
{
   struct moca_pqos_ingr_update req;
   int ret, i;
   struct moca_pqos_table * p_table = NULL;

   if ((BE32(pqosu_rsp->responsecode) == MOCA_L2_SUCCESS) &&
       (BE32(pqosu_rsp->decision) == MOCA_PQOS_DECISION_SUCCESS))
   {
      /* There should be an entry for this flow in the context */
      for (i = 0; i < MOCA_MAX_PQOS_ENTRIES; i++)
      {
         if ((ctx->pqos_table[i].flow_id_hi == BE32(pqosu_rsp->flowid_hi)) &&
             (ctx->pqos_table[i].flow_id_lo == BE32(pqosu_rsp->flowid_lo)))
         {
            p_table = &ctx->pqos_table[i];
            break;
         }
      }

      /* This update is not for us, nothing to do */
      if (p_table == NULL)
      {
         mocad_log(ctx, L_DEBUG, "%s: Couldn't find entry in table\n",
            __FUNCTION__);
         return;
      }

      req.flowid_hi = BE32(pqosu_rsp->flowid_hi);
      req.flowid_lo = BE32(pqosu_rsp->flowid_lo);
      req.flowtag = BE32(pqosu_rsp->flowtag);
      req.tpeakdatarate = BE32(pqosu_rsp->maxpeakdatarate);
      req.tpacketsize = BE32(pqosu_rsp->tpacketsize);
      req.tburstsize = BE32(pqosu_rsp->maxburstsize);
      req.tleasetime = BE32(pqosu_rsp->tleasetime);
      req.flowda_hi = BE32(pqosu_rsp->flowda_hi);
      req.flowda_lo = BE32(pqosu_rsp->flowda_lo);
      req.committedstps = BE32(pqosu_rsp->flowstps);
      req.committedtxps = BE32(pqosu_rsp->flowtxps);

      /* update the relevant local table parameters */
      p_table->lease_time = BE32(pqosu_rsp->tleasetime);
      p_table->create_time = (uint32_t)time(NULL);
      
      ret = moca_set_pqos_ingr_update(ctx, &req);
      if (ret != 0)
         mocad_log(ctx, L_ERR, "Update MoCA Ingress flow error! %d\n", ret);
   }
}


static void mocad_handle_pqos_update_cmp(struct mocad_ctx *ctx, 
   struct moca_pqos_update_complete * pqosu_cmp)
{
   struct moca_pqos_ingr_update req;
   int ret, i;
   struct moca_pqos_table * p_table = NULL;

   if ((BE32(pqosu_cmp->responsecode) == MOCA_L2_SUCCESS) &&
       (BE32(pqosu_cmp->decision) == MOCA_PQOS_DECISION_SUCCESS))
   {
      /* There should be an entry for this flow in the context */
      for (i = 0; i < MOCA_MAX_PQOS_ENTRIES; i++)
      {
         if ((ctx->pqos_table[i].flow_id_hi == BE32(pqosu_cmp->flowid_hi)) &&
             (ctx->pqos_table[i].flow_id_lo == BE32(pqosu_cmp->flowid_lo)))
         {
            p_table = &ctx->pqos_table[i];
            break;
         }
      }

      if (p_table == NULL)
      {
         mocad_log(ctx, L_DEBUG, "%s: Couldn't find entry in table\n",
            __FUNCTION__);
         return;
      }

      req.flowid_hi = BE32(pqosu_cmp->flowid_hi);
      req.flowid_lo = BE32(pqosu_cmp->flowid_lo);
      req.flowtag = BE32(pqosu_cmp->flowtag);
      req.tpeakdatarate = BE32(pqosu_cmp->maxpeakdatarate);
      req.tpacketsize = BE32(pqosu_cmp->tpacketsize);
      req.tburstsize = BE32(pqosu_cmp->maxburstsize);
      req.tleasetime = BE32(pqosu_cmp->tleasetime);
      req.flowda_hi = BE32(pqosu_cmp->flowda_hi);
      req.flowda_lo = BE32(pqosu_cmp->flowda_lo);
      req.committedstps = BE32(pqosu_cmp->flowstps);
      req.committedtxps = BE32(pqosu_cmp->flowtxps);

      /* update the relevant local table parameters */
      p_table->lease_time = BE32(pqosu_cmp->tleasetime);
      p_table->create_time = (uint32_t)time(NULL);

      ret = moca_set_pqos_ingr_update(ctx, &req);
      if (ret != 0)
         mocad_log(ctx, L_ERR, 
            "Update MoCA Ingress flow error! %d\n", ret);
   }
}

static void mocad_handle_pqos_delete_rsp(
   struct mocad_ctx *ctx, 
   struct moca_pqos_delete_response * pqosd_rsp)
{
   struct moca_pqos_ingr_delete req;
   struct moca_pqos_table p_table;
   int ret;
   
   /* delete the flow from our table if it exists */
   p_table.flow_id_hi = BE32(pqosd_rsp->flowid_hi);
   p_table.flow_id_lo = BE32(pqosd_rsp->flowid_lo);
   ret = mocad_del_pqos_entry(ctx, &p_table);
   if (ret == 0)
   {
      /* found the flow in our table */
      req.flowid_hi = BE32(pqosd_rsp->flowid_hi);
      req.flowid_lo = BE32(pqosd_rsp->flowid_lo);
      moca_set_pqos_ingr_delete(ctx, &req);
   }
}

static void mocad_handle_pqos_delete_cmp(
   struct mocad_ctx *ctx, 
   struct moca_pqos_delete_complete * pqosd_cmp)
{
   struct moca_pqos_ingr_delete req;
   struct moca_pqos_table p_table;
   int ret;
   
   /* delete the flow from our table if it exists */
   p_table.flow_id_hi = BE32(pqosd_cmp->flowid_hi);
   p_table.flow_id_lo = BE32(pqosd_cmp->flowid_lo);
   ret = mocad_del_pqos_entry(ctx, &p_table);
   if (ret == 0)
   {
      /* found the flow in our table */
      req.flowid_hi = BE32(pqosd_cmp->flowid_hi);
      req.flowid_lo = BE32(pqosd_cmp->flowid_lo);
      moca_set_pqos_ingr_delete(ctx, &req);
   }
}

static int mocad_reg_write_multiple(
   struct mocad_ctx *ctx, uint32_t reg, uint32_t *val, uint32_t nwords)
{
   struct moca_lab_register lab_reg;

   lab_reg.address = reg;
    __moca_copy_be32(lab_reg.value, val, 4*nwords);
   lab_reg.len = nwords;

   return(moca_set_lab_register(ctx, &lab_reg));
}


static void mocad_handle_const_tx_mode(
   struct mocad_ctx *ctx)
{
   switch(ctx->init_time_options.const_tx_mode)
   {
      case MoCA_CONTINUOUS_TX_CW:
         ctx->init_time.const_tx_submode = 2;
         break;
      case MoCA_CONTINUOUS_TX_BAND:
         ctx->init_time.const_tx_submode = 3;
         break;
      case MoCA_CONTINUOUS_TX_TONE:
         ctx->init_time.const_tx_sc1 = 0x40;
         ctx->init_time.const_tx_sc2 = 0x40;
         ctx->init_time.const_tx_submode = 0;
         break;
   
      case MoCA_CONTINUOUS_TX_DUAL_TONE_SC:
         ctx->init_time.const_tx_sc1 = ctx->init_time_options.const_tx_sc1;
         ctx->init_time.const_tx_sc2 = ctx->init_time_options.const_tx_sc2;
         ctx->init_time.const_tx_submode = 0;
         break;

      case MoCA_CONTINUOUS_TX_TONE_SC:
         ctx->init_time.const_tx_sc1 = ctx->init_time_options.const_tx_sc1;
         ctx->init_time.const_tx_sc2 = ctx->init_time_options.const_tx_sc1;
         ctx->init_time.const_tx_submode = 0;
         break;
      default:
         ctx->init_time.const_tx_submode = 1;
         break;
   }
   ctx->init_time.const_tx_band0 = ctx->init_time_options.const_tx_band0;
   ctx->init_time.const_tx_band1 = ctx->init_time_options.const_tx_band1;
   ctx->init_time.const_tx_band2 = ctx->init_time_options.const_tx_band2;
   ctx->init_time.const_tx_band3 = ctx->init_time_options.const_tx_band3;
   ctx->init_time.const_tx_band4 = ctx->init_time_options.const_tx_band4;
   ctx->init_time.const_tx_band5 = ctx->init_time_options.const_tx_band5;
   ctx->init_time.const_tx_band6 = ctx->init_time_options.const_tx_band6;
   ctx->init_time.const_tx_band7 = ctx->init_time_options.const_tx_band7;
   }


static void mocad_print_stats(struct mocad_ctx *ctx)
{
   int i;
   
   // print ctx->gen_stats and ctx->ext_stats
   MoCAOS_Printf(ctx->os_handle, "in_uc_packets          : %u\n", (unsigned int)ctx->gen_stats.in_uc_packets);
   MoCAOS_Printf(ctx->os_handle, "in_discard_packets_ecl : %u\n", (unsigned int)ctx->gen_stats.in_discard_packets_ecl);
   MoCAOS_Printf(ctx->os_handle, "in_discard_packets_mac : %u\n", (unsigned int)ctx->gen_stats.in_discard_packets_mac);
   MoCAOS_Printf(ctx->os_handle, "in_unknown_packets     : %u\n", (unsigned int)ctx->gen_stats.in_unknown_packets);
   MoCAOS_Printf(ctx->os_handle, "in_mc_packets          : %u\n", (unsigned int)ctx->gen_stats.in_mc_packets);
   MoCAOS_Printf(ctx->os_handle, "in_bc_packets          : %u\n", (unsigned int)ctx->gen_stats.in_bc_packets);
   MoCAOS_Printf(ctx->os_handle, "in_octets              : %u\n", (unsigned int)ctx->gen_stats.in_octets);
   MoCAOS_Printf(ctx->os_handle, "out_uc_packets         : %u\n", (unsigned int)ctx->gen_stats.out_uc_packets);
   MoCAOS_Printf(ctx->os_handle, "out_discard_packets    : %u\n", (unsigned int)ctx->gen_stats.out_discard_packets);
   MoCAOS_Printf(ctx->os_handle, "out_bc_packets         : %u\n", (unsigned int)ctx->gen_stats.out_bc_packets);
   MoCAOS_Printf(ctx->os_handle, "out_octets             : %u\n", (unsigned int)ctx->gen_stats.out_octets);
   MoCAOS_Printf(ctx->os_handle, "nc_handoff_counter     : %u\n", (unsigned int)ctx->gen_stats.nc_handoff_counter);
   MoCAOS_Printf(ctx->os_handle, "nc_backup_counter      : %u\n", (unsigned int)ctx->gen_stats.nc_backup_counter);
   
   for (i=0;i<10;i++)
   {
      MoCAOS_Printf(ctx->os_handle, "aggr_pkt_stats_tx[%d]   : %-8u   ", i, (unsigned int)ctx->gen_stats.aggr_pkt_stats_tx[i]);
      MoCAOS_Printf(ctx->os_handle, "aggr_pkt_stats_rx[%d]   : %-8u\n", i, (unsigned int)ctx->gen_stats.aggr_pkt_stats_rx[i]);
   }
   MoCAOS_Printf(ctx->os_handle, "received_data_filtered : %u\n", (unsigned int)ctx->gen_stats.received_data_filtered);

   MoCAOS_Printf(ctx->os_handle, "\n");

   MoCAOS_Printf(ctx->os_handle, "received_map_packets        : %u\n", (unsigned int)ctx->ext_stats.received_map_packets);
   MoCAOS_Printf(ctx->os_handle, "received_rr_packets         : %u\n", (unsigned int)ctx->ext_stats.received_rr_packets);
   MoCAOS_Printf(ctx->os_handle, "received_beacons            : %u\n", (unsigned int)ctx->ext_stats.received_beacons);
   MoCAOS_Printf(ctx->os_handle, "received_control_packets    : %u\n", (unsigned int)ctx->ext_stats.received_control_packets);
   MoCAOS_Printf(ctx->os_handle, "transmitted_beacons         : %u\n", (unsigned int)ctx->ext_stats.transmitted_beacons);
   MoCAOS_Printf(ctx->os_handle, "transmitted_maps            : %u\n", (unsigned int)ctx->ext_stats.transmitted_maps);
   MoCAOS_Printf(ctx->os_handle, "transmitted_lcs             : %u\n", (unsigned int)ctx->ext_stats.transmitted_lcs);
   MoCAOS_Printf(ctx->os_handle, "transmitted_rr_packets      : %u\n", (unsigned int)ctx->ext_stats.transmitted_rr_packets);
   MoCAOS_Printf(ctx->os_handle, "resync_attempts_to_network  : %u\n", (unsigned int)ctx->ext_stats.resync_attempts_to_network);
   MoCAOS_Printf(ctx->os_handle, "gmii_tx_buffer_full_counter : %u\n", (unsigned int)ctx->ext_stats.gmii_tx_buffer_full_counter);
   MoCAOS_Printf(ctx->os_handle, "moca_rx_buffer_full_counter : %u\n", (unsigned int)ctx->ext_stats.moca_rx_buffer_full_counter);
   MoCAOS_Printf(ctx->os_handle, "this_handoff_counter        : %u\n", (unsigned int)ctx->ext_stats.this_handoff_counter);
   MoCAOS_Printf(ctx->os_handle, "this_backup_counter         : %u\n", (unsigned int)ctx->ext_stats.this_backup_counter);

   for(i=0;i<3;i++)
      MoCAOS_Printf(ctx->os_handle, "fc_counter[%d]               : %u\n", i, (unsigned int)ctx->ext_stats.fc_counter[i]);
   
   MoCAOS_Printf(ctx->os_handle, "transmitted_protocol_ie     : %u\n", (unsigned int)ctx->ext_stats.transmitted_protocol_ie);
   MoCAOS_Printf(ctx->os_handle, "received_protocol_ie        : %u\n", (unsigned int)ctx->ext_stats.received_protocol_ie);
   MoCAOS_Printf(ctx->os_handle, "transmitted_time_ie         : %u\n", (unsigned int)ctx->ext_stats.transmitted_time_ie);
   MoCAOS_Printf(ctx->os_handle, "received_time_ie            : %u\n", (unsigned int)ctx->ext_stats.received_time_ie);
   MoCAOS_Printf(ctx->os_handle, "rx_lc_adm_req_crc_error     : %u\n", (unsigned int)ctx->ext_stats.rx_lc_adm_req_crc_error);
}


static void mocad_print_assert(struct mocad_ctx *ctx, uint16_t ie_len, 
   uint32_t * p_assert)
{
   uint32_t max_size;
   uint8_t  *pdata = (uint8_t *)p_assert;
   uint32_t *a2 = (uint32_t *)p_assert;
   uint32_t i;
   int ret;
   uintptr_t start_addr;
   uintptr_t end_addr;
   void *pMem;
   uint32_t *temp_ptr;
   uint32_t *temp_ptr_kernel;
   int dump_dma_descs = 0;
   uint32_t *dest;
   unsigned int stringID = BE32(*(uint32_t *)(a2 + 4));
   unsigned int numParams = BE32(*(uint32_t *)(a2 + 5));            
   char str[MAX_STRING_LENGTH];
   char str1[MAX_STRING_LENGTH] = "Assert string  : ";

   max_size = 8192-sizeof(struct mmp_msg_hdr) - sizeof(struct mmp_ie_hdr);
   mocad_log(ctx, L_ERR, "-----------| MoCA Core Assertion !!! |----------\n");
   mocad_log(ctx, L_ERR, "CPU ID             : %d\n", 1);
   mocad_log(ctx, L_ERR, "Error Code         : %d \n", 
      BE32(*((uint32_t *) pdata)));
   mocad_log(ctx, L_ERR, "MacClock           : 0x%08X\n", 
      BE32(*((uint32_t *) (pdata + 28))));
   mocad_log(ctx, L_ERR, "Assertion Info Len : %d \n", 
      ie_len);
    
   /* Accounting for the assertion Id of 4-bytes */
   pdata += 4 ;
   ie_len -= 4 ;
   max_size -= 4 ;

   if (ie_len < 28 + sizeof(ctx->gen_stats) + sizeof(ctx->ext_stats))
   {
      mocad_log(ctx, L_ERR,"Short assertion (%d bytes).  Not enough data\n", ie_len);
      return;
   }

   if ((*(uint32_t *)(pdata)) == BE32(0x0000DEAD) )
   {
      mocad_log(ctx, L_ERR,"Parameters 1-3: No trap error occurred recently.\n");
   }
   else
   {
      mocad_log(ctx, L_ERR,"Parameters 1-3: Trap error occurred recently � Trap error ID: 0x%08X, occurred at 0x%08X. TS at assert � 0x%08X\n",
         BE32(*(uint32_t *)(pdata)),
         BE32(*(uint32_t *)(pdata+4)),
         BE32(*(uint32_t *)(pdata+8)) );
   }
   
   for (i = 28 ; i < ie_len - sizeof(ctx->gen_stats) - sizeof(ctx->ext_stats) ; ) 
   {
      if (*(uint32_t *)(pdata + i) == BE32(0xDEADBEEF))  /* Delimiter */
         break;

      if (*(uint32_t *)(pdata + i) == BE32(0xDEADFACE))  /* Delimiter */
      {
         dump_dma_descs = 1;
      }
      else
      {
         mocad_log(ctx, L_ERR, "Param %d%s  : 0x%08X\n",
            (i/4) + 1 - dump_dma_descs,
            (((i/4)+ 1 - dump_dma_descs) < 9 ? "   " : ((i/4)+ 1 - dump_dma_descs) < 99 ? "  " : ((i/4)+ 1 - dump_dma_descs) < 999 ? " " : ""),
            BE32(*(uint32_t *)(pdata + i))) ;
      }
      i += 4 ;
      if (i > max_size)
         break ;
   }
   if ((ctx->link_state == LINK_STATE_DOWN) && (ctx->kdrv_info.hw_rev != MOCA_CHIP_20))
      mocad_log(ctx, L_ERR, "PACKET RAM STATE = %d (0-good, 1-bad).\n", checkPacketRam(ctx));
   if ( stringID & 0x80000000 )
   {
      mocad_string_formatting_2(ctx, str, stringID, numParams,(unsigned int*)(a2+8));
   }
   else
   {
      mocad_string_formatting(ctx, str, stringID, numParams, (unsigned int*)(a2+8));
   }
   if (stringID != 0xffffffff)
   {
      strcat(str1,str);
      mocad_log(ctx, L_ERR, str1);
   }

   // print any errors that occurred recently
   if (ctx->error_wrap || ctx->error_index)
   {
      int firstindex = 0;
      int numentries = ctx->error_index;
      int j;
      mocad_log(ctx, L_ERR, "Recent Errors (oldest first):\n");

      if (ctx->error_wrap)
      {
         firstindex = (ctx->error_index+1) % MOCAD_NUM_ERRORS;
         numentries = MOCAD_NUM_ERRORS;
      }

      for(j=0;j<numentries;j++)
      {
         mocad_log(ctx, L_ERR, "%6d\n", ctx->error_list[(j+firstindex) % MOCAD_NUM_ERRORS]);
      }
   }
   
   mocad_log(ctx, L_ERR, "Return Address : 0x%x \n", BE32(*(uint32_t *)(a2 + 6)));
   mocad_log(ctx, L_ERR, 
      "Assertion Info - Core SW     : %d.%d.%d \n",
      (ctx->moca_sw_version >> 28), 
      ((ctx->moca_sw_version >> 24) & 0xf),
      (ctx->moca_sw_version & 0xffffff));
   mocad_log(ctx, L_ERR, 
      "Assertion Info - Drv SW      : %d.%d.%x \n",
      (ctx->kdrv_info.version >> 16),
      (ctx->kdrv_info.version & 0xffff),
      ctx->kdrv_info.build_number) ;
   mocad_log(ctx, L_ERR, "------------------------------------------------------\n");
            
   /* Only print descriptor and RTT data if MoCA Core traces are enabled */
   if (ctx->show_lab_printf)
   {
      if (dump_dma_descs == 1)
      {
         start_addr = BE32(*(uint32_t *)(pdata+ 16)) & 0xFFFFF;
         end_addr = BE32(*(uint32_t *)(pdata + 20)) & 0xFFFFF;

         mocad_log(ctx, L_ERR, 
            "Descriptors start address: 0x%X, Descriptors End address: 0x%X\n", 
            start_addr, end_addr);

         mocad_log(ctx, L_ERR, 
            "Address   Info A Info B    Tot xfr  Ctrl st."
            "Buff ptr Link ptr SW info1 SW info2\n");
         mocad_log(ctx, L_ERR, 
            "                     ----   "
            "SSXfrLen               Buff ptr LenPAAQQ\n");

         /* the memory transfer at the kernel layer might require 
         * 64-bit alignment */
         if (MoCAOS_MemAlign(&pMem, 64, (int)(end_addr - (start_addr & 0xFFFFFFF8))) < 0)
            return;

         ret = MoCAOS_ReadMem(ctx->os_handle, (unsigned char *)pMem, (int)(end_addr - (start_addr & 0xFFFFFFF8)),
            (unsigned char *)(start_addr & 0xFFFFFFF8) );

         if (ret != 0)
         {
            mocad_log(ctx, L_ERR,
               "Unable to read mem from kernel (err %d)\n",ret);
         }
         else
         {
            temp_ptr_kernel = (uint32_t *)((uint8_t *)pMem + (start_addr & 0x7));

            for (temp_ptr = (uint32_t*)start_addr; 
               (uintptr_t)temp_ptr < end_addr; 
               temp_ptr += 8, temp_ptr_kernel += 8)
            {
//                mocad_log(ctx, L_ERR, 
//                   "%08x: %08x %08x %08x %08x %08x %08x %08x %08x\n",
//                   (uint32_t)temp_ptr,  BE32(*(temp_ptr_kernel + 0)),
//                   BE32(*(temp_ptr_kernel + 1)), BE32(*(temp_ptr_kernel + 2)),
//                   BE32(*(temp_ptr_kernel + 3)), BE32(*(temp_ptr_kernel + 4)),
//                   BE32(*(temp_ptr_kernel + 5)), BE32(*(temp_ptr_kernel + 6)),
//                   BE32(*(temp_ptr_kernel + 7)));
            }
         }
         free(pMem);
      }


      /* Print the RTT buffer */
      if ((i < max_size) && (*(uint32_t *)(pdata + i) == BE32(0xDEADBEEF))) {
         i += 4 ; // advance the 0xDEADBEEF
         start_addr = BE32(*(uint32_t *)(pdata + i)) & 0xFFFFF;
         end_addr = start_addr + 
            (BE32(*(uint32_t *)(pdata + i + 4)) * sizeof(uint32_t));
         i += 4 ; // advance the buffer pointer
         mocad_log(ctx, L_ERR, "FOUND RTT DATA at %08x (len %lu)\n", 
            start_addr, BE32(*(uint32_t *)(pdata + i))); 

         mocad_log(ctx, L_ERR, "%08x %08x %08x\n", 
            BE32(*(uint32_t *)(pdata + i)), 
            BE32(*(uint32_t *)(pdata + i + 4)),
            BE32(*(uint32_t *)(pdata + i + 8)));
         i += 12;

         /* the memory transfer at the kernel layer might require 
          * 64-bit alignment */
         if (MoCAOS_MemAlign(&pMem, 64, (int)(end_addr - (start_addr & 0xFFFFFFF8))) < 0)
            return;


         ret = MoCAOS_ReadMem(ctx->os_handle, (unsigned char *)pMem, (int)(end_addr - (start_addr & 0xFFFFFFF8)),
            (unsigned char *)(start_addr & 0xFFFFFFF8) );          

         if (ret != 0)
         {
            mocad_log(ctx, L_ERR,
               "Unable to read mem from kernel (err %d)\n", ret);
         }
         else
         {
            temp_ptr_kernel = (uint32_t *)((uint8_t *)pMem + (start_addr & 0x7));

            for (temp_ptr = (uint32_t*)start_addr; (uintptr_t)temp_ptr < end_addr;  temp_ptr += 16, temp_ptr_kernel += 16)
            {
               mocad_log(ctx, L_ERR, 
                  "%08x %08x %08x %08x %08x %08x %08x %08x %08x %08x %08x %08x %08x %08x %08x %08x\n",
                  BE32(*(temp_ptr_kernel + 0)), BE32(*(temp_ptr_kernel + 1)), 
                  BE32(*(temp_ptr_kernel + 2)), BE32(*(temp_ptr_kernel + 3)), 
                  BE32(*(temp_ptr_kernel + 4)), BE32(*(temp_ptr_kernel + 5)), 
                  BE32(*(temp_ptr_kernel + 6)), BE32(*(temp_ptr_kernel + 7)),
                  BE32(*(temp_ptr_kernel + 8)), BE32(*(temp_ptr_kernel + 9)),
                  BE32(*(temp_ptr_kernel + 10)), BE32(*(temp_ptr_kernel + 11)),
                  BE32(*(temp_ptr_kernel + 12)), BE32(*(temp_ptr_kernel + 13)),
                  BE32(*(temp_ptr_kernel + 14)), BE32(*(temp_ptr_kernel + 15)));
               
               MoCAOS_MSleep(10);
            }
         }
         free(pMem);
      }
   }
   else if ((i < max_size) && (*(uint32_t *)(pdata + i) == BE32(0xDEADBEEF)))
      i+= 5 *sizeof(uint32_t);

   // accumulate stats in the assert with the already collected stats
   dest = (uint32_t *)&ctx->gen_stats;
   temp_ptr = (uint32_t *)(pdata + i);
   for(i = 0; i < (sizeof(struct moca_gen_stats) >> 2); i++, dest++, temp_ptr++) 
   {
      *dest += BE32(*temp_ptr);
   }
   
   dest = (uint32_t *)&ctx->ext_stats;
   for(i = 0; i < (sizeof(struct moca_ext_stats) >> 2); i++, dest++, temp_ptr++) \
   {
      *dest += BE32(*temp_ptr);
   }

   mocad_print_stats(ctx);
}

static void mocad_remove_pqos_flows(struct mocad_ctx *ctx)
{
   int i;
   struct moca_pqos_table * ptable;
   struct moca_pqos_ingr_delete req;
   
   for (i = 0; i < MOCA_MAX_PQOS_ENTRIES; i++)
   {
      ptable = &ctx->pqos_table[i];
      if ((ptable->flow_id_hi != 0) ||
         (ptable->flow_id_lo != 0))
      {
         mocad_log(ctx, L_DEBUG, "%s: deleting pqos flow %08x:%08x\n",
            __FUNCTION__, ptable->flow_id_hi, ptable->flow_id_lo);
         /* delete this entry */
         if (ctx->moca_running)
         {
            req.flowid_hi = ptable->flow_id_hi;
            req.flowid_lo = ptable->flow_id_lo;
            moca_set_pqos_ingr_delete(ctx, &req);
         }
         mocad_del_pqos_entry(ctx, ptable);
      }
   }
}

static void mocad_update_pqos_node(struct mocad_ctx *ctx, 
   uint32_t node_id, uint32_t node_dropped)
{
   int i;
   struct moca_pqos_table * ptable;
   struct moca_pqos_ingr_delete req;

   if (node_dropped)
   {
      for (i = 0; i < MOCA_MAX_PQOS_ENTRIES; i++)
      {
         ptable = &ctx->pqos_table[i];
         if (((ptable->flow_id_hi != 0) ||
              (ptable->flow_id_lo != 0)) &&
             (ptable->egress_node_mask & (1 << node_id)))
         {
            ptable->egress_node_mask &= ~(1 << node_id);

            if (ptable->egress_node_mask == 0)
            {
               mocad_log(ctx, L_DEBUG, 
                  "%s: deleting pqos flow %08x:%08x\n",
                  __FUNCTION__, ptable->flow_id_hi, ptable->flow_id_lo);
               /* delete this entry */
               req.flowid_hi = ptable->flow_id_hi;
               req.flowid_lo = ptable->flow_id_lo;
               moca_set_pqos_ingr_delete(ctx, &req);
               mocad_del_pqos_entry(ctx, ptable);
            }
         }
      }
   }
}

time_t mocad_expire_pqos_flows(struct mocad_ctx *ctx, time_t now)
{
   int i;
   struct moca_pqos_table * ptable;
   struct moca_pqos_ingr_delete req;
   uint32_t low_lease_time = 0xFFFFFFFF;
   
   for (i = 0; i < MOCA_MAX_PQOS_ENTRIES; i++)
   {
      ptable = &ctx->pqos_table[i];
      if (((ptable->flow_id_hi != 0) ||
           (ptable->flow_id_lo != 0)) &&
          (ptable->lease_time != 0))
      {
         if ((time_t)(ptable->lease_time + ptable->create_time) <= now) {
            mocad_log(ctx, L_DEBUG, "%s: expiring pqos flow %08x:%08x\n",
               __FUNCTION__, ptable->flow_id_hi, ptable->flow_id_lo);
            /* delete this entry */
            req.flowid_hi = ptable->flow_id_hi;
            req.flowid_lo = ptable->flow_id_lo;
            moca_set_pqos_ingr_delete(ctx, &req);
            mocad_del_pqos_entry(ctx, ptable);
         }

         if ((ptable->lease_time != 0) &&
             (((ptable->lease_time + ptable->create_time) - now)
                < low_lease_time)) {
            low_lease_time = 
               (ptable->lease_time + ptable->create_time) - (uint32_t)now;
         }
      }
   }

   if (low_lease_time == 0xFFFFFFFF)
      return 0;
   else
      return(low_lease_time);
}

int mocad_get_default_freq(struct mocad_ctx *ctx)
{
   if (ctx->init_time.rf_type == 0) // hi-rf
      return(1150);
   else if (ctx->init_time.rf_type == 1) // hi-rf
      return(575);
   else if (ctx->init_time.rf_type == 2) 
      return(800);
   else if (ctx->init_time.rf_type == 4) // H band
      return(1000);    
   else  // C4
      return(1000);
}

int mocad_freq_in_band(struct mocad_ctx *ctx)
{
   if (ctx->init_time.lof == 0)
      return 1;
   
   if (ctx->init_time.rf_type == 0) //  MoCA_RF_TYPE_D_BAND, HI-RF
   {
      switch ( ctx->init_time.lof ) {
         /* LAN */
         case 1150 :
         case 1200 :
         case 1250 :
         case 1300 :
         case 1350 :
         case 1400 :
         case 1450 :
         case 1500 :
           return 1 ;
      
         default :
           return 0 ;
      }
   }
   else if (ctx->init_time.rf_type == 1) // mid rf, E-Band low subband
   {
      switch ( ctx->init_time.lof ) {
         /* MidRF */
         case 500 :
         case 525 :
         case 550 :
         case 575 :
         case 600 :
           return 1 ;
         default :
           return 0 ;
      }
   }
   else if (ctx->init_time.rf_type == 2) // mid rf, F-Band hi subband
   {
      switch ( ctx->init_time.lof ) {
         case 675:
         case 700:
         case 725:
         case 750:
         case 775:
         case 800:
         case 825:
         case 850:
            return 1 ;
         default : 
            return 0;
      }
   }
   else if (ctx->init_time.rf_type == 4) // H-Band 
   {
      switch ( ctx->init_time.lof ) {
         case 975:
         case 1000:
         case 1025:
            return 1 ;
         default : 
            return 0;
      }
   }    
   else // WAN C4-band
   {
      switch ( ctx->init_time.lof ) {
         /* WAN */
         case 1000 :
            return 1 ;
         default : 
            return 0;
      }
   }
}

void mocad_log_error(struct mocad_ctx *ctx, int32_t error)
{
   ctx->error_list[ctx->error_index++] = error;

   if (ctx->error_index >= MOCAD_NUM_ERRORS)
   {
      ctx->error_index = 0;
      ctx->error_wrap = 1;
   }
}

unsigned get_svn_version(const char* string)
{
   const char* str = string; 
   unsigned int res=0;

   while(*str && ( *str < '0' || *str > '9' ))
      str++;

   while(*str && ( *str >= '0' && *str <= '9' ))
   {
      res=10*res + ( *str-'0' );
      str++;
   }
   return (res);
}


int mocad_handle_trap(struct mocad_ctx *ctx, int trap_len)
{
   struct mmp_msg_hdr *mh;
   struct mmp_ie_hdr *ih;
   void *data;
   uint32_t res;
   uint16_t ie_type, ie_len;
   int i;
   int ret;
   struct moca_max_constellation mc;
   struct moca_gen_status gs;
   uint16_t num_ies;
   int delete_ie = 0, lone_ie = 0;
#ifdef DSL_MOCA
   unsigned char c;
#endif

   mh = (struct mmp_msg_hdr *)ctx->trap_buf;
   ih = (struct mmp_ie_hdr *)(mh + 1);
   data = (void *)(ih + 1);

   if(BE16(mh->num_ies) != 1)
   {
      mocad_log(ctx, L_TRAP, "Trap: num_ies = %d\n", BE16(mh->num_ies));
   }
   else
   {
      lone_ie = 1;
   }

   num_ies = BE16(mh->num_ies);

   while (num_ies > 0)
   {
      ie_type = BE16(ih->ie_type);
      ie_len = BE16(ih->ie_len);

      mocad_log(ctx, L_TRAP, "Got trap %04x (%s)\n", ie_type,
         moca_ie_name(ie_type));

      if(ctx->verbose & L_TRAP)
         mocad_dump_buf(ctx, "TRAP:", (unsigned char *)data, ie_len);

      switch(ie_type) {
         case IE_ADMISSION_STATUS:
         {
            time_t now;
            time_t then;
            char timestr[80];
            uint32_t *a = (uint32_t *)data;

            if ((BE32(*a) != 0) && (ctx->show_lab_printf))
            {
               now = time(NULL);

               if (ctx->core_uptime > ctx->link_downtime)
                  then = ctx->core_uptime;
               else
                  then = ctx->link_downtime;
               
               sprintf(timestr, "Network search completed after %ds\n", (int)(now - then));
               mocad_lab_printf(ctx, timestr);
            }
            break;
         }
         case IE_TOPOLOGY_CHANGED: {
            uint32_t *a = (uint32_t *)data;

            for (i = 0; i < MOCA_MAX_NODES; i++)
            {
               if ((ctx->active_nodes & (1 << i)) !=
                  (BE32(*a) & (1 << i)))
               {
                  mocad_log(ctx, L_DEBUG,
                     "Topology changed node=%d  add/del=%d\n",
                     i,((BE32(*a) >> i) & 0x1));

                  memset(&ctx->node_stats[i], 0, sizeof(ctx->node_stats[i]));
                  mocad_update_pqos_node(ctx, i, !((BE32(*a) >> i) & 0x1));
               }
            }
            ctx->active_nodes = BE32(*a);

            break;
         }
         case IE_KEY_CHANGED: {
            uint32_t *a = (uint32_t *)data;
            if (BE32(*a) == 0) // TEK
            {
               ctx->tekEvenOdd = BE32(*(a+1));
               if (ctx->tekTime != 0)
                  ctx->tekLastInterval = time(NULL) - ctx->tekTime;
               ctx->tekTime = time(NULL);
            }
            else  // PMK
            {
               ctx->pmkEvenOdd = BE32(*(a+1));
               if (ctx->pmkTime != 0)             
                  ctx->pmkLastInterval = time(NULL) - ctx->pmkTime;
               ctx->pmkTime = time(NULL);
            }
            break;
         }
         case IE_MOCA_CORE_READY: {
            uint32_t *a = (uint32_t *)data;
            uint8_t macAddr[6];

            if (BE32(*a) == 0)
            {
               mocad_log(ctx, L_WARN,
                              "Core is NOT ready\n");
               break;
            }

#ifdef DSL_MOCA 
            if ((BE32(*a) & 0xFF000000) != 0x02000000)   // bits 0-3 are the chip id firmware is expecting
#else
            if ( ( ((BE32(*a) & 0xFF000000) != 0x04000000) && 
                   ((ctx->kdrv_info.hw_rev == MOCA_CHIP_11) || (ctx->kdrv_info.hw_rev == MOCA_CHIP_11_LITE))) ||
                 ( ((BE32(*a) & 0xFF000000) != 0x08000000) && (ctx->kdrv_info.hw_rev == MOCA_CHIP_11_PLUS) ))
#endif
            {
               mocad_log(ctx, L_WARN,
                  "WARNING: MoCA firmware not appropriate for chip.  Firmware compiled for %s (0x%08x).\n", 
                  (BE32(*a) & 0xFF000000)==0x02000000?"6816":
                  (BE32(*a) & 0xFF000000)==0x04000000?"7xxx-gen1":
                  (BE32(*a) & 0xFF000000)==0x08000000?"7xxx-gen2":"UNKNOWN chip", BE32(*a));
            }

         // Check the mocad_strings.h consistency
            if ((BE32(*(a+1)) != get_svn_version(MOCAD_STRINGS_VER_STRING)) && (ctx->kdrv_info.hw_rev != MOCA_CHIP_20))
            {
               mocad_log(ctx, L_WARN,
                 "WARNING: mocad_strings.h file does not match. Version in Host: %d, Version in MoCA core: %d\n",
                 get_svn_version(MOCAD_STRINGS_VER_STRING), BE32(*(a+1)));
            }

            mocad_log(ctx, L_DEBUG,
               "Core is ready, sending INIT_TIME args\n");

            if (ctx->init_time.lof == 1)
            {
               ctx->init_time.lof = ctx->disk_lof;
            }
            else
            {
               mocad_write_lof(ctx, ctx->init_time.lof);
            }

            if ((ctx->init_time.continuous_power_tx_mode != 0) && (ctx->init_time.lof == 0))
            {
               ctx->init_time.lof = mocad_get_default_freq(ctx);
            }
            
#if defined(DSL_MOCA)
            if ( ctx->any_time.sapm_en == 1 ) 
            {
               mocad_log(ctx, L_WARN, "WARNING: Enabling SAPM is not supported on 6816 chip.\n");
               ctx->any_time.sapm_en = 0;
            }
#endif
            if ((ctx->init_time.continuous_power_tx_mode == 0) && !mocad_freq_in_band(ctx))
            {
               mocad_log(ctx, L_WARN, "WARNING: LOF is out of RF band.  Resetting to NULL.\n");
               ctx->init_time.lof = 0;
            }

            if ((ctx->init_time.lof == 0) &&
                ((ctx->init_time.auto_network_search_en == 0) ||
                 (ctx->init_time.rf_type == 3)))
            {
               ctx->init_time.lof = mocad_get_default_freq(ctx);

               if ((ctx->init_time.rf_type == 2) ||
                  (ctx->init_time.rf_type == 4)) {  // mid-hi rf || hband 
                  ctx->init_time.tpc_en = 1;
               }
            }

            if ((ctx->init_time.rf_type == 0) || (ctx->init_time.rf_type == 3))
            {
               if (ctx->init_time.beacon_channel != 0)
               {
                  mocad_log(ctx, L_WARN, "WARNING: rf_type = HIRF, forcing beacon_channel to 0\n"); 
                  ctx->init_time.beacon_channel = 0;
               }
            }
            else
            {
               unsigned int defaultChannel;

               defaultChannel = mocad_get_default_freq(ctx);
               
               if (ctx->init_time.beacon_channel == 0)
                  ctx->init_time.beacon_channel = defaultChannel;

               if (ctx->init_time.terminal_intermediate_device == 0) // INTERMEDIATE device
               {
                  if (ctx->init_time.beacon_channel != defaultChannel)
                  {
                     mocad_log(ctx, L_WARN, "WARNING: beacon channel cannot be set when device type=INTERMEDIATE. Using %dMHz\n", defaultChannel);
                     ctx->init_time.beacon_channel = defaultChannel;
                  }
               }
            }

            /* Force single channel operation for WAN channel */
            if ((ctx->init_time.lof == 1000) && (ctx->init_time.rf_type == MoCA_RF_TYPE_C4_BAND))
            {
               ctx->init_time.auto_network_search_en = 2;
            }

            mocad_handle_const_tx_mode(ctx);

            res = moca_set_init_time(ctx, &ctx->init_time);
            if(res != 0)
               mocad_log(ctx, L_WARN,
                  "warning: INIT_TIME reply %x\n", res);

            /* set any_time parameters */
            mocad_log(ctx, L_DEBUG,
               "Sending ANY_TIME args\n");

            mocad_set_all_anytime(ctx);

            // special case for rx_power_tuning because of diplexer parameter
            moca_set_rx_power_tuning(ctx, ctx->any_time.rx_power_tuning+ctx->any_time.diplexer);

            // send EGR_MC_FILTER table
            for (i=0; i< MOCA_MAX_EGR_MC_FILTERS;i++)
            {
               struct moca_egr_mc_addr_filter filter;
               if (ctx->any_time.egr_mc_addr_filter[i].valid)
               {
                  filter.addr_hi = ctx->any_time.egr_mc_addr_filter[i].addr_hi;
                  filter.addr_lo = ctx->any_time.egr_mc_addr_filter[i].addr_lo;
                  filter.valid = ctx->any_time.egr_mc_addr_filter[i].valid;
                  filter.entryid = i;
                  moca_set_egr_mc_addr_filter(ctx, &filter);;
               }
            }
               
            for (i = 0; i < MOCA_MAX_NODES; i++ ) {
               mc.node_id = i;
               mc.bits_per_carrier = ctx->any_time.max_constellation[i];
               res = moca_set_max_constellation(ctx, &mc);
               if(res != 0)
                  mocad_log(ctx, L_WARN,
                     "warning: %s[%i] reply %x\n", 
                     moca_ie_name(IE_MAX_CONSTELLATION), i, res);
            }
            
            if (MoCAOS_GetDriverInfo(ctx->os_handle, &ctx->kdrv_info) != 0)
            {
               die("can't read MoCA driver info\n");
               MoCAOS_MSleep(4000);
               ctx->restart = 2;
               return(0);
            }

            /* for watchdog purposes, always enable core traces at start */
            mocad_set_moca_core_trace_enable(ctx, 1);
#if defined(DSL_MOCA)
            res = __moca_set_start_moca_core(ctx, ctx->kdrv_info.phy_freq);
#else
            res = __moca_set_start_moca_core(ctx, 225);
#endif

            /* Clear the wait flag if we've been given an order to start */
            if (ctx->init_time_options.dont_start_moca == 2)
               ctx->init_time_options.dont_start_moca = 0;
            
            if(ctx->link_state == LINK_STATE_DEBUG) {
               mocad_update_times(ctx, MOCA_TIME_EVENT_CORE_UP);
               ctx->moca_running = 1;
               /* Check for special Const Tx Mode options */
               return(0);
            }

            if(res != 0)
               mocad_log(ctx, L_WARN,
                  "warning: START_MOCA_CORE reply %x\n",
                  res);
            else {
               mocad_update_times(ctx, MOCA_TIME_EVENT_CORE_UP);
               ctx->moca_running = 1;

               /* Retrieve the driver info again because the core doesn't
                * set gp1 until the start command is issued */
               if (MoCAOS_GetDriverInfo(ctx->os_handle, &ctx->kdrv_info) != 0)
               {                    
                  die("can't read MoCA driver info\n");
                  MoCAOS_MSleep(4000);
                  ctx->restart = 3;
                  return(0);
               }
                       
            }
            
            mocad_log(ctx, L_DEBUG, "GP1 is %08x\n",
               ctx->kdrv_info.gp1);

            moca_u32_to_mac(macAddr, ctx->kdrv_info.macaddr_hi, ctx->kdrv_info.macaddr_lo);

            mocad_log(ctx, L_INFO, 
               "THIS Node MAC address: %02x:%02x:%02x:%02x:%02x:%02x\n",
               macAddr[0], macAddr[1], macAddr[2],
               macAddr[3], macAddr[4], macAddr[5]);
            mocad_log(ctx, L_INFO, "Last Operational Frequency = %u Mhz\n",
               ctx->init_time.lof);

            moca_get_gen_status(ctx, &gs);
            mocad_log(ctx, L_INFO, "MoCA Startup Successful.\n");
            mocad_log(ctx, L_INFO, "MoCA Version\n");
            mocad_log(ctx, L_INFO, "-----------------------\n");
            mocad_log(ctx, L_INFO, "MoCA coreHWVersion   : 0x%x\n", 
               /* gs.moca_hw_version */
               ctx->kdrv_info.chip_id);
            mocad_log(ctx, L_INFO, "MoCA coreSWVersion   : %u.%u.%u\n",
               (gs.moca_sw_version >> 28), 
               ((gs.moca_sw_version >> 24) & 0xf),
               (gs.moca_sw_version & 0xffffff));
            ctx->moca_sw_version = gs.moca_sw_version;
            mocad_log(ctx, L_INFO, "MoCA self version    : 0x%x\n",
               gs.self_moca_version);
            mocad_log(ctx, L_INFO, "MoCA driver version  : %u.%u.%x\n",
               (ctx->kdrv_info.version >> 16),
               (ctx->kdrv_info.version & 0xffff),
               ctx->kdrv_info.build_number);
            mocad_log(ctx, L_INFO, "-----------------------\n");
            return(0);
         }
        
         case IE_LAB_PRINTF_CODES:
         {
            unsigned int stringID = ((unsigned int*)data)[0];
            unsigned int numParams = ((unsigned int*)data)[1]; 
            unsigned int bPrintStr = ((unsigned int*)data)[2];
            char str[MAX_STRING_LENGTH];
            
            ctx->lab_printf_wdog_count++;

            if(!ctx->show_lab_printf) {
               mocad_set_moca_core_trace_enable(ctx,0);
            } 

            if (bPrintStr || ctx->show_lab_printf) {
               if ((BE32(stringID)) & 0x80000000 )
               {
                  mocad_string_formatting_2(ctx, str, BE32(stringID), BE32(numParams), 
                     &(((unsigned int*)data)[3]));
               }
               else
               {
                  mocad_string_formatting(ctx, str, BE32(stringID), BE32(numParams), 
                     &(((unsigned int*)data)[3]));
               }
               mocad_lab_printf(ctx, str);
            }
            
            if (lone_ie)
               return(0);
            else
               delete_ie = 1;
            break;
         }

         case IE_DRV_PRINTF:
            mocad_lab_printf(ctx, (char *)data);
            if (lone_ie)
               return(0);
            else
               delete_ie = 1;

            break;
          
         case IE_ASSERT: {
            uint32_t *a = (uint32_t *)data;
#ifdef DSL_MOCA
            bcm_reg_read(0x0000005d, (char *)&c, 1);

            mocad_log(ctx, L_ERR, "GENET if state reg=%X\n", c);
            system("/bin/ethswctl -c pagedump -P 0");
            system("dw 0xb0da1420");
            system("fh 0xb0e00a00 5 1");
            system("dh 0xb0e00a90 16");                
#endif
            MoCAOS_MSleep(1000);

            mocad_print_assert(ctx, ie_len, a);
            
            mocad_update_times(ctx, MOCA_TIME_EVENT_CORE_DOWN);
            ctx->moca_running = 0;
            ctx->restart = 4;
            return(0);
         }
         case IE_ERROR: {
            uint32_t *val = (uint32_t *)data;
            int32_t error = BE32(*val);

            mocad_log_error(ctx, error);

            /* Special case for errors to be masked. */
            if ((error == ctx->error_to_mask.error1) ||
               (error == ctx->error_to_mask.error2) ||
               (error == ctx->error_to_mask.error3))
            {
               /* Do nothing. The user has requested that this error
                  not be printed. */
               mocad_log(ctx, L_DEBUG, "Skipping error %u\n", error);
            }
            else if (error >= MMP_ASSERTION_ERROR) {
               mocad_log(ctx, L_ERR, 
                  "MoCA_Msg: %d. Continuing... \n",
                  error) ;
            }
            else if ((error >= MMP_MOCA_CORE_ERROR_START) &&
                   (error <= MMP_MOCA_CORE_ERROR_END)) {
               if ((error == MMP_MOCA_DUPLICATE_ADDRESS_ERROR_NN) ||
                  (error == MMP_MOCA_DUPLICATE_ADDRESS_ERROR_EN) ||
                  (error == MMP_MOCA_DUPLICATE_ADDRESS_ERROR_NC))                
                  mocad_log(ctx, L_ERR, "Error: Duplicate MAC address on MoCA network (%d)\n", error) ;
               else if ((ctx->error_to_mask.error1 != -1) || ctx->show_lab_printf)
                  mocad_log(ctx, L_ERR, "MoCA_Msg: %d \n",
                     error) ;

               /* If a TRAPQFULL message was received, there's a chance that
                * we've missed a LINK UP/DOWN trap. Check the status to update
                * the link up/down times and LOF if necessary. */
               if ((ctx->link_state != LINK_STATE_DEBUG) &&
                  (error == MMP_TRAP_QUEUE_FULL_ERROR))
               {
                  res = moca_get_gen_status(ctx, &gs);
                  if (res == 0)
                  {
                     if (gs.link_status != (uint32_t) ctx->link_state)
                     {
                        mocad_log(ctx, L_WARN, 
                           "Traps overflow, link status changed\n");
                        mocad_update_link_state(ctx, gs.link_status);
                     }
                     if ((gs.link_status == 1) &&
                        ((gs.rf_channel*25) != (uint32_t) ctx->disk_lof))
                     {
                        mocad_log(ctx, L_WARN, 
                           "Traps overflow, operating frequency changed\n");
                        mocad_write_lof(ctx, (gs.rf_channel*25));
                     }
                  }
               }
            }
            else {
               mocad_log(ctx, L_ERR, "MoCA_Msg: %s \n",
                  ((error == MMP_PRINT_QUEUE_FULL_ERROR) ? "PRINTQFULL" :
                  ((error == MMP_PRINT_BUFFER_FULL_ERROR) ? "PRINTBUFFULL" :
                  ((error == MMP_TRAP_QUEUE_FULL_ERROR) ? "TRAPQFULL" :
                  "UNKNOWNERROR")))) ;
            }
            if (lone_ie)
               return(0);
            else
               delete_ie = 1;

            break;
         }
         case IE_MIPS_EXCEPTION: {
            struct moca_mips_exception *e = (struct moca_mips_exception *)data;

            mocad_log(ctx, L_ERR, "Assertion from MoCA Core \n");
            mocad_log(ctx, L_ERR, 
               "Assertion ID (in decimals)  : %d \n", 
               BE32(e->err_code));
            mocad_log(ctx, L_ERR, 
               "\t RESERVED    (in hex)  : 0x%x \n", 
               BE32(e->zero));
            mocad_log(ctx, L_ERR, 
               "\t CP0_EPC     (in hex)  : 0x%x \n", 
               BE32(e->cp0_epc));
            mocad_log(ctx, L_ERR, 
               "\t CP0_CAUSE   (in hex)  : 0x%x \n", 
               BE32(e->cp0_cause));
            mocad_log(ctx, L_ERR, 
               "\t CP0_STATUS  (in hex)  : 0x%x \n", 
               BE32(e->cp0_status));
            mocad_log(ctx, L_ERR, 
               "\t CP0_ERROREPC (in hex)  : 0x%x \n", 
               BE32(e->cp0_errorepc));
            mocad_log(ctx, L_ERR, 
               "Assertion Info - Core SW     : %d.%d.%d \n",
               (ctx->moca_sw_version >> 28), 
               ((ctx->moca_sw_version >> 24) & 0xf),
               (ctx->moca_sw_version & 0xffffff));
            mocad_log(ctx, L_ERR, 
               "Assertion Info - Drv SW      : %d.%d.%x \n",
               (ctx->kdrv_info.version >> 16),
               (ctx->kdrv_info.version & 0xffff),
               ctx->kdrv_info.build_number) ;
            mocad_update_times(ctx, MOCA_TIME_EVENT_CORE_DOWN);
            ctx->moca_running = 0;
            ctx->restart = 5;
            if ((ctx->link_state == LINK_STATE_DOWN) && (ctx->kdrv_info.hw_rev != MOCA_CHIP_20))
               mocad_log(ctx, L_ERR, "PACKET RAM STATE = %d (0-good, 1-bad).\n", checkPacketRam(ctx));

#ifdef DSL_MOCA
            bcm_reg_read(0x0000005d, (char *)&c, 1);
            mocad_log(ctx, L_ERR, "GENET if state reg=%X\n", c);
            system("/bin/ethswctl -c pagedump -P 0");
            system("dw 0xb0da1420");
            system("fh 0xb0e00a00 5 1");
            system("dh 0xb0e00a90 16");
#endif
            return(0);
         }
         case IE_WDT:
            mocad_log(ctx, L_ERR, "MoCA WDT timeout\n");
            mocad_update_times(ctx, MOCA_TIME_EVENT_CORE_DOWN);
            ctx->moca_running = 0;
            ctx->restart = 6;
            return(0);
         case IE_LOF: {
            uint32_t *lof = (uint32_t *)data;
            mocad_write_lof(ctx, BE32(*lof));

            /* NOTE: LOF is also broadcast to the clients */
            break;
         }
         case IE_LINK_UP_STATE: {
            uint32_t *st = (uint32_t *)data;

            mocad_update_link_state(ctx, BE32(*st) ? 1 : 0);
            /* NOTE: link state is broadcast to the clients */
            break;
         }
         case IE_LMO_INFO: {
            uint32_t *node = (uint32_t *)data;
            struct moca_lmo_info *lmo = (struct moca_lmo_info *)data;
            struct moca_gen_node_status gns;
            struct moca_rx_uc_profile uc;
            struct moca_rx_bc_profile bc;
            struct moca_rx_map_profile map;
            unsigned char lnMacAddr[6];
            unsigned char ncMacAddr[6];
            unsigned char macAddr[6];

            moca_get_gen_status(ctx, &gs);
            mocad_accum_node_stats_ext(ctx, gs.connected_nodes);

            /* retrieve the CIR data from memory */
            if((ctx->kdrv_info.gp1 != 0) && ( BE32(*node) < MOCA_MAX_NODES))
            {
               ret = MoCAOS_ReadMem(ctx->os_handle, (unsigned char *)ctx->cir_data[ BE32(*node) ], 
                     CIR_DATA_SIZE,
                     (unsigned char *)((uintptr_t)ctx->kdrv_info.gp1 & 0x1fffffff) + CIR_DATA_OFFSET);
               
               if (ret != 0)
               {
                  mocad_log(ctx, L_ERR, "Failure to read CIR data for node %lu (%d)\n",
                     BE32(*node), ret);
               } 
            }

            if ((ctx->show_lab_printf) && (BE32(lmo->is_lmo_success)))
            {
               __moca_copy_be32(data, data, sizeof(struct moca_lmo_info));
                    
               moca_get_gen_node_status(ctx, lmo->lmo_node_id, &gns);
               moca_u32_to_mac(lnMacAddr, gns.eui_hi, gns.eui_lo);

               moca_get_gen_node_status(ctx, lmo->nc_node_id, &gns);
               moca_u32_to_mac(ncMacAddr, gns.eui_hi, gns.eui_lo);

               mocad_accum_stats(ctx, IE_GEN_STATS,
                     ctx->sock_out, &ctx->gen_stats,
                     sizeof(ctx->gen_stats), 4);

               if (lmo->lmo_node_id != gs.node_id)
               {
                  moca_get_rx_bc_profile(ctx, lmo->lmo_node_id, &bc);
                  moca_get_rx_uc_profile(ctx, lmo->lmo_node_id, &uc);
                  moca_get_rx_map_profile(ctx, lmo->lmo_node_id, &map);
               }
               
               if (ctx->in_lab_printf)
               {
                  MoCAOS_Printf(ctx->os_handle, "\n");
                  ctx->in_lab_printf = 0;
               }
               
               MoCAOS_Printf(ctx->os_handle, "%s+===========================================================================\n", ctx->core_print_prefix);               
               
            MoCAOS_Printf(ctx->os_handle, "%s@ LMO : LNId=%x, MyID=%x, NcID=%x, BkNc(prev)=%x, LMO_Cnt=%u, Duration=%u\n",
               ctx->core_print_prefix, (unsigned int)lmo->lmo_node_id, (unsigned int)gs.node_id, (unsigned int)lmo->nc_node_id, 
               (unsigned int)lmo->backup_nc_id, (unsigned int)lmo->lmo_counter, (unsigned int)lmo->lmo_duration_sec);

            MoCAOS_Printf(ctx->os_handle, "%s@ INF1: LOF=%u, ANB=%x, SW_Ver=%u.%u.%u, NT_Ver=%2x, NC_Md=%u, Privacy=%u\n",
               ctx->core_print_prefix, (unsigned int)ctx->init_time.lof, (unsigned int)(gs.connected_nodes | (1<<gs.node_id)),  
               (unsigned int)gs.moca_sw_version >> 28, (unsigned int)((gs.moca_sw_version >> 24) & 0xf),
               (unsigned int)gs.moca_sw_version & 0xffffff, (unsigned int)gs.network_moca_version, 
               (unsigned int)ctx->init_time.nc_mode, (unsigned int)ctx->init_time.privacy_en);

            MoCAOS_Printf(ctx->os_handle, "%s@ INF2: MAC_CLK=%08x, TurboMode=%x, CPU=%u, CPU_OVLD=%u\n",
               ctx->core_print_prefix, (unsigned int)lmo->mac_clock, (unsigned int)lmo->turbo_mode, (unsigned int)lmo->cpu_usage, (unsigned int)lmo->cpu_overload);

               MoCAOS_Printf(ctx->os_handle, "%s@ MAC : ",ctx->core_print_prefix);

               MoCAOS_Printf(ctx->os_handle, "LN=%02X:%02X:%02X:%02X:%02X:%02X, ", 
                  lnMacAddr[0], lnMacAddr[1], lnMacAddr[2], lnMacAddr[3], lnMacAddr[4], lnMacAddr[5]);
               
               moca_u32_to_mac(macAddr, ctx->kdrv_info.macaddr_hi, ctx->kdrv_info.macaddr_lo);

               MoCAOS_Printf(ctx->os_handle, "Self=%02X:%02X:%02X:%02X:%02X:%02X, ", 
                  macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5]);

               MoCAOS_Printf(ctx->os_handle, "NC=%02X:%02X:%02X:%02X:%02X:%02X\n", 
                  ncMacAddr[0], ncMacAddr[1], ncMacAddr[2], ncMacAddr[3], ncMacAddr[4], ncMacAddr[5]);

               if (lmo->lmo_node_id != gs.node_id)
               {
               MoCAOS_Printf(ctx->os_handle, "%s@ Rx  : nBas=%04u, cp=%02u, PR=%03ld, BO=%02u, HT=%u, AGC=%02u, RS=%06u, RxCnt=%u\n",
                  ctx->core_print_prefix, (unsigned int)lmo->rx_uc_nbas, (unsigned int)lmo->rx_uc_payload_cp, 
                  moca_phy_rate(lmo->rx_uc_nbas, lmo->rx_uc_payload_cp, lmo->rx_uc_turbo)/1000000,
                  (unsigned int)lmo->rx_uc_backoff, (unsigned int)lmo->rx_uc_en_high_throughput,
                  (unsigned int)lmo->rx_uc_agc_init_gain_adr, (unsigned int)lmo->rx_uc_hw_rssi, (unsigned int)ctx->rx_pkts );

                  MoCAOS_Printf(ctx->os_handle, "%s@ Rx2 : RxUcPwr=%.2lf, RxBcPwr=%.2lf, RxMapPwr=%.2lf\n",
                     ctx->core_print_prefix, (*(int*)&uc.rx_gain)/4.0, 
                     (*(int*)&bc.rx_gain)/4.0, (*(int*)&map.rx_gain)/4.0);

               MoCAOS_Printf(ctx->os_handle, "%s@ Tx  : nBas=%04u, cp=%02u, PR=%03ld, BO=%02u, HT=%u,                    TxCnt=%u\n",
                  ctx->core_print_prefix, (unsigned int)lmo->tx_uc_nbas, (unsigned int)lmo->tx_uc_payload_cp, 
                  moca_phy_rate(lmo->tx_uc_nbas, lmo->tx_uc_payload_cp, lmo->tx_uc_turbo)/1000000,
                  (unsigned int)lmo->tx_uc_backoff, (unsigned int)lmo->tx_uc_en_high_throughput, (unsigned int)ctx->tx_pkts);

               MoCAOS_Printf(ctx->os_handle, "%s@ Bc  : nBas=%04u, cp=%02u, PR=%03ld, BO=%02u, AGC=%02u, PREV_AGC=%02u, RS=%06u\n",
                  ctx->core_print_prefix, (unsigned int)lmo->bc_nbas, (unsigned int)lmo->bc_payload_cp,
                  moca_phy_rate(lmo->bc_nbas, lmo->bc_payload_cp, 0)/1000000,
                  (unsigned int)lmo->bc_backoff, (unsigned int)lmo->rx_bc_hw_agc_addr, (unsigned int)lmo->rx_bc_agc_init_gain_adr, (unsigned int)lmo->rx_bc_gw_rssi);
               }
               else
               {
               MoCAOS_Printf(ctx->os_handle, "%s@ Bc  : nBas=%04u, cp=%02u, PR=%03ld, BO=%02u, BcTxCnt=%u\n",
                  ctx->core_print_prefix, (unsigned int)lmo->bc_nbas, (unsigned int)lmo->bc_payload_cp,
                  moca_phy_rate(lmo->bc_nbas, lmo->bc_payload_cp, 0)/1000000,
                  (unsigned int)lmo->bc_backoff, (unsigned int)ctx->bc_pkts);
               }
               
               if (lmo->lmo_node_id != gs.node_id)
               {

               MoCAOS_Printf(ctx->os_handle, "%s@ CCOF: HT=%u, UC=%u, BC=%u, MAP=%u, MAP_P1=%u\n",
                     ctx->core_print_prefix,
                  (unsigned int)lmo->rx_uc_cc_delay_offset,
                  (unsigned int)lmo->rx_uc_ac_delay_offset, (unsigned int)lmo->rx_bc_rx_ac_delay_offset, 
                  (unsigned int)lmo->map_rx_ac_delay_offset, (unsigned int)lmo->map_rx_cc_delay_offset);

#define CONVERT_HW_FREQ_50_CFO_HZ(freq) ((int)((((long long)((int)freq))*148/10000)))
#define CONVERT_HW_FREQ_100_CFO_HZ(freq) ((int)((((long long)((int)freq))*296/10000)))
#define CONVERT_CFO_2_SFO(CFO,lof) ((lof)==0?0:((int)((((long long)((long long)-CFO))*5000/(618 *(lof)))))) 

                  if (lmo->turbo_mode)
                     MoCAOS_Printf(ctx->os_handle, "%s@ CSFO: C_SFO_50=%06d, CFO_50=%06d, C_SFO_100=%06d, CFO_100=%06d\n",
                        ctx->core_print_prefix,
                     (4* CONVERT_CFO_2_SFO(CONVERT_HW_FREQ_50_CFO_HZ(lmo->freq_offset),(ctx->init_time.lof))),
                     CONVERT_HW_FREQ_50_CFO_HZ(lmo->freq_offset),
                     (4* CONVERT_CFO_2_SFO(CONVERT_HW_FREQ_50_CFO_HZ(lmo->freq_offset),(ctx->init_time.lof))),
                     (4* CONVERT_CFO_2_SFO(CONVERT_HW_FREQ_100_CFO_HZ(lmo->freq_offset),(ctx->init_time.lof))) );
                  else                    
                     MoCAOS_Printf(ctx->os_handle, "%s@ CSFO: C_SFO_50=%06d, CFO_50=%06d\n",
                        ctx->core_print_prefix,
                     (4* CONVERT_CFO_2_SFO(CONVERT_HW_FREQ_50_CFO_HZ(lmo->freq_offset),(ctx->init_time.lof))),
                     CONVERT_HW_FREQ_50_CFO_HZ(lmo->freq_offset) );
               }
               MoCAOS_Printf(ctx->os_handle, "%s-===========================================================================\n",ctx->core_print_prefix);

               // undo the byte swap so things are back to what lmo callback expect
               __moca_copy_be32(data, data, sizeof(struct moca_lmo_info));
            }
            break;
         }
         case IE_CPU_CHECK: {

            if (ctx->cpu_check_sec == 0)
            {          
               MoCAOS_GetTimeOfDay(&ctx->cpu_check_sec, NULL);
            }
            else
            {
               unsigned int timeSec;
               
               timeSec  = ctx->cpu_check_sec;
               MoCAOS_GetTimeOfDay(&ctx->cpu_check_sec, NULL);

               if ((abs((ctx->cpu_check_sec - timeSec) - CPU_CHECK_INTERVAL)) > CPU_CHECK_MARGIN_ERR )
               
               {
                     
                  mocad_log(ctx, L_WARN, "warning: CPU_CHECK time difference of %d sec\n", (ctx->cpu_check_sec - timeSec));
               }
            }
            break;
         }
         case IE_PQOS_CREATE_RESPONSE: {
            /* Transaction initiated by this node */
            struct moca_pqos_create_response * pqosc_rsp = (struct moca_pqos_create_response *)data;
            mocad_handle_pqos_create_rsp(ctx, pqosc_rsp);
            break;
         }
         case IE_PQOS_CREATE_COMPLETE: {
            /* Transaction initiated by other node */
            struct moca_pqos_create_complete * pqosc_cmp = (struct moca_pqos_create_complete *) data;
            mocad_handle_pqos_create_cmp(ctx, pqosc_cmp);
            break;
         }
         case IE_PQOS_UPDATE_RESPONSE: {
            struct moca_pqos_update_response * pqosu_rsp = (struct moca_pqos_update_response *)data;
            mocad_handle_pqos_update_rsp(ctx, pqosu_rsp);
            break;
         }
         case IE_PQOS_UPDATE_COMPLETE: {
            struct moca_pqos_update_complete * pqosu_cmp = (struct moca_pqos_update_complete *)data;
            mocad_handle_pqos_update_cmp(ctx, pqosu_cmp);
            break;
         }
         case IE_PQOS_DELETE_RESPONSE: {
            /* Transaction initiated by this node */
            struct moca_pqos_delete_response * pqosd_rsp = (struct moca_pqos_delete_response *)data;
            mocad_handle_pqos_delete_rsp(ctx, pqosd_rsp);
            break;
         }
         case IE_PQOS_DELETE_COMPLETE: {
            /* Transaction initiated by other node */
            struct moca_pqos_delete_complete * pqosd_cmp = (struct moca_pqos_delete_complete *)data;
            mocad_handle_pqos_delete_cmp(ctx, pqosd_cmp);
            break;
         }
         case IE_PQOS_MAINTENANCE_COMPLETE: {
            struct moca_pqos_maintenance_complete * pqos_maint = (struct moca_pqos_maintenance_complete *)data;

            mocad_log(ctx, L_TRAP, "PQoS Maintenance complete.\n") ;
            mocad_log(ctx, L_TRAP, "      iocOvercommit:   %d\n", 
               pqos_maint->iocovercommit) ;
            mocad_log(ctx, L_TRAP, "      allocatedSTPS:   %d\n", 
               pqos_maint->allocatedstps) ;
            mocad_log(ctx, L_TRAP, "      allocatedTXPS:   %d\n", 
               pqos_maint->allocatedtxps) ;
            break;
         }
         case IE_PQOS_QUERY_RESPONSE: {
            struct moca_pqos_query_response* pqos_query = 
               (struct moca_pqos_query_response *)data;
            /* tpeakdatarate is a 24-bit field trapped in a u32 */
            pqos_query->tpeakdatarate &= BE32(0xFFFFFF);
            break;
         }

         case IE_TRAP_1:
         case IE_TRAP_2:
         {
            uint32_t *val = (uint32_t *)data;
            mocad_log(ctx, L_INFO, "Trap %d:  %08X\n", ie_type-IE_TRAP_1+1, BE32(*val));
            break;
         }

         case IE_MOCA_RESET_REQUEST:
         {
            uint32_t *cause = (uint32_t *)data;
            MoCAOS_Printf(ctx->os_handle, "MoCA reset request.  Cause: 0x%08X\n", (unsigned int)BE32(*cause));
            ctx->restart = 7;
            break;
         }
         case IE_MR_COMPLETE:
         case IE_MR_RESPONSE:
         {
            uint32_t *nondefseqnum = (uint32_t *)data;
            mocad_write_nondefseqnum(ctx, BE32(*nondefseqnum));

            break;
         }
         case IE_UCFWD_UPDATE:
         {
#ifdef DSL_MOCA
            mocad_update_br_entries(ctx, 0);
#endif
            mocad_log(ctx, L_DEBUG, "UCFWD table update\n");
            break;
         }
      }

      num_ies--;

      if (delete_ie)
      {
         /* This IE is not to be broadcasted to clients */
         if (num_ies == 0)
         {
            /* This is the last IE, just memset it to zero */
            memset(ih, 0x0, ie_len + sizeof(*ih));
         }
         else
         {
            /* Copy the rest of the trap over top of this IE */
            memcpy((uint8_t *)ih, ((uint8_t *)ih + ie_len + sizeof(*ih)),
                   trap_len - ((uintptr_t)ih - (uintptr_t)ctx->trap_buf) - ie_len - sizeof(*ih));
         }

         mh->num_ies = BE16(BE16(mh->num_ies) - 1);
         trap_len -= (ie_len + sizeof(*ih));

         delete_ie = 0;
      }
      else
      {
         if (num_ies > 0)
         {
            ih = (struct mmp_ie_hdr *)((uintptr_t) ih + ie_len + sizeof(*ih));
            data = (void *)(ih + 1);
         }
      }
   }

   /* broadcast event to all evt clients */
   if (BE16(mh->num_ies) > 0)
   {
      MoCAOS_SendMMP(ctx->os_handle, MoCAOS_CLIENT_BROADCAST, ctx->trap_buf, trap_len);
   }

   return(0);
}

static void mocad_handle_deferred_traps(struct mocad_ctx *ctx)
{
   struct mocad_trap_list * trap;

   /* Process deferred traps */
   trap = mocad_get_trap(ctx);
   while (trap != NULL) {
      memcpy(ctx->trap_buf, trap->trap, trap->len);
      mocad_handle_trap(ctx, trap->len);
      mocad_free_trap(ctx, trap);
      trap = mocad_get_trap(ctx);
   }
}

void mocad_enable_data_if(struct mocad_ctx *ctx)
{
   MoCAOS_EnableDataIf(ctx->os_handle, ctx->ifname, ctx->any_time.pss_en);
}

int mocad_wr_get_response(void *wr, uint16_t ie_type, uint16_t ie_len)
{
   struct mmp_msg_hdr *mh;
   struct mmp_ie_hdr *ih;

   mh = (struct mmp_msg_hdr *)wr;
   mh->msg_type = MOCA_MSG_GET_RESPONSE;
   mh->msg_id = 0;
   mh->num_ies = BE16(1);

   ih = (struct mmp_ie_hdr *)(mh + 1);
   ih->ie_type = BE16(ie_type);
   ih->ie_len = BE16(ie_len);

   return(sizeof(*mh) + sizeof(*ih));
}

int mocad_wr_result(void *wr, uint8_t msg_type, uint16_t ie_type,
   uint32_t retcode)
{
   struct mmp_msg_hdr *mh;
   struct mmp_ie_hdr *ih;
   uint32_t *data;

   mh = (struct mmp_msg_hdr *)wr;
   mh->msg_type = msg_type;
   mh->msg_id = 0;
   mh->num_ies = BE16(1);

   ih = (struct mmp_ie_hdr *)(mh + 1);
   ih->ie_type = BE16(ie_type);
   ih->ie_len = BE16(sizeof(uint32_t));

   data = (uint32_t *)(ih + 1);
   *data = BE32(retcode);

   return(sizeof(*mh) + sizeof(*ih) + sizeof(uint32_t));
}

int mocad_wr_abort(void *wr)
{
   return(mocad_wr_result(wr, MOCA_MSG_TRAP, IE_ABORT, 1));
}

int mocad_get_anytime(struct mocad_ctx *ctx, uint16_t ie_type, uint32_t *data, unsigned char *wr)
{
   int i;
   int ret=0;

   for (i=0; i<(int)(sizeof(g_AnyTimeLocations)/sizeof(g_AnyTimeLocations[0])); i++)
   {
      if (g_AnyTimeLocations[i].ie_type == ie_type)
      {
         if (g_AnyTimeLocations[i].offset < sizeof(ctx->any_time))
         {
            ret = mocad_wr_get_response(wr, ie_type, g_AnyTimeLocations[i].len);
            wr += ret;

            if (g_AnyTimeLocations[i].swap)
               __moca_copy_be32(wr, (unsigned char *)&ctx->any_time + g_AnyTimeLocations[i].offset, 
                  g_AnyTimeLocations[i].len);
            else
               memcpy(wr, (unsigned char *)&ctx->any_time + g_AnyTimeLocations[i].offset, 
                  g_AnyTimeLocations[i].len);

            ret += g_AnyTimeLocations[i].len;
         }
         return(ret);
      }
   }               
   return(0);
}

int mocad_set_anytime(struct mocad_ctx *ctx, uint16_t ie_type, uint32_t *data, uint32_t len, void *wr)
{
   int i;

   for (i=0; i<(int)(sizeof(g_AnyTimeLocations)/sizeof(g_AnyTimeLocations[0])); i++)
   {
      if (g_AnyTimeLocations[i].ie_type == ie_type)
      {

         if (g_AnyTimeLocations[i].offset < sizeof(ctx->any_time))
         {
            if (len != g_AnyTimeLocations[i].len)
            {
               return(-1);
            }
            
            if (g_AnyTimeLocations[i].swap)
               __moca_copy_be32((unsigned char *)&ctx->any_time + g_AnyTimeLocations[i].offset, data, 
                            g_AnyTimeLocations[i].len);
            else
               memcpy((unsigned char *)&ctx->any_time + g_AnyTimeLocations[i].offset, data, 
                     g_AnyTimeLocations[i].len);
            
            if ((ctx->moca_running) && (g_AnyTimeLocations[i].moca_set))
            {           
               if (g_AnyTimeLocations[i].ptr)
               g_AnyTimeLocations[i].moca_set(ctx, (unsigned char *)(&ctx->any_time) + g_AnyTimeLocations[i].offset);                 
               else
                  g_AnyTimeLocations[i].moca_set(ctx, (unsigned char *) 
                     *(uintptr_t *)
                         ((uintptr_t)(&ctx->any_time) + g_AnyTimeLocations[i].offset));
            }
            
            return(mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0));
         }
         return(0);
      }
   }

   return(0);
}

static int mocad_set_all_anytime(struct mocad_ctx *ctx)
{
    int i;
    int ret=0;

    for (i=0; i<(int)(sizeof(g_AnyTimeLocations)/sizeof(g_AnyTimeLocations[0])); i++)
    {
        if (g_AnyTimeLocations[i].ie_type == 0)
            break;
        
        if (g_AnyTimeLocations[i].offset < sizeof(ctx->any_time))
        {
            if (g_AnyTimeLocations[i].moca_set)
            {
                if (g_AnyTimeLocations[i].ptr)
                    ret = g_AnyTimeLocations[i].moca_set(ctx, (unsigned char *)(&ctx->any_time) 
                        + g_AnyTimeLocations[i].offset);
                else
                    ret = g_AnyTimeLocations[i].moca_set(ctx, (unsigned char *)
                        *(uintptr_t *)
                            ((uintptr_t)(&ctx->any_time) + g_AnyTimeLocations[i].offset));
            }
            
            if (ret != 0)
                mocad_log(ctx, L_WARN,
                    "warning: %s reply %x\n",
                    moca_ie_name(g_AnyTimeLocations[i].ie_type), ret);
        }
    }

    return(0);
}


int mocad_core_wdog(struct mocad_ctx *ctx)
{
   struct moca_gen_status gs;
   int ret;

   ret = mocad_cmd(ctx, MOCA_MSG_GET, IE_GEN_STATUS, NULL, 0,
      &gs, sizeof(gs), 0);
   mocad_log(ctx, L_DEBUG, "MoCA WDOG ret %d, version 0x%x  count %u\n", 
      ret, BE32(gs.moca_sw_version), ctx->lab_printf_wdog_count);
#if !defined(__EMU_HOST_11__)
   if (ctx->lab_printf_wdog_count == 0)
   {
      ctx->restart = 8;
   }
#endif

   ctx->lab_printf_wdog_count = 0;

   if (!ctx->show_lab_printf)
   {
      mocad_set_moca_core_trace_enable(ctx,1);
   }
   
   return(ret);
}

int mocad_local_req(struct mocad_ctx *ctx, void *rd, int rd_len,
   void *wr, int wr_len)
{
   struct mmp_msg_hdr *mh;
   struct mmp_ie_hdr *ih;
   void *stat_ptr = NULL, *data;
   int ret;
   int stat_len = 0;
   int field_len = 4;
   uint16_t num_ies, ie_len, ie_type;


   mh = (struct mmp_msg_hdr *) rd;
   ih = (struct mmp_ie_hdr *)(mh + 1);
   num_ies = BE16(mh->num_ies);
   ie_len = BE16(ih->ie_len);
   ie_type = BE16(ih->ie_type);
   data = (void *)((uintptr_t)rd + sizeof(*mh) + sizeof(*ih));

   if(rd_len < (int)(sizeof(*mh) + sizeof(*ih)))
      return(-1);
   if(num_ies != 1)
      return(0);
   if((ie_len + sizeof(*mh) + sizeof(*ih)) > (uint32_t)rd_len)
      return(-2);
 
   /* request for statistics */
   if(ie_type == IE_GEN_STATS) {
      stat_ptr = &ctx->gen_stats;
      stat_len = sizeof(ctx->gen_stats);
      field_len=4;
   }
   if(ie_type == IE_EXT_STATS) {
      stat_ptr = &ctx->ext_stats;
      stat_len = sizeof(ctx->ext_stats);
      field_len=4;
   }
   if((ie_type >= IE_NODE_STATS) &&
      (ie_type < (IE_NODE_STATS + MOCA_MAX_NODES))) {
      stat_ptr = &ctx->node_stats[ie_type - IE_NODE_STATS];
      stat_len = sizeof(ctx->node_stats[0]);
      field_len=4;
   }
   if((ie_type >= IE_NODE_STATS_EXT) &&
      (ie_type < (IE_NODE_STATS_EXT + MOCA_MAX_NODES))) {
      stat_ptr = &ctx->node_stats_ext[ie_type - IE_NODE_STATS_EXT];
      stat_len = sizeof(ctx->node_stats_ext[0]);
      field_len=1;
   }
   
   if(stat_ptr) {
      if(stat_len <= wr_len) {
         ret = mocad_accum_stats(ctx, ie_type, wr,
            stat_ptr, stat_len, field_len);
         if(ret > 0)
            return(ret);
      } else {
         goto bad;
      }
   }

   if ((ie_type >= IE_NODE_STATS_EXT_ACC) && 
      (ie_type < IE_NODE_STATS_EXT_ACC + MOCA_MAX_NODES))
   {
      struct moca_node_stats_ext_acc *r = 
         (struct moca_node_stats_ext_acc *)data;

      if(mh->msg_type == MOCA_MSG_GET) {
         mocad_accum_node_stats_ext(ctx, (1 << (ie_type - IE_NODE_STATS_EXT_ACC)));

         ret = mocad_wr_get_response(wr, ie_type,
            sizeof(*r));

         r = ( struct moca_node_stats_ext_acc *)((uintptr_t)wr + ret);

         __moca_copy_be32(r, &ctx->acc_err_stats[ie_type - IE_NODE_STATS_EXT_ACC], 
            sizeof(*r));

         ret += sizeof(*r);

         return(ret);
      }
   }


   /* others */

   ret = 0;
   if (((ie_type >= 0x2000) && (ie_type < 0x2500)) ||   // any-time config
      (ie_type >= 0xf000)) // mocad IEs
   {
      if(mh->msg_type == MOCA_MSG_GET)
      {
         if ((ret=mocad_get_anytime(ctx, ie_type, (uint32_t *)data, (unsigned char *)wr)) < 0)
            goto bad;
      }
      else
      {         
         if ((ret=mocad_set_anytime(ctx, ie_type, (uint32_t *)data, rd_len - sizeof(*mh) - sizeof(*ih), wr)) < 0)
            goto bad;
      }
   }

   switch(ie_type) {
      case IE_WOL:
         if ((ret = MoCAOS_WolCtrl(ctx->os_handle, BE32(*(int*)data)) != 0)) {
            MoCAOS_Printf(ctx->os_handle, "Failed to change WOL mode\n");
            goto bad;
         }
         break;
      case IE_RESET_STATS: /* WO */
         mocad_reset_stats(ctx);
         ret = mocad_wr_result(wr, MOCA_MSG_ACK, ie_type, 0);
         break;
      case IE_EXT_OCTET_COUNT: { /* RO */
         struct moca_ext_octet_count *r;

         ret = mocad_accum_stats(ctx, IE_GEN_STATS, wr,
            &ctx->gen_stats, sizeof(ctx->gen_stats), 4);
         if(ret < 0) {
            ret = mocad_wr_abort(wr);
            break;
         }
         ret = mocad_wr_get_response(wr, ie_type,
            sizeof(*r));
         r = (struct moca_ext_octet_count *)((uintptr_t)wr + ret);

         r->in_octets_hi = (uint32_t)BE32(ctx->in_octets >> 32);
         r->in_octets_lo = (uint32_t)BE32(ctx->in_octets & 0xffffffff);
         r->out_octets_hi = (uint32_t)BE32(ctx->out_octets >> 32);
         r->out_octets_lo = (uint32_t)BE32(ctx->out_octets & 0xffffffff);

         ret += sizeof(*r);
         break;
      }
      case IE_START: /* WO */
         if(ctx->moca_running) {
            /* already running */
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 1);
            break;
         }
         ctx->restart = 9;
         ret = mocad_wr_result(wr, MOCA_MSG_ACK, ie_type, 0);
         mocad_log(ctx, L_INFO, "Starting MoCA interface\n");
         break;
      case IE_STOP: /* WO */
         if(! ctx->moca_running) {
            /* already stopped */
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 1);
            break;
         }
         mocad_update_times(ctx, MOCA_TIME_EVENT_CORE_DOWN);
         ctx->moca_running = 0;
#ifdef DSL_MOCA
         mocad_update_br_entries(ctx, 1);
#endif
         MoCAOS_EnableDataIf(ctx->os_handle, ctx->ifname, 2);
         // In order release all the data buffers that already exist in the Packet RAM wait 20 Msec..
         MoCAOS_MSleep(20);

         if (MoCAOS_StopCore(ctx->os_handle) != 0)
         {
            die("MoCAOS_StopCore failed\n");
            MoCAOS_MSleep(4000);
            ctx->restart = 10;
            ret = mocad_wr_result(wr, MOCA_MSG_ACK, ie_type, 1);
         }
         else
         {
            ret = mocad_wr_result(wr, MOCA_MSG_ACK, ie_type, 0);
            mocad_log(ctx, L_INFO, "Stopping MoCA interface\n");
         }

         break;
      case IE_PASSWORD: { /* RW */
         struct moca_password *a;
         if(mh->msg_type == MOCA_MSG_GET) {

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*a));

            a = (struct moca_password *)((uintptr_t)wr + ret);
            memcpy(a, &ctx->password, sizeof(*a));

            ret += sizeof(*a);
            break;
         }
         if(mh->msg_type == MOCA_MSG_SET) {
            uint8_t mmk[8], pmki[8];

            a = ( struct moca_password *)data;
            if(mocad_keygen(mmk, pmki,
               (unsigned char *)a->password) < 0) {
               ret = mocad_wr_result(wr, MOCA_MSG_ACK,
                  ie_type, 1);
            } else {
               ctx->init_time.mmk_key_hi =
                  (mmk[0]  << 24) | (mmk[1]  << 16) |
                  (mmk[2]  <<  8) | (mmk[3]  <<  0);
               ctx->init_time.mmk_key_lo =
                  (mmk[4]  << 24) | (mmk[5]  << 16) |
                  (mmk[6]  <<  8) | (mmk[7]  <<  0);
               ctx->init_time.pmk_initial_key_hi =
                  (pmki[0] << 24) | (pmki[1] << 16) |
                  (pmki[2] <<  8) | (pmki[3] <<  0);
               ctx->init_time.pmk_initial_key_lo =
                  (pmki[4] << 24) | (pmki[5] << 16) |
                  (pmki[6] <<  8) | (pmki[7] <<  0);
               ret = mocad_wr_result(wr, MOCA_MSG_ACK,
                  ie_type, 0);
            }
            memcpy(&ctx->password, a, sizeof(*a));
            break;
         }
         goto bad;         
      }
      case IE_INIT_TIME: /* RW */
         if(mh->msg_type == MOCA_MSG_GET) {
            struct moca_init_time *r;

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r));

            r = ( struct moca_init_time *)((uintptr_t)wr + ret);

            __moca_copy_be32(r, &ctx->init_time, sizeof(*r));

            ret += sizeof(*r);
            break;
         }
         if(mh->msg_type == MOCA_MSG_SET) {
            const int len = sizeof(ctx->init_time);

            if(rd_len != (sizeof(*mh) + sizeof(*ih) + len))
               goto bad;

            __moca_copy_be32(&ctx->init_time, data, len);

            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
            break;
         }
         goto bad;
      case IE_INIT_TIME_OPTIONS: /* RW */
         if(mh->msg_type == MOCA_MSG_GET) {
            struct moca_init_time_options *r;

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r));

            r = (struct moca_init_time_options *)((uintptr_t)wr + ret);
            __moca_copy_be32(r, &ctx->init_time_options, sizeof(*r));

            ret += sizeof(*r);
            break;
         }
         if(mh->msg_type == MOCA_MSG_SET) {
            const int len = sizeof(ctx->init_time_options);

            if(rd_len != (sizeof(*mh) + sizeof(*ih) + len))
               goto bad;

            __moca_copy_be32(&ctx->init_time_options, data, len);

            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
            break;
         }
         goto bad;
      case IE_DRV_INFO: { /* RO */
         struct moca_drv_info *r;

         if (MoCAOS_GetDriverInfo(ctx->os_handle, &ctx->kdrv_info) != 0)
         {
                MoCAOS_Printf(ctx->os_handle, "BAD: no driver info\n");
            goto bad;
         }

         ret = mocad_wr_get_response(wr, ie_type,
            sizeof(*r));
         r = (struct moca_drv_info *)((uintptr_t)wr + ret);
         r->version = BE32(ctx->kdrv_info.version);
         r->build_number = BE32(ctx->kdrv_info.build_number);
         r->uptime = BE32(ctx->kdrv_info.uptime);
         r->hw_rev = BE32(ctx->kdrv_info.hw_rev);
         r->chip_id = BE32(ctx->kdrv_info.chip_id);
         r->rf_band = BE32(ctx->kdrv_info.rf_band);
         strncpy((char *)r->ifname, ctx->ifname, 16);
         mocad_get_core_times(ctx, &r->core_uptime, &r->link_uptime);

         ret += sizeof(*r);
         break;
      }
      case IE_SNR_DATA: {
         void * pMem;
         int    retVal = 0;

         if(ctx->kdrv_info.gp1 == 0)
            goto bad;

         ret = mocad_wr_get_response(wr, ie_type, SNR_DATA_SIZE);

         /* the memory transfer at the kernel layer might require 
          * 64-bit alignment */
         if (MoCAOS_MemAlign(&pMem, 64, SNR_DATA_SIZE) < 0)
            goto bad;

         retVal = MoCAOS_ReadMem(ctx->os_handle, (unsigned char *)pMem, 
               SNR_DATA_SIZE,
               (unsigned char *)((uintptr_t)ctx->kdrv_info.gp1 & 0x1fffffff) + SNR_DATA_OFFSET);

         if (retVal != 0)
         {
            mocad_log(ctx, L_ERR, "Failure to read SNR data (%d)\n", retVal);
            free(pMem);
            goto bad;
         }
         memcpy((unsigned char *)((uintptr_t)wr + ret), pMem, SNR_DATA_SIZE);
         free(pMem);
         ret += SNR_DATA_SIZE;
         break;
      }
      case IE_IQ_DATA: {
         void * pMem;
         int    retVal = 0;

         if(ctx->kdrv_info.gp1 == 0)
            goto bad;

         ret = mocad_wr_get_response(wr, ie_type, IQ_DATA_SIZE);

         /* the memory transfer at the kernel layer might require 
          * 64-bit alignment */
         if (MoCAOS_MemAlign(&pMem, 64, IQ_DATA_SIZE) < 0)
            goto bad;

         retVal = MoCAOS_ReadMem(ctx->os_handle, (unsigned char *)pMem, 
               IQ_DATA_SIZE,
               (unsigned char *)((uintptr_t)ctx->kdrv_info.gp1 & 0x1fffffff) + IQ_DATA_OFFSET);

         if (retVal != 0)
         {
            mocad_log(ctx, L_ERR, "Failure to read IQ data (%d)\n", retVal);
            free(pMem);
            goto bad;
         }
         memcpy((void *)(((uintptr_t)wr + ret)), pMem, IQ_DATA_SIZE);
         free(pMem);
         ret += IQ_DATA_SIZE;
         break;
      }
      case IE_CIR_DATA: {
         uint32_t * node;

         node = (uint32_t *)data;

         ret = mocad_wr_get_response(wr, ie_type, CIR_DATA_SIZE);

         memcpy((void *)(((uintptr_t)wr + ret)), ctx->cir_data[*node], CIR_DATA_SIZE);
         ret += CIR_DATA_SIZE;
         break;
      }
      case IE_RESTORE_DEFAULTS: /* WO */
         mocad_restore_defaults(ctx, ctx->init_time.lof, ctx->init_time_options.dont_start_moca);
         
         strcpy((char *)ctx->password.password, "99999999988888888");
            
         if (ctx->init_time.rf_type == 0)
            ctx->init_time.lof=0;
         else if (ctx->init_time.rf_type == 3)
            ctx->init_time.lof=1000;
         else if (ctx->init_time.rf_type == 1)
            ctx->init_time.lof=575;
         else if (ctx->init_time.rf_type == 4)
            ctx->init_time.lof=1000;
         else
            ctx->init_time.lof=800;

         mocad_write_nondefseqnum(ctx, 0);
         ret = mocad_wr_result(wr, MOCA_MSG_ACK, ie_type, 0);
         break;

      case IE_PSS_EN:
         #if 0 /* TBD Chris */
         /* store set values in context */
         if(mh->msg_type == MOCA_MSG_SET) {
            mocad_enable_data_if(ctx);
         }
         #endif
         break;
      case IE_MR_REQUEST:
          if(mh->msg_type == MOCA_MSG_SET) {
              if (ctx->moca_running)
              {
                struct moca_mr_request *mr = (struct moca_mr_request *)data;

                if (BE16(mr->nonDefSeqNum) == 0xFFFF)
                {
                   mr->nonDefSeqNum = BE16((uint16_t)(ctx->disk_nondefseqnum+1));
               }
            }
         }
         break;
      case IE_EGR_MC_ADDR_FILTER:
         if(mh->msg_type == MOCA_MSG_SET) 
         {
            struct moca_egr_mc_addr_filter *filter = (struct moca_egr_mc_addr_filter *)data; 
            const int len = sizeof(struct moca_egr_mc_addr_filter);

            if(rd_len != (sizeof(*mh) + sizeof(*ih) + len))
               goto bad;

            filter->valid = BE32(filter->valid);
            filter->addr_hi = BE32(filter->addr_hi);
            filter->addr_lo = BE32(filter->addr_lo);
            filter->entryid = BE32(filter->entryid);
                
            if (filter->entryid >= MOCA_MAX_EGR_MC_FILTERS)
               goto bad;

            if ((ctx->any_time.egr_mc_addr_filter[filter->entryid].valid != filter->valid) ||
               (ctx->any_time.egr_mc_addr_filter[filter->entryid].addr_hi != filter->addr_hi) ||
               (ctx->any_time.egr_mc_addr_filter[filter->entryid].addr_lo != filter->addr_lo))
            {
               ctx->any_time.egr_mc_addr_filter[filter->entryid].valid = filter->valid;
               ctx->any_time.egr_mc_addr_filter[filter->entryid].addr_hi = filter->addr_hi;
               ctx->any_time.egr_mc_addr_filter[filter->entryid].addr_lo = filter->addr_lo;

               
               if (ctx->moca_running)
                  moca_set_egr_mc_addr_filter(ctx, filter);
            }

            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
         }
         else
         {
            struct moca_egr_mc_addr_filter *r;
            struct moca_egr_mc_addr_filter *filter = (struct moca_egr_mc_addr_filter *)data; 

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r));

            r = (struct moca_egr_mc_addr_filter *)((uintptr_t)wr + ret);

            if (BE32(filter->entryid) >= MOCA_MAX_EGR_MC_FILTERS)
            {
               ret = -1;
               break;
            }

            r->valid = BE32(ctx->any_time.egr_mc_addr_filter[BE32(filter->entryid)].valid);
            r->entryid = filter->entryid; // double BE32 cancels
            r->addr_hi = BE32(ctx->any_time.egr_mc_addr_filter[BE32(filter->entryid)].addr_hi);
            r->addr_lo = BE32(ctx->any_time.egr_mc_addr_filter[BE32(filter->entryid)].addr_lo);

            ret += sizeof(*r);      
         }
         break;
      case IE_LAB_TPCAP:
         {
            struct moca_lab_tpcap* tpcap = (struct moca_lab_tpcap *)data;

            tpcap->enable = BE32(tpcap->enable);
            tpcap->type = BE32(tpcap->type);
            if (tpcap->enable == 1)
            {
               MoCAOS_Printf(ctx->os_handle, "Allocating 1M TPCAP buffer, please wait...\n");
               if (!ctx->tpcapbufphys)
                  MoCAOS_AllocPhysMem(1024*1024+256, (unsigned int **)&ctx->tpcapbufphys);
               MoCAOS_Printf(ctx->os_handle, "tpcap buffer allocated at: 0x%08X\n", (unsigned int)((ctx->tpcapbufphys +256) & 0xFFFFFF00));
            }

            moca_set_lab_tpcap(ctx, tpcap);
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
         }
         break;
      case IE_DIPLEXER:
         if(mh->msg_type == MOCA_MSG_SET)
         {
            if (ctx->moca_running)
               moca_set_rx_power_tuning(ctx, ctx->any_time.rx_power_tuning+ctx->any_time.diplexer);
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
         }
         break;
      case IE_RX_POWER_TUNING:
         if(mh->msg_type == MOCA_MSG_SET) 
         {
            if (ctx->moca_running)
               moca_set_rx_power_tuning(ctx, ctx->any_time.rx_power_tuning+ctx->any_time.diplexer);
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
         }
         break;
      case IE_MAX_CONSTELLATION:
         /* store set values in context */
         if(mh->msg_type == MOCA_MSG_SET) {
            const int len = sizeof(struct moca_max_constellation);
            struct moca_max_constellation *mc = (struct moca_max_constellation *)data;

            if(rd_len != (sizeof(*mh) + sizeof(*ih) + len))
               goto bad;
            if (BE32(mc->node_id) >= MOCA_MAX_NODES)
               goto bad;
            ctx->any_time.max_constellation[BE32(mc->node_id)] = 
               BE32(mc->bits_per_carrier);

            // moca_set_max_constellation will byte swap these values but they are already byte swapped, so we byte swap them
            mc->bits_per_carrier = BE32(mc->bits_per_carrier);
            mc->node_id = BE32(mc->node_id);
            if (ctx->moca_running)
               moca_set_max_constellation(ctx, mc);

            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
         }
         else
         {
            uint32_t *r;
            struct moca_max_constellation *mc = (struct moca_max_constellation *)data;

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r));

            r = (uint32_t *)((uintptr_t)wr + ret);

            *r = BE32(ctx->any_time.max_constellation[BE32(mc->node_id)]);

            ret += sizeof(*r); 
         }
         break;
      case IE_MOCA_CORE_TRACE_ENABLE: { /* RW */
         if(mh->msg_type == MOCA_MSG_GET) {
            uint32_t *r;

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r));

            r = (uint32_t *)((uintptr_t)wr + ret);
            *r = BE32(ctx->show_lab_printf);
            ret += sizeof(*r);
            break;
         }
         if(mh->msg_type == MOCA_MSG_SET) {
            const int len = sizeof(uint32_t);
            uint32_t *val = (uint32_t *)data;

            if(rd_len != (sizeof(*mh) + sizeof(*ih) + len))
               goto bad;

            ctx->show_lab_printf = !!(*val);
            /* if the link is down, keep traces on for wdog */
            if (ctx->moca_running &&
                  (ctx->lab_printf_wdog_count ||
                     ctx->show_lab_printf ||
                (ctx->link_state == LINK_STATE_UP)))
            {
               mocad_set_moca_core_trace_enable(ctx,
                  ctx->show_lab_printf);
            }
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);

            if ((ctx->show_lab_printf) && (ctx->init_time.nc_mode != 0))
            {
               mocad_log(ctx, L_WARN, "WARNING: Using non-standard nc_mode\n");
            }
            break;
         }
         goto bad;
      }
      case IE_FW_FILE: { /* WO */
         struct moca_fw_file *r = (struct moca_fw_file *)data;

         ctx->fw_file = (char *)r->fw_file;
         mocad_log(ctx, L_VERBOSE, "FW_FILE %s\n", ctx->fw_file);
         ctx->fw_img = MoCAOS_GetFw(ctx->os_handle, (unsigned char *)ctx->fw_file, 
            (int *)&ctx->fw_len);

         ret = mocad_wr_result(wr, MOCA_MSG_ACK,
            ie_type, 0);

         break;
      }
      case IE_VERBOSE: { /* RW */
         if(mh->msg_type == MOCA_MSG_GET) {
            uint32_t *r;

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r));

            r = (uint32_t *)((uintptr_t)wr + ret);
            *r = BE32(ctx->verbose);
            ret += sizeof(*r);
            break;
         }
         if(mh->msg_type == MOCA_MSG_SET) {
            const int len = sizeof(uint32_t);

            if(rd_len != (sizeof(*mh) + sizeof(*ih) + len))
               goto bad;

            __moca_copy_be32(&ctx->verbose, data, len);

            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
            break;
         }
         goto bad;
      }
      case IE_MOCA_CONST_TX_MODE: { /* RO */
            uint32_t *r;

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r));

            r = (uint32_t *)((uintptr_t)wr + ret);
            *r = BE32((ctx->link_state == LINK_STATE_DEBUG) ? 1 : 0);
            ret += sizeof(*r);
            break;
      }
      case IE_KEY_TIMES: {       
         struct moca_key_times *r = (struct moca_key_times *)data;

         if(mh->msg_type == MOCA_MSG_GET) {
            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r));

            r = (struct moca_key_times *)((uintptr_t)wr + ret);
            
            r->tekTime = (uint32_t)BE32(ctx->tekTime);
            r->tekLastInterval = (uint32_t)BE32(ctx->tekLastInterval);
            r->tekEvenOdd = BE32(ctx->tekEvenOdd);
            r->pmkTime = (uint32_t)BE32(ctx->pmkTime);
            r->pmkLastInterval = (uint32_t)BE32(ctx->pmkLastInterval);
            r->pmkEvenOdd = BE32(ctx->pmkEvenOdd);
            
            ret += sizeof(*r);
         }
         break;
      }       
         
      case IE_PQOS_TABLE: { /* RW */
         struct moca_pqos_table *r = (struct moca_pqos_table *)data;
         struct moca_pqos_table pqos_table;

         if(mh->msg_type == MOCA_MSG_GET_TABLE) {

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r)*MOCA_MAX_PQOS_ENTRIES);

            r = (struct moca_pqos_table *)((uintptr_t)wr + ret);
            __moca_copy_be32(r, ctx->pqos_table, 
               sizeof(ctx->pqos_table));
            ret += sizeof(ctx->pqos_table);
            break;
         }
         if(mh->msg_type == MOCA_MSG_ADD_ENTRY) {
            const int len = sizeof(*r);

            if(rd_len != (sizeof(*mh) + sizeof(*ih) + len))
               goto bad;

            __moca_copy_be32(&pqos_table, r, sizeof(*r));
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, mocad_add_pqos_entry(ctx, &pqos_table, NULL));
            break;
         }
         if(mh->msg_type == MOCA_MSG_DEL_ENTRY) {
            const int len = sizeof(uint32_t);

            if(rd_len != (sizeof(*mh) + sizeof(*ih) + len))
               goto bad;

            __moca_copy_be32(&pqos_table, r, sizeof(*r));
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, mocad_del_pqos_entry(ctx, &pqos_table));
            break;
         }
         goto bad;
      }
      case IE_ERROR_TO_MASK: /* RW */
         if(mh->msg_type == MOCA_MSG_GET) {
            struct moca_error_to_mask *r;

            ret = mocad_wr_get_response(wr, ie_type,
               sizeof(*r));

            r = (struct moca_error_to_mask *)((uintptr_t)wr + ret);
            __moca_copy_be32(r, &ctx->error_to_mask, sizeof(*r));

            ret += sizeof(*r);
            break;
         }
         if(mh->msg_type == MOCA_MSG_SET) {
            const int len = sizeof(ctx->error_to_mask);

            if(rd_len != (sizeof(*mh) + sizeof(*ih) + len))
               goto bad;

            __moca_copy_be32(&ctx->error_to_mask, data, len);
            mocad_write_e2m(ctx, &ctx->error_to_mask);

            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
            break;
         }
      case IE_MESSAGE: { /* WO */
         uint32_t *r = (uint32_t *)data;
         
         ret = mocad_send_notification(ctx, BE32(*r));
         if (ret == 0) {
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 0);
         } else {
            ret = mocad_wr_result(wr, MOCA_MSG_ACK,
               ie_type, 1);
         }
         break;
      }
   }

#define LOCL_MSG_LIMIT     0x80

   if(ret && (ctx->verbose & L_MMP_MSG)) {
      mocad_dump_buf(ctx, "LOCL<", (unsigned char *)rd, rd_len);
      if(ret > LOCL_MSG_LIMIT) {
         mocad_dump_buf(ctx, "LOCL>", (unsigned char *)wr, LOCL_MSG_LIMIT);
         mocad_dump_buf(ctx, "LOCL>", (unsigned char *)wr, LOCL_MSG_LIMIT - ret);
      } else {
         mocad_dump_buf(ctx, "LOCL>", (unsigned char *)wr, ret);
      }
   }

   return(ret);

bad:
   return(mocad_wr_abort(wr));
}

/* we want to allow some MMP communication in debug mode */
int mocad_allow_msg_in_dbg(void * msg)
{
   struct mmp_msg_hdr *mh;
   struct mmp_ie_hdr *ih;

   mh = (struct mmp_msg_hdr *)msg;
   ih = (struct mmp_ie_hdr *)(mh + 1);
   switch (BE16(ih->ie_type)) {
      case IE_LAB_REGISTER:
      case IE_LAB_CALL_FUNC:
         return(1);
      default:
         return(0);
   }
}

int mocad_filter_requests(struct mocad_ctx *ctx)
{
    if (!ctx->any_time.en_capable)
    {
        struct mmp_msg_hdr *mh;
        struct mmp_ie_hdr *ih;
        
        mh = (struct mmp_msg_hdr *)ctx->sock_in;
        ih = (struct mmp_ie_hdr *)(mh + 1);
        switch (BE16(ih->ie_type)) {
            case IE_FMR_REQUEST:
            case IE_PQOS_CREATE_REQUEST:
            case IE_PQOS_UPDATE_REQUEST:
            case IE_PQOS_DELETE_REQUEST:
            case IE_PQOS_LIST_REQUEST:
            case IE_PQOS_QUERY_REQUEST:
            case IE_PQOS_MAINTENANCE_START:
            case IE_MR_REQUEST:            
                return(1);
            default:
                return(0);
        }
    }    
    return(0);
}

int mocad_handle_client_req(struct mocad_ctx *ctx, MoCAOS_ClientHandle client)
{
   int ret, len;

   len = MOCA_BUF_LEN;
   ret = MoCAOS_ReadMMP(ctx->os_handle, client, MoCAOS_TIMEOUT_INFINITE, ctx->sock_in, &len);

   if (ret <= 0)
      return(-1);
      
   /* handle requests to the daemon */
   ret = mocad_local_req(ctx, ctx->sock_in, len, ctx->sock_out,
      MOCA_BUF_LEN);
   if (ret != 0) 
   {
      if (ret < 0)
         ret = mocad_wr_abort(ctx->sock_out);

      ret = MoCAOS_SendMMP(ctx->os_handle, client, ctx->sock_out, ret);
      return(ret);
   }
   /* else, send the request up to the driver */
   if(ctx->moca_running) {
      if(((ctx->link_state == LINK_STATE_DEBUG) &&
         !mocad_allow_msg_in_dbg(ctx->sock_in)) ||
         mocad_filter_requests(ctx)) 
      {
         ret = mocad_wr_abort(ctx->drv_in);
         if(ctx->verbose & L_VERBOSE)
            mocad_dump_buf(ctx, "DROP<", ctx->sock_in, len);
      } 
      else 
      {
         ret = mocad_req(ctx, ctx->sock_in, len);
         if(ret < 0) 
         {
            mocad_log(ctx, L_VERBOSE,
               "bad request from client\n");
            ret = mocad_wr_abort(ctx->drv_in);
         }
      }
   } else {
      struct mmp_msg_hdr *mh;
      struct mmp_ie_hdr *ih;
      uint16_t ie_type;

      mh = (struct mmp_msg_hdr *)ctx->sock_in;
      ih = (struct mmp_ie_hdr *)(mh + 1);

      ie_type = BE16(ih->ie_type);
   
      mocad_log(ctx, L_VERBOSE,
         "request from client while !moca_running (IE=%04X)\n", ie_type);
      ret = mocad_wr_abort(ctx->drv_in);
   }

   ret = MoCAOS_SendMMP(ctx->os_handle, client, ctx->drv_in, ret);

   return(ret);
}

#ifdef DSL_MOCA
int mocad_handle_nl_notification(struct mocad_ctx *ctx)
{
   int err;

   err = MoCAOS_HandleNlNotify( ctx->os_handle );
   if ( err < 0 )
   {
      mocad_log(ctx, L_ERR, "MoCAOS_HandleNlNotify error %d\n", err);
      return err;
   }

   /* bit 1 indicates we need to delete all entries
      bit 2 indiactes we need to add all entries
      in both cases delete all entries first */
   if (0x3 & err)
   {
      /* delete entries - uses previous bridge name */
      mocad_update_br_entries(ctx, 1);
   }
   
   if (0x2 & err)
   {
      /* update bridge name */
      mocad_find_brname(ctx);

      /* add entries */
      mocad_update_br_entries(ctx, 0);
   }
   /* else - nothing to do */

   return 0;
}
#endif

/*
 * CHAR DEVICE OPERATIONS
 */

void mocad_start_moca(struct mocad_ctx *ctx)
{
   mocad_log(ctx, L_INFO, "Loading Moca Core image...(%d)\n", ctx->restart);

   ctx->restart = 0;
   ctx->moca_running = 0;
   ctx->cpu_check_sec  = 0;
   ctx->error_index = 0;
   ctx->error_wrap = 0;

   
   mocad_update_link_state(ctx, ctx->init_time.continuous_power_tx_mode ?
      LINK_STATE_DEBUG : LINK_STATE_DOWN);
   mocad_reset_stats(ctx);
   mocad_remove_pqos_flows(ctx);    

   MoCAOS_EnableDataIf(ctx->os_handle, ctx->ifname, 2);

   if (MoCAOS_StopCore(ctx->os_handle) != 0)
   {
      die("MoCAOS_StopCore failed\n");
      MoCAOS_MSleep(4000);
      ctx->restart = 13;
   }

   ctx->any_time.core_trace_enable = 0;

   if (MoCAOS_StartCore(ctx->os_handle, (unsigned char *)ctx->fw_img, ctx->fw_len, ctx->init_time.continuous_power_tx_mode, &ctx->cpu0strings, (int*)&ctx->sizeofcpu0strings, &ctx->cpu1strings, (int*)&ctx->sizeofcpu1strings) != 0)
   {
      die("MoCAOS_StartCore failed\n");
      MoCAOS_MSleep(4000);
      ctx->restart = 11;
      return;
   }

   mocad_log(ctx, L_INFO, "Loading Moca Core image done.\n");

   if (ctx->kdrv_info.hw_rev != MOCA_CHIP_20)
      MoCAOS_ReadMem(ctx->os_handle, ctx->firmwareInitData, MOCAD_FIRMWAREDATA_REINIT_LEN, (unsigned char *)PACKETRAM_ADDR_REINIT);

   while (1)
   {
      MoCAOS_ClientHandle client;
      client = MoCAOS_WaitForRequest(ctx->os_handle, 3);

      if (client == MoCAOS_CLIENT_CORE)
         break;

      if (client == MoCAOS_CLIENT_TIMEOUT)
      {
         die("Timeout waiting for MOCA_CORE_READY trap\n");
         MoCAOS_MSleep(4000);
         ctx->restart = 12;
         return;
      }
      else if (client == MoCAOS_CLIENT_NL)
      {
         /* handle these in the main loop */
         continue;
      }
      else if (client != MoCAOS_CLIENT_NULL)
      {
         mocad_handle_client_req(ctx, client);
      }
   }
}

static void mocad_set_core_print_prefix(struct mocad_ctx *ctx)
{
   int i = 0;
   int len = 0;
   char * pifnum;

   pifnum = strpbrk(ctx->ifname, "0123456789");

   if (pifnum != NULL) {
      /* Assuming that the interface name includes a number. Find the number
       * and use it to indentify which moca core is generating the traces. */
      strcpy(ctx->core_print_prefix, "CORE");

      /* Subtract 3 from length for colon, space and null character */
      len = (int)MIN(sizeof(ctx->core_print_prefix) - strlen("CORE") - 3, 
                strlen(pifnum));
      strncpy(&ctx->core_print_prefix[strlen("CORE")], pifnum, len);
      i = (int)(strlen("CORE") + len);
   }
   else {
      /* If there's no number in the interface name, just use the
       * interface name in uppercase to identify the moca core. */
      strcpy(ctx->core_print_prefix, ctx->ifname);

      for (i = 0; i < (int)strlen(ctx->core_print_prefix); i++) {
         ctx->core_print_prefix[i] = toupper((int)ctx->core_print_prefix[i]);
      }
   }

   ctx->core_print_prefix[i] = ':';
   ctx->core_print_prefix[i+1] = ' ';
   ctx->core_print_prefix[i+2] = 0x0;
}

#ifdef DSL_MOCA
static int mocad_find_brname(struct mocad_ctx *ctx)
{
   int err;

   err = MoCAOS_FindBrName(ctx->os_handle);
   if ( err < 0 )
   {
      mocad_log(ctx, L_ERR, "MoCAOS_FindBrName: error %d\n", err);
      return -1;
   }
   return 0;
}


static int mocad_update_br_entries(struct mocad_ctx *ctx, int delAll)
{
   struct moca_uc_fwd *pUcFwdTable;
   unsigned char      *pMacAddr;
   int                 numEntries;
   int                 err = 0;
   int                 i, j;
   int                 entryCount;
   unsigned char       savedMac[6];
   unsigned char       currentMac[6];
   int                 found;

   /* 128 matches MoCA_MAX_UC_FWD_ENTRIES */
   pUcFwdTable = calloc(sizeof(struct moca_uc_fwd) * 128, 1);
   pMacAddr    = calloc((6 * 128), 1);
   if ( (NULL == pUcFwdTable) || (NULL == pMacAddr) )
   {
      mocad_log(ctx, L_ERR, "mocad_update_br_entries: out of memory\n");
      free(pUcFwdTable);
      free(pMacAddr);
      return -1;
   }

   if ( 1 == delAll )
   {
      numEntries = 0;
   }
   else
   {
      numEntries = moca_get_uc_fwd((void *)ctx, pUcFwdTable, 
                                   (sizeof(struct moca_uc_fwd) * 128));
   }

   /* check to see if we need to delete entries */
   entryCount = 0;
   for (i = 0; i < ctx->numUcFwdEntries; i++)
   {
      moca_u32_to_mac(&savedMac[0], 
                      ctx->ucFwdTable[i].mac_addr_hi, 
                      ctx->ucFwdTable[i].mac_addr_lo);
      found = 0;
      for( j = 0; j < numEntries; j++ )
      {
         moca_u32_to_mac(&currentMac[0], 
                         pUcFwdTable[j].mac_addr_hi, 
                         pUcFwdTable[j].mac_addr_lo);
         if (0 == memcmp(&currentMac[0], &savedMac[0], 6) )
         {
            found = 1;
            break;
         }
      }
      if ( 0 == found )
      {
         //mocad_log(ctx, L_ERR, "DEL: %02x, %02x, %02x, %02x, %02x, %02x\n",
         //   savedMac[0], savedMac[1], savedMac[2], savedMac[3], savedMac[4], savedMac[5] );
         memcpy(pMacAddr + (6*entryCount), &savedMac[0], 6);
         entryCount++;
      }
   }
   if ( entryCount > 0 )
   {
      err = MoCAOS_DelBrEntries(ctx->os_handle, pMacAddr, entryCount);
      if ( err )
      {
         mocad_log(ctx, L_VERBOSE, "MoCAOS_DelBrEntries: error %d\n", err);
         free(pUcFwdTable);
         free(pMacAddr);
         return -1;
      }
   }

   /* check to see if we need to add entries */
   if ( 0 == delAll )
   {
      entryCount = 0;
      for (i = 0; i < numEntries; i++)
      {
         moca_u32_to_mac(&currentMac[0], 
                         pUcFwdTable[i].mac_addr_hi, 
                         pUcFwdTable[i].mac_addr_lo);
         found = 0;
         for( j = 0; j < ctx->numUcFwdEntries; j++ )
         {
            moca_u32_to_mac(&savedMac[0], 
                            ctx->ucFwdTable[j].mac_addr_hi, 
                            ctx->ucFwdTable[j].mac_addr_lo);
            if (0 == memcmp(&currentMac[0], &savedMac[0], 6) )
            {
               found = 1;
               break;
            }
         }
         if ( 0 == found )
         {
            //mocad_log(ctx, L_ERR, "ADD: %02x, %02x, %02x, %02x, %02x, %02x\n",
            //   currentMac[0], currentMac[1], currentMac[2], currentMac[3], currentMac[4], currentMac[5]);
            memcpy(pMacAddr + (6*entryCount), &currentMac[0], 6);
            entryCount++;
         }
      }
      if ( entryCount > 0 )
      {
         err = MoCAOS_AddBrEntries(ctx->os_handle, pMacAddr, entryCount);
         if ( err )
         {
            mocad_log(ctx, L_VERBOSE, "MoCAOS_AddBrEntries: error %d\n", err);
            free(pUcFwdTable);
            free(pMacAddr);
            return -1;
         }
      }
      memcpy(ctx->ucFwdTable, pUcFwdTable, 
             numEntries*sizeof(struct moca_uc_fwd));
      ctx->numUcFwdEntries = numEntries;
   }
   else
   {
      memset(ctx->ucFwdTable, 0, sizeof(ctx->ucFwdTable));
      ctx->numUcFwdEntries = 0;
   }

   free(pUcFwdTable);
   free(pMacAddr);

   return 0;

}
#endif

#if defined (__EMU_HOST_11__)

void mocad_set_args(struct mocad_ctx *ctx, struct mocad_args *args)
{
   if (args->sc == 0)    // Single channel
      ctx->init_time.auto_network_search_en = 1;    // Single channel
   else if (args->sc == 1)
      ctx->init_time.auto_network_search_en = 0;
   else
      ctx->init_time.auto_network_search_en = 2;

   ctx->init_time.taboo_left_mask = args->tlb;   // Taboo left bitmask
   ctx->init_time.taboo_right_mask = args->trb;   // Taboo tight bitmask
   ctx->init_time.pns_freq_mask = args->pfm;   // Preliminary Network Search
   ctx->init_time.lof = args->lof;   // LOF parameter - Last Operating Frequency
   ctx->init_time.tpc_en = args->tpc;   // TPC enable
   ctx->init_time.rf_type = args->rf;    // RF type
   ctx->init_time.taboo_fixed_mask_start = args->tsc;   // Taboo fixed mask start
   ctx->init_time.taboo_fixed_channel_mask = args->tbm;   // Taboo fixed channel bitmask 
   ctx->init_time.freq_mask = args->frm;   // Frequency bitmask
   ctx->any_time.loopback_en =  args->lpbk;  // Loopback mode enable
   ctx->init_time.nc_mode = args->nc_mode; // NC mode
}

int mocad_main(struct mocad_args *args)
#else
int main(int argc, char **argv)
#endif
{
   int ret, i;
   int len;

   const char *chardev = MOCA_DEFAULT_DEV;
   struct mocad_ctx *ctx;
   time_t last_stat_update = time(NULL) + MOCA_STAT_INTERVAL;
   time_t next_pqos_expiry = 0;
   int daemon = 0, freq = 0;

   ctx = (struct mocad_ctx *)calloc(sizeof(*ctx), 1);
   if(! ctx)
   {
      die("can't allocate ctx\n");
        exit(1);
   }

   /* the memory transfer at the kernel layer might require 
    * 64-bit alignment */     
   for (i=0;i<MOCA_MAX_NODES;i++)
   {
      if (MoCAOS_MemAlign((void**)&ctx->cir_data[i], 64, CIR_DATA_SIZE) < 0)
      {
         mocad_log(ctx, L_ERR, "Error, failure allocating memory\n");

         return(-1);
      }
      memset(ctx->cir_data[i], 0, CIR_DATA_SIZE);
   }
 
   ctx->restart = 1;
   ctx->verbose = L_ERR | L_WARN | L_INFO;
   ctx->trap_list = NULL;

   __mocad_cmd_hook = &mocad_cmd;
   __mocad_table_cmd_hook = &mocad_table_cmd;

#if !defined (__EMU_HOST_11__)
{
   int vcount = 0;
   ctx->workdir = "/etc/moca";
   /* parse command line */

   while((ret = getopt(argc, argv, "hd:wDvqPF:f:i:l:")) != -1) {
      switch(ret) {
         case 'd':
            chardev = optarg;
            break;
         case 'w':
            ctx->restart = 0;
            break;
         case 'v':
            vcount++;
            switch (vcount) {
               case 1:
                  ctx->verbose = L_ERR | L_WARN | L_INFO | L_VERBOSE;
                  break;
               case 2:
                  ctx->verbose = L_ERR | L_WARN | L_INFO | L_VERBOSE |
                                 L_DEBUG;
                  break;
               case 3:
               default:
                  ctx->verbose = L_ERR | L_WARN | L_INFO | L_VERBOSE |
                                 L_DEBUG |
                                 L_TRAP | L_MMP_MSG;
                  break;
            }
            break;
         case 'q':
            ctx->verbose = L_ERR | L_WARN;
            break;
         case 'P':
            ctx->show_lab_printf = 1;
            break;
         case 'f':
            ctx->fw_file = optarg;
            break;
         case 'F':
            freq = atoi(optarg);
            break;
         case 'D':
            daemon = 1;
            break;
         case 'i':
            if (strlen(optarg) < MoCAOS_IFNAMSIZE)
               strcpy(ctx->ifname, optarg);
            break;
         case 'l':
            ctx->workdir = optarg;
            break;
         case 'h':
         default:
            mocad_usage(ctx);
            return(1);
      }
   }
}
#endif

#if defined (__EMU_HOST_11__)
   ctx->workdir = "";
   if (args->wait)
      ctx->restart = 0;

   sprintf(ctx->ifname,"%u", args->sn+(args->cn<<12));
#endif

   ctx->os_handle = MoCAOS_Init(chardev, ctx->ifname, ctx->workdir, daemon);

   MoCAOS_GetDriverInfo(ctx->os_handle, &ctx->kdrv_info);

   ctx->fw_img = MoCAOS_GetFw(ctx->os_handle, (unsigned char *)ctx->fw_file,
      (int *)&ctx->fw_len);

#if defined(DSL_MOCA)
   /* establish communication with CMS */
   if ((ret = cmsMsg_init(EID_MOCAD, &ctx->cmsMsgHandle)) != CMSRET_SUCCESS)
   {
      die("could not initialize msg, ret=%d\n", ret);
        exit(2);
   }
#endif

   mocad_set_core_print_prefix(ctx);

   mocad_read_lof(ctx);

   strcpy((char *)ctx->password.password, "99999999988888888");

   /* set default init_time and any_time params */

   if(ctx->kdrv_info.rf_band == MOCA_BAND_MIDRF) 
   {
      ctx->init_time.rf_type = 1; // mid-lo
      mocad_log(ctx, L_INFO, "MidRF board detected\n");
   }
   else if(ctx->kdrv_info.rf_band == MOCA_BAND_WANRF)
   {
#if !defined(DSL_MOCA)  
      mocad_log(ctx, L_INFO, "HiRF WAN board detected\n");     
#endif
      ctx->init_time.rf_type = 3; // WAN C4-band
   }
   else
   {
#if !defined(DSL_MOCA)  
      mocad_log(ctx, L_INFO, "HiRF board detected\n");      
#endif
      ctx->init_time.rf_type = 0; // hi rf
   }

#if defined(DSL_MOCA)
   ctx->init_time.terminal_intermediate_device = 0; // intermediate
#else
   ctx->init_time.terminal_intermediate_device = 1; // terminal
#endif

   ctx->init_time.turbo_en = 0;    

#if defined (__EMU_HOST_11__) 
   // do this before and after mocad_restore_defaults, since there's a circular 
   // dependency on the defaults of some of the args
   mocad_set_args (ctx, args);
#endif

   if (ctx->restart)
      mocad_restore_defaults(ctx, freq, 0);
   else
      mocad_restore_defaults(ctx, freq, 2);     // wait = 2 means mocad is initialized with -w option
   
#if defined (__EMU_HOST_11__)
   mocad_set_args (ctx, args);
#endif

   /* create pidfile */
   mocad_write_pidfile(ctx);

   ctx->error_to_mask.error1 = -1;

   mocad_read_e2m(ctx);

#if defined(DSL_MOCA) /* DSL Code */
   mocad_init_dsl(ctx);
#endif

   mocad_update_times(ctx, MOCA_TIME_EVENT_CORE_DOWN);
   mocad_update_times(ctx, MOCA_TIME_EVENT_LINK_DOWN);

   if (!ctx->restart)
      MoCAOS_StopCore(ctx->os_handle);
   
   /* main loop */
   while(1) {
      MoCAOS_ClientHandle client;
      time_t timeout_sec;
      time_t now;
      
      if(ctx->restart)
      {
         
#if defined (__EMU_HOST_11__)
         args->wait = 0;
#else
         mocad_start_moca(ctx);
#endif
      }

      now = time(NULL);

      next_pqos_expiry = mocad_expire_pqos_flows(ctx, now);
      if(now >= (last_stat_update + MOCA_STAT_INTERVAL)) {
         last_stat_update = now;

         if ((ctx->show_lab_printf) && (ctx->init_time.nc_mode != 0))
         {
            mocad_log(ctx, L_WARN, "WARNING: Using non-standard nc_mode\n");
         }

         if(ctx->moca_running) {
            if(ctx->link_state == LINK_STATE_UP) {
               mocad_accum_stats(ctx, IE_GEN_STATS,
                  ctx->sock_out, &ctx->gen_stats,
                  sizeof(ctx->gen_stats), 4);
               mocad_accum_stats(ctx, IE_EXT_STATS,
                  ctx->sock_out, &ctx->ext_stats,
                  sizeof(ctx->ext_stats), 4);
            }
            else if (ctx->link_state != LINK_STATE_DEBUG) {
               mocad_core_wdog(ctx);
            }
            if(ctx->restart)
               continue;
         }
      }

#if defined(__EMU_HOST_11__)
      if ((ctx->moca_running) || (args->wait == 0))
#endif
         mocad_handle_deferred_traps(ctx); 

      now = time(NULL);

      timeout_sec = (last_stat_update + MOCA_STAT_INTERVAL) - now;

      if (next_pqos_expiry &&
         (next_pqos_expiry < timeout_sec)) {
         timeout_sec = next_pqos_expiry;
      }
      client = MoCAOS_WaitForRequest(ctx->os_handle, (unsigned int)timeout_sec);
      if (client == MoCAOS_CLIENT_CORE)
      {
         len = MOCA_BUF_LEN;
         ret = MoCAOS_ReadMMP(ctx->os_handle, client, MoCAOS_TIMEOUT_INFINITE, ctx->trap_buf, &len);

#if defined (__EMU_HOST_11__)
         // in the emulator, we can get the CORE_READY trap before we even start the core.  Process this trap after we've restarted
         if ((!ctx->moca_running) && (args->wait))
         {
            mocad_add_trap(ctx, ctx->trap_buf, len);
         }
         else
#endif
            mocad_handle_trap(ctx, len);
      }
      else if (client == MoCAOS_CLIENT_NL)
      {
#ifdef DSL_MOCA
          mocad_handle_nl_notification(ctx);
#endif
      }
      else if ((client != MoCAOS_CLIENT_NULL) && (client != MoCAOS_CLIENT_TIMEOUT))
      {         
         mocad_handle_client_req(ctx, client);         
      }

#if defined(__EMU_HOST_11__)
      if ((ctx->moca_running) || (args->wait == 0))
#endif
         mocad_handle_deferred_traps(ctx);
   }
   return(0);
}
