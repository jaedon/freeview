/******************************************************************************
 *
 *  Copyright (c) 2009  Broadcom Corporation
 *  All Rights Reserved
 *
<:license-private
 *
 ************************************************************************/
/***************************************************************************
 *
 *     Copyright (c) 2008-2009, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *  Description: Internal declarations for libmoca and mocad
 *
 ***************************************************************************/

#ifndef _MOCAINT_H_
#define _MOCAINT_H_

#include "moca_os.h"

#include <stdint.h>



#ifdef __cplusplus
extern "C" {
#endif

#if defined(DSL_MOCA)
#define MOCA_CMD_SOCK_FMT	"/var/moca-cmd.%s"
#define MOCA_EVT_SOCK_FMT	"/var/moca-evt.%s"
#else
#define MOCA_CMD_SOCK_FMT	"/tmp/moca-cmd.%s"
#define MOCA_EVT_SOCK_FMT	"/tmp/moca-evt.%s"
#endif
#define MOCA_FILENAME_LEN	64
#define MOCA_BUF_LEN		1024
#define MOCA_BIG_BUF_LEN	(SNR_DATA_SIZE + 16)
#define MOCA_DEFAULT_IFNAME	"default"
#define MOCA_DEFAULT_DEV	"/dev/bmoca0"

#define FL_SWAP_RD		0x00000001
#define FL_SWAP_WR		0x00000002

#define MOCACORE_PATH_0		"/etc/moca/mocacore.bin"
#define MOCACORE_PATH_1		"mocacore.bin"
#define MOCACORE_PATH_GEN_1 "/etc/moca/mocacore-gen1.bin"
#define MOCACORE_PATH_GEN_2 "/etc/moca/mocacore-gen2.bin"
#define MOCACORE_PATH_GEN_3 "/etc/moca/mocacore-gen3.bin"



#define LOF_PATH_FMT		"lof.%s"
#define NONDEFSEQNUM_PATH_FMT		"nondefseqnum.%s"
#define E2M_PATH_FMT		"e2m.%s"

#define PIDFILE_FMT		"mocad-%s.pid"

#define IFNAME_GLOB		"/sys/class/net/*"
#define DEVNAME_FMT		"/sys/class/bmoca/%s/dev"

#define SNR_DATA_OFFSET		(1 * 1024)
#define SNR_DATA_SIZE		(8 * 1024)
#define IQ_DATA_OFFSET		(0 * 1024)
#define IQ_DATA_SIZE			(1 * 1024)
#define CIR_DATA_OFFSET		(9 * 1024)
#define CIR_DATA_SIZE		(1 * 1024)

#define MUTEX_INIT()		MoCAOS_MutexInit()
#define MUTEX_LOCK(x)		MoCAOS_MutexLock((MoCAOS_MutexHandle)x)
#define MUTEX_UNLOCK(x)		MoCAOS_MutexUnlock((MoCAOS_MutexHandle)x)
#define MUTEX_T			MoCAOS_MutexHandle


void __moca_copy_be32(void *out, const void *in, int size);

extern int (*__mocad_cmd_hook)(void *vctx, uint8_t msg_type, uint16_t ie_type,
	const void *wr, int wr_len, void *rd, int rd_len, int flags);

extern int (*__mocad_table_cmd_hook)(void *vctx, uint16_t ie_type, void **rd);

#if (__BYTE_ORDER == __LITTLE_ENDIAN) && (!defined(WIN32) && !defined(__EMU_HOST_11__))
#define BE64(x) \
( \
	((uint64_t)( \
		(((uint64_t)(x) & (uint64_t)0x00000000000000ffULL) << 56) | \
		(((uint64_t)(x) & (uint64_t)0x000000000000ff00ULL) << 40) | \
		(((uint64_t)(x) & (uint64_t)0x0000000000ff0000ULL) << 24) | \
		(((uint64_t)(x) & (uint64_t)0x00000000ff000000ULL) << 8) | \
		(((uint64_t)(x) & (uint64_t)0x000000ff00000000ULL) >> 8) | \
		(((uint64_t)(x) & (uint64_t)0x0000ff0000000000ULL) >> 24) | \
		(((uint64_t)(x) & (uint64_t)0x00ff000000000000ULL) >> 40) | \
		(((uint64_t)(x) & (uint64_t)0xff00000000000000ULL) >> 56) )) \
)

#define BE32(x) \
    (       \
            (((x) & 0x000000ffUL) << 24) | \
            (((x) & 0x0000ff00UL) <<  8) | \
            (((x) & 0x00ff0000UL) >>  8) | \
            (((x) & 0xff000000UL) >> 24) \
    )
    
#define BE16(x) \
    ( \
            (((x) & 0x00ffUL) << 8) | \
            (((x) & 0xff00UL) >>  8) \
    )
    
#else
#define BE64(x)		(x)
#define BE32(x)		(x)
#define BE16(x)		(x)
#endif

#if defined(WIN32) || defined(__EMU_HOST_11__)
struct mmp_msg_hdr
{
	uint16_t		num_ies;	
	uint8_t			msg_id;
	uint8_t			msg_type;
} __attribute__((packed));

struct mmp_ie_hdr
{
	uint16_t		ie_len;
	uint16_t		ie_type;	
} __attribute__((packed));
#else
struct mmp_msg_hdr
{
	uint8_t			msg_type;
	uint8_t			msg_id;
	uint16_t		num_ies;
} __attribute__((packed));

struct mmp_ie_hdr
{
	uint16_t		ie_type;
	uint16_t		ie_len;
} __attribute__((packed));
#endif

#define MOCA_MSG_SET		0x01
#define MOCA_MSG_ADD_ENTRY	0x02
#define MOCA_MSG_DEL_ENTRY	0x03
#define MOCA_MSG_ACK		0x04
#define MOCA_MSG_GET_TABLE	0x05
#define MOCA_MSG_GET		0x06
#define MOCA_MSG_GET_RESPONSE	0x07
#define MOCA_MSG_SET_NV		0x08
#define MOCA_MSG_TRAP		0x09

/* GENERATED DECLARATIONS BELOW THIS LINE - DO NOT EDIT */

#define IE_INIT_TIME			0x1001
#define IE_START_MOCA_CORE		0x1002
#define IE_MAX_FRAME_SIZE		0x2002
#define IE_MAX_TRANSMIT_TIME		0x2003
#define IE_MIN_BW_ALARM_THRESHOLD	0x2004
#define IE_OOO_LMO			0x2005
#define IE_CONFIG_RESERVED_1		0x2006
#define IE_CONFIG_RESERVED_2		0x2007
#define IE_CONFIG_RESERVED_3		0x2008
#define IE_CONTINUOUS_IE_RR_INSERT	0x2009
#define IE_CONTINUOUS_IE_MAP_INSERT	0x200a
#define IE_MAX_PKT_AGGR			0x200b
#define IE_MAX_CONSTELLATION		0x200c
#define IE_SIG_Y_DONE			0x200d
#define IE_PMK_EXCHANGE_INTERVAL	0x200e
#define IE_TEK_EXCHANGE_INTERVAL	0x200f
#define IE_PRIORITY_ALLOCATIONS		0x2010
#define IE_SNR_MARGIN_TABLE		0x2011
#define IE_MIN_MAP_CYCLE		0x2012
#define IE_MAX_MAP_CYCLE		0x2013
#define IE_EN_MAX_RATE_IN_MAX_BO	0x2014
#define IE_TARGET_PHY_RATE_QAM128	0x2015
#define IE_TARGET_PHY_RATE_QAM256	0x2016
#define IE_MOCA_CORE_TRACE_ENABLE	0x2017
#define IE_SAPM_EN			0x2018
#define IE_ARPL_TH			0x2019
#define IE_SAPM_TABLE			0x201a
#define IE_RLAPM_EN			0x201b
#define IE_RLAPM_TABLE			0x201c
#define IE_BEACON_CHANNEL_SET		0x201d
#define IE_PSS_EN			0x201e
#define IE_FREQ_SHIFT			0x201f
#define IE_EGR_MC_ADDR_FILTER		0x2020
#define IE_EGR_MC_ADDR_FILTER_GET	0x2020
#define IE_RX_POWER_TUNING		0x2021
#define IE_RX_TX_PACKETS_PER_QM		0x2022
#define IE_EXTRA_RX_PACKETS_PER_QM	0x2023
#define IE_MIN_AGGR_WAITING_TIME	0x2024
#define IE_DOWNLOAD_TO_PACKET_RAM_DONE	0x2028
#define IE_TARGET_PHY_RATE_TURBO	0x2029
#define IE_TARGET_PHY_RATE_TURBO_PLUS	0x202a
#define IE_NBAS_CAPPING_EN		0x202b
#define IE_SELECTIVE_RR			0x202c
#define IE_LOOPBACK_EN			0x202d
#define IE_LAB_PILOTS			0x2100
#define IE_LAB_IQ_DIAGRAM_SET		0x2101
#define IE_LAB_SNR_GRAPH_SET		0x2102
#define IE_LAB_REGISTER			0x2103
#define IE_LAB_CALL_FUNC		0x2104
#define IE_LAB_TPCAP			0x2105
#define IE_FMR_REQUEST			0x2500
#define IE_PQOS_CREATE_REQUEST		0x2501
#define IE_PQOS_INGR_ADD_FLOW		0x2502
#define IE_PQOS_UPDATE_REQUEST		0x2503
#define IE_PQOS_INGR_UPDATE		0x2504
#define IE_PQOS_DELETE_REQUEST		0x2505
#define IE_PQOS_INGR_DELETE		0x2506
#define IE_PQOS_LIST_REQUEST		0x2507
#define IE_PQOS_QUERY_REQUEST		0x2508
#define IE_PQOS_MAINTENANCE_START	0x2509
#define IE_MR_REQUEST			0x250a
#define IE_GEN_STATUS			0x3000
#define IE_EXT_STATUS			0x3100
#define IE_GEN_STATS			0x3200
#define IE_EXT_STATS			0x3300
#define IE_GEN_NODE_STATUS		0x4000
#define IE_TX_PROFILE			0x4100
#define IE_RX_UC_PROFILE		0x4200
#define IE_RX_BC_PROFILE		0x4300
#define IE_RX_MAP_PROFILE		0x4400
#define IE_NODE_STATS			0x4500
#define IE_NODE_STATS_EXT		0x4600
#define IE_UC_FWD			0x5200
#define IE_MC_FWD_RD			0x5300
#define IE_MC_FWD_WR			0x5300
#define IE_SRC_ADDR			0x5400
#define IE_START			0xf100
#define IE_STOP				0xf101
#define IE_DRV_INFO			0xf102
#define IE_PASSWORD			0xf103
#define IE_EXT_OCTET_COUNT		0xf104
#define IE_RESET_STATS			0xf105
#define IE_SNR_DATA			0xf106
#define IE_IQ_DATA			0xf107
#define IE_FW_FILE			0xf108
#define IE_VERBOSE			0xf109
#define IE_MOCA_CONST_TX_MODE		0xf10a
#define IE_CIR_DATA			0xf10b
#define IE_RESTORE_DEFAULTS		0xf10c
#define IE_PQOS_TABLE			0xf10d
#define IE_KEY_TIMES			0xf10f
#define IE_INIT_TIME_OPTIONS		0xf110
#define IE_NODE_STATS_EXT_ACC		0xf111
#define IE_ERROR_TO_MASK		0xf128
#define IE_EN_CAPABLE			0xf129
#define IE_MESSAGE			0xf12a
#define IE_DIPLEXER			0xf12b
#define IE_RLAPM_CAP			0xf12c
#define IE_WOL				0xf12d
#define IE_MISCVAL			0xf12e
#define IE_HOST_QOS			0xf12f
#define IE_MOCA_CORE_READY		0x6001
#define IE_POWER_UP_STATUS		0x6002
#define IE_LINK_UP_STATE		0x6003
#define IE_ADMISSION_STATUS		0x6004
#define IE_LIMITED_BW			0x6005
#define IE_ERROR			0x6006
#define IE_LMO_INFO			0x6007
#define IE_KEY_CHANGED			0x6008
#define IE_TOPOLOGY_CHANGED		0x6009
#define IE_MOCA_VERSION_CHANGED		0x600a
#define IE_LAB_PRINTF			0x600b
#define IE_LAB_PRINTF_CODES		0x600c
#define IE_TRAP_1			0x600e
#define IE_TRAP_2			0x600f
#define IE_SIG_Y_READY			0x6010
#define IE_UCFWD_UPDATE			0x6011
#define IE_MOCA_RESET_REQUEST		0x6012
#define IE_NC_ID_CHANGED		0x6013
#define IE_REMOVE_NODE_REQUEST		0x6014
#define IE_REMOVE_NODE_COMPLETE		0x6015
#define IE_CPU_CHECK			0x6016
#define IE_ASSERT			0x8000
#define IE_MIPS_EXCEPTION		0x8001
#define IE_PQOS_CREATE_RESPONSE		0x6500
#define IE_PQOS_CREATE_COMPLETE		0x6501
#define IE_PQOS_UPDATE_RESPONSE		0x6502
#define IE_PQOS_UPDATE_COMPLETE		0x6503
#define IE_PQOS_DELETE_RESPONSE		0x6504
#define IE_PQOS_DELETE_COMPLETE		0x6505
#define IE_PQOS_LIST_RESPONSE		0x6506
#define IE_PQOS_QUERY_RESPONSE		0x6507
#define IE_PQOS_MAINTENANCE_COMPLETE	0x6508
#define IE_FMR_RESPONSE			0x6509
#define IE_MR_RESPONSE			0x650a
#define IE_MR_COMPLETE			0x650b
#define IE_LOF				0x7001
#define IE_ABORT			0xf200
#define IE_DRV_PRINTF			0xff00
#define IE_MOCAD_PRINTF			0xff01
#define IE_WDT				0xff01

struct moca_lab_printf {
	uint32_t		str_ptr;
	uint32_t		str_len;
} __attribute__((packed,aligned(4)));

struct moca_lab_printf_codes {
	uint32_t		code;
	uint32_t		param;
} __attribute__((packed,aligned(4)));

struct moca_sig_y_ready {
	uint32_t		lmo_counter;
	uint32_t		descriptor_addr;
	uint32_t		numberOfSymbales;
	uint32_t		min_cp_threshold;
	uint32_t		firstTime2_calc_cp;
	uint32_t		reg_pp_cc_maxf_th_scl;
	uint32_t		g_pp_cc_maxf_th_scl;
	uint32_t		g_cp_min;
	uint32_t		g_cp_max;
	uint32_t		reg_pp_cc_avg_length;
} __attribute__((packed,aligned(4)));

struct moca_mips_exception {
	uint32_t		err_code;
	uint32_t		zero;
	uint32_t		cp0_epc;
	uint32_t		cp0_cause;
	uint32_t		cp0_status;
	uint32_t		cp0_errorepc;
} __attribute__((packed,aligned(4)));

struct moca_drv_printf {
	int8_t			msg[104];
} __attribute__((packed,aligned(4)));

int __moca_set_start_moca_core(void *vctx, uint32_t phy_freq);

struct mocalib_cb_tbl {
	void			(*power_up_status_cb)(void *, uint32_t status);
	void			*power_up_status_userarg;

	void			(*link_up_state_cb)(void *, uint32_t status);
	void			*link_up_state_userarg;

	void			(*admission_status_cb)(void *, uint32_t status);
	void			*admission_status_userarg;

	void			(*limited_bw_cb)(void *, uint32_t bw_status);
	void			*limited_bw_userarg;

	void			(*error_cb)(void *, uint32_t error_id);
	void			*error_userarg;

	void			(*lmo_info_cb)(void *, struct moca_lmo_info *);
	void			*lmo_info_userarg;

	void			(*key_changed_cb)(void *, struct moca_key_changed *);
	void			*key_changed_userarg;

	void			(*topology_changed_cb)(void *, uint32_t nodemask);
	void			*topology_changed_userarg;

	void			(*moca_version_changed_cb)(void *, uint32_t new_version);
	void			*moca_version_changed_userarg;

	void			(*ucfwd_update_cb)(void *);
	void			*ucfwd_update_userarg;

	void			(*moca_reset_request_cb)(void *, uint32_t cause);
	void			*moca_reset_request_userarg;

	void			(*nc_id_changed_cb)(void *, uint32_t new_nc_id);
	void			*nc_id_changed_userarg;

	void			(*pqos_create_response_cb)(void *, struct moca_pqos_create_response *);
	void			*pqos_create_response_userarg;

	void			(*pqos_create_complete_cb)(void *, struct moca_pqos_create_complete *);
	void			*pqos_create_complete_userarg;

	void			(*pqos_update_response_cb)(void *, struct moca_pqos_update_response *);
	void			*pqos_update_response_userarg;

	void			(*pqos_update_complete_cb)(void *, struct moca_pqos_update_complete *);
	void			*pqos_update_complete_userarg;

	void			(*pqos_delete_response_cb)(void *, struct moca_pqos_delete_response *);
	void			*pqos_delete_response_userarg;

	void			(*pqos_delete_complete_cb)(void *, struct moca_pqos_delete_complete *);
	void			*pqos_delete_complete_userarg;

	void			(*pqos_list_response_cb)(void *, struct moca_pqos_list_response *);
	void			*pqos_list_response_userarg;

	void			(*pqos_query_response_cb)(void *, struct moca_pqos_query_response *);
	void			*pqos_query_response_userarg;

	void			(*pqos_maintenance_complete_cb)(void *, struct moca_pqos_maintenance_complete *);
	void			*pqos_maintenance_complete_userarg;

	void			(*fmr_response_cb)(void *, struct moca_fmr_response *);
	void			*fmr_response_userarg;

	void			(*mr_response_cb)(void *, struct moca_mr_response *);
	void			*mr_response_userarg;

	void			(*mr_complete_cb)(void *, struct moca_mr_complete *);
	void			*mr_complete_userarg;

	void			(*lof_cb)(void *, uint32_t lof);
	void			*lof_userarg;

	void			(*mocad_printf_cb)(void *, struct moca_mocad_printf *);
	void			*mocad_printf_userarg;

};

/* GENERATED DECLARATIONS ABOVE THIS LINE - DO NOT EDIT */

#define MoCAOS_IFNAMSIZE 16

struct moca_ctx
{
	MUTEX_T			lock;

	MoCAOS_ClientHandle			connect_fd;
    MoCAOS_ClientHandle         mocad_rx_fd;

	uint8_t			in_buf[MOCA_BIG_BUF_LEN];
	uint8_t			out_buf[MOCA_BUF_LEN];
	uint8_t			evt_buf[MOCA_BUF_LEN];

	struct mocalib_cb_tbl	cb;
	char			ifname[MoCAOS_IFNAMSIZE];
};

#ifdef __cplusplus
}
#endif

#endif /* ! _MOCAINT_H_ */
