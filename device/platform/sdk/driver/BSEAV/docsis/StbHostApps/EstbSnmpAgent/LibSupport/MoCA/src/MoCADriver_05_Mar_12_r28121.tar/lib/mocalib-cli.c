/******************************************************************************
 *
 *  Copyright (c) 2009  Broadcom Corporation
 *  All Rights Reserved
 *
<:license-private
 *
 ************************************************************************/
#include <math.h>
#include "devctl_moca.h"
#include "mocalib.h"
#include "mocalib-cli.h"


static int IsSupportedMoCAFrequency ( unsigned int freq )
{
   switch ( freq ) {
      case MoCA_NULL_FREQ_MHZ:
      /* MidRF - low */
      case 500 :
      case 525 :
      case 550 :
      case 575 :
      case 600 :
      /* MidRF - hi */
      case 675:
      case 700:
      case 725:
      case 750:
      case 775:
      case 800:
      case 825:
      case 850:
      /* H BAND */
      case 975:
      case 1000 :
      case 1025 :
      /* LAN */
      case 1150 : 
      case 1200 : 
      case 1250 : 
      case 1300 : 
      case 1350 : 
      case 1400 :
      case 1450 : 
      case 1500 :
      case MoCA_FREQ_UNSET:
         return 1;

      default :
         return 0;
   }
}

int ParseMacAddress ( char * macAddrString, MAC_ADDRESS * pMacAddr )
{
   char * mac;
   char * mac1;
   UINT32 i;
   
   mac = macAddrString;
   
   for ( i = 0; i < sizeof(MAC_ADDRESS); i++ ) 
   {
      (*pMacAddr)[i] = (UINT8)( strtol( mac, &mac1, 16) );
      if ((i < (sizeof(MAC_ADDRESS) - 1)) && (*mac1 != ':') && (*mac1 != '.'))
         return (-1);
      if (mac == mac1)
         return (-1);

      mac1++;
      mac = mac1;
   }

   return (0);
}


/** Parses a moca cli argument type.
 *
 * This function parses "moca" CLI commands returns the argument type of
 * the supplied string.
 *
 * @param pszArg (IN) String pointer to the command line arguments.
 * @param pCmds (IN) Pointer to (global) array of moca commands.
 * @param ppszOptions (IN) Pointer to string array of options.
 * @return One of: ARG_TYPE_COMMAND, ARG_TYPE_OPTION, ARG_TYPE_PARAMETER.
 */
int mocacli_get_arg_type( char *pszArg, PCOMMAND_INFO pCmds, char **ppszOptions )
{
   int nArgType = ARG_TYPE_PARAMETER;

   /* See if the argument is a option. */
   if( ppszOptions )
   {
      do
      {
         if( !strcmp( pszArg, *ppszOptions) )
         {
            nArgType = ARG_TYPE_OPTION;
            break;
         }
      } while( *++ppszOptions );
   }

   /* Next, see if the argument is an command. */
   if( nArgType == ARG_TYPE_PARAMETER )
   {
      while( pCmds->szCmdName[0] != '\0' )
      {
         if( !strcmp( pszArg, pCmds->szCmdName ) )
         {
            nArgType = ARG_TYPE_COMMAND;
            break;
         }

         pCmds++;
      }
   }

   /* Otherwise, assume that it is a parameter. */

   return( nArgType );
} /* GetArgType */


/** Parses a moca cli command string.
 *
 * This function parses "moca" CLI string and returns the command that 
 * matches from the pCmds array.
 *
 * @param pszArg (IN) String pointer to the command line arguments.
 * @param pCmds (IN) Pointer to (global) array of moca commands.
 * @return Pointer to PCOMMAND_INFO entry from pCmds matching supplied 
 * string.
 */
PCOMMAND_INFO mocacli_get_command( char *pszArg, PCOMMAND_INFO pCmds )
{
   PCOMMAND_INFO pCmd = NULL;

   while( pCmds->szCmdName[0] != '\0' )
   {
      if( !strcmp( pszArg, pCmds->szCmdName ) )
      {
         pCmd = pCmds;
         break;
      }

      pCmds++;
   }

   return( pCmd );
} /* GetCommand */


/** Processes a moca cli command.
 *
 * Gets the options and option paramters for a command and
 * calls the command handler function to process the command.
 *
 * @param pszPgmName (IN) string pointer to applciation name used for error 
 * prints
 * @param pCmd (IN) Pointer to the command info.
 * @param argc (IN) Number of command line arguments
 * @param argv (IN) String array of command line arguments
 * @param pCmds (IN) Pointer to global array of CLI commands
 * @param pnArgNext (OUT) Argument count of next argument following this 
 *    command's completion
 * @return 0 - success, non-0 - error
 */
int mocacli_process_command( 
	char * pszPgmName,
	PCOMMAND_INFO pCmd, 
	int argc, 
	char **argv,
	PCOMMAND_INFO pCmds, 
	int *pnArgNext )
{
   int nRet = 0;
   static OPTION_INFO OptInfo[MAX_OPTS]; // static, too large to fit on stack in some cases
   OPTION_INFO *pCurrOpt = NULL;
   int nNumOptInfo = 0;
   int nArgType = 0;
	PCOMMAND_INFO pHelpCmd = NULL;

   memset( OptInfo, 0x00, sizeof(OptInfo) );
   *pnArgNext = 0;

   do
   {
      if( argc == 0 )
         break;

      nArgType = mocacli_get_arg_type( *argv, pCmds, pCmd->pszOptionNames );
      switch( nArgType )
      {
         case ARG_TYPE_OPTION:
            if( nNumOptInfo < MAX_OPTS )
            {
               pCurrOpt = &OptInfo[nNumOptInfo++];
               pCurrOpt->pszOptName = *argv;
            }
            else
            {
               nRet = -1;
               fprintf( stderr, "%s: too many options\n", pszPgmName );
            }
            (*pnArgNext)++;
            break;

         case ARG_TYPE_PARAMETER:
            if( pCurrOpt && pCurrOpt->nNumParms < MAX_PARMS )
            {
               pCurrOpt->pszParms[pCurrOpt->nNumParms++] = *argv;
            }
            else
            {
               if( pCurrOpt )
               {
                  nRet = -1;
                  fprintf( stderr, "%s: invalid option\n", pszPgmName );
               }
               else
               {
                  nRet = -1;
                  fprintf( stderr, "%s: too many options\n", pszPgmName );
               }
            }
            (*pnArgNext)++;
            break;

         case ARG_TYPE_COMMAND:
            /* The current command is done. */
            break;
      }

      argc--, argv++;
   } while( nRet == 0 && nArgType != ARG_TYPE_COMMAND );


   if( nRet == 0 )
      nRet = (*pCmd->pfnCmdHandler) (OptInfo, nNumOptInfo);
   else {
		/* Try to run a help command if it exists */
		pHelpCmd = mocacli_get_command("help", pCmds);
		if (pHelpCmd != NULL)
			pHelpCmd->pfnCmdHandler(NULL, 0);
   }

   return( nRet );
} /* ProcessCommand */


/** Parses moca initialization parmaters from cli input
 *
 * Parses the pOptions array and populates the pParms structure,
 * pu32Mask, and plocal structure based on the input.
 *
 * @param pszPgmName (IN) string pointer to applciation name used for error 
 * prints
 * @param pOptions (IN) Pointer to the CLI options.
 * @param nNumOptions (IN) Number of command line options
 * @param pParms (OUT) MoCA initialization parameters as parsed from 
 * CLI string
 * @param pu32Mask (OUT) Bit mask of init parameters set by CLI string
 * @param plocal (OUT) Extra information parsed from CLI string to be used
 * locally by the CLI application
 * @return 0 - success, non-0 - error
 */
int mocacli_parse_init_parms (
	char * pszPgmName, 
	POPTION_INFO pOptions, 
	int nNumOptions, 
	PMoCA_INITIALIZATION_PARMS pParms, 
	uint64_t *pu32Mask)
{
   uint32_t   *pulValue, *puxValue;
   signed int *plValue;
   int         nRet = 0;
   int         i;
   char        *pszEnd = NULL;


   pParms->nvParams.lastOperFreq = MoCA_FREQ_UNSET; // unconfigured

   while( nRet == 0 && nNumOptions )
   {
      pulValue = puxValue = NULL ;
      plValue = NULL ;

      if( !strcmp(pOptions->pszOptName, "--nc") ) {

         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "auto" ) )
               pParms->ncMode = MoCA_AUTO_NEGOTIATE_FOR_NC ;
            else if( !strcmp( pOptions->pszParms[0], "on" ) )
               pParms->ncMode = MoCA_ALWAYS_NC ;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pParms->ncMode = MoCA_NEVER_NC ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName ) ;
         *pu32Mask |= MoCA_INIT_PARAM_NC_MODE_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--autoScan") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pParms->autoNetworkSearchEn = MoCA_AUTO_NW_SCAN_ENABLED ;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pParms->autoNetworkSearchEn = MoCA_AUTO_NW_SCAN_DISABLED_NOTABOO ;
            else if( !strcmp( pOptions->pszParms[0], "off2" ) )
               pParms->autoNetworkSearchEn = MoCA_AUTO_NW_SCAN_DISABLED ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         *pu32Mask |= MoCA_INIT_PARAM_AUTO_NETWORK_SEARCH_EN_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--singleCh") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pParms->autoNetworkSearchEn = MoCA_AUTO_NW_SCAN_DISABLED ;
            else if( !strcmp( pOptions->pszParms[0], "on2" ) )
               pParms->autoNetworkSearchEn = MoCA_AUTO_NW_SCAN_DISABLED_NOTABOO ;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pParms->autoNetworkSearchEn = MoCA_AUTO_NW_SCAN_ENABLED ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         *pu32Mask |= MoCA_INIT_PARAM_AUTO_NETWORK_SEARCH_EN_MASK ;
      }
      
      else if( !strcmp(pOptions->pszOptName, "--privacy") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pParms->privacyEn = MoCA_PRIVACY_ENABLED ;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pParms->privacyEn = MoCA_PRIVACY_DISABLED ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         *pu32Mask |= MoCA_INIT_PARAM_PRIVACY_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--tpc") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pParms->txPwrControlEn = MoCA_TPC_ENABLED ;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pParms->txPwrControlEn = MoCA_TPC_DISABLED ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         *pu32Mask |= MoCA_INIT_PARAM_TX_PWR_CONTROL_EN_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--constTxMode") )
      {
         if( !strcmp( pOptions->pszParms[0], "band" ) )
         {
            int startBand, endBand;
            
            pParms->constTransmitMode = MoCA_CONTINUOUS_TX_BAND;
            *pu32Mask |= MoCA_INIT_PARAM_OPTIONS_MASK ;
            memset(&pParms->initOptions.constTxNoiseBand[0], 0, 
                   sizeof(pParms->initOptions.constTxNoiseBand));

            for (i = 1; i < pOptions->nNumParms; i++)
            {
               startBand = strtoul ( pOptions->pszParms[i], &pszEnd, 0 );
               if ((startBand < MoCA_CONTINUOUS_TX_BAND_MIN) ||
                   (startBand > MoCA_CONTINUOUS_TX_BAND_MAX))
               {
                  nRet = -1;
                  break;
               }

               if (*pszEnd == ',')
               {
                  pszEnd++;
                  endBand = strtoul ( pszEnd, &pszEnd, 0 );
                  if ((endBand < startBand) ||
                      (endBand > MoCA_CONTINUOUS_TX_BAND_MAX))
                  {
                     nRet = -1;
                     break;
                  }
               }
               else 
               {
                  endBand = startBand;
               }

               for (; startBand <= endBand; startBand++)
               {
                  pParms->initOptions.constTxNoiseBand[(startBand - 1) / 32] |=
                     (0x80000000 >> ((startBand - 1) % 32));
               }
            }
         }
         else if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "normal" ) )
               pParms->constTransmitMode = MoCA_NORMAL_OPERATION ;
            else if( !strcmp( pOptions->pszParms[0], "tx" ) )
               pParms->constTransmitMode = MoCA_CONTINUOUS_TX_PROBE_I ;
            else if( !strcmp( pOptions->pszParms[0], "rx" ) )
               pParms->constTransmitMode = MoCA_CONTINUOUS_RX ;
            else if( !strcmp( pOptions->pszParms[0], "rxlo" ) )
               pParms->constTransmitMode = MoCA_CONTINUOUS_RX_LO_ON ;            
             else if( !strcmp( pOptions->pszParms[0], "tone" ) )
               pParms->constTransmitMode = MoCA_CONTINUOUS_TX_TONE ;
            else if( !strcmp( pOptions->pszParms[0], "cw" ) )
               pParms->constTransmitMode = MoCA_CONTINUOUS_TX_CW;
            else
               nRet = -1 ;
         }
         else if( pOptions->nNumParms == 2)
         {
            if( !strcmp( pOptions->pszParms[0], "tone" ) ) {

               pParms->constTransmitMode = MoCA_CONTINUOUS_TX_TONE_SC ;
               pParms->initOptions.constTxSubCarrier1 = (long) strtol ( pOptions->pszParms[1], &pszEnd, 0 ) ;
               if( *pszEnd != '\0' )
                  nRet = -1;
               *pu32Mask |= MoCA_INIT_PARAM_OPTIONS_MASK ;
            }
            else
               nRet = -1;
         }
         else if( pOptions->nNumParms == 3)
         {
            if( !strcmp( pOptions->pszParms[0], "tone" ) ) {
               pParms->constTransmitMode = MoCA_CONTINUOUS_TX_DUAL_TONE_SC ;

               pParms->initOptions.constTxSubCarrier1 = (long) strtol ( pOptions->pszParms[1], &pszEnd, 0 ) ;
               if( *pszEnd != '\0' )
                  nRet = -1;
               else {
                  pParms->initOptions.constTxSubCarrier2 = (long) strtol ( pOptions->pszParms[2], &pszEnd, 0 ) ;
                  if( *pszEnd != '\0' )
                     nRet = -1;
               }
               *pu32Mask |= MoCA_INIT_PARAM_OPTIONS_MASK ;
            }
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         *pu32Mask |= MoCA_INIT_PARAM_CONST_TRANSMIT_MODE_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--maxTxPower") )
      {
         plValue = &pParms->maxTxPowerBeacons ;
         *pu32Mask |= MoCA_INIT_PARAM_MAX_TX_POWER_BEACONS_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--beaconChannel") )
      {
         pulValue = &pParms->beaconChannel;
         *pu32Mask |= MoCA_INIT_PARAM_BEACON_CHANNEL_MASK ;
      }       
      else if( !strcmp(pOptions->pszOptName, "--mrNonDefSeqNum") )
      {
         pulValue = &pParms->mrNonDefSeqNum ;
         *pu32Mask |= MoCA_INIT_PARAM_MR_NON_DEF_SEQ_NUM_MASK ;
      }   
      else if( !strcmp(pOptions->pszOptName, "--backoffMode") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "slow" ) )
               pParms->boMode= MoCA_BO_MODE_SLOW;
            else if( !strcmp( pOptions->pszParms[0], "fast" ) )
               pParms->boMode = MoCA_BO_MODE_FAST;
            else
            {
                            fprintf(stderr,"parms = %s\n", pOptions->pszParms[0]);
               nRet = -1 ;
            }
         }
         else {
            fprintf(stderr,"numparms = %d\n", pOptions->nNumParms);
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );

         *pu32Mask |= MoCA_INIT_PARAM_BO_MODE_MASK ;
      }       
      else if( !strcmp(pOptions->pszOptName, "--egrMcFilter") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pParms->egrMcFilterEn= MoCA_EGR_MC_FILTER_ENABLED;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pParms->egrMcFilterEn= MoCA_EGR_MC_FILTER_DISABLED;
            else
            {
               fprintf(stderr,"parms = %s\n", pOptions->pszParms[0]);
               nRet = -1 ;
            }
         }
         else {
            fprintf(stderr,"numparms = %d\n", pOptions->nNumParms);
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );

         *pu32Mask |= MoCA_INIT_PARAM_EGR_MC_FILTER_EN_MASK ;
      }             
      else if( !strcmp(pOptions->pszOptName, "--lowPriQNum") )
      {
         if( pOptions->nNumParms == 1)
         {
            pulValue = &pParms->lowPriQNum;
            *pu32Mask |= MoCA_INIT_PARAM_LOW_PRI_Q_NUM_MASK ;
         }
         else {
            fprintf(stderr,"numparms = %d\n", pOptions->nNumParms);
            nRet = -1;
         }
      }             
      else if( !strcmp(pOptions->pszOptName, "--qam256Capability") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pParms->qam256Capability = MoCA_QAM256_CAPABILITY_ENABLED;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pParms->qam256Capability = MoCA_QAM256_CAPABILITY_DISABLED;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );

         *pu32Mask |= MoCA_INIT_PARAM_QAM256_CAPABILITY_MASK ;
      }   
      else if( !strcmp(pOptions->pszOptName, "--continuousRxModeAttn") )
      {
         plValue = &pParms->continuousRxModeAttn ;
         *pu32Mask |= MoCA_INIT_PARAM_CONTINUOUS_RX_MODE_ATTN_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--rfType") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "hi" ) )
               pParms->rfType= MoCA_RF_TYPE_D_BAND;
            else if( !strcmp( pOptions->pszParms[0], "midlo" ) )
               pParms->rfType = MoCA_RF_TYPE_E_BAND;
            else if( !strcmp( pOptions->pszParms[0], "midhi" ) )
               pParms->rfType = MoCA_RF_TYPE_F_BAND;
            else if( !strcmp( pOptions->pszParms[0], "wan" ) )
               pParms->rfType = MoCA_RF_TYPE_C4_BAND;
            else if( !strcmp( pOptions->pszParms[0], "bandD" ) )
               pParms->rfType= MoCA_RF_TYPE_D_BAND;
            else if( !strcmp( pOptions->pszParms[0], "bandE" ) )
               pParms->rfType = MoCA_RF_TYPE_E_BAND;
            else if( !strcmp( pOptions->pszParms[0], "bandF" ) )
               pParms->rfType = MoCA_RF_TYPE_F_BAND;
            else if( !strcmp( pOptions->pszParms[0], "bandH" ) )
               pParms->rfType = MoCA_RF_TYPE_H_BAND;
            else if( !strcmp( pOptions->pszParms[0], "bandC4" ) )
               pParms->rfType = MoCA_RF_TYPE_C4_BAND;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );

         *pu32Mask |= MoCA_INIT_PARAM_RF_TYPE_MASK ;
      }             
      else if( !strcmp(pOptions->pszOptName, "--password") )
      {
         if( pOptions->nNumParms == 1)
         {
            pParms->passwordSize = (UINT32)strlen (pOptions->pszParms[0]) ;
            strcpy ((char *)(pParms->password), pOptions->pszParms[0]) ;
         }
         else {
            nRet = -1;
         }
         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         *pu32Mask |= MoCA_INIT_PARAM_PASSWORD_SIZE_MASK ;
         *pu32Mask |= MoCA_INIT_PARAM_PASSWORD_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--lof") )
      {
         pulValue = &pParms->nvParams.lastOperFreq ;
         *pu32Mask |= MoCA_INIT_PARAM_NV_PARAMS_LOF_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--mcastMode") ) {

         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "normal" ) )
               pParms->mcastMode = MoCA_MCAST_NORMAL_MODE ;
            else if( !strcmp( pOptions->pszParms[0], "bcast" ) )
               pParms->mcastMode = MoCA_MCAST_BCAST_MODE ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         *pu32Mask |= MoCA_INIT_PARAM_MCAST_MODE_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--labMode") ) {

         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pParms->labMode = MoCA_LAB_MODE ;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pParms->labMode = MoCA_NORMAL_MODE ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         *pu32Mask |= MoCA_INIT_PARAM_LAB_MODE_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--tabooFixedMaskStart") )
      {
         pulValue = &pParms->tabooFixedMaskStart ;
         *pu32Mask |= MoCA_INIT_PARAM_TABOO_FIXED_MASK_START_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--tabooFixedChannelMask") )
      {
         puxValue = &pParms->tabooFixedChannelMask ;
         *pu32Mask |= MoCA_INIT_PARAM_TABOO_FIXED_CHANNEL_MASK_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--tabooLeftMask") )
      {
         puxValue = &pParms->tabooLeftMask ;
         *pu32Mask |= MoCA_INIT_PARAM_TABOO_LEFT_MASK_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--tabooRightMask") )
      {
         puxValue = &pParms->tabooRightMask ;
         *pu32Mask |= MoCA_INIT_PARAM_TABOO_RIGHT_MASK_MASK ;
      }            
      else if( !strcmp(pOptions->pszOptName, "--res1") )
      {
         pulValue = &pParms->reservedInit1 ;
         *pu32Mask |= MoCA_INIT_PARAM_RESERVED_INIT_1_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--res2") )
      {
         pulValue = &pParms->reservedInit2 ;
         *pu32Mask |= MoCA_INIT_PARAM_RESERVED_INIT_2_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--res3") )
      {
         pulValue = &pParms->reservedInit3 ;
         *pu32Mask |= MoCA_INIT_PARAM_RESERVED_INIT_3_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--res4") )
      {
         pulValue = &pParms->reservedInit4 ;
         *pu32Mask |= MoCA_INIT_PARAM_RESERVED_INIT_4_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--res5") )
      {
         pulValue = &pParms->reservedInit5 ;
         *pu32Mask |= MoCA_INIT_PARAM_RESERVED_INIT_5_MASK ;
      }            
      else if( !strcmp(pOptions->pszOptName, "--padPower") )
      {
         plValue = &pParms->padPower ;
         *pu32Mask |= MoCA_INIT_PARAM_PAD_POWER_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--beaconPwrReduction") )
      {
         pulValue = &pParms->beaconPwrReduction ;
         *pu32Mask |= MoCA_INIT_PARAM_BEACON_PWR_REDUCTION_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--beaconPwrReductionEn")  || 
               !strcmp(pOptions->pszOptName, "--agcOnDiversityEn") )
      {
         pulValue = &pParms->beaconPwrReductionEn;
         *pu32Mask |= MoCA_INIT_PARAM_BEACON_PWR_REDUCTION_EN_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--nodeType") )
      {
          if( pOptions->nNumParms == 1)
          {
             if( !strcmp( pOptions->pszParms[0], "terminal" ) )
                pParms->terminalIntermediateType= MoCA_NODE_TYPE_TERMINAL ;
             else if( !strcmp( pOptions->pszParms[0], "intermediate" ) )
                pParms->terminalIntermediateType = MoCA_NODE_TYPE_INTERMEDIATE ;
             else
             {
                nRet = -1 ;
             }
          }
          else {
             nRet = -1;
          }
          
          if( nRet != 0 )
             fprintf( stderr, "%s: invalid parameter for option %s\n",
                   pszPgmName, pOptions->pszOptName );
         
         *pu32Mask |= MoCA_INIT_PARAM_TERMINAL_INTERMEDIATE_TYPE_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--version") )
      {
         puxValue = (uint32_t *)&pParms->operatingVersion ;
         *pu32Mask |= MoCA_INIT_PARAM_OPERATING_VERSION_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--preferedNC") || 
               !strcmp(pOptions->pszOptName, "--preferredNC") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pParms->preferedNC = MoCA_PREFERED_NC_MODE ;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pParms->preferedNC = MoCA_NO_PREFERED_NC_MODE ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         *pu32Mask |= MoCA_INIT_PARAM_PREFERED_NC_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--ledMode") )
      {
         pulValue = (uint32_t *)&pParms->ledMode ;
         *pu32Mask |= MoCA_INIT_PARAM_LED_MODE_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--freqMask") )
      {
         puxValue = (uint32_t *)&pParms->freqMask ;
         *pu32Mask |= MoCA_INIT_PARAM_FREQ_MASK_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--pnsFreqMask") )
      {
         puxValue = (uint32_t *)&pParms->pnsFreqMask ;
         *pu32Mask |= MoCA_INIT_PARAM_PNS_FREQ_MASK_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--otfEn") )
      {
         pulValue = (uint32_t *)&pParms->otfEn;
         *pu32Mask |= MoCA_INIT_PARAM_OTF_EN_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--flowControlEn") )
      {
         pulValue = (uint32_t *)&pParms->flowControlEn;
         *pu32Mask |= MoCA_INIT_PARAM_FLOW_CONTROL_EN_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--mtmEn") )
      {
         pulValue = (uint32_t *)&pParms->mtmEn;
         *pu32Mask |= MoCA_INIT_PARAM_MTM_EN_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--qam1024En") )
      {
         pulValue = (uint32_t *)&pParms->qam1024En;
         *pu32Mask |= MoCA_INIT_PARAM_QAM1024_EN_MASK ;
      }  
       else if( !strcmp(pOptions->pszOptName, "--T50TimeMin") )
      {
         pulValue = (uint32_t *)&pParms->T50TimeMin;
         *pu32Mask |= MoCA_INIT_PARAM_T50_TIME_MIN_MASK ;
      }     
      else if( !strcmp(pOptions->pszOptName, "--T50TimeMax") )
      {
         pulValue = (uint32_t *)&pParms->T50TimeMax;
         *pu32Mask |= MoCA_INIT_PARAM_T50_TIME_MAX_MASK ;
      }        
      else if( !strcmp(pOptions->pszOptName, "--turboEn") )
      {
         pulValue = (uint32_t *)&pParms->turboEn;
         *pu32Mask |= MoCA_INIT_PARAM_TURBO_EN_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--wait") )
      {
         pulValue = (uint32_t *)&pParms->initOptions.dontStartMoca;
         *pu32Mask |= MoCA_INIT_PARAM_OPTIONS_MASK ;
      }
      else        
      {
         nRet = -1;
         fprintf( stderr, "%s: invalid option %s\n", pszPgmName,
               pOptions->pszOptName );
      }

      if( pulValue || puxValue )
      {
         /* Convert the value for a particular option to an integer. */
         if( pOptions->nNumParms == 1 )
         {
            if (pulValue)
               *pulValue = (long) strtol ( pOptions->pszParms[0], &pszEnd, 10 ) ;
            else if (puxValue)
               *puxValue = (long) strtoul ( pOptions->pszParms[0], &pszEnd, 16 ) ;

            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter %s for option %s\n",
                     pszPgmName, pOptions->pszParms[0], pOptions->pszOptName );
            }
         }
         else
         {
            nRet = -1;
            fprintf( stderr, "%s: invalid number of parameters for option "
                  "%s\n", pszPgmName, pOptions->pszOptName );
         }
      }
      else if( plValue )
      {
         /* Convert the value for a particular option to an integer. */
         if( pOptions->nNumParms == 1 )
         {
            *plValue = (signed long) strtol( pOptions->pszParms[0], &pszEnd, 10 );
            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     pszPgmName, pOptions->pszOptName );
            }
         }
         else
         {
            nRet = -1;
            fprintf( stderr, "%s: invalid number of parameters for option "
                  "%s\n", pszPgmName, pOptions->pszOptName );
         }
      }

      nNumOptions--;
      pOptions++;
   }

   if ( (*pu32Mask & MoCA_INIT_PARAM_NV_PARAMS_LOF_MASK) &&
        !IsSupportedMoCAFrequency (pParms->nvParams.lastOperFreq) ) {
      fprintf( stderr, "Warning: %u is not a standard MoCA frequency.\n", pParms->nvParams.lastOperFreq ) ;
   }
      
   return nRet ;
}

static void mocacli_calc_sapm_gsm(
   int moca_freq, int gsm_freq,
   struct _sapmTable * sapm_table_out)
{
   int k;
   int L;
   int tI;
   int L1, L2, M;
   int i = 0;
   static uint32_t sapm_gsm_filter[224];

   /* Default GSM filter table for SAPM. The units are in 0.5 dB */
   sapm_gsm_filter[i++] = 1;
   sapm_gsm_filter[i++] = 2;
   sapm_gsm_filter[i++] = 3;
   sapm_gsm_filter[i++] = 4;
   sapm_gsm_filter[i++] = 5;
   sapm_gsm_filter[i++] = 6;
   sapm_gsm_filter[i++] = 7;
   sapm_gsm_filter[i++] = 8;
   sapm_gsm_filter[i++] = 9;
   sapm_gsm_filter[i++] = 10;
   sapm_gsm_filter[i++] = 12;
   sapm_gsm_filter[i++] = 13;
   sapm_gsm_filter[i++] = 14;
   sapm_gsm_filter[i++] = 16;
   sapm_gsm_filter[i++] = 17;
   sapm_gsm_filter[i++] = 19;
   sapm_gsm_filter[i++] = 20;
   sapm_gsm_filter[i++] = 21;
   sapm_gsm_filter[i++] = 23;
   sapm_gsm_filter[i++] = 24;
   sapm_gsm_filter[i++] = 28;
   sapm_gsm_filter[i++] = 32;
   sapm_gsm_filter[i++] = 36;
   sapm_gsm_filter[i++] = 40;
   sapm_gsm_filter[i++] = 44;
   sapm_gsm_filter[i++] = 48;
   sapm_gsm_filter[i++] = 52;
   sapm_gsm_filter[i++] = 56;
   sapm_gsm_filter[i++] = 60;
   sapm_gsm_filter[i++] = 64;
   sapm_gsm_filter[i++] = 68;
   sapm_gsm_filter[i++] = 72;
   sapm_gsm_filter[i++] = 76;
   sapm_gsm_filter[i++] = 80;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 84;
   sapm_gsm_filter[i++] = 80;
   sapm_gsm_filter[i++] = 76;
   sapm_gsm_filter[i++] = 72;
   sapm_gsm_filter[i++] = 68;
   sapm_gsm_filter[i++] = 64;
   sapm_gsm_filter[i++] = 60;
   sapm_gsm_filter[i++] = 56;
   sapm_gsm_filter[i++] = 52;
   sapm_gsm_filter[i++] = 48;
   sapm_gsm_filter[i++] = 44;
   sapm_gsm_filter[i++] = 40;
   sapm_gsm_filter[i++] = 36;
   sapm_gsm_filter[i++] = 32;
   sapm_gsm_filter[i++] = 28;
   sapm_gsm_filter[i++] = 24;
   sapm_gsm_filter[i++] = 23;
   sapm_gsm_filter[i++] = 21;
   sapm_gsm_filter[i++] = 20;
   sapm_gsm_filter[i++] = 19;
   sapm_gsm_filter[i++] = 17;
   sapm_gsm_filter[i++] = 16;
   sapm_gsm_filter[i++] = 14;
   sapm_gsm_filter[i++] = 13;
   sapm_gsm_filter[i++] = 12;
   sapm_gsm_filter[i++] = 10;
   sapm_gsm_filter[i++] = 9;
   sapm_gsm_filter[i++] = 8;
   sapm_gsm_filter[i++] = 7;
   sapm_gsm_filter[i++] = 6;
   sapm_gsm_filter[i++] = 5;
   sapm_gsm_filter[i++] = 4;
   sapm_gsm_filter[i++] = 3;
   sapm_gsm_filter[i++] = 2;
   sapm_gsm_filter[i++] = 1;

   L = (i - 1) / 2;

   M = (((gsm_freq - moca_freq) * 256) / 50);

   L1 = M - L;
   L2 = M + L;

   for (k = 0; k < 112; k++)
   {
      tI= -(k + 4);

      if ((tI >= L1) && (tI <= L2))
      {
         sapm_table_out->sapmTableLo[k] = sapm_gsm_filter[tI - L1];
      }
      else
      {
         sapm_table_out->sapmTableLo[k] = 0;
      }

      tI = 114 - k;

      if ((tI >= L1) && (tI <= L2))
      {
         sapm_table_out->sapmTableHi[k] = sapm_gsm_filter[tI - L1];
      }
      else
      {
         sapm_table_out->sapmTableHi[k] = 0;
      }
   }
}


/** Parses moca configuration parmaters from cli input
 *
 * Parses the pOptions array and populates the pConfigParms structure,
 * and pConfigMask based on the input.
 *
 * @param pszPgmName (IN) string pointer to applciation name used for error 
 * prints
 * @param pOptions (IN) Pointer to the CLI options.
 * @param nNumOptions (IN) Number of command line options
 * @param pConfigParms (OUT) MoCA configuration parameters as parsed from 
 * CLI string
 * @param pConfigMask (OUT) Bit mask of init parameters set by CLI string
 * @return 0 - success, non-0 - error
 */
int mocacli_parse_config_parms ( 
   char * pszPgmName, 
   POPTION_INFO pOptions, 
   int nNumOptions,
   MoCA_CONFIG_PARAMS * pConfigParms,
   unsigned long long * pConfigMask,
   MoCA_CONFIG_PARAMS * pCurrParms)
{
   int nRet = 0;
   uint32_t *pulValue, *puxValue ;
   float *pufValue;
   float  snrMargin, snrMarginOffset [MoCA_MAX_SNR_TBL_INDEX], rlapmCap ;
   uint16_t *pusValue ;
   signed int *plValue;   
   uint32_t constellationNodeId = MoCA_MAX_NODES;
   uint32_t constellationInfo = QAM1024;
   int i ;

   if ( (pszPgmName   == NULL) ||
        (pOptions     == NULL) ||
        (pConfigParms == NULL) ||
        (pConfigMask  == NULL) )
      return -1;

   while( nRet == 0 && nNumOptions )
   {
      pulValue = puxValue = NULL ;
      pusValue = NULL ;
      pufValue = NULL ;
      plValue = NULL;
      
      if( !strcmp(pOptions->pszOptName, "--frameSize") )
      {
         pulValue = &pConfigParms->maxFrameSize ;
         *pConfigMask |= MoCA_CFG_PARAM_MAX_FRAME_SIZE_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--maxTxTime") )
      {
         pulValue = &pConfigParms->maxTransmitTime ;
         *pConfigMask |= MoCA_CFG_PARAM_MAX_TRANS_TIME_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--minBwThreshold") )
      {
         pulValue = &pConfigParms->minBwAlarmThreshold ;
         *pConfigMask |= MoCA_CFG_PARAM_MIN_BW_ALARM_THRE_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--snrMgn") )
      {
         pufValue = &snrMargin ;
      }
      else if( !strcmp(pOptions->pszOptName, "--snrMgnOffset") )
      {
         pufValue = &snrMarginOffset [0] ;
      }
      else if( !strcmp(pOptions->pszOptName, "--outOfOrderLMO") )
      {
         pulValue = &pConfigParms->outOfOrderLmo ;
         *pConfigMask |= MoCA_CFG_PARAM_OUT_OF_ORDER_LMO_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--ieRRInsert") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pConfigParms->continuousIERRInsert = MoCA_CONTINUOUS_IE_RR_INSERT_ON ;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pConfigParms->continuousIERRInsert = MoCA_CONTINUOUS_IE_RR_INSERT_OFF ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         *pConfigMask |= MoCA_CFG_PARAM_CONT_IE_RR_INS_MASK ;
         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--ieMapInsert") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
               pConfigParms->continuousIEMapInsert = MoCA_CONTINUOUS_IE_MAP_INSERT_ON ;
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
               pConfigParms->continuousIEMapInsert = MoCA_CONTINUOUS_IE_MAP_INSERT_OFF ;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         *pConfigMask |= MoCA_CFG_PARAM_CONT_IE_MAP_INS_MASK ;
         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--maxAggr") )
      {
         pulValue = &pConfigParms->maxPktAggr ;
         *pConfigMask |= MoCA_CFG_PARAM_MAX_PKT_AGGR_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--res1") )
      {
         pulValue = &pConfigParms->res1 ;
         *pConfigMask |= MoCA_CFG_PARAM_RES_1_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--res2") )
      {
         pulValue = &pConfigParms->res2 ;
         *pConfigMask |= MoCA_CFG_PARAM_RES_2_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--res3") )
      {
         pulValue = &pConfigParms->res3 ;
         *pConfigMask |= MoCA_CFG_PARAM_RES_3_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--sapm") )
      {
        int co = 0;
        
        if ( pOptions->nNumParms % 2 == 0)  // ARPL Threshold passed in
        {
            *pConfigMask |= MoCA_CFG_PARAM_ARPL_TH_MASK;
            pConfigParms->arplTh = atoi(pOptions->pszParms[1]);

            if ((pConfigParms->arplTh < MoCA_MIN_ARPL_TH) || 
                (pConfigParms->arplTh > MoCA_MAX_ARPL_TH))
            {
                fprintf( stderr, "%s: margin out of range for option %s\n",
                      pszPgmName, pOptions->pszOptName );
                nRet = -1;
            }
            
            co = 1;
        }

        if (nRet == 0)
        {            
            if (nRet == 0)
            {   

                if ( strcmp(pOptions->pszParms[0], "off") == 0)
                {
                    pConfigParms->sapmEn = 0;
                }
                else if ( strcmp(pOptions->pszParms[0], "reset") == 0)
                {
                    *pConfigMask |= MoCA_CFG_PARAM_SAPM_TABLE_MASK;
                    memset(&pConfigParms->sapmTable, 0x0, sizeof(pCurrParms->sapmTable));

                    if (pOptions->nNumParms % 2 == 1) // ARPL Threshold not passed in
                    {
                        *pConfigMask |= MoCA_CFG_PARAM_ARPL_TH_MASK;
                        pConfigParms->arplTh = MoCA_DEF_ARPL_TH;
                    }
                }
                else
                {            
                    co++;

                    memcpy(&pConfigParms->sapmTable, &pCurrParms->sapmTable, sizeof(pCurrParms->sapmTable));
                    *pConfigMask |= MoCA_CFG_PARAM_SAPM_TABLE_MASK;

                    pConfigParms->sapmEn = 1;
                
                    while (co < pOptions->nNumParms)
                    {
                        int carrier;
                        int firstcarrier = atoi(pOptions->pszParms[co]);
                        int carrierrange = firstcarrier;
                        char *c;
                        float margin = (float)atof(pOptions->pszParms[co+1]);

                        c=strchr(pOptions->pszParms[co],'-');

                        if (c)
                            carrierrange=atoi(c+1);

                        if (carrierrange < firstcarrier)
                        {
                            fprintf( stderr, "%s: backwards range for option %s\n",
                                  pszPgmName, pOptions->pszOptName );
                            nRet = -1;
                            break;
                        }

                        if (((int)(margin*2) < (int)(2*MoCA_MIN_SAPM_TABLE)) || ((int)(margin*2) > (MoCA_MAX_SAPM_TABLE*2)))
                        {
                            fprintf( stderr, "%s: margin out of range for option %s\n",
                                  pszPgmName, pOptions->pszOptName );
                            nRet = -1;
                            break;
                        }

                        for (carrier = firstcarrier; carrier <= carrierrange; carrier++)
                        {
                            if ((carrier >= 4) && (carrier <= 115))
                            {
                                pConfigParms->sapmTable.sapmTableLo[carrier-4] = (int)(margin * 2);
                            }
                            else if ((carrier >= 141) && (carrier <= 252))
                            {
                                pConfigParms->sapmTable.sapmTableHi[carrier-141] = (int)(margin * 2);
                            }
                            else
                            {
                                fprintf( stderr, "%s: invalid carrier for option %s\n",
                                      pszPgmName, pOptions->pszOptName );
                                nRet = -1;
                                break;
                            }
                        }
                        co+=2;
                    }
                }
            }
         }

         *pConfigMask |= MoCA_CFG_PARAM_SAPM_EN_MASK;
      }
      else if( !strcmp(pOptions->pszOptName, "--sapm_LTE") )
      {        
        if ( pOptions->nNumParms % 2 == 0)  // ARPL Threshold passed in
        {
            *pConfigMask |= MoCA_CFG_PARAM_ARPL_TH_MASK;
            pConfigParms->arplTh = atoi(pOptions->pszParms[1]);

            if ((pConfigParms->arplTh < MoCA_MIN_ARPL_TH) || 
                (pConfigParms->arplTh > MoCA_MAX_ARPL_TH))
            {
                fprintf( stderr, "%s: margin out of range for option %s\n",
                      pszPgmName, pOptions->pszOptName );
                nRet = -1;
            }
        }

        if (nRet == 0)
        {
            if (nRet == 0)
            {
                if ( strcmp(pOptions->pszParms[0], "off") == 0)
                {
                    pConfigParms->sapmEn = 0;
                }
                else if ( strcmp(pOptions->pszParms[0], "reset") == 0)
                {
                    *pConfigMask |= MoCA_CFG_PARAM_SAPM_TABLE_MASK;
                    memset(&pConfigParms->sapmTable, 0x0, sizeof(pCurrParms->sapmTable));

                    if (pOptions->nNumParms % 2 == 1) // ARPL Threshold not passed in
                    {
                        *pConfigMask |= MoCA_CFG_PARAM_ARPL_TH_MASK;
                        pConfigParms->arplTh = MoCA_DEF_ARPL_TH;
                    }
                }
                else
                {            
                    // Fixed table
                    *pConfigMask |= MoCA_CFG_PARAM_SAPM_TABLE_MASK;

                    pConfigParms->sapmEn = 1;

                    memset(pConfigParms->sapmTable.sapmTableLo, 0, sizeof(pConfigParms->sapmTable.sapmTableLo));
                    memset(pConfigParms->sapmTable.sapmTableHi, 0, sizeof(pConfigParms->sapmTable.sapmTableHi));


                    pConfigParms->sapmTable.sapmTableLo[36-4] =  1; // 0.29
                    pConfigParms->sapmTable.sapmTableLo[37-4] =  1; // 0.59 
                    pConfigParms->sapmTable.sapmTableLo[38-4] =  2; // 0.88 
                    pConfigParms->sapmTable.sapmTableLo[39-4] =  2; // 1.18 
                    pConfigParms->sapmTable.sapmTableLo[40-4] =  3; // 1.47 
                    pConfigParms->sapmTable.sapmTableLo[41-4] =  4; // 1.76 
                    pConfigParms->sapmTable.sapmTableLo[42-4] =  4; // 2.06 
                    pConfigParms->sapmTable.sapmTableLo[43-4] =  5; // 2.35 
                    pConfigParms->sapmTable.sapmTableLo[44-4] =  5; // 2.65 
                    pConfigParms->sapmTable.sapmTableLo[45-4] =  6; // 2.94 
                    pConfigParms->sapmTable.sapmTableLo[46-4] =  6; // 3.24 
                    pConfigParms->sapmTable.sapmTableLo[47-4] =  7; // 3.53 
                    pConfigParms->sapmTable.sapmTableLo[48-4] =  8; // 3.82 
                    pConfigParms->sapmTable.sapmTableLo[49-4] =  8; // 4.12 
                    pConfigParms->sapmTable.sapmTableLo[50-4] =  9; // 4.41 
                    pConfigParms->sapmTable.sapmTableLo[51-4] =  9; // 4.71 
                    pConfigParms->sapmTable.sapmTableLo[52-4] = 10; // 5.00 
                    pConfigParms->sapmTable.sapmTableLo[53-4] = 18; // 8.75 
                    pConfigParms->sapmTable.sapmTableLo[54-4] = 25; // 12.50 
                    pConfigParms->sapmTable.sapmTableLo[55-4] = 33; // 16.25 
                    pConfigParms->sapmTable.sapmTableLo[56-4] = 40; // 20.00 
                    pConfigParms->sapmTable.sapmTableLo[57-4] = 48; // 23.75 
                    pConfigParms->sapmTable.sapmTableLo[58-4] = 55; // 27.50 
                    pConfigParms->sapmTable.sapmTableLo[59-4] = 63; // 31.25 
                    pConfigParms->sapmTable.sapmTableLo[60-4] = 70; // 35.00 
                    pConfigParms->sapmTable.sapmTableLo[61-4] = 78; // 38.75 
                    pConfigParms->sapmTable.sapmTableLo[62-4] = 85; // 42.50 
                    pConfigParms->sapmTable.sapmTableLo[63-4] = 93; // 46.25 

                    for (i = 64; i <= 115; i++) 
                    {
                        pConfigParms->sapmTable.sapmTableLo[i-4] = 100; // 50.0
                    }
                }
            }
         }

         *pConfigMask |= MoCA_CFG_PARAM_SAPM_EN_MASK;
      }
      else if( !strcmp(pOptions->pszOptName, "--sapm_GSM") )
      {        
        if ( pOptions->nNumParms >= 2 )  // ARPL Threshold passed in
        {
            *pConfigMask |= MoCA_CFG_PARAM_ARPL_TH_MASK;
            pConfigParms->arplTh = atoi(pOptions->pszParms[1]);

            if ((pConfigParms->arplTh < MoCA_MIN_ARPL_TH) || 
                (pConfigParms->arplTh > MoCA_MAX_ARPL_TH))
            {
                fprintf( stderr, "%s: margin out of range for option %s\n",
                      pszPgmName, pOptions->pszOptName );
                nRet = -1;
            }
        }

        if (nRet == 0)
        {            
             if ( strcmp(pOptions->pszParms[0], "off") == 0)
             {
                 pConfigParms->sapmEn = 0;
             }
             else if ( strcmp(pOptions->pszParms[0], "reset") == 0)
             {
                 *pConfigMask |= MoCA_CFG_PARAM_SAPM_TABLE_MASK;
                 memset(&pConfigParms->sapmTable, 0x0, sizeof(pCurrParms->sapmTable));

                 if (pOptions->nNumParms == 1) // ARPL Threshold not passed in
                 {
                     *pConfigMask |= MoCA_CFG_PARAM_ARPL_TH_MASK;
                     pConfigParms->arplTh = MoCA_DEF_ARPL_TH;
                 }
             }
             else
             {
                 int sapmGsmFreq = 0;
                 for (i = 2; i < pOptions->nNumParms; i++) 
                 {
                     sapmGsmFreq += atoi(pOptions->pszParms[i]);
                 }

                 sapmGsmFreq /= (pOptions->nNumParms - 2);

                 mocacli_calc_sapm_gsm(pCurrParms->res1, sapmGsmFreq, &pConfigParms->sapmTable);
                 *pConfigMask |= MoCA_CFG_PARAM_SAPM_TABLE_MASK;

                 pConfigParms->sapmEn = 1;
             }
         }

         *pConfigMask |= MoCA_CFG_PARAM_SAPM_EN_MASK;
      }
      else if( !strcmp(pOptions->pszOptName, "--rlapmCap") )
      {
         pufValue = &rlapmCap ;
      }
      else if( !strcmp(pOptions->pszOptName, "--hostQOSEn") )
      {
         pulValue = &pConfigParms->hostQOSEn;
         *pConfigMask |= MoCA_CFG_PARAM_HOST_QOS_MASK;
      }      
      else if( !strcmp(pOptions->pszOptName, "--rlapm") )
      {        
         if ( pOptions->nNumParms == 0 )
         {
             fprintf( stderr, "%s: parameter missing %s\n",
                           pszPgmName, pOptions->pszOptName );
             nRet = -1;
         }
         else
         {
            int co = 0;

            if ( !strcmp(pOptions->pszParms[co], "off") )
            {
                 pConfigParms->rlapmEn = 0;
            }
            else
            {
                if ( !strcmp(pOptions->pszParms[co], "on") )
                {
                    unsigned char rlapmDefaults[66];

                    memset(rlapmDefaults, 0, sizeof(rlapmDefaults));
                    
                    /* This is duplicated in mocad */
                    rlapmDefaults[65]= (int)(16.0000*2);
                    rlapmDefaults[64]= (int)(16.0000*2);
                    rlapmDefaults[63]= (int)(16.0000*2);
                    rlapmDefaults[62]= (int)(16.0000*2);
                    rlapmDefaults[61]= (int)(16.0000*2);
                    rlapmDefaults[60]= (int)(16.0000*2);
                    rlapmDefaults[59]= (int)(16.0000*2);
                    rlapmDefaults[58]= (int)(16.0000*2);
                    rlapmDefaults[57]= (int)(16.0000*2);
                    rlapmDefaults[56]= (int)(16.0000*2);
                    rlapmDefaults[55]= (int)(16.0000*2);
                    rlapmDefaults[54]= (int)(16.0000*2);
                    rlapmDefaults[53]= (int)(16.0000*2);
                    rlapmDefaults[52]= (int)(16.0000*2);
                    rlapmDefaults[51]= (int)(15.0000*2);
                    rlapmDefaults[50]= (int)(15.0000*2);
                    rlapmDefaults[49]= (int)(15.0000*2);
                    rlapmDefaults[48]= (int)(14.5000*2);
                    rlapmDefaults[47]= (int)(14.5000*2);
                    rlapmDefaults[46]= (int)(13.5000*2);
                    rlapmDefaults[45]= (int)(12.5000*2);
                    rlapmDefaults[44]= (int)(11.5000*2);
                    rlapmDefaults[43]= (int)(10.5000*2);
                    rlapmDefaults[42]= (int)(10.5000*2);
                    rlapmDefaults[41]= (int)(9.5000*2);
                    rlapmDefaults[40]= (int)(8.5000*2);
                    rlapmDefaults[39]= (int)(7.5000*2);
                    rlapmDefaults[38]= (int)(6.5000*2);
                    rlapmDefaults[37]= (int)(5.5000*2);
                    rlapmDefaults[36]= (int)(4.5000*2);
                    rlapmDefaults[35]= (int)(4.0000*2);
                    rlapmDefaults[34]= (int)(3.5000*2);
                    rlapmDefaults[33]= (int)(3.0000*2);
                    rlapmDefaults[32]= (int)(2.5000*2);
                    rlapmDefaults[31]= (int)(2.0000*2);
                    rlapmDefaults[30]= (int)(1.5000*2);
                    rlapmDefaults[29]= (int)(1.5000*2);
                    rlapmDefaults[28]= (int)(1.0000*2);
                    rlapmDefaults[27]= (int)(1.0000*2);
                    rlapmDefaults[26]= (int)(1.0000*2);
                    rlapmDefaults[25]= (int)(0.5000*2);
                    rlapmDefaults[24]= (int)(0.5000*2);
                    rlapmDefaults[23]= (int)(0.5000*2);
                    rlapmDefaults[22]= (int)(0.5000*2);
                    rlapmDefaults[21]= (int)(0.5000*2);
                    
                    pConfigParms->rlapmEn = 1;

                    if (pCurrParms->rlapmEn != pConfigParms->rlapmEn)
                        memcpy(&pConfigParms->rlapmTable, rlapmDefaults, sizeof(rlapmDefaults));
                    else
                        memcpy(&pConfigParms->rlapmTable, &pCurrParms->rlapmTable, sizeof(pCurrParms->rlapmTable));
                }
                else if ( !strcmp(pOptions->pszParms[co], "phy") )
                {
                    // use a default table for phy:
                    static const unsigned char rlapmDefaults[] = 
                    {300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, // 0  - 9,
                    300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, // 10 - 19,
                    300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, 300-45, // 20 - 29,
                    300-45, 300-45, 255-45, 255-45, 255-45, 255-45, 225-45, 225-45, 225-45, 225-45, // 30 - 39,
                    195-45, 195-45, 195-45, 195-45, 160-45, 160-45, 160-45, 130-45, 130-45, 130-45, // 40 - 49,
                    100-45, 100-45, 100-45, 100-45,  66-45,  66-45,  66-45,  45-45,  45-45,  45-45, // 50 - 59 
                    45-45, 45-45, 45-45, 45-45, 45-45, 45-45};
                    
                    pConfigParms->rlapmEn = 2;

                    if (pCurrParms->rlapmEn != pConfigParms->rlapmEn)
                        memcpy(&pConfigParms->rlapmTable, rlapmDefaults, sizeof(rlapmDefaults));
                    else
                        memcpy(&pConfigParms->rlapmTable, &pCurrParms->rlapmTable, sizeof(pCurrParms->rlapmTable));
                }
                else
                {
                    fprintf( stderr, "%s: Invalid parameter to --rlapm: %s\n", pszPgmName, pOptions->pszParms[co]);
                    nRet = -1;
                }

                co++;

                *pConfigMask |= MoCA_CFG_PARAM_RLAPM_TABLE_MASK;
                
                if ((pOptions->nNumParms %2 == 0) && (nRet == 0))
                {
                    fprintf( stderr, "%s: power margin pair %s\n",
                                  pszPgmName, pOptions->pszOptName );
                    nRet = -1;
                }
                
                if (nRet == 0)
                {   
                    while (co < pOptions->nNumParms)
                    {
                        int power;
                        int powerstart = atoi(pOptions->pszParms[co]);
                        int powerend = powerstart;
                        char *c;
                        float margin = (float)atof(pOptions->pszParms[co+1]);

                        if (pConfigParms->rlapmEn == 2)
                        {
                            margin -= 45;
                            if (((int)(margin) < (int)(MoCA_MIN_RLAPM_TABLE_PHY)) || ((int)(margin) > (MoCA_MAX_RLAPM_TABLE_PHY)))
                            {
                                fprintf( stderr, "%s: margin out of range for option %s\n",
                                pszPgmName, pOptions->pszOptName );
                                nRet = -1;
                                break;
                            }
                        }
                        else if (((int)(margin*2) < (int)(2*MoCA_MIN_RLAPM_TABLE)) || ((int)(margin*2) > (MoCA_MAX_RLAPM_TABLE*2)))
                        {
                            fprintf( stderr, "%s: margin out of range for option %s\n",
                                  pszPgmName, pOptions->pszOptName );
                            nRet = -1;
                            break;
                        }
                        
                        c=strchr(pOptions->pszParms[co],'-');

                        if (c)
                            powerend=atoi(c+1);

                        if (powerend < powerstart)
                        {
                            fprintf( stderr, "%s: backwards range for option %s\n",
                                  pszPgmName, pOptions->pszOptName );
                            nRet = -1;
                            break;
                        }

                        for (power = powerstart; power <= powerend; power++)
                        {
                            if (power > 65)
                            {
                                fprintf( stderr, "%s: power out of range %s\n",
                                  pszPgmName, pOptions->pszOptName );
                                nRet = -1;
                                break;                                
                            }
                            
                            if (pConfigParms->rlapmEn == 2)
                                pConfigParms->rlapmTable[power] = (int)(margin);
                            else
                                pConfigParms->rlapmTable[power] = (int)(margin * 2);
                        }
                        
                        co+=2;
                    }
                }
            }
         }

         *pConfigMask |= MoCA_CFG_PARAM_RLAPM_EN_MASK;
      }      
      else if( !strcmp(pOptions->pszOptName, "--maxConstellationNode") )
      {
         pulValue = &constellationNodeId;
         *pConfigMask |= MoCA_CFG_PARAM_MAX_CONSTELLATION_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--rxPowerTuning") )
      {
         plValue = &pConfigParms->rxPowerTuning;
         *pConfigMask |= MoCA_CFG_PARAM_RX_POWER_TUNING_MASK ;
      }
      else if ( !strcmp(pOptions->pszOptName, "--enCapable") )
      {
         pulValue = &pConfigParms->enCapable;
         *pConfigMask |= MoCA_CFG_PARAM_EN_CAPABLE_MASK;
      }
      else if ( !strcmp(pOptions->pszOptName, "--enMaxRateInMaxBo") )
      {
         pulValue = &pConfigParms->enMaxRateInMaxBo;
         *pConfigMask |= MoCA_CFG_PARAM_EN_MAX_RATE_IN_MAX_BO_MASK;
      }
      else if ( !strcmp(pOptions->pszOptName, "--diplexer") )
      {
         if ( pOptions->nNumParms == 1)
         {
            plValue = &pConfigParms->diplexer;
            *pConfigMask |= MoCA_CFG_PARAM_DIPLEXER_MASK;
         }
         else
         {
            pConfigParms->diplexer = -3;
            *pConfigMask |= MoCA_CFG_PARAM_DIPLEXER_MASK;
         }
      }
      else if ( !strcmp(pOptions->pszOptName, "--egrMcFilterEntry") )
      {
         memcpy(&pConfigParms->mcAddrFilter, &pCurrParms->mcAddrFilter, sizeof(pCurrParms->mcAddrFilter));
         
         if( pOptions->nNumParms >= 2)
         {
            unsigned int entryId;
            entryId = atoi(pOptions->pszParms[0]);
            
            if (entryId >= MOCA_MAX_EGR_MC_FILTERS)
            {
                nRet = -1;
            }
            else
            {
                pConfigParms->mcAddrFilter[entryId].EntryId = entryId;
                pConfigParms->mcAddrFilter[entryId].Valid = atoi(pOptions->pszParms[1]);

                if (pConfigParms->mcAddrFilter[entryId].Valid)
                {
                    MAC_ADDRESS mac;
                    
                    nRet = ParseMacAddress ( pOptions->pszParms[2], &mac );

                    moca_mac_to_u32(&pConfigParms->mcAddrFilter[entryId].AddrHi, 
                        &pConfigParms->mcAddrFilter[entryId].AddrLo, mac);
                }
            }
         }
         else
         {
            nRet = -1;
         }
         
         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );

         *pConfigMask |= MoCA_CFG_PARAM_EGR_MC_ADDR_FILTER_MASK ;         
      }
      else if( !strcmp(pOptions->pszOptName, "--freqShiftMode") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "off" ) )
               pConfigParms->freqShiftMode= MoCA_FREQ_SHIFT_MODE_OFF;
            else if( !strcmp( pOptions->pszParms[0], "plus" ) )
               pConfigParms->freqShiftMode= MoCA_FREQ_SHIFT_MODE_PLUS;
            else if( !strcmp( pOptions->pszParms[0], "minus" ) )
               pConfigParms->freqShiftMode= MoCA_FREQ_SHIFT_MODE_MINUS;
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );

         *pConfigMask |= MoCA_CFG_PARAM_FREQ_SHIFT_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--maxConstellationInfo") )
      {
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "bpsk" ) )
               constellationInfo = BPSK ;
            else if( !strcmp( pOptions->pszParms[0], "qpsk" ) )
               constellationInfo = QPSK ;
            else if( !strcmp( pOptions->pszParms[0], "qam8" ) )
               constellationInfo = QAM8 ;
            else if( !strcmp( pOptions->pszParms[0], "qam16" ) )
               constellationInfo = QAM16 ;
            else if( !strcmp( pOptions->pszParms[0], "qam32" ) )
               constellationInfo = QAM32 ;
            else if( !strcmp( pOptions->pszParms[0], "qam64" ) )
               constellationInfo = QAM64 ;
            else if( !strcmp( pOptions->pszParms[0], "qam128" ) )
               constellationInfo = QAM128 ;
            else if( !strcmp( pOptions->pszParms[0], "qam256" ) )
               constellationInfo = QAM256 ;
            else if( !strcmp( pOptions->pszParms[0], "qam512" ) )
               constellationInfo = QAM512 ;
            else if( !strcmp( pOptions->pszParms[0], "qam1024" ) )
               constellationInfo = QAM1024 ;
            else
               nRet = -1 ;
         }
         else if( pOptions->nNumParms == MoCA_MAX_NODES)
         {
            /* Special case where the user is specifying the max constellation
             * value for each node in one command option */
            for (i = 0; (i < MoCA_MAX_NODES) && (nRet == 0); i++)
            {
               if( !strcmp( pOptions->pszParms[i], "bpsk" ) )
                  constellationInfo = BPSK ;
               else if( !strcmp( pOptions->pszParms[i], "qpsk" ) )
                  constellationInfo = QPSK ;
               else if( !strcmp( pOptions->pszParms[i], "qam8" ) )
                  constellationInfo = QAM8 ;
               else if( !strcmp( pOptions->pszParms[i], "qam16" ) )
                  constellationInfo = QAM16 ;
               else if( !strcmp( pOptions->pszParms[i], "qam32" ) )
                  constellationInfo = QAM32 ;
               else if( !strcmp( pOptions->pszParms[i], "qam64" ) )
                  constellationInfo = QAM64 ;
               else if( !strcmp( pOptions->pszParms[i], "qam128" ) )
                  constellationInfo = QAM128 ;
               else if( !strcmp( pOptions->pszParms[i], "qam256" ) )
                  constellationInfo = QAM256 ;
               else if( !strcmp( pOptions->pszParms[i], "qam512" ) )
                  constellationInfo = QAM512 ;
               else if( !strcmp( pOptions->pszParms[i], "qam1024" ) )
                  constellationInfo = QAM1024 ;
               else
                  nRet = -1 ;

               pConfigParms->constellation[i] = constellationInfo;
            }

            /* Trick the code below so that we don't have to do anything
             * special in this "MAX_NODES" case. This will just set the
             * last entry in the array again later. */
            constellationNodeId = i - 1;
         }
         else {
            nRet = -1;
         }

         *pConfigMask |= MoCA_CFG_PARAM_MAX_CONSTELLATION_MASK ;
         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--pmk") )
      {
         pulValue = &pConfigParms->pmkExchangeInterval ;
         *pConfigMask |= MoCA_CFG_PARAM_PMK_EXCHG_INTVL_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--tek") )
      {
         pulValue = &pConfigParms->tekExchangeInterval ;
         *pConfigMask |= MoCA_CFG_PARAM_TEK_EXCHG_INTVL_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--prio") )
      {
         /* Convert the value for a particular option to an integer. */
         if( pOptions->nNumParms == 6 )
         {
            char *pszEnd = NULL;

            pConfigParms->prioAllocation.resvHigh = (UINT32) 
                                          strtol( pOptions->pszParms[0], &pszEnd, 10 ) ;
            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     pszPgmName, pOptions->pszOptName );
            }
            pConfigParms->prioAllocation.resvMed = (UINT32) 
                                          strtol( pOptions->pszParms[1], &pszEnd, 10 ) ;
            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     pszPgmName, pOptions->pszOptName );
            }
            pConfigParms->prioAllocation.resvLow = (UINT32) 
                                          strtol( pOptions->pszParms[2], &pszEnd, 10 ) ;
            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     pszPgmName, pOptions->pszOptName );
            }
            pConfigParms->prioAllocation.limitHigh = (UINT32) 
                                          strtol( pOptions->pszParms[3], &pszEnd, 10 ) ;
            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     pszPgmName, pOptions->pszOptName );
            }
            pConfigParms->prioAllocation.limitMed = (UINT32) 
                                          strtol( pOptions->pszParms[4], &pszEnd, 10 ) ;
            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     pszPgmName, pOptions->pszOptName );
            }
            pConfigParms->prioAllocation.limitLow = (UINT32) 
                                          strtol( pOptions->pszParms[5], &pszEnd, 10 ) ;
            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     pszPgmName, pOptions->pszOptName );
            }
         }
         else
         {
            nRet = -1;
            fprintf( stderr, "%s: invalid number of parameters for option "
                  "%s\n", pszPgmName, pOptions->pszOptName );
         }
         *pConfigMask |= MoCA_CFG_PARAM_PRIO_ALLOCATIONS_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--phyRate128") )
      {
         pulValue = &pConfigParms->targetPhyRateQAM128 ;
         *pConfigMask |= MoCA_CFG_PARAM_TARGET_PHY_RATE_QAM128_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--phyRate256") )
      {
         pulValue = &pConfigParms->targetPhyRateQAM256 ;
         *pConfigMask |= MoCA_CFG_PARAM_TARGET_PHY_RATE_QAM256_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--phyRateTurbo") )
      {
         pulValue = &pConfigParms->targetPhyRateTurbo ;
         *pConfigMask |= MoCA_CFG_PARAM_TARGET_PHY_RATE_TURBO_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--phyRateTurboPlus") )
      {
         pulValue = &pConfigParms->targetPhyRateTurboPlus ;
         *pConfigMask |= MoCA_CFG_PARAM_TARGET_PHY_RATE_TURBO_PLUS_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--nbasCappingEn") )
      {
         pulValue = &pConfigParms->nbasCappingEn ;
         *pConfigMask |= MoCA_CFG_PARAM_NBAS_CAPPING_EN_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--loopbackEn") )
      {
         pulValue = &pConfigParms->loopbackEn ;
         *pConfigMask |= MoCA_CFG_PARAM_LOOPBACK_EN_MASK ;
      }      
      else if( !strcmp(pOptions->pszOptName, "--selectiveRR") )
      {
         pulValue = &pConfigParms->selectiveRR ;
         *pConfigMask |= MoCA_CFG_PARAM_SELECTIVE_RR_MASK ;
      }                  
      else if( !strcmp(pOptions->pszOptName, "--minMapCycle") )
      {
         pulValue = &pConfigParms->minMapCycle ;
         *pConfigMask |= MoCA_CFG_PARAM_MIN_MAP_CYCLE_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--maxMapCycle") )
      {
         pulValue = &pConfigParms->maxMapCycle ;
         *pConfigMask |= MoCA_CFG_PARAM_MAX_MAP_CYCLE_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--extraRxPacketsPerQM") )
      {
         pulValue = &pConfigParms->extraRxPacketsPerQM ;
         *pConfigMask |= MoCA_CFG_PARAM_EXTRA_RX_PACKETS_PER_QM_MASK ;
      }
      else if( !strcmp(pOptions->pszOptName, "--rxTxPacketsPerQM") )
      {
         pulValue = &pConfigParms->rxTxPacketsPerQM ;
         *pConfigMask |= MoCA_CFG_PARAM_RX_TX_PACKETS_PER_QM_MASK ;
      } 
      else if( !strcmp(pOptions->pszOptName, "--mocareg") )
      {
         if( pOptions->nNumParms == 2)
         {
            char *pszEnd = NULL;

            pConfigParms->RegMem.input = (long) strtoul( pOptions->pszParms[0], &pszEnd, 16 ) ;
            pConfigParms->RegMem.value[0] = (long) strtoul( pOptions->pszParms[1], &pszEnd, 16 ) ;
            pConfigParms->RegMem.len = 1;
            *pConfigMask |= MoCA_CFG_PARAM_LAB_REG_MEM_MASK ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--tpcap") )
      {
         pConfigParms->labTPCAP.enable = strtoul( pOptions->pszParms[0], NULL, 10 ) ;

         if (pOptions->nNumParms == 2)             
             pConfigParms->labTPCAP.type = strtoul( pOptions->pszParms[1], NULL, 10 ) ;         
         else
             pConfigParms->labTPCAP.type = 0;
         
         *pConfigMask |= MoCA_CFG_PARAM_LAB_TPCAP_MASK;
      }
      else if( !strcmp(pOptions->pszOptName, "--powersave") )
      {         
         // turn off interface
         
         if( pOptions->nNumParms == 1)
         {
            if( !strcmp( pOptions->pszParms[0], "on" ) )
            {
               pConfigParms->pssEn = MoCA_PSS_IE_ENABLE ;
            }
            else if( !strcmp( pOptions->pszParms[0], "off" ) )
            {
                pConfigParms->pssEn = MoCA_PSS_IE_DISABLE ;
            }
            else
               nRet = -1 ;
         }
         else {
            nRet = -1;
         }
         
         *pConfigMask |= MoCA_CFG_PARAM_PSS_EN_MASK ;
         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         
      }
      
      else {

         nRet = -1;

         fprintf( stderr, "%s: invalid parameter for option %s\n",
               pszPgmName, pOptions->pszOptName );
      }

      if( pulValue || puxValue || plValue )
      {
         /* Convert the value for a particular option to an integer. */
         if( pOptions->nNumParms == 1 )
         {
            char *pszEnd = NULL;

            if (pulValue)
               *pulValue = (long) strtol( pOptions->pszParms[0], &pszEnd, 10 ) ;
            else if (puxValue)
               *puxValue = (long) strtol( pOptions->pszParms[0], &pszEnd, 16 ) ;
            else if (plValue)
               *plValue = (long) strtol( pOptions->pszParms[0], &pszEnd, 10 ) ;
            
            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     pszPgmName, pOptions->pszOptName );
            }
         }
         else
         {
            nRet = -1;
            fprintf( stderr, "%s: invalid number of parameters for option "
                  "%s\n", pszPgmName, pOptions->pszOptName );
         }
      }

      if( pusValue )
      {
         /* Convert the value for a particular option to an integer. */
         if( pOptions->nNumParms == 1 )
         {
            char *pszEnd = NULL;
            *pusValue = (UINT16) strtol( pOptions->pszParms[0], &pszEnd, 10 );
            if( *pszEnd != '\0' )
            {
               nRet = -1;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     pszPgmName, pOptions->pszOptName );
            }
         }
         else
         {
            nRet = -1;
            fprintf( stderr, "%s: invalid number of parameters for option "
                  "%s\n", pszPgmName, pOptions->pszOptName );
         }
      }

      if (pufValue) {

         /* Convert the value for a particular option to an integer. */
         if( pOptions->nNumParms == 1 )
         {
            *pufValue = (float) atof (pOptions->pszParms [0]) ;
            if (pufValue == &snrMargin) {
               if ((((signed int) (*pufValue * 10)) % 5) == 0) {
                  pConfigParms->snrMargin = (signed int) (*pufValue * 2) ;
                  *pConfigMask |= MoCA_CFG_PARAM_SNR_MARGIN_MASK ;
               }
               else {
                  nRet = -1;
                  fprintf( stderr, "%s: invalid parameter value for option "
                        "%s\n", pszPgmName, pOptions->pszOptName );
               }
            }
            else if (pufValue == &rlapmCap) {
               if ((((signed int) (*pufValue * 10)) % 5) == 0) {
                  pConfigParms->rlapmCap = (signed int) (*pufValue * 2) ;
                  *pConfigMask |= MoCA_CFG_PARAM_RLAPM_CAP_MASK ;
               }
               else {
                  nRet = -1;
                  fprintf( stderr, "%s: invalid parameter value for option "
                        "%s\n", pszPgmName, pOptions->pszOptName );
               }
            }
         }
         else if (pOptions->nNumParms == MoCA_MAX_SNR_TBL_INDEX-1)
         {
            for (i=0; i< MoCA_MAX_SNR_TBL_INDEX-1; i++) {
               pufValue [i] = (float) atof ( pOptions->pszParms[i] ) ;
               if ((((signed int) (pufValue[i] * 10)) % 5) == 0) {
                  pConfigParms->snrMarginOffset[i] = (signed int) (pufValue[i] * 2) ;
               }
               else {
                  nRet = -1;
                  fprintf( stderr, "%s: invalid parameter for option %s\n",
                        pszPgmName, pOptions->pszOptName );
               }
            }

            *pConfigMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         }
         else
         {
            nRet = -1;
            fprintf( stderr, "%s: invalid number of parameters for option "
                  "%s\n", pszPgmName, pOptions->pszOptName );
         }
      } /* if (pufValue) */
      
      nNumOptions--;
      pOptions++;
   }

   if (*pConfigMask & MoCA_CFG_PARAM_MAX_CONSTELLATION_MASK)
   {
      /* Need to set constellation array based on user input.
       * If node is not specified, set all nodes to value specified.
       * If value is not specified, set node ID to default
       */
      if (constellationNodeId == MoCA_MAX_NODES)
      {
         for (i = 0; i < MoCA_MAX_NODES; i++)
         {
            pConfigParms->constellation[i] = constellationInfo;
         }
      }
      else if (constellationNodeId < MoCA_MAX_NODES)
      {
         pConfigParms->constellation[constellationNodeId] = constellationInfo;
      }
      else
      {
         nRet = -1;
         fprintf( stderr, "%s: invalid value (%u) for maxConstellationNode\n", 
            pszPgmName, constellationNodeId );
      }
   }


   return (nRet);
}


/** Parses moca trace configuration parmaters from cli input
 *
 * Parses the pOptions array and populates the pTraceParmas structure,
 * based on the input.
 *
 * @param pszPgmName (IN) string pointer to applciation name used for error 
 * prints
 * @param pOptions (IN) Pointer to the CLI options.
 * @param nNumOptions (IN) Number of command line options
 * @param pTraceParms (OUT) MoCA trace parameters as parsed from 
 * CLI string
 * @return 0 - success, non-0 - error
 */
int mocacli_parse_trace_parms ( 
	char * pszPgmName, 
	POPTION_INFO pOptions, 
	int nNumOptions,
	MoCA_TRACE_PARAMS * pTraceParams )
{
   int nRet = 0;

   if (pTraceParams != NULL)
   {
      pTraceParams->traceLevel = MOCA_TRC_LEVEL_NONE ;
      pTraceParams->bRestoreDefault = 0 ;
   }
   else
      nRet = -1;

   while( nRet == 0 && nNumOptions )
   {
      if( !strcmp(pOptions->pszOptName, "--none") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel = MOCA_TRC_LEVEL_NONE ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName ) ;
         break ;
      }
      else if( !strcmp(pOptions->pszOptName, "--entry") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel |= MOCA_TRC_LEVEL_FN_ENTRY ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--exit") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel |= MOCA_TRC_LEVEL_FN_EXIT ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--dbg") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel |= MOCA_TRC_LEVEL_DBG ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--info") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel |= MOCA_TRC_LEVEL_INFO ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0)
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--mmpdump") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel |= MOCA_DUMP_HOST_CORE ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--core") ) {

#if 1
         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel |= MOCA_TRC_LEVEL_CORE ;
         }
         else {
            nRet = -1;
         }
#else
         nRet = CMSRET_METHOD_NOT_SUPPORTED;
#endif

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s Not Supported.\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--trap") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel |= MOCA_TRC_LEVEL_TRAP ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--time") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel |= MOCA_TRC_TIMESTAMPS ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else if( !strcmp(pOptions->pszOptName, "--all") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel = MOCA_TRC_LEVEL_ALL ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         break ;
      }
      else if( !strcmp(pOptions->pszOptName, "--default") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->bRestoreDefault = 1 ;
         }
         else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
         break ;
      }
      else if( !strcmp(pOptions->pszOptName, "--verbose") ) {

         if( pOptions->nNumParms == 0)
         {
            pTraceParams->traceLevel |= MOCA_TRC_LEVEL_VERBOSE ;
         }
      else {
            nRet = -1;
         }

         if( nRet != 0 )
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                  pszPgmName, pOptions->pszOptName );
      }
      else {

         nRet = -1;

         fprintf( stderr, "%s: invalid parameter for option %s\n",
               pszPgmName, pOptions->pszOptName );
      }

      nNumOptions--;
      pOptions++;
   }

   return( nRet );
}

static void mocacli_build_option_list(char * parms, OPTION_INFO * pOptInfo, int * numOptions)
{
   char *argv = NULL;
//   int  argvIndex = 0;
   OPTION_INFO * pCurrOpt = pOptInfo;
  
   *numOptions = 0;
   pCurrOpt->nNumParms = 0;

   if (parms == NULL)
      return;

   /* tokenize the string */
   argv = strtok(parms, " ");
   while ((argv != NULL) && 
          (*numOptions < MAX_OPTS) && 
          (pCurrOpt->nNumParms < MAX_PARMS))
   {
      if (strncmp(argv, "--", strlen("--")) == 0)
      {
         pCurrOpt = pOptInfo;
         pOptInfo++;
         pCurrOpt->pszOptName = argv;
         pCurrOpt->nNumParms = 0;
         *numOptions += 1;
         //printf("New option %s, (%d)\n", argv, *numOptions);
      }
      else
      {
         pCurrOpt->pszParms[pCurrOpt->nNumParms] = argv;
         pCurrOpt->nNumParms++;
         //printf("  New parm %s  (%d)\n", argv, pCurrOpt->nNumParms);
      }

      argv = strtok(NULL, " ");
   }
}


/** Convert init string parameters to structure.
 *
 * Takes the 'initString' variable which holds the parameters to 
 * the CLI command "mocactl start" or "mocactl restart" and converts
 * it into the MoCA_INITIALIZATION_PARMS structure.
 *
 * @param initString (IN) pointer to init param string
 * @param pInitParms (OUT) Pointer to init param structure
 * @param mask (OUT) Pointer to bit mask of fields set in string 
 *
 * @return none
 */
void mocacli_convert_init_string(
   char * initString, 
   PMoCA_INITIALIZATION_PARMS pInitParms, 
   unsigned long long * mask)
{
   OPTION_INFO OptInfo[MAX_OPTS];
   int numOpts = 0;
   char * copy;

   if (initString == NULL)
   {
      if (mask != NULL)
         *mask = 0;

      return;
   }

   /* We need to make a copy of the string because the 
    * build option list function will call strtok_r which
    * puts NULL chars into the string.
    */
   copy = malloc(strlen(initString) + 1);
   if (copy == NULL)
   {
      fprintf(stderr, "%s: unable to allocate %d bytes\n",
              __FUNCTION__, (strlen(initString) + 1));
      return;
   }
   
   strcpy(copy, initString);

   mocacli_build_option_list(copy, &OptInfo[0], &numOpts);

   /* ignore any errors returned by this function */
   mocacli_parse_init_parms((char *)__FUNCTION__, &OptInfo[0], numOpts, pInitParms, mask);

   free(copy);
}


/** Convert config string parameters to structure.
 *
 * Takes the 'cfgString' variable which holds the parameters to 
 * the CLI command "mocactl config" and converts it into the 
 * MoCA_CONFIG_PARAMS structure.
 *
 * @param cfgString (IN) pointer to config param string
 * @param pCfgParms (OUT) Pointer to config param structure
 * @param mask (OUT) Pointer to bit mask of fields set in string 
 *
 * @return none
 */
void mocacli_convert_cfg_string(
   char * cfgString, 
   PMoCA_CONFIG_PARAMS pCfgParms, 
   unsigned long long * mask)
{
   OPTION_INFO OptInfo[MAX_OPTS];
   int numOpts = 0;
   char * copy;

   if (cfgString == NULL)
   {
      if (mask != NULL)
         *mask = 0;

      return;
   }

   /* We need to make a copy of the string because the 
    * build option list function will call strtok_r which
    * puts NULL chars into the string.
    */
   copy = malloc(strlen(cfgString) + 1);
   if (copy == NULL)
   {
      fprintf(stderr, "%s: unable to allocate %d bytes\n",
              __FUNCTION__, (strlen(cfgString) + 1));
      return;
   }
   
   strcpy(copy, cfgString);
   
   mocacli_build_option_list(copy, &OptInfo[0], &numOpts);

   /* ignore any errors returned by this function */
   mocacli_parse_config_parms((char *)__FUNCTION__, &OptInfo[0], numOpts, pCfgParms, mask, pCfgParms);

   free(copy);
}



/** Convert trace string parameters to structure.
 *
 * Takes the 'traceString' variable which holds the parameters to 
 * the CLI command "mocactl trace" and converts it into the 
 * MoCA_TRACE_PARAMS structure.
 *
 * @param traceString (IN) pointer to trace param string
 * @param pTraceParms (OUT) Pointer to trace param structure
 *
 * @return none
 */
void mocacli_convert_trace_string(
   char * traceString, 
   PMoCA_TRACE_PARAMS pTraceParms )
{
   OPTION_INFO OptInfo[MAX_OPTS];
   int numOpts = 0;
   char * copy;

   if (traceString == NULL)
   {
      if (pTraceParms != NULL)
      {
         pTraceParms->traceLevel = 0;
         pTraceParms->bRestoreDefault = 0;
      }
      return;
   }

   /* We need to make a copy of the string because the 
    * build option list function will call strtok_r which
    * puts NULL chars into the string.
    */
   copy = malloc(strlen(traceString) + 1);
   if (copy == NULL)
   {
      fprintf(stderr, "%s: unable to allocate %d bytes\n",
              __FUNCTION__, (strlen(traceString) + 1));
      return;
   }
   
   strcpy(copy, traceString);
   
   mocacli_build_option_list(copy, &OptInfo[0], &numOpts);

   /* ignore any errors returned by this function */
   mocacli_parse_trace_parms((char *)__FUNCTION__, &OptInfo[0], numOpts, pTraceParms);

   free(copy);
}


/** Print moca initialization parmaters
 *
 * Prints MoCA initialization parameters stored in pInitParms structure in
 * a clean way.
 *
 * @param pInitParms (IN) pointer to MoCA initialization parameters
 * @return None.
 */
void mocacli_print_init_parms ( MoCA_INITIALIZATION_PARMS * pInitParms )
{
   int i;
   char buffer[80];

   printf ("        MoCA InitTime Configuration          \n");
   printf ("=============================================\n");
   printf ("Operating Version          : %s \n", (pInitParms->operatingVersion == MoCA_VERSION_11) ? "1.1" : "1.0")  ;
   printf ("Network Controller Mode    : %s \n", (pInitParms->ncMode == MoCA_AUTO_NEGOTIATE_FOR_NC) ? "AUTO" : ((pInitParms->ncMode == MoCA_ALWAYS_NC) ? "NC" : "NN")) ;
   printf ("SingleCh                   : %s \n", (pInitParms->autoNetworkSearchEn == MoCA_AUTO_NW_SCAN_ENABLED) ? "off" : 
                                                 (pInitParms->autoNetworkSearchEn == MoCA_AUTO_NW_SCAN_DISABLED) ? "on" : "on2") ;
   printf ("Privacy                    : %s \n", (pInitParms->privacyEn == MoCA_PRIVACY_ENABLED) ? "enabled" : "disabled")  ;
   printf ("Tx Pwr Control             : %s \n", (pInitParms->txPwrControlEn == MoCA_TPC_ENABLED) ? "enabled" : "disabled")  ;

   switch(pInitParms->constTransmitMode)
   {
      case MoCA_NORMAL_OPERATION:
         sprintf(buffer, "%s", "Normal");
         break;
      case MoCA_CONTINUOUS_TX_PROBE_I:
         sprintf(buffer, "%s", "Tx");
         break;
      case MoCA_CONTINUOUS_RX:
      case MoCA_CONTINUOUS_RX_LO_ON:
         sprintf(buffer, "%s", "Rx");
         break;
      case MoCA_EXTERNAL_CONTROL:
         sprintf(buffer, "%s", "External");
         break;
      case MoCA_CONTINUOUS_TX_CW:
         sprintf(buffer, "%s", "Tx - CW");
         break;
      case MoCA_CONTINUOUS_TX_TONE:
         sprintf(buffer, "%s", "Tx - Tone");
         break;
      case MoCA_CONTINUOUS_TX_TONE_SC:
         sprintf(buffer, "%s (0x%x)", 
            "Tx - Tone", pInitParms->initOptions.constTxSubCarrier1);
         break;
      case MoCA_CONTINUOUS_TX_DUAL_TONE_SC:
         sprintf(buffer, "%s (0x%x / 0x%x)", 
            "Tx - Tone", pInitParms->initOptions.constTxSubCarrier1, 
            pInitParms->initOptions.constTxSubCarrier2);
         break;
      case MoCA_CONTINUOUS_TX_BAND:
         sprintf(buffer, "%s (%08x %08x %08x %08x %08x %08x %08x %08x)", 
            "Band", pInitParms->initOptions.constTxNoiseBand[0],
            pInitParms->initOptions.constTxNoiseBand[1],
            pInitParms->initOptions.constTxNoiseBand[2],
            pInitParms->initOptions.constTxNoiseBand[3],
            pInitParms->initOptions.constTxNoiseBand[4],
            pInitParms->initOptions.constTxNoiseBand[5],
            pInitParms->initOptions.constTxNoiseBand[6],
            pInitParms->initOptions.constTxNoiseBand[7]);
         break;
      default:
         sprintf(buffer, "%s", "Unknown");
         break;
   }
   printf ("Const Tx Mode              : %s \n", buffer) ;
   printf ("Continuous Rx Mode Attn    : %d dBm\n", pInitParms->continuousRxModeAttn) ;
   printf ("Nv Params - Last Oper Freq : ");
   if (pInitParms->nvParams.lastOperFreq == MoCA_FREQ_UNSET)
      printf("not set\n");
   else
      printf ("%u Mhz\n", pInitParms->nvParams.lastOperFreq)  ;

   printf ("Max Tx Power               : %d dBm\n", pInitParms->maxTxPowerBeacons)  ;
   printf ("PasswordSize               : %u \n", pInitParms->passwordSize)  ;
   printf ("Password                   : ") ;
   for (i = 0; i < (int)pInitParms->passwordSize ; i++) {
      printf ("%c", pInitParms->password [i]) ;
   }
   printf ("\n") ;
   printf ("Mcast Mode                 : %s \n", (pInitParms->mcastMode == MoCA_MCAST_BCAST_MODE) ? "Broadcast Mode" : "Normal") ;
   printf ("Laboratory Mode            : %s \n", (pInitParms->labMode == MoCA_LAB_MODE) ? "LabMode" : "Normal") ;
   printf ("Taboo Fixed Start Channel  : %d \n", pInitParms->tabooFixedMaskStart)  ;
   printf ("Taboo Fixed Channel Mask   : 0x%08x \n", pInitParms->tabooFixedChannelMask)  ;
   printf ("Taboo Left Mask            : 0x%08x \n", pInitParms->tabooLeftMask)  ;
   printf ("Taboo Right Mask           : 0x%08x \n", pInitParms->tabooRightMask)  ;   
   printf ("Pwr Amplifier Driver Power : %d dBm\n", pInitParms->padPower)  ;
   printf ("preferredNC                : %s \n", (pInitParms->preferedNC == MoCA_PREFERED_NC_MODE) ? "preferred" : "non-preferred" )  ;
   printf ("LED Mode                   : %u \n", pInitParms->ledMode)  ;
   printf ("Backoff Mode               : %s \n", pInitParms->boMode == MoCA_BO_MODE_FAST? "fast" : "slow")  ;   
   printf ("RF Type                    : %s \n", pInitParms->rfType == MoCA_RF_TYPE_D_BAND? "hi" :
                                                 pInitParms->rfType == MoCA_RF_TYPE_E_BAND? "midlo" :
                                                 pInitParms->rfType == MoCA_RF_TYPE_H_BAND? "bandH" :
                                                 pInitParms->rfType == MoCA_RF_TYPE_F_BAND? "midhi" : "wan");
   printf ("Node Type                  : %s \n", pInitParms->terminalIntermediateType == MoCA_NODE_TYPE_TERMINAL? 
                                                    "terminal":"intermediate");
   printf ("Beacon Channel             : %d \n", pInitParms->beaconChannel);    
   printf ("mrNonDefSeqNum             : %d \n", pInitParms->mrNonDefSeqNum);
   printf ("EGR MC Addr Filter En      : %d \n", pInitParms->egrMcFilterEn);
   printf ("lowPriQNum                 : %d \n", pInitParms->lowPriQNum);      
   printf ("qam256Capability           : %s \n", pInitParms->qam256Capability == MoCA_QAM256_CAPABILITY_DISABLED?
                                                    "off":"on");
   printf ("Freq Mask                  : 0x%08x \n", pInitParms->freqMask);
   printf ("PNS Freq Mask              : 0x%08x \n", pInitParms->pnsFreqMask);   
   printf ("OTF En                     : %d \n", pInitParms->otfEn);   
   printf ("Turbo En                   : %d \n", pInitParms->turboEn);
   printf ("Flow Control En            : %d \n", pInitParms->flowControlEn);
   printf ("Beacon Power Reduction     : %d \n", pInitParms->beaconPwrReduction);
   printf ("Beacon Power Reduction En  : %d \n", pInitParms->beaconPwrReductionEn);
   printf ("Persistent Stop            : %d \n", pInitParms->initOptions.dontStartMoca);   
   printf ("MTM En                     : %d \n", pInitParms->mtmEn);
   printf ("QAM1024 En                 : %d \n", pInitParms->qam1024En);
   printf ("T50 Time Min               : %d \n", pInitParms->T50TimeMin);
   printf ("T50 Time Max               : %d \n", pInitParms->T50TimeMax);   
   printf ("=============================================\n");
}


/** Print moca bit loading data
 *
 * Prints MoCA bit loading data stored in pBitLoading and pSecBitLoading
 *
 * @param pBitLoading (IN) pointer to first bit loading data array
 * @param pSecBitLoading (IN) pointer to second bit loading data array
 * @return None.
 */
void mocacli_display_bit_loading (UINT32 *pBitLoading, UINT32 *pSecBitLoading)
{
   UINT32  val, secVal ;
   UINT32  subCarrier, secSubCarrier ;

   secSubCarrier = 0 ;
   for (subCarrier = 0 ; subCarrier < (MoCA_MAX_SUB_CARRIERS/8); subCarrier++) {
      val = pBitLoading [subCarrier] ;
      val = (val<<28) | ((val&0xf0)<<20) | ((val&0xf00)<<12) | ((val&0xf000)<<4)
         | ((val&0xf0000)>>4) | ((val&0xf00000)>>12) | ((val&0xf000000)>>20) | val >>28 ;
      printf ("%8.8x", val) ;
      if (((subCarrier+1) % 4) == 0) {
         if (pSecBitLoading == NULL)
            printf ("\n") ;
         else {
            printf ("\t   ") ;
            /* Display the second Bit Loading */
            for (;secSubCarrier < (MoCA_MAX_SUB_CARRIERS/8); secSubCarrier++) {
               secVal = pSecBitLoading [secSubCarrier] ;
               secVal = (secVal<<28) | ((secVal&0xf0)<<20) | ((secVal&0xf00)<<12) | ((secVal&0xf000)<<4)
                  | ((secVal&0xf0000)>>4) | ((secVal&0xf00000)>>12) | ((secVal&0xf000000)>>20) | secVal >>28 ;
               printf ("%8.8x", secVal) ;
               if (((secSubCarrier+1) % 4) == 0) {
                  printf ("\n") ;
                  secSubCarrier++ ;
                  break ;
               }
            } /* for (secSubCarrier) */
         }
      } /* if (subCarrier) */
   } /* for (subCarrier) */
}


/** Print moca node status
 *
 * Prints MoCA node status data stored in pNodeStatus and bitLoading
 *
 * @param pNodeStatus (IN) pointer to node status data
 * @param bitLoading (IN) flag indicating whether to print bit loading data 
 * or not
 * @return None.
 */
void mocacli_display_node_status (PMoCA_NODE_STATUS_ENTRY pNodeStatus, int bitLoading, int csv, int header)
{
   MAC_ADDRESS macAddr;

   moca_u32_to_mac(macAddr, pNodeStatus->eui[0], pNodeStatus->eui[1]);

   if (!csv)
   {
       printf ("Node                             : %d \n", pNodeStatus->nodeId) ;
       printf ("=============================================\n");
       printf ("MAC Address                      : %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\n",
             macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5]);
       printf ("Freq Offset                      : %d KHz \n", pNodeStatus->freqOffset/1000) ;
       printf ("Protocol Support                 : 0x%X\n", pNodeStatus->protocolSupport);
       printf ("   - Preferred NC                : %d\n", (pNodeStatus->protocolSupport>>6)&1);
       printf ("   - 256 QAM capable             : %d\n", (pNodeStatus->protocolSupport>>4)&1);
       printf ("   - Aggregated PDUs             : %s\n", ((pNodeStatus->protocolSupport>>7)&3) == 0?"6":
                                                          ((pNodeStatus->protocolSupport>>7)&3) == 2?"10":"Not allowed");
       printf ("Other Node UC Pwr Backoff        : %d dB \n", pNodeStatus->otherNodeUcPwrBackOff) ;
       printf ("Turbo Mode                       : %d\n", pNodeStatus->txUc.turbo);
       printf ("-------------------------------------------------------------------------\n") ;
       printf ("        Nbas  Preamble    CP    TxPower   RxPower   Rate              SNR\n") ;
       printf ("=========================================================================\n") ;
       printf ("TxUc    %4d     %2d      %3d    %3d dBm   N/A       %9u bps   %2.1lf dB\n",pNodeStatus->txUc.nBas,
             pNodeStatus->txUc.preambleType, pNodeStatus->txUc.cp,
             pNodeStatus->txUc.txPower, pNodeStatus->maxPhyRates.txUcPhyRate,
             (float)pNodeStatus->txUc.avgSnr/2.0 ) ;
       printf ("RxUc    %4d     %2d      %3d    N/A      %6.2lf dBm %9u bps   %2.1lf dB\n",pNodeStatus->rxUc.nBas,
             pNodeStatus->rxUc.preambleType, pNodeStatus->rxUc.cp,
             pNodeStatus->rxUc.rxGain/4.0, pNodeStatus->maxPhyRates.rxUcPhyRate,
             pNodeStatus->rxUc.avgSnr/2.0 ) ;
       printf ("RxBc    %4d     %2d      %3d    N/A      %6.2lf dBm %9u bps   %2.1lf dB\n",pNodeStatus->rxBc.nBas,
             pNodeStatus->rxBc.preambleType, pNodeStatus->rxBc.cp,
             pNodeStatus->rxBc.rxGain/4.0, pNodeStatus->maxPhyRates.rxBcPhyRate,
             pNodeStatus->rxBc.avgSnr/2.0 ) ;
       printf ("RxMap   %4d     %2d      %3d    N/A      %6.2lf dBm %9u bps   %2.1lf dB\n",pNodeStatus->rxMap.nBas,
             pNodeStatus->rxMap.preambleType, pNodeStatus->rxMap.cp,
             pNodeStatus->rxMap.rxGain/4.0,  pNodeStatus->maxPhyRates.rxMapPhyRate,
             pNodeStatus->rxMap.avgSnr/2.0 ) ;
       printf ("===========================================================\n") ;
       printf ("\n") ;

       if (bitLoading) {
          printf ("   Tx Unicast Bit Loading Info  \t   Rx Unicast Bit Loading Info \n" ) ;
          printf ("--------------------------------\t   -------------------------------\n") ;
          mocacli_display_bit_loading(&pNodeStatus->txUc.bitLoading[0], &pNodeStatus->rxUc.bitLoading[0]) ;
          printf ("--------------------------------\t   -------------------------------\n") ;

          printf ("   Rx Broadcast Bit Loading Info  \t   Rx Map Bit Loading Info \n" ) ;
          printf ("----------------------------------\t   -----------------------------\n") ;
          mocacli_display_bit_loading(&pNodeStatus->rxBc.bitLoading[0], &pNodeStatus->rxMap.bitLoading[0]) ;
          printf ("--------------------------------\t   -------------------------------\n") ;
       }
   }
   else
   {
       if (header)
       {
           printf("node, mac, freq_offset, protocol_support, preferredNC, 256QAM_capable, aggr_pdus, pwr_backoff, ");
           printf("TxUc_Nbas, TxUc_Preamble, TxUc_CP, TxUc_TxPower, TxUc_RxPower, TxUc_Rate, TxUc_SNR, ");
           printf("RxUc_Nbas, RxUc_Preamble, RxUc_CP, RxUc_TxPower, RxUc_RxPower, RxUc_Rate, RxUc_SNR, ");
           printf("RxBc_Nbas, RxBc_Preamble, RxBc_CP, RxBc_TxPower, RxBc_RxPower, RxBc_Rate, RxBc_SNR, ");       
           printf("RxMap_Nbas, RxMap_Preamble, RxMap_CP, RxMap_TxPower, RxMap_RxPower, RxMap_Rate, RxMap_SNR\n");       
       }
       
       printf ("%d,%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x,%d,0x%X,%d,%d,%s,%d,", 
            pNodeStatus->nodeId,
            macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5],
            pNodeStatus->freqOffset/1000,
            pNodeStatus->protocolSupport,
            ((pNodeStatus->protocolSupport>>6)&1),
            ((pNodeStatus->protocolSupport>>4)&1),
            ((pNodeStatus->protocolSupport>>7)&3) == 0?"6":((pNodeStatus->protocolSupport>>7)&3) == 2?"10":"Not allowed",
            pNodeStatus->otherNodeUcPwrBackOff) ;

       printf("%d,%d,%d,%d,N/A,%u,%f,",
             pNodeStatus->txUc.nBas,
             pNodeStatus->txUc.preambleType, pNodeStatus->txUc.cp,
             pNodeStatus->txUc.txPower, pNodeStatus->maxPhyRates.txUcPhyRate,
             (float)pNodeStatus->txUc.avgSnr/2.0 ) ;

       printf("%d,%d,%d,N/A,%lf,%u,%f,",
             pNodeStatus->rxUc.nBas,
             pNodeStatus->rxUc.preambleType, pNodeStatus->rxUc.cp,
             pNodeStatus->rxUc.rxGain/4.0, pNodeStatus->maxPhyRates.rxUcPhyRate,
             pNodeStatus->rxUc.avgSnr/2.0 ) ;


        printf("%d,%d,%d,N/A,%lf,%u,%f,",
             pNodeStatus->rxBc.nBas,
             pNodeStatus->rxBc.preambleType, pNodeStatus->rxBc.cp,
             pNodeStatus->rxBc.rxGain/4.0, pNodeStatus->maxPhyRates.rxBcPhyRate,
             pNodeStatus->rxBc.avgSnr/2.0 ) ;

        printf("%d,%d,%d,N/A,%lf,%u,%f",
             pNodeStatus->rxMap.nBas,
             pNodeStatus->rxMap.preambleType, pNodeStatus->rxMap.cp,
             pNodeStatus->rxMap.rxGain/4.0,  pNodeStatus->maxPhyRates.rxMapPhyRate,
             pNodeStatus->rxMap.avgSnr/2.0 ) ;
   }
   printf ("\n") ;
}



/** Print moca node stats
 *
 * Prints MoCA node stats data stored in pNodeStats
 *
 * @param pNodeStats (IN) pointer to node stats data
 * @return None.
 */
void mocacli_display_node_stats (PMoCA_NODE_STATUS_ENTRY pNodeStatus, PMoCA_NODE_STATISTICS_ENTRY pNodeStats)
{
   MAC_ADDRESS macAddr;

   moca_u32_to_mac(macAddr, pNodeStatus->eui[0], pNodeStatus->eui[1]);
   
   printf ("Node                             : %d \n", pNodeStats->nodeId) ;   
   printf ("MAC Address                      : %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\n",
             macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5]);   
   printf ("=============================================\n");
   printf ("Unicast Tx Pkts To Node          : %d \n", pNodeStats->txPkts) ;
   printf ("Unicast Rx Pkts From Node        : %d \n", pNodeStats->rxPkts) ;
   printf ("Rx CodeWord NoError              : %d \n", pNodeStats->rxCwUnError) ;
   printf ("Rx CodeWord ErrorAndCorrected    : %d \n", pNodeStats->rxCwCorrected) ;
   printf ("Rx CodeWord ErrorAndUnCorrected  : %d \n", pNodeStats->rxCwUncorrected) ;
   printf ("Rx NoSync Errors                 : %d \n", pNodeStats->rxNoSync) ;
   printf ("=============================================\n") ;
   printf ("\n") ;
}


/** Print extended moca node stats
 *
 * Prints extended MoCA node stats data stored in pNodeStats
 *
 * @param pNodeStats (IN) pointer to extended node stats data
 * @return None.
 */
void mocacli_display_node_stats_ext (PMoCA_NODE_STATISTICS_EXT_ENTRY pNodeStats)
{
   printf ("Node                             : %d \n", pNodeStats->nodeId) ;
   printf ("=============================================\n");

   printf ("NODE_RX_UC_CRC_ERROR                  : %d \n", pNodeStats->rxUcCrcError);
   printf ("NODE_RX_UC_TIMEOUT_ERROR              : %d \n", pNodeStats->rxUcTimeoutError);  
   printf ("NODE_RX_BC_CRC_ERROR                  : %d \n", pNodeStats->rxBcCrcError);
   printf ("NODE_RX_BC_TIMEOUT_ERROR              : %d \n", pNodeStats->rxBcTimeoutError);
   
   printf ("NODE_RX_MAP_CRC_ERROR                 : %d \n", pNodeStats->rxMapCrcError);
   printf ("NODE_RX_MAP_TIMEOUT_ERROR             : %d \n", pNodeStats->rxMapTimeoutError);
   printf ("NODE_RX_BEACON_CRC_ERROR              : %d \n", pNodeStats->rxBeaconCrcError);
   printf ("NODE_RX_BEACON_TIMEOUT_ERROR          : %d \n", pNodeStats->rxBeaconTimeoutError);
   printf ("NODE_RX_RR_CRC_ERROR                  : %d \n", pNodeStats->rxRrCrcError);
   printf ("NODE_RX_RR_TIMEOUT_ERROR              : %d \n", pNodeStats->rxRrTimeoutError);
   
   printf ("NODE_RX_LC_CRC_ERROR                  : %d \n", pNodeStats->rxLcCrcError);
   printf ("NODE_RX_LC_TIMEOUT_ERROR              : %d \n", pNodeStats->rxLcTimeoutError);
   
   printf ("NODE_RX_P1_ERROR                      : %d \n", pNodeStats->rxP2Error);
   printf ("NODE_RX_P2_ERROR                      : %d \n", pNodeStats->rxP2Error);
   printf ("NODE_RX_P3_ERROR                      : %d \n", pNodeStats->rxP3Error);
   printf ("NODE_RX_P1_GCD_ERROR                  : %d \n", pNodeStats->rxP1GcdError);
    
   printf ("=============================================\n") ;
   printf ("\n");
}

/** Print moca configuration
 *
 * Prints MoCA configuration data stored in pCfg
 *
 * @param pCfg (IN) pointer to config data
 * @param showAbsSnrTable (IN) flag indicating whether or not to print
 *                             absolute value SNR table
 * @return None.
 */
void mocacli_print_config( MoCA_CONFIG_PARAMS * pCfg, UINT32 showAbsSnrTable, UINT32 rftype)
{
   int i;

   printf ("        MoCA Configuration          \n");
   printf ("==================================  \n");
   printf ("maxFrameSize                : %u bytes \n", pCfg->maxFrameSize) ;
   printf ("maxTransmitTime             : %u uSec\n", pCfg->maxTransmitTime) ;
   printf ("minBwAlarmThreshold         : %u Mbps \n", pCfg->minBwAlarmThreshold) ;
   printf ("continuousIERRInsert        : %s \n", (pCfg->continuousIERRInsert == MoCA_CONTINUOUS_IE_RR_INSERT_ON) ? "on" : "off" )  ;
   printf ("continuousIEMapInsert       : %s \n", (pCfg->continuousIEMapInsert == MoCA_CONTINUOUS_IE_MAP_INSERT_ON) ? "on" : "off" )  ;
   printf ("maxPktAggr                  : %u pkts\n", pCfg->maxPktAggr)  ;
   printf ("minAggrWaitTime             : %u us\n", pCfg->minAggrWaitTime)  ;
   printf ("maxConstellationInfo (0-7)  : %2u  %2u  %2u  %2u  %2u  %2u  %2u  %2u\n", 
      pCfg->constellation[0], pCfg->constellation[1], pCfg->constellation[2], pCfg->constellation[3], 
      pCfg->constellation[4], pCfg->constellation[5], pCfg->constellation[6], pCfg->constellation[7] )  ;
   printf ("                    (8-15)  : %2u  %2u  %2u  %2u  %2u  %2u  %2u  %2u\n", 
      pCfg->constellation[8], pCfg->constellation[9], pCfg->constellation[10], pCfg->constellation[11], 
      pCfg->constellation[12], pCfg->constellation[13], pCfg->constellation[14], pCfg->constellation[15] )  ;
   printf ("pmkExchangeInterval         : %u hrs \n", pCfg->pmkExchangeInterval)  ;
   printf ("tekExchangeInterval         : %u min \n", pCfg->tekExchangeInterval)  ;
   printf ("HighPrioAlloc (Resv:Limit)  : %u:%u \n", pCfg->prioAllocation.resvHigh,
                  pCfg->prioAllocation.limitHigh) ;
   printf ("medPrioAlloc (Resv:Limit)   : %u:%u \n", pCfg->prioAllocation.resvMed,
                  pCfg->prioAllocation.limitMed) ;
   printf ("lowPrioAlloc (Resv:Limit)   : %u:%u \n", pCfg->prioAllocation.resvLow,
                  pCfg->prioAllocation.limitLow) ;
   printf ("snrMargin                   : %1.1fdB \n", (pCfg->snrMargin * 0.5))  ;
    
   printf ("minMapCycle                 : %u micro secs \n", pCfg->minMapCycle) ;
   printf ("maxMapCycle                 : %u micro secs \n", pCfg->maxMapCycle) ;
   printf ("rxTxPacketsPerQM            : %u \n", pCfg->rxTxPacketsPerQM) ;
   printf ("extraRxPacketsPerQM         : %u \n", pCfg->extraRxPacketsPerQM) ;   
   printf ("targetPHYRateQAM128         : %u mbps \n", pCfg->targetPhyRateQAM128) ;   
   printf ("targetPHYRateQAM256         : %u mbps \n", pCfg->targetPhyRateQAM256) ;
   printf ("targetPHYRateTurbo          : %u mbps \n", pCfg->targetPhyRateTurbo) ;
   printf ("targetPHYRateTurboPlus      : %u mbps \n", pCfg->targetPhyRateTurboPlus) ;
   printf ("nbasCappingEn               : %d \n", pCfg->nbasCappingEn) ;   
   printf ("selectiveRR                 : %d \n", pCfg->selectiveRR) ;
   printf ("Frequency shift mode        : %s \n", pCfg->freqShiftMode == MoCA_FREQ_SHIFT_MODE_MINUS? "minus":
                                                 pCfg->freqShiftMode == MoCA_FREQ_SHIFT_MODE_PLUS? "plus":"off");         
   printf ("snrMarginOffset             : %1.1f %1.1f %1.1f %1.1f %1.1f %1.1f %1.1f %1.1f %1.1f %1.1f \n",
                                          pCfg->snrMarginOffset[0]*0.5, pCfg->snrMarginOffset[1]*0.5,
                                          pCfg->snrMarginOffset[2]*0.5, pCfg->snrMarginOffset[3]*0.5,
                                          pCfg->snrMarginOffset[4]*0.5, pCfg->snrMarginOffset[5]*0.5,
                                          pCfg->snrMarginOffset[6]*0.5, pCfg->snrMarginOffset[7]*0.5,
                                          pCfg->snrMarginOffset[8]*0.5, pCfg->snrMarginOffset[9]*0.5) ;

   printf ("SapmTableEn                 : %d\n", pCfg->sapmEn);

   if (((rftype != MoCA_RF_TYPE_D_BAND) && (rftype != MoCA_RF_TYPE_C4_BAND)) ||
       (pCfg->sapmEn))
   {
       printf ("ArplTh                      : %d\n", pCfg->arplTh);
       printf ("SapmTable:");
       for (i=0;i<MoCA_MAX_SAPM_TBL_INDEX * 2;i++)
       {
          if (i%8 == 0)
              printf("\n");

          if (i < MoCA_MAX_SAPM_TBL_INDEX)
              printf ("[%3d=%5.01f] ", i+4, pCfg->sapmTable.sapmTableLo[i]/2.0);
          else
              printf ("[%3d=%5.01f] ", i+141-MoCA_MAX_SAPM_TBL_INDEX, pCfg->sapmTable.sapmTableHi[i-MoCA_MAX_SAPM_TBL_INDEX]/2.0);                
       }

       printf("\n");
   }

   printf ("RlapmTableEn                : %s\n", pCfg->rlapmEn==0?"off":pCfg->rlapmEn==1?"on":"phy");

   if (((rftype != MoCA_RF_TYPE_D_BAND) && (rftype != MoCA_RF_TYPE_C4_BAND)) ||
       (pCfg->rlapmEn))
   {
       printf ("RlapmTable:");

       if (pCfg->rlapmEn == 1)
       {
           for (i=0;i<MoCA_MAX_RLAPM_TBL_INDEX;i++)
           {
              if (i%8 == 0)
                  printf("\n");
              
              printf ("[%3d=%4.01f] ", i, pCfg->rlapmTable[i]/2.0);
           }
       }
       else
       {
           for (i=0;i<MoCA_MAX_RLAPM_TBL_INDEX;i++)
           {
              if (i%8 == 0)
                  printf("\n");
              
              printf ("[%3d=%3d] ", i, (unsigned int)pCfg->rlapmTable[i]+45);
           }        
       }

       printf("\n");
       printf ("RlapmCap                    : %1.1fdB \n", (pCfg->rlapmCap * 0.5));       
   }

   for (i=0;i<MOCA_MAX_EGR_MC_FILTERS;i++)
   {
      if (pCfg->mcAddrFilter[i].Valid)  
      {
          MAC_ADDRESS macAddr;

          moca_u32_to_mac(macAddr, pCfg->mcAddrFilter[i].AddrHi, pCfg->mcAddrFilter[i].AddrLo);

          printf ("EgrMcAddrFilter EntryId %02d  : %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\n",
             pCfg->mcAddrFilter[i].EntryId, macAddr[0], macAddr[1], macAddr[2], 
             macAddr[3], macAddr[4], macAddr[5]);    
      }
   }
   printf ("Diplexer                    : %d\n", pCfg->diplexer);    
   printf ("Rx Power Tuning             : %d (%d /w diplexer)\n", pCfg->rxPowerTuning, pCfg->rxPowerTuning+pCfg->diplexer);
  
   printf ("EN Capable                  : %d\n", pCfg->enCapable);
   printf ("EN Max Rate in Max BO       : %d\n", pCfg->enMaxRateInMaxBo);
   printf ("HostQOSEn                   : %d\n", pCfg->hostQOSEn);   
   printf ("loopbackEn                  : %d\n", pCfg->loopbackEn) ;

   if ( showAbsSnrTable ) {
      float  absSnr ;
      UINT32 i ;
      
      printf ("snrMarginOffsetAbs          : ") ;

      for ( i = 0 ; i < MoCA_MAX_SNR_TBL_INDEX ; i++ ) {
         absSnr = (float) (pCfg->snrMarginTable.mgnTable[ i ] / 2.0);
         printf ("%2.1f ", absSnr ) ;
      }
      printf ("\n") ;
   }
   printf ("==================================  \n");
}



/** Print moca trace configuration
 *
 * Prints MoCA trace configuration data stored in pTraceCfg
 *
 * @param pCfg (IN) pointer to trace config data
 * @return None.
 */
void mocacli_print_trace_config( MoCA_TRACE_PARAMS * pTraceCfg )
{            
   printf ("\n MoCA trace level is ") ;
   if (pTraceCfg->traceLevel == MOCA_TRC_LEVEL_NONE) {
      printf ("NONE \n") ;
      goto _End ;
   }
   else if (pTraceCfg->traceLevel == MOCA_TRC_LEVEL_ALL) {
      printf ("ALL \n") ;
      goto _End ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_FN_ENTRY) {
      printf ("ENTRY \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_FN_ENTRY) {
      printf ("ENTRY \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_FN_EXIT) {
      printf ("EXIT \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_INFO) {
      printf ("INFO \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_ERR) {
      printf ("ERR \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_DBG) {
      printf ("DBG \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_DUMP_HOST_CORE) {
      printf ("MMP \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_CORE) {
      printf ("CORE \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_TRAP) {
      printf ("TRAP \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_TIMESTAMPS) {
      printf ("TIME \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_WARN) {
      printf ("WARN \t") ;
   }

   if (pTraceCfg->traceLevel & MOCA_TRC_LEVEL_VERBOSE) {
      printf ("VERBOSE \t") ;
   }
   _End :
   printf ("\n") ;
}
