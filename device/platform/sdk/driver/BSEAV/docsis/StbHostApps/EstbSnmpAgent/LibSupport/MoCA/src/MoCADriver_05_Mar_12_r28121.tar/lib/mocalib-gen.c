/***************************************************************************
 *
 *     Copyright (c) 2008-2009, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *  Description: Generated libmoca functions - DO NOT EDIT
 *
 ***************************************************************************/

const char *moca_ie_name(uint16_t ie_type)
{
	switch(ie_type) {
		case IE_INIT_TIME:
			return("INIT_TIME");
		case IE_START_MOCA_CORE:
			return("START_MOCA_CORE");
		case IE_MAX_FRAME_SIZE:
			return("MAX_FRAME_SIZE");
		case IE_MAX_TRANSMIT_TIME:
			return("MAX_TRANSMIT_TIME");
		case IE_MIN_BW_ALARM_THRESHOLD:
			return("MIN_BW_ALARM_THRESHOLD");
		case IE_OOO_LMO:
			return("OOO_LMO");
		case IE_CONFIG_RESERVED_1:
			return("CONFIG_RESERVED_1");
		case IE_CONFIG_RESERVED_2:
			return("CONFIG_RESERVED_2");
		case IE_CONFIG_RESERVED_3:
			return("CONFIG_RESERVED_3");
		case IE_CONTINUOUS_IE_RR_INSERT:
			return("CONTINUOUS_IE_RR_INSERT");
		case IE_CONTINUOUS_IE_MAP_INSERT:
			return("CONTINUOUS_IE_MAP_INSERT");
		case IE_MAX_PKT_AGGR:
			return("MAX_PKT_AGGR");
		case IE_MAX_CONSTELLATION:
			return("MAX_CONSTELLATION");
		case IE_SIG_Y_DONE:
			return("SIG_Y_DONE");
		case IE_PMK_EXCHANGE_INTERVAL:
			return("PMK_EXCHANGE_INTERVAL");
		case IE_TEK_EXCHANGE_INTERVAL:
			return("TEK_EXCHANGE_INTERVAL");
		case IE_PRIORITY_ALLOCATIONS:
			return("PRIORITY_ALLOCATIONS");
		case IE_SNR_MARGIN_TABLE:
			return("SNR_MARGIN_TABLE");
		case IE_MIN_MAP_CYCLE:
			return("MIN_MAP_CYCLE");
		case IE_MAX_MAP_CYCLE:
			return("MAX_MAP_CYCLE");
		case IE_EN_MAX_RATE_IN_MAX_BO:
			return("EN_MAX_RATE_IN_MAX_BO");
		case IE_TARGET_PHY_RATE_QAM128:
			return("TARGET_PHY_RATE_QAM128");
		case IE_TARGET_PHY_RATE_QAM256:
			return("TARGET_PHY_RATE_QAM256");
		case IE_MOCA_CORE_TRACE_ENABLE:
			return("MOCA_CORE_TRACE_ENABLE");
		case IE_SAPM_EN:
			return("SAPM_EN");
		case IE_ARPL_TH:
			return("ARPL_TH");
		case IE_SAPM_TABLE:
			return("SAPM_TABLE");
		case IE_RLAPM_EN:
			return("RLAPM_EN");
		case IE_RLAPM_TABLE:
			return("RLAPM_TABLE");
		case IE_BEACON_CHANNEL_SET:
			return("BEACON_CHANNEL_SET");
		case IE_PSS_EN:
			return("PSS_EN");
		case IE_FREQ_SHIFT:
			return("FREQ_SHIFT");
		case IE_EGR_MC_ADDR_FILTER:
			return("EGR_MC_ADDR_FILTER");
		case IE_RX_POWER_TUNING:
			return("RX_POWER_TUNING");
		case IE_RX_TX_PACKETS_PER_QM:
			return("RX_TX_PACKETS_PER_QM");
		case IE_EXTRA_RX_PACKETS_PER_QM:
			return("EXTRA_RX_PACKETS_PER_QM");
		case IE_MIN_AGGR_WAITING_TIME:
			return("MIN_AGGR_WAITING_TIME");
		case IE_DOWNLOAD_TO_PACKET_RAM_DONE:
			return("DOWNLOAD_TO_PACKET_RAM_DONE");
		case IE_TARGET_PHY_RATE_TURBO:
			return("TARGET_PHY_RATE_TURBO");
		case IE_TARGET_PHY_RATE_TURBO_PLUS:
			return("TARGET_PHY_RATE_TURBO_PLUS");
		case IE_NBAS_CAPPING_EN:
			return("NBAS_CAPPING_EN");
		case IE_SELECTIVE_RR:
			return("SELECTIVE_RR");
		case IE_LOOPBACK_EN:
			return("LOOPBACK_EN");
		case IE_LAB_PILOTS:
			return("LAB_PILOTS");
		case IE_LAB_IQ_DIAGRAM_SET:
			return("LAB_IQ_DIAGRAM_SET");
		case IE_LAB_SNR_GRAPH_SET:
			return("LAB_SNR_GRAPH_SET");
		case IE_LAB_REGISTER:
			return("LAB_REGISTER");
		case IE_LAB_CALL_FUNC:
			return("LAB_CALL_FUNC");
		case IE_LAB_TPCAP:
			return("LAB_TPCAP");
		case IE_FMR_REQUEST:
			return("FMR_REQUEST");
		case IE_PQOS_CREATE_REQUEST:
			return("PQOS_CREATE_REQUEST");
		case IE_PQOS_INGR_ADD_FLOW:
			return("PQOS_INGR_ADD_FLOW");
		case IE_PQOS_UPDATE_REQUEST:
			return("PQOS_UPDATE_REQUEST");
		case IE_PQOS_INGR_UPDATE:
			return("PQOS_INGR_UPDATE");
		case IE_PQOS_DELETE_REQUEST:
			return("PQOS_DELETE_REQUEST");
		case IE_PQOS_INGR_DELETE:
			return("PQOS_INGR_DELETE");
		case IE_PQOS_LIST_REQUEST:
			return("PQOS_LIST_REQUEST");
		case IE_PQOS_QUERY_REQUEST:
			return("PQOS_QUERY_REQUEST");
		case IE_PQOS_MAINTENANCE_START:
			return("PQOS_MAINTENANCE_START");
		case IE_MR_REQUEST:
			return("MR_REQUEST");
		case IE_GEN_STATUS:
			return("GEN_STATUS");
		case IE_EXT_STATUS:
			return("EXT_STATUS");
		case IE_GEN_STATS:
			return("GEN_STATS");
		case IE_EXT_STATS:
			return("EXT_STATS");
		case IE_GEN_NODE_STATUS:
			return("GEN_NODE_STATUS");
		case IE_TX_PROFILE:
			return("TX_PROFILE");
		case IE_RX_UC_PROFILE:
			return("RX_UC_PROFILE");
		case IE_RX_BC_PROFILE:
			return("RX_BC_PROFILE");
		case IE_RX_MAP_PROFILE:
			return("RX_MAP_PROFILE");
		case IE_NODE_STATS:
			return("NODE_STATS");
		case IE_NODE_STATS_EXT:
			return("NODE_STATS_EXT");
		case IE_UC_FWD:
			return("UC_FWD");
		case IE_MC_FWD_RD:
			return("MC_FWD_RD");
		case IE_SRC_ADDR:
			return("SRC_ADDR");
		case IE_START:
			return("START");
		case IE_STOP:
			return("STOP");
		case IE_DRV_INFO:
			return("DRV_INFO");
		case IE_PASSWORD:
			return("PASSWORD");
		case IE_EXT_OCTET_COUNT:
			return("EXT_OCTET_COUNT");
		case IE_RESET_STATS:
			return("RESET_STATS");
		case IE_SNR_DATA:
			return("SNR_DATA");
		case IE_IQ_DATA:
			return("IQ_DATA");
		case IE_FW_FILE:
			return("FW_FILE");
		case IE_VERBOSE:
			return("VERBOSE");
		case IE_MOCA_CONST_TX_MODE:
			return("MOCA_CONST_TX_MODE");
		case IE_CIR_DATA:
			return("CIR_DATA");
		case IE_RESTORE_DEFAULTS:
			return("RESTORE_DEFAULTS");
		case IE_PQOS_TABLE:
			return("PQOS_TABLE");
		case IE_KEY_TIMES:
			return("KEY_TIMES");
		case IE_INIT_TIME_OPTIONS:
			return("INIT_TIME_OPTIONS");
		case IE_NODE_STATS_EXT_ACC:
			return("NODE_STATS_EXT_ACC");
		case IE_ERROR_TO_MASK:
			return("ERROR_TO_MASK");
		case IE_EN_CAPABLE:
			return("EN_CAPABLE");
		case IE_MESSAGE:
			return("MESSAGE");
		case IE_DIPLEXER:
			return("DIPLEXER");
		case IE_RLAPM_CAP:
			return("RLAPM_CAP");
		case IE_WOL:
			return("WOL");
		case IE_MISCVAL:
			return("MISCVAL");
		case IE_HOST_QOS:
			return("HOST_QOS");
		case IE_MOCA_CORE_READY:
			return("MOCA_CORE_READY");
		case IE_POWER_UP_STATUS:
			return("POWER_UP_STATUS");
		case IE_LINK_UP_STATE:
			return("LINK_UP_STATE");
		case IE_ADMISSION_STATUS:
			return("ADMISSION_STATUS");
		case IE_LIMITED_BW:
			return("LIMITED_BW");
		case IE_ERROR:
			return("ERROR");
		case IE_LMO_INFO:
			return("LMO_INFO");
		case IE_KEY_CHANGED:
			return("KEY_CHANGED");
		case IE_TOPOLOGY_CHANGED:
			return("TOPOLOGY_CHANGED");
		case IE_MOCA_VERSION_CHANGED:
			return("MOCA_VERSION_CHANGED");
		case IE_LAB_PRINTF:
			return("LAB_PRINTF");
		case IE_LAB_PRINTF_CODES:
			return("LAB_PRINTF_CODES");
		case IE_TRAP_1:
			return("TRAP_1");
		case IE_TRAP_2:
			return("TRAP_2");
		case IE_SIG_Y_READY:
			return("SIG_Y_READY");
		case IE_UCFWD_UPDATE:
			return("UCFWD_UPDATE");
		case IE_MOCA_RESET_REQUEST:
			return("MOCA_RESET_REQUEST");
		case IE_NC_ID_CHANGED:
			return("NC_ID_CHANGED");
		case IE_REMOVE_NODE_REQUEST:
			return("REMOVE_NODE_REQUEST");
		case IE_REMOVE_NODE_COMPLETE:
			return("REMOVE_NODE_COMPLETE");
		case IE_CPU_CHECK:
			return("CPU_CHECK");
		case IE_ASSERT:
			return("ASSERT");
		case IE_MIPS_EXCEPTION:
			return("MIPS_EXCEPTION");
		case IE_PQOS_CREATE_RESPONSE:
			return("PQOS_CREATE_RESPONSE");
		case IE_PQOS_CREATE_COMPLETE:
			return("PQOS_CREATE_COMPLETE");
		case IE_PQOS_UPDATE_RESPONSE:
			return("PQOS_UPDATE_RESPONSE");
		case IE_PQOS_UPDATE_COMPLETE:
			return("PQOS_UPDATE_COMPLETE");
		case IE_PQOS_DELETE_RESPONSE:
			return("PQOS_DELETE_RESPONSE");
		case IE_PQOS_DELETE_COMPLETE:
			return("PQOS_DELETE_COMPLETE");
		case IE_PQOS_LIST_RESPONSE:
			return("PQOS_LIST_RESPONSE");
		case IE_PQOS_QUERY_RESPONSE:
			return("PQOS_QUERY_RESPONSE");
		case IE_PQOS_MAINTENANCE_COMPLETE:
			return("PQOS_MAINTENANCE_COMPLETE");
		case IE_FMR_RESPONSE:
			return("FMR_RESPONSE");
		case IE_MR_RESPONSE:
			return("MR_RESPONSE");
		case IE_MR_COMPLETE:
			return("MR_COMPLETE");
		case IE_LOF:
			return("LOF");
		case IE_ABORT:
			return("ABORT");
		case IE_DRV_PRINTF:
			return("DRV_PRINTF");
		case IE_MOCAD_PRINTF:
			return("MOCAD_PRINTF");
	}
	return(NULL);
}

int moca_get_init_time(void *vctx, struct moca_init_time *out)
{
	return(moca_get(vctx, IE_INIT_TIME, out, sizeof(*out)));
}

int moca_set_init_time(void *vctx, const struct moca_init_time *in)
{
	return(moca_set(vctx, IE_INIT_TIME, in, sizeof(*in)));
}

int __moca_set_start_moca_core(void *vctx, uint32_t phy_freq)
{
	return(moca_set(vctx, IE_START_MOCA_CORE, &phy_freq, sizeof(phy_freq)));
}

int moca_get_max_frame_size(void *vctx, uint32_t *bytes)
{
	return(moca_get(vctx, IE_MAX_FRAME_SIZE, bytes, sizeof(*bytes)));
}

int moca_set_max_frame_size(void *vctx, uint32_t bytes)
{
	return(moca_set(vctx, IE_MAX_FRAME_SIZE, &bytes, sizeof(bytes)));
}

int moca_get_max_transmit_time(void *vctx, uint32_t *usec)
{
	return(moca_get(vctx, IE_MAX_TRANSMIT_TIME, usec, sizeof(*usec)));
}

int moca_set_max_transmit_time(void *vctx, uint32_t usec)
{
	return(moca_set(vctx, IE_MAX_TRANSMIT_TIME, &usec, sizeof(usec)));
}

int moca_get_min_bw_alarm_threshold(void *vctx, uint32_t *mbps)
{
	return(moca_get(vctx, IE_MIN_BW_ALARM_THRESHOLD, mbps, sizeof(*mbps)));
}

int moca_set_min_bw_alarm_threshold(void *vctx, uint32_t mbps)
{
	return(moca_set(vctx, IE_MIN_BW_ALARM_THRESHOLD, &mbps, sizeof(mbps)));
}

int moca_set_ooo_lmo(void *vctx, uint32_t node_id)
{
	return(moca_set(vctx, IE_OOO_LMO, &node_id, sizeof(node_id)));
}

int moca_get_config_reserved_1(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_CONFIG_RESERVED_1, val, sizeof(*val)));
}

int moca_set_config_reserved_1(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_CONFIG_RESERVED_1, &val, sizeof(val)));
}

int moca_get_config_reserved_2(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_CONFIG_RESERVED_2, val, sizeof(*val)));
}

int moca_set_config_reserved_2(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_CONFIG_RESERVED_2, &val, sizeof(val)));
}

int moca_get_config_reserved_3(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_CONFIG_RESERVED_3, val, sizeof(*val)));
}

int moca_set_config_reserved_3(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_CONFIG_RESERVED_3, &val, sizeof(val)));
}

int moca_get_continuous_ie_rr_insert(void *vctx, uint32_t *bool_val)
{
	return(moca_get(vctx, IE_CONTINUOUS_IE_RR_INSERT, bool_val, sizeof(*bool_val)));
}

int moca_set_continuous_ie_rr_insert(void *vctx, uint32_t bool_val)
{
	return(moca_set(vctx, IE_CONTINUOUS_IE_RR_INSERT, &bool_val, sizeof(bool_val)));
}

int moca_get_continuous_ie_map_insert(void *vctx, uint32_t *bool_val)
{
	return(moca_get(vctx, IE_CONTINUOUS_IE_MAP_INSERT, bool_val, sizeof(*bool_val)));
}

int moca_set_continuous_ie_map_insert(void *vctx, uint32_t bool_val)
{
	return(moca_set(vctx, IE_CONTINUOUS_IE_MAP_INSERT, &bool_val, sizeof(bool_val)));
}

int moca_get_max_pkt_aggr(void *vctx, uint32_t *pkts)
{
	return(moca_get(vctx, IE_MAX_PKT_AGGR, pkts, sizeof(*pkts)));
}

int moca_set_max_pkt_aggr(void *vctx, uint32_t pkts)
{
	return(moca_set(vctx, IE_MAX_PKT_AGGR, &pkts, sizeof(pkts)));
}

int moca_get_max_constellation(void *vctx, uint32_t node_id, uint32_t *bits_per_carrier)
{
	return(moca_get_inout(vctx, IE_MAX_CONSTELLATION, &node_id, sizeof(node_id), bits_per_carrier, sizeof(*bits_per_carrier)));
}

int moca_set_max_constellation(void *vctx, const struct moca_max_constellation *in)
{
	return(moca_set(vctx, IE_MAX_CONSTELLATION, in, sizeof(*in)));
}

int moca_set_sig_y_done(void *vctx, const struct moca_sig_y_done *in)
{
	return(moca_set(vctx, IE_SIG_Y_DONE, in, sizeof(*in)));
}

int moca_get_pmk_exchange_interval(void *vctx, uint32_t *msec)
{
	return(moca_get(vctx, IE_PMK_EXCHANGE_INTERVAL, msec, sizeof(*msec)));
}

int moca_set_pmk_exchange_interval(void *vctx, uint32_t msec)
{
	return(moca_set(vctx, IE_PMK_EXCHANGE_INTERVAL, &msec, sizeof(msec)));
}

int moca_get_tek_exchange_interval(void *vctx, uint32_t *msec)
{
	return(moca_get(vctx, IE_TEK_EXCHANGE_INTERVAL, msec, sizeof(*msec)));
}

int moca_set_tek_exchange_interval(void *vctx, uint32_t msec)
{
	return(moca_set(vctx, IE_TEK_EXCHANGE_INTERVAL, &msec, sizeof(msec)));
}

int moca_get_priority_allocations(void *vctx, struct moca_priority_allocations *out)
{
	return(moca_get(vctx, IE_PRIORITY_ALLOCATIONS, out, sizeof(*out)));
}

int moca_set_priority_allocations(void *vctx, const struct moca_priority_allocations *in)
{
	return(moca_set(vctx, IE_PRIORITY_ALLOCATIONS, in, sizeof(*in)));
}

int moca_get_snr_margin_table(void *vctx, struct moca_snr_margin_table *out)
{
	int ret;
	ret = moca_get_noswap(vctx, IE_SNR_MARGIN_TABLE, out, sizeof(*out));
	return(ret);
}

int moca_set_snr_margin_table(void *vctx, struct moca_snr_margin_table *out)
{
	struct moca_snr_margin_table tmp = *out;
	return(moca_set_noswap(vctx, IE_SNR_MARGIN_TABLE, &tmp, sizeof(tmp)));
}

int moca_get_min_map_cycle(void *vctx, uint32_t *usec)
{
	return(moca_get(vctx, IE_MIN_MAP_CYCLE, usec, sizeof(*usec)));
}

int moca_set_min_map_cycle(void *vctx, uint32_t usec)
{
	return(moca_set(vctx, IE_MIN_MAP_CYCLE, &usec, sizeof(usec)));
}

int moca_get_max_map_cycle(void *vctx, uint32_t *usec)
{
	return(moca_get(vctx, IE_MAX_MAP_CYCLE, usec, sizeof(*usec)));
}

int moca_set_max_map_cycle(void *vctx, uint32_t usec)
{
	return(moca_set(vctx, IE_MAX_MAP_CYCLE, &usec, sizeof(usec)));
}

int moca_get_en_max_rate_in_max_bo(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_EN_MAX_RATE_IN_MAX_BO, val, sizeof(*val)));
}

int moca_set_en_max_rate_in_max_bo(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_EN_MAX_RATE_IN_MAX_BO, &val, sizeof(val)));
}

int moca_get_target_phy_rate_qam128(void *vctx, uint32_t *mbps)
{
	return(moca_get(vctx, IE_TARGET_PHY_RATE_QAM128, mbps, sizeof(*mbps)));
}

int moca_set_target_phy_rate_qam128(void *vctx, uint32_t mbps)
{
	return(moca_set(vctx, IE_TARGET_PHY_RATE_QAM128, &mbps, sizeof(mbps)));
}

int moca_get_target_phy_rate_qam256(void *vctx, uint32_t *mbps)
{
	return(moca_get(vctx, IE_TARGET_PHY_RATE_QAM256, mbps, sizeof(*mbps)));
}

int moca_set_target_phy_rate_qam256(void *vctx, uint32_t mbps)
{
	return(moca_set(vctx, IE_TARGET_PHY_RATE_QAM256, &mbps, sizeof(mbps)));
}

int moca_get_moca_core_trace_enable(void *vctx, uint32_t *bool_val)
{
	return(moca_get(vctx, IE_MOCA_CORE_TRACE_ENABLE, bool_val, sizeof(*bool_val)));
}

int moca_set_moca_core_trace_enable(void *vctx, uint32_t bool_val)
{
	return(moca_set(vctx, IE_MOCA_CORE_TRACE_ENABLE, &bool_val, sizeof(bool_val)));
}

int moca_get_sapm_en(void *vctx, uint32_t *bool_val)
{
	return(moca_get(vctx, IE_SAPM_EN, bool_val, sizeof(*bool_val)));
}

int moca_set_sapm_en(void *vctx, uint32_t bool_val)
{
	return(moca_set(vctx, IE_SAPM_EN, &bool_val, sizeof(bool_val)));
}

int moca_get_arpl_th(void *vctx, int32_t *arpl)
{
	return(moca_get(vctx, IE_ARPL_TH, arpl, sizeof(*arpl)));
}

int moca_set_arpl_th(void *vctx, int32_t arpl)
{
	return(moca_set(vctx, IE_ARPL_TH, &arpl, sizeof(arpl)));
}

int moca_get_sapm_table(void *vctx, struct moca_sapm_table *out)
{
	int ret;
	ret = moca_get_noswap(vctx, IE_SAPM_TABLE, out, sizeof(*out));
	return(ret);
}

int moca_set_sapm_table(void *vctx, struct moca_sapm_table *out)
{
	struct moca_sapm_table tmp = *out;
	return(moca_set_noswap(vctx, IE_SAPM_TABLE, &tmp, sizeof(tmp)));
}

int moca_get_rlapm_en(void *vctx, uint32_t *bool_val)
{
	return(moca_get(vctx, IE_RLAPM_EN, bool_val, sizeof(*bool_val)));
}

int moca_set_rlapm_en(void *vctx, uint32_t bool_val)
{
	return(moca_set(vctx, IE_RLAPM_EN, &bool_val, sizeof(bool_val)));
}

int moca_get_rlapm_table(void *vctx, struct moca_rlapm_table *out)
{
	int ret;
	ret = moca_get_noswap(vctx, IE_RLAPM_TABLE, out, sizeof(*out));
	return(ret);
}

int moca_set_rlapm_table(void *vctx, struct moca_rlapm_table *out)
{
	struct moca_rlapm_table tmp = *out;
	return(moca_set_noswap(vctx, IE_RLAPM_TABLE, &tmp, sizeof(tmp)));
}

int moca_set_beacon_channel_set(void *vctx, uint32_t channel)
{
	return(moca_set(vctx, IE_BEACON_CHANNEL_SET, &channel, sizeof(channel)));
}

int moca_get_pss_en(void *vctx, uint32_t *enable)
{
	return(moca_get(vctx, IE_PSS_EN, enable, sizeof(*enable)));
}

int moca_set_pss_en(void *vctx, uint32_t enable)
{
	return(moca_set(vctx, IE_PSS_EN, &enable, sizeof(enable)));
}

int moca_get_freq_shift(void *vctx, uint32_t *direction)
{
	return(moca_get(vctx, IE_FREQ_SHIFT, direction, sizeof(*direction)));
}

int moca_set_freq_shift(void *vctx, uint32_t direction)
{
	return(moca_set(vctx, IE_FREQ_SHIFT, &direction, sizeof(direction)));
}

int moca_set_egr_mc_addr_filter(void *vctx, const struct moca_egr_mc_addr_filter *in)
{
	return(moca_set(vctx, IE_EGR_MC_ADDR_FILTER, in, sizeof(*in)));
}

int moca_get_egr_mc_addr_filter_get(void *vctx, uint32_t entryid, struct moca_egr_mc_addr_filter_get *out)
{
	return(moca_get_inout(vctx, IE_EGR_MC_ADDR_FILTER_GET, &entryid, sizeof(entryid), out, sizeof(*out)));
}

int moca_get_rx_power_tuning(void *vctx, int32_t *val)
{
	return(moca_get(vctx, IE_RX_POWER_TUNING, val, sizeof(*val)));
}

int moca_set_rx_power_tuning(void *vctx, int32_t val)
{
	return(moca_set(vctx, IE_RX_POWER_TUNING, &val, sizeof(val)));
}

int moca_get_rx_tx_packets_per_qm(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_RX_TX_PACKETS_PER_QM, val, sizeof(*val)));
}

int moca_set_rx_tx_packets_per_qm(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_RX_TX_PACKETS_PER_QM, &val, sizeof(val)));
}

int moca_get_extra_rx_packets_per_qm(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_EXTRA_RX_PACKETS_PER_QM, val, sizeof(*val)));
}

int moca_set_extra_rx_packets_per_qm(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_EXTRA_RX_PACKETS_PER_QM, &val, sizeof(val)));
}

int moca_get_min_aggr_waiting_time(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_MIN_AGGR_WAITING_TIME, val, sizeof(*val)));
}

int moca_set_min_aggr_waiting_time(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_MIN_AGGR_WAITING_TIME, &val, sizeof(val)));
}

int moca_set_download_to_packet_ram_done(void *vctx)
{
	return(moca_set(vctx, IE_DOWNLOAD_TO_PACKET_RAM_DONE, NULL, 0));
}

int moca_get_target_phy_rate_turbo(void *vctx, uint32_t *mbps)
{
	return(moca_get(vctx, IE_TARGET_PHY_RATE_TURBO, mbps, sizeof(*mbps)));
}

int moca_set_target_phy_rate_turbo(void *vctx, uint32_t mbps)
{
	return(moca_set(vctx, IE_TARGET_PHY_RATE_TURBO, &mbps, sizeof(mbps)));
}

int moca_get_target_phy_rate_turbo_plus(void *vctx, uint32_t *mbps)
{
	return(moca_get(vctx, IE_TARGET_PHY_RATE_TURBO_PLUS, mbps, sizeof(*mbps)));
}

int moca_set_target_phy_rate_turbo_plus(void *vctx, uint32_t mbps)
{
	return(moca_set(vctx, IE_TARGET_PHY_RATE_TURBO_PLUS, &mbps, sizeof(mbps)));
}

int moca_get_nbas_capping_en(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_NBAS_CAPPING_EN, val, sizeof(*val)));
}

int moca_set_nbas_capping_en(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_NBAS_CAPPING_EN, &val, sizeof(val)));
}

int moca_get_selective_rr(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_SELECTIVE_RR, val, sizeof(*val)));
}

int moca_set_selective_rr(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_SELECTIVE_RR, &val, sizeof(val)));
}

int moca_get_loopback_en(void *vctx, uint32_t *en)
{
	return(moca_get(vctx, IE_LOOPBACK_EN, en, sizeof(*en)));
}

int moca_set_loopback_en(void *vctx, uint32_t en)
{
	return(moca_set(vctx, IE_LOOPBACK_EN, &en, sizeof(en)));
}

int moca_get_lab_pilots(void *vctx, struct moca_lab_pilots *out)
{
	int ret;
	ret = moca_get_noswap(vctx, IE_LAB_PILOTS, out, sizeof(*out));
	return(ret);
}

int moca_set_lab_iq_diagram_set(void *vctx, const struct moca_lab_iq_diagram_set *in)
{
	return(moca_set(vctx, IE_LAB_IQ_DIAGRAM_SET, in, sizeof(*in)));
}

int moca_set_lab_snr_graph_set(void *vctx, uint32_t node_id)
{
	return(moca_set(vctx, IE_LAB_SNR_GRAPH_SET, &node_id, sizeof(node_id)));
}

int moca_get_lab_register(void *vctx, uint32_t address, uint32_t *data)
{
	return(moca_get_inout(vctx, IE_LAB_REGISTER, &address, sizeof(address), data, sizeof(*data)));
}

int moca_set_lab_register(void *vctx, const struct moca_lab_register *in)
{
	return(moca_set(vctx, IE_LAB_REGISTER, in, sizeof(*in)));
}

int moca_get_lab_call_func(void *vctx, uint32_t *retval)
{
	return(moca_get(vctx, IE_LAB_CALL_FUNC, retval, sizeof(*retval)));
}

int moca_set_lab_call_func(void *vctx, const struct moca_lab_call_func *in)
{
	return(moca_set(vctx, IE_LAB_CALL_FUNC, in, sizeof(*in)));
}

int moca_set_lab_tpcap(void *vctx, const struct moca_lab_tpcap *in)
{
	return(moca_set(vctx, IE_LAB_TPCAP, in, sizeof(*in)));
}

int moca_set_fmr_request(void *vctx, struct moca_fmr_request *out)
{
	struct moca_fmr_request tmp = *out;
	tmp.hdrFmt = 0x8;
	tmp.reserved_0 = 0;
	tmp.vendorId = BE16(0);
	tmp.transType = 0x2;
	tmp.transSubtype = 0x1;
	tmp.wave0Nodemask = BE32(tmp.wave0Nodemask);
	tmp.reserved_1 = BE32(0);
	tmp.reserved_2 = 0;
	tmp.msgPriority = 0x80;
	tmp.txnLastWaveNum = 1;
	tmp.reserved_3 = 0;
	tmp.reserved_4 = BE32(0);
	return(moca_set_noswap(vctx, IE_FMR_REQUEST, &tmp, sizeof(tmp)));
}

int moca_set_pqos_create_request(void *vctx, struct moca_pqos_create_request *out)
{
	struct moca_pqos_create_request tmp = *out;
	tmp.hdrFmt = 0x8;
	tmp.reserved_0 = 0;
	tmp.vendorId = BE16(0);
	tmp.transType = 0x1;
	tmp.transSubtype = 0x1;
	tmp.wave0Nodemask = BE32(tmp.wave0Nodemask);
	tmp.reserved_1 = BE32(0);
	tmp.reserved_2 = 0;
	tmp.msgPriority = 0xf0;
	tmp.txnLastWaveNum = 2;
	tmp.reserved_3 = 0;
	tmp.flowid_hi = BE32(tmp.flowid_hi);
	tmp.flowid_lo = BE32(tmp.flowid_lo);
	tmp.tPacketSize = BE16(tmp.tPacketSize);
	tmp.reserved_4 = 0;
	tmp.flowTag = BE32(tmp.flowTag);
	tmp.packetda_hi = BE32(tmp.packetda_hi);
	tmp.packetda_lo = BE32(tmp.packetda_lo);
	tmp.tPeakDataRate = BE32(tmp.tPeakDataRate);
	tmp.tLeaseTime = BE32(tmp.tLeaseTime);
	tmp.reserved_6[0] = 0;
	tmp.reserved_6[1] = 0;
	tmp.reserved_6[2] = 0;
	return(moca_set_noswap(vctx, IE_PQOS_CREATE_REQUEST, &tmp, sizeof(tmp)));
}

int moca_set_pqos_ingr_add_flow(void *vctx, const struct moca_pqos_ingr_add_flow *in)
{
	return(moca_set(vctx, IE_PQOS_INGR_ADD_FLOW, in, sizeof(*in)));
}

int moca_set_pqos_update_request(void *vctx, struct moca_pqos_update_request *out)
{
	struct moca_pqos_update_request tmp = *out;
	tmp.hdrFmt = 0x8;
	tmp.reserved_0 = 0;
	tmp.vendorId = BE16(0);
	tmp.transType = 0x1;
	tmp.transSubtype = 0x2;
	tmp.wave0Nodemask = BE32(tmp.wave0Nodemask);
	tmp.reserved_1 = BE32(0);
	tmp.reserved_2 = 0;
	tmp.msgPriority = 0xf0;
	tmp.txnLastWaveNum = 2;
	tmp.reserved_3 = 0;
	tmp.flowid_hi = BE32(tmp.flowid_hi);
	tmp.flowid_lo = BE32(tmp.flowid_lo);
	tmp.tPacketSize = BE16(tmp.tPacketSize);
	tmp.reserved_4 = 0;
	tmp.flowTag = BE32(tmp.flowTag);
	tmp.packetda_hi = BE32(tmp.packetda_hi);
	tmp.packetda_lo = BE32(tmp.packetda_lo);
	tmp.tPeakDataRate = BE32(tmp.tPeakDataRate);
	tmp.tLeaseTime = BE32(tmp.tLeaseTime);
	tmp.reserved_6[0] = 0;
	tmp.reserved_6[1] = 0;
	tmp.reserved_6[2] = 0;
	return(moca_set_noswap(vctx, IE_PQOS_UPDATE_REQUEST, &tmp, sizeof(tmp)));
}

int moca_set_pqos_ingr_update(void *vctx, const struct moca_pqos_ingr_update *in)
{
	return(moca_set(vctx, IE_PQOS_INGR_UPDATE, in, sizeof(*in)));
}

int moca_set_pqos_delete_request(void *vctx, struct moca_pqos_delete_request *out)
{
	struct moca_pqos_delete_request tmp = *out;
	tmp.hdrFmt = 0x8;
	tmp.reserved_0 = 0;
	tmp.vendorId = BE16(0);
	tmp.transType = 0x1;
	tmp.transSubtype = 0x3;
	tmp.wave0Nodemask = BE32(tmp.wave0Nodemask);
	tmp.reserved_1 = BE32(0);
	tmp.reserved_2 = 0;
	tmp.msgPriority = 0xf0;
	tmp.txnLastWaveNum = 2;
	tmp.reserved_3 = 0;
	tmp.flowid_hi = BE32(tmp.flowid_hi);
	tmp.flowid_lo = BE32(tmp.flowid_lo);
	tmp.reserved_4 = BE32(0);
	return(moca_set_noswap(vctx, IE_PQOS_DELETE_REQUEST, &tmp, sizeof(tmp)));
}

int moca_set_pqos_ingr_delete(void *vctx, const struct moca_pqos_ingr_delete *in)
{
	return(moca_set(vctx, IE_PQOS_INGR_DELETE, in, sizeof(*in)));
}

int moca_set_pqos_list_request(void *vctx, struct moca_pqos_list_request *out)
{
	struct moca_pqos_list_request tmp = *out;
	tmp.hdrFmt = 0x8;
	tmp.reserved_0 = 0;
	tmp.vendorId = BE16(0);
	tmp.transType = 0x1;
	tmp.transSubtype = 0x4;
	tmp.wave0Nodemask = BE32(tmp.wave0Nodemask);
	tmp.reserved_1 = BE32(0);
	tmp.reserved_2 = 0;
	tmp.msgPriority = 0x80;
	tmp.txnLastWaveNum = 1;
	tmp.reserved_3 = 0;
	tmp.flowStartIndex = BE32(tmp.flowStartIndex);
	tmp.reserved_4[0] = 0;
	tmp.reserved_4[1] = 0;
	tmp.reserved_4[2] = 0;
	return(moca_set_noswap(vctx, IE_PQOS_LIST_REQUEST, &tmp, sizeof(tmp)));
}

int moca_set_pqos_query_request(void *vctx, struct moca_pqos_query_request *out)
{
	struct moca_pqos_query_request tmp = *out;
	tmp.hdrFmt = 0x8;
	tmp.reserved_0 = 0;
	tmp.vendorId = BE16(0);
	tmp.transType = 0x1;
	tmp.transSubtype = 0x5;
	tmp.wave0Nodemask = BE32(tmp.wave0Nodemask);
	tmp.reserved_1 = BE32(0);
	tmp.reserved_2 = 0;
	tmp.msgPriority = 0x80;
	tmp.txnLastWaveNum = 1;
	tmp.reserved_3 = 0;
	tmp.reserved_4 = BE32(0);
	tmp.flowid_hi = BE32(tmp.flowid_hi);
	tmp.flowid_lo = BE32(tmp.flowid_lo);
	return(moca_set_noswap(vctx, IE_PQOS_QUERY_REQUEST, &tmp, sizeof(tmp)));
}

int moca_set_pqos_maintenance_start(void *vctx)
{
	return(moca_set(vctx, IE_PQOS_MAINTENANCE_START, NULL, 0));
}

int moca_set_mr_request(void *vctx, struct moca_mr_request *out)
{
	struct moca_mr_request tmp = *out;
	tmp.hdrFmt = 0x8;
	tmp.reserved_0 = 0;
	tmp.vendorId = BE16(0);
	tmp.transType = 0x3;
	tmp.transSubtype = 0x1;
	tmp.wave0Nodemask = BE32(tmp.wave0Nodemask);
	tmp.reserved_1 = BE32(0);
	tmp.reserved_2 = 0;
	tmp.msgPriority = 0x80;
	tmp.txnLastWaveNum = 2;
	tmp.reserved_3 = 0;
	tmp.resetStatus = 0;
	tmp.nonDefSeqNum = BE16(tmp.nonDefSeqNum);
	return(moca_set_noswap(vctx, IE_MR_REQUEST, &tmp, sizeof(tmp)));
}

int moca_get_gen_status(void *vctx, struct moca_gen_status *out)
{
	return(moca_get(vctx, IE_GEN_STATUS, out, sizeof(*out)));
}

int moca_get_ext_status(void *vctx, struct moca_ext_status *out)
{
	return(moca_get(vctx, IE_EXT_STATUS, out, sizeof(*out)));
}

int moca_get_gen_stats(void *vctx, struct moca_gen_stats *out)
{
	return(moca_get(vctx, IE_GEN_STATS, out, sizeof(*out)));
}

int moca_get_ext_stats(void *vctx, struct moca_ext_stats *out)
{
	return(moca_get(vctx, IE_EXT_STATS, out, sizeof(*out)));
}

int moca_get_gen_node_status(void *vctx, uint32_t idx, struct moca_gen_node_status *out)
{
	return(moca_get(vctx, IE_GEN_NODE_STATUS + idx, out, sizeof(*out)));
}

int moca_get_tx_profile(void *vctx, uint32_t idx, struct moca_tx_profile *out)
{
	return(moca_get(vctx, IE_TX_PROFILE + idx, out, sizeof(*out)));
}

int moca_get_rx_uc_profile(void *vctx, uint32_t idx, struct moca_rx_uc_profile *out)
{
	return(moca_get(vctx, IE_RX_UC_PROFILE + idx, out, sizeof(*out)));
}

int moca_get_rx_bc_profile(void *vctx, uint32_t idx, struct moca_rx_bc_profile *out)
{
	return(moca_get(vctx, IE_RX_BC_PROFILE + idx, out, sizeof(*out)));
}

int moca_get_rx_map_profile(void *vctx, uint32_t idx, struct moca_rx_map_profile *out)
{
	return(moca_get(vctx, IE_RX_MAP_PROFILE + idx, out, sizeof(*out)));
}

int moca_get_node_stats(void *vctx, uint32_t idx, struct moca_node_stats *out)
{
	return(moca_get(vctx, IE_NODE_STATS + idx, out, sizeof(*out)));
}

int moca_get_node_stats_ext(void *vctx, uint32_t idx, struct moca_node_stats_ext *out)
{
	int ret;
	ret = moca_get_noswap(vctx, IE_NODE_STATS_EXT + idx, out, sizeof(*out));
	return(ret);
}

int moca_get_uc_fwd(void *vctx, struct moca_uc_fwd *out, int max_out_len)
{
	return(moca_get_table(vctx, IE_UC_FWD, out, sizeof(*out), max_out_len));
}

int moca_get_mc_fwd_rd(void *vctx, struct moca_mc_fwd_rd *out, int max_out_len)
{
	return(moca_get_table(vctx, IE_MC_FWD_RD, out, sizeof(*out), max_out_len));
}

int moca_add_mc_fwd_wr(void *vctx, const struct moca_mc_fwd_wr *entry)
{
	return(moca_table_op(vctx, MOCA_MSG_ADD_ENTRY, IE_MC_FWD_WR, entry, sizeof(*entry)));
}

int moca_del_mc_fwd_wr(void *vctx, const struct moca_mc_fwd_wr *entry)
{
	return(moca_table_op(vctx, MOCA_MSG_DEL_ENTRY, IE_MC_FWD_WR, entry, sizeof(*entry)));
}

int moca_get_src_addr(void *vctx, struct moca_src_addr *out, int max_out_len)
{
	return(moca_get_table(vctx, IE_SRC_ADDR, out, sizeof(*out), max_out_len));
}

int moca_set_start(void *vctx)
{
	return(moca_set(vctx, IE_START, NULL, 0));
}

int moca_set_stop(void *vctx)
{
	return(moca_set(vctx, IE_STOP, NULL, 0));
}

int moca_get_drv_info(void *vctx, struct moca_drv_info *out)
{
	int ret;
	ret = moca_get_noswap(vctx, IE_DRV_INFO, out, sizeof(*out));
	out->version = BE32(out->version);
	out->build_number = BE32(out->build_number);
	out->hw_rev = BE32(out->hw_rev);
	out->uptime = BE32(out->uptime);
	out->link_uptime = BE32(out->link_uptime);
	out->core_uptime = BE32(out->core_uptime);
	out->rf_band = BE32(out->rf_band);
	out->chip_id = BE32(out->chip_id);
	return(ret);
}

int moca_get_password(void *vctx, struct moca_password *out)
{
	int ret;
	ret = moca_get_noswap(vctx, IE_PASSWORD, out, sizeof(*out));
	return(ret);
}

int moca_set_password(void *vctx, struct moca_password *out)
{
	struct moca_password tmp = *out;
	return(moca_set_noswap(vctx, IE_PASSWORD, &tmp, sizeof(tmp)));
}

int moca_get_ext_octet_count(void *vctx, struct moca_ext_octet_count *out)
{
	return(moca_get(vctx, IE_EXT_OCTET_COUNT, out, sizeof(*out)));
}

int moca_set_reset_stats(void *vctx)
{
	return(moca_set(vctx, IE_RESET_STATS, NULL, 0));
}

int moca_get_snr_data(void *vctx, struct moca_snr_data *out)
{
	return(moca_get(vctx, IE_SNR_DATA, out, sizeof(*out)));
}

int moca_get_iq_data(void *vctx, struct moca_iq_data *out)
{
	int ret;
	ret = moca_get_noswap(vctx, IE_IQ_DATA, out, sizeof(*out));
	return(ret);
}

int moca_set_fw_file(void *vctx, struct moca_fw_file *out)
{
	struct moca_fw_file tmp = *out;
	return(moca_set_noswap(vctx, IE_FW_FILE, &tmp, sizeof(tmp)));
}

int moca_get_verbose(void *vctx, uint32_t *level)
{
	return(moca_get(vctx, IE_VERBOSE, level, sizeof(*level)));
}

int moca_set_verbose(void *vctx, uint32_t level)
{
	return(moca_set(vctx, IE_VERBOSE, &level, sizeof(level)));
}

int moca_get_moca_const_tx_mode(void *vctx, uint32_t *state)
{
	return(moca_get(vctx, IE_MOCA_CONST_TX_MODE, state, sizeof(*state)));
}

int moca_get_cir_data(void *vctx, uint32_t node, struct moca_cir_data *out)
{
	int ret;
	ret = moca_get_inout_noswap(vctx, IE_CIR_DATA, &node, sizeof(node), out, sizeof(*out));
	return(ret);
}

int moca_set_restore_defaults(void *vctx)
{
	return(moca_set(vctx, IE_RESTORE_DEFAULTS, NULL, 0));
}

int moca_get_pqos_table(void *vctx, struct moca_pqos_table *out, int max_out_len)
{
	return(moca_get_table(vctx, IE_PQOS_TABLE, out, sizeof(*out), max_out_len));
}

int moca_add_pqos_table(void *vctx, const struct moca_pqos_table *entry)
{
	return(moca_table_op(vctx, MOCA_MSG_ADD_ENTRY, IE_PQOS_TABLE, entry, sizeof(*entry)));
}

int moca_del_pqos_table(void *vctx, const struct moca_pqos_table *entry)
{
	return(moca_table_op(vctx, MOCA_MSG_DEL_ENTRY, IE_PQOS_TABLE, entry, sizeof(*entry)));
}

int moca_get_key_times(void *vctx, struct moca_key_times *out)
{
	return(moca_get(vctx, IE_KEY_TIMES, out, sizeof(*out)));
}

int moca_set_init_time_options(void *vctx, const struct moca_init_time_options *in)
{
	return(moca_set(vctx, IE_INIT_TIME_OPTIONS, in, sizeof(*in)));
}

int moca_get_init_time_options(void *vctx, struct moca_init_time_options *out)
{
	return(moca_get(vctx, IE_INIT_TIME_OPTIONS, out, sizeof(*out)));
}

int moca_get_node_stats_ext_acc(void *vctx, uint32_t idx, struct moca_node_stats_ext_acc *out)
{
	return(moca_get(vctx, IE_NODE_STATS_EXT_ACC + idx, out, sizeof(*out)));
}

int moca_set_error_to_mask(void *vctx, const struct moca_error_to_mask *in)
{
	return(moca_set(vctx, IE_ERROR_TO_MASK, in, sizeof(*in)));
}

int moca_get_error_to_mask(void *vctx, struct moca_error_to_mask *out)
{
	return(moca_get(vctx, IE_ERROR_TO_MASK, out, sizeof(*out)));
}

int moca_set_en_capable(void *vctx, uint32_t enable)
{
	return(moca_set(vctx, IE_EN_CAPABLE, &enable, sizeof(enable)));
}

int moca_get_en_capable(void *vctx, uint32_t *enable)
{
	return(moca_get(vctx, IE_EN_CAPABLE, enable, sizeof(*enable)));
}

int moca_set_message(void *vctx, uint32_t id)
{
	return(moca_set(vctx, IE_MESSAGE, &id, sizeof(id)));
}

int moca_set_diplexer(void *vctx, int32_t val)
{
	return(moca_set(vctx, IE_DIPLEXER, &val, sizeof(val)));
}

int moca_get_diplexer(void *vctx, int32_t *val)
{
	return(moca_get(vctx, IE_DIPLEXER, val, sizeof(*val)));
}

int moca_set_rlapm_cap(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_RLAPM_CAP, &val, sizeof(val)));
}

int moca_get_rlapm_cap(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_RLAPM_CAP, val, sizeof(*val)));
}

int moca_set_wol(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_WOL, &val, sizeof(val)));
}

int moca_get_wol(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_WOL, val, sizeof(*val)));
}

int moca_set_miscval(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_MISCVAL, &val, sizeof(val)));
}

int moca_get_miscval(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_MISCVAL, val, sizeof(*val)));
}

int moca_set_host_qos(void *vctx, uint32_t val)
{
	return(moca_set(vctx, IE_HOST_QOS, &val, sizeof(val)));
}

int moca_get_host_qos(void *vctx, uint32_t *val)
{
	return(moca_get(vctx, IE_HOST_QOS, val, sizeof(*val)));
}

static inline int mocalib_handle_power_up_status(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.power_up_status_cb == NULL)
		return(-3);
	ctx->cb.power_up_status_cb(ctx->cb.power_up_status_userarg, BE32(*in));
	return(0);
}

void moca_register_power_up_status_cb(void *vctx, void (*callback)(void *userarg, uint32_t status), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.power_up_status_cb = callback;
	ctx->cb.power_up_status_userarg = userarg;
}

static inline int mocalib_handle_link_up_state(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.link_up_state_cb == NULL)
		return(-3);
	ctx->cb.link_up_state_cb(ctx->cb.link_up_state_userarg, BE32(*in));
	return(0);
}

void moca_register_link_up_state_cb(void *vctx, void (*callback)(void *userarg, uint32_t status), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.link_up_state_cb = callback;
	ctx->cb.link_up_state_userarg = userarg;
}

static inline int mocalib_handle_admission_status(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.admission_status_cb == NULL)
		return(-3);
	ctx->cb.admission_status_cb(ctx->cb.admission_status_userarg, BE32(*in));
	return(0);
}

void moca_register_admission_status_cb(void *vctx, void (*callback)(void *userarg, uint32_t status), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.admission_status_cb = callback;
	ctx->cb.admission_status_userarg = userarg;
}

static inline int mocalib_handle_limited_bw(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.limited_bw_cb == NULL)
		return(-3);
	ctx->cb.limited_bw_cb(ctx->cb.limited_bw_userarg, BE32(*in));
	return(0);
}

void moca_register_limited_bw_cb(void *vctx, void (*callback)(void *userarg, uint32_t bw_status), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.limited_bw_cb = callback;
	ctx->cb.limited_bw_userarg = userarg;
}

static inline int mocalib_handle_error(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.error_cb == NULL)
		return(-3);
	ctx->cb.error_cb(ctx->cb.error_userarg, BE32(*in));
	return(0);
}

void moca_register_error_cb(void *vctx, void (*callback)(void *userarg, uint32_t error_id), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.error_cb = callback;
	ctx->cb.error_userarg = userarg;
}

static inline int mocalib_handle_lmo_info(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_lmo_info *in = (struct moca_lmo_info *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.lmo_info_cb == NULL)
		return(-4);
	ctx->cb.lmo_info_cb(ctx->cb.lmo_info_userarg, in);
	return(0);
}

void moca_register_lmo_info_cb(void *vctx, void (*callback)(void *userarg, struct moca_lmo_info *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.lmo_info_cb = callback;
	ctx->cb.lmo_info_userarg = userarg;
}

static inline int mocalib_handle_key_changed(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_key_changed *in = (struct moca_key_changed *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.key_changed_cb == NULL)
		return(-4);
	ctx->cb.key_changed_cb(ctx->cb.key_changed_userarg, in);
	return(0);
}

void moca_register_key_changed_cb(void *vctx, void (*callback)(void *userarg, struct moca_key_changed *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.key_changed_cb = callback;
	ctx->cb.key_changed_userarg = userarg;
}

static inline int mocalib_handle_topology_changed(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.topology_changed_cb == NULL)
		return(-3);
	ctx->cb.topology_changed_cb(ctx->cb.topology_changed_userarg, BE32(*in));
	return(0);
}

void moca_register_topology_changed_cb(void *vctx, void (*callback)(void *userarg, uint32_t nodemask), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.topology_changed_cb = callback;
	ctx->cb.topology_changed_userarg = userarg;
}

static inline int mocalib_handle_moca_version_changed(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.moca_version_changed_cb == NULL)
		return(-3);
	ctx->cb.moca_version_changed_cb(ctx->cb.moca_version_changed_userarg, BE32(*in));
	return(0);
}

void moca_register_moca_version_changed_cb(void *vctx, void (*callback)(void *userarg, uint32_t new_version), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.moca_version_changed_cb = callback;
	ctx->cb.moca_version_changed_userarg = userarg;
}

static inline int mocalib_handle_ucfwd_update(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	if(ctx->cb.ucfwd_update_cb == NULL)
		return(-3);
	ctx->cb.ucfwd_update_cb(ctx->cb.ucfwd_update_userarg);
	return(0);
}

void moca_register_ucfwd_update_cb(void *vctx, void (*callback)(void *userarg), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.ucfwd_update_cb = callback;
	ctx->cb.ucfwd_update_userarg = userarg;
}

static inline int mocalib_handle_moca_reset_request(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.moca_reset_request_cb == NULL)
		return(-3);
	ctx->cb.moca_reset_request_cb(ctx->cb.moca_reset_request_userarg, BE32(*in));
	return(0);
}

void moca_register_moca_reset_request_cb(void *vctx, void (*callback)(void *userarg, uint32_t cause), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.moca_reset_request_cb = callback;
	ctx->cb.moca_reset_request_userarg = userarg;
}

static inline int mocalib_handle_nc_id_changed(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.nc_id_changed_cb == NULL)
		return(-3);
	ctx->cb.nc_id_changed_cb(ctx->cb.nc_id_changed_userarg, BE32(*in));
	return(0);
}

void moca_register_nc_id_changed_cb(void *vctx, void (*callback)(void *userarg, uint32_t new_nc_id), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.nc_id_changed_cb = callback;
	ctx->cb.nc_id_changed_userarg = userarg;
}

static inline int mocalib_handle_pqos_create_response(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_pqos_create_response *in = (struct moca_pqos_create_response *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.pqos_create_response_cb == NULL)
		return(-4);
	ctx->cb.pqos_create_response_cb(ctx->cb.pqos_create_response_userarg, in);
	return(0);
}

void moca_register_pqos_create_response_cb(void *vctx, void (*callback)(void *userarg, struct moca_pqos_create_response *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.pqos_create_response_cb = callback;
	ctx->cb.pqos_create_response_userarg = userarg;
}

static inline int mocalib_handle_pqos_create_complete(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_pqos_create_complete *in = (struct moca_pqos_create_complete *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.pqos_create_complete_cb == NULL)
		return(-4);
	ctx->cb.pqos_create_complete_cb(ctx->cb.pqos_create_complete_userarg, in);
	return(0);
}

void moca_register_pqos_create_complete_cb(void *vctx, void (*callback)(void *userarg, struct moca_pqos_create_complete *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.pqos_create_complete_cb = callback;
	ctx->cb.pqos_create_complete_userarg = userarg;
}

static inline int mocalib_handle_pqos_update_response(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_pqos_update_response *in = (struct moca_pqos_update_response *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.pqos_update_response_cb == NULL)
		return(-4);
	ctx->cb.pqos_update_response_cb(ctx->cb.pqos_update_response_userarg, in);
	return(0);
}

void moca_register_pqos_update_response_cb(void *vctx, void (*callback)(void *userarg, struct moca_pqos_update_response *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.pqos_update_response_cb = callback;
	ctx->cb.pqos_update_response_userarg = userarg;
}

static inline int mocalib_handle_pqos_update_complete(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_pqos_update_complete *in = (struct moca_pqos_update_complete *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.pqos_update_complete_cb == NULL)
		return(-4);
	ctx->cb.pqos_update_complete_cb(ctx->cb.pqos_update_complete_userarg, in);
	return(0);
}

void moca_register_pqos_update_complete_cb(void *vctx, void (*callback)(void *userarg, struct moca_pqos_update_complete *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.pqos_update_complete_cb = callback;
	ctx->cb.pqos_update_complete_userarg = userarg;
}

static inline int mocalib_handle_pqos_delete_response(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_pqos_delete_response *in = (struct moca_pqos_delete_response *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.pqos_delete_response_cb == NULL)
		return(-4);
	ctx->cb.pqos_delete_response_cb(ctx->cb.pqos_delete_response_userarg, in);
	return(0);
}

void moca_register_pqos_delete_response_cb(void *vctx, void (*callback)(void *userarg, struct moca_pqos_delete_response *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.pqos_delete_response_cb = callback;
	ctx->cb.pqos_delete_response_userarg = userarg;
}

static inline int mocalib_handle_pqos_delete_complete(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_pqos_delete_complete *in = (struct moca_pqos_delete_complete *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.pqos_delete_complete_cb == NULL)
		return(-4);
	ctx->cb.pqos_delete_complete_cb(ctx->cb.pqos_delete_complete_userarg, in);
	return(0);
}

void moca_register_pqos_delete_complete_cb(void *vctx, void (*callback)(void *userarg, struct moca_pqos_delete_complete *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.pqos_delete_complete_cb = callback;
	ctx->cb.pqos_delete_complete_userarg = userarg;
}

static inline int mocalib_handle_pqos_list_response(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_pqos_list_response *in = (struct moca_pqos_list_response *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.pqos_list_response_cb == NULL)
		return(-4);
	ctx->cb.pqos_list_response_cb(ctx->cb.pqos_list_response_userarg, in);
	return(0);
}

void moca_register_pqos_list_response_cb(void *vctx, void (*callback)(void *userarg, struct moca_pqos_list_response *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.pqos_list_response_cb = callback;
	ctx->cb.pqos_list_response_userarg = userarg;
}

static inline int mocalib_handle_pqos_query_response(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_pqos_query_response *in = (struct moca_pqos_query_response *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	in->responsecode = BE32(in->responsecode);
	in->leasetimeleft = BE32(in->leasetimeleft);
	in->tpacketsize = BE16(in->tpacketsize);
	in->flowtag = BE32(in->flowtag);
	in->tpeakdatarate = BE32(in->tpeakdatarate);
	in->tleasetime = BE32(in->tleasetime);
	if(ctx->cb.pqos_query_response_cb == NULL)
		return(-5);
	ctx->cb.pqos_query_response_cb(ctx->cb.pqos_query_response_userarg, in);
	return(0);
}

void moca_register_pqos_query_response_cb(void *vctx, void (*callback)(void *userarg, struct moca_pqos_query_response *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.pqos_query_response_cb = callback;
	ctx->cb.pqos_query_response_userarg = userarg;
}

static inline int mocalib_handle_pqos_maintenance_complete(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_pqos_maintenance_complete *in = (struct moca_pqos_maintenance_complete *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	__moca_copy_be32(in, in, sizeof(*in));
	if(ctx->cb.pqos_maintenance_complete_cb == NULL)
		return(-4);
	ctx->cb.pqos_maintenance_complete_cb(ctx->cb.pqos_maintenance_complete_userarg, in);
	return(0);
}

void moca_register_pqos_maintenance_complete_cb(void *vctx, void (*callback)(void *userarg, struct moca_pqos_maintenance_complete *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.pqos_maintenance_complete_cb = callback;
	ctx->cb.pqos_maintenance_complete_userarg = userarg;
}

static inline int mocalib_handle_fmr_response(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	int i;
	struct moca_fmr_response *in = (struct moca_fmr_response *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	in->responsecode = BE32(in->responsecode);
	in->responded_node_0 = BE32(in->responded_node_0);
	for(i = 0; i < 16; i++)
		in->fmrinfo_node_0[i] = BE16(in->fmrinfo_node_0[i]);
	in->responded_node_1 = BE32(in->responded_node_1);
	for(i = 0; i < 16; i++)
		in->fmrinfo_node_1[i] = BE16(in->fmrinfo_node_1[i]);
	in->responded_node_2 = BE32(in->responded_node_2);
	for(i = 0; i < 16; i++)
		in->fmrinfo_node_2[i] = BE16(in->fmrinfo_node_2[i]);
	in->responded_node_3 = BE32(in->responded_node_3);
	for(i = 0; i < 16; i++)
		in->fmrinfo_node_3[i] = BE16(in->fmrinfo_node_3[i]);
	in->responded_node_4 = BE32(in->responded_node_4);
	for(i = 0; i < 16; i++)
		in->fmrinfo_node_4[i] = BE16(in->fmrinfo_node_4[i]);
	in->responded_node_5 = BE32(in->responded_node_5);
	for(i = 0; i < 16; i++)
		in->fmrinfo_node_5[i] = BE16(in->fmrinfo_node_5[i]);
	in->responded_node_6 = BE32(in->responded_node_6);
	for(i = 0; i < 16; i++)
		in->fmrinfo_node_6[i] = BE16(in->fmrinfo_node_6[i]);
	in->responded_node_7 = BE32(in->responded_node_7);
	for(i = 0; i < 16; i++)
		in->fmrinfo_node_7[i] = BE16(in->fmrinfo_node_7[i]);
	in->responded_node_8 = BE32(in->responded_node_8);
	for(i = 0; i < 16; i++)
		in->fmrinfo_node_8[i] = BE16(in->fmrinfo_node_8[i]);
	if(ctx->cb.fmr_response_cb == NULL)
		return(-5);
	ctx->cb.fmr_response_cb(ctx->cb.fmr_response_userarg, in);
	return(0);
}

void moca_register_fmr_response_cb(void *vctx, void (*callback)(void *userarg, struct moca_fmr_response *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.fmr_response_cb = callback;
	ctx->cb.fmr_response_userarg = userarg;
}

static inline int mocalib_handle_mr_response(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_mr_response *in = (struct moca_mr_response *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	in->ResponseCode = BE32(in->ResponseCode);
	in->ResetStatus = BE32(in->ResetStatus);
	in->NonDefSeqNum = BE32(in->NonDefSeqNum);
	if(ctx->cb.mr_response_cb == NULL)
		return(-5);
	ctx->cb.mr_response_cb(ctx->cb.mr_response_userarg, in);
	return(0);
}

void moca_register_mr_response_cb(void *vctx, void (*callback)(void *userarg, struct moca_mr_response *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.mr_response_cb = callback;
	ctx->cb.mr_response_userarg = userarg;
}

static inline int mocalib_handle_mr_complete(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_mr_complete *in = (struct moca_mr_complete *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	in->ResponseCode = BE32(in->ResponseCode);
	in->ResetStatus = BE32(in->ResetStatus);
	in->NonDefSeqNum = BE32(in->NonDefSeqNum);
	if(ctx->cb.mr_complete_cb == NULL)
		return(-5);
	ctx->cb.mr_complete_cb(ctx->cb.mr_complete_userarg, in);
	return(0);
}

void moca_register_mr_complete_cb(void *vctx, void (*callback)(void *userarg, struct moca_mr_complete *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.mr_complete_cb = callback;
	ctx->cb.mr_complete_userarg = userarg;
}

static inline int mocalib_handle_lof(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	uint32_t *in = (uint32_t *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.lof_cb == NULL)
		return(-3);
	ctx->cb.lof_cb(ctx->cb.lof_userarg, BE32(*in));
	return(0);
}

void moca_register_lof_cb(void *vctx, void (*callback)(void *userarg, uint32_t lof), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.lof_cb = callback;
	ctx->cb.lof_userarg = userarg;
}

static inline int mocalib_handle_mocad_printf(void *vctx, void *vin, int in_len)
{
	struct moca_ctx *ctx = (struct moca_ctx*) vctx;
	struct moca_mocad_printf *in = (struct moca_mocad_printf *)vin;
	if(in_len != sizeof(*in))
		return(-1);
	if(ctx->cb.mocad_printf_cb == NULL)
		return(-5);
	ctx->cb.mocad_printf_cb(ctx->cb.mocad_printf_userarg, in);
	return(0);
}

void moca_register_mocad_printf_cb(void *vctx, void (*callback)(void *userarg, struct moca_mocad_printf *out), void *userarg)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	ctx->cb.mocad_printf_cb = callback;
	ctx->cb.mocad_printf_userarg = userarg;
}

static inline int mocalib_dispatch_event(void *vctx, uint16_t ie_type, void *vin, int in_len)
{
	switch(ie_type) {
		case IE_POWER_UP_STATUS:
			return(mocalib_handle_power_up_status(vctx, vin, in_len));
		case IE_LINK_UP_STATE:
			return(mocalib_handle_link_up_state(vctx, vin, in_len));
		case IE_ADMISSION_STATUS:
			return(mocalib_handle_admission_status(vctx, vin, in_len));
		case IE_LIMITED_BW:
			return(mocalib_handle_limited_bw(vctx, vin, in_len));
		case IE_ERROR:
			return(mocalib_handle_error(vctx, vin, in_len));
		case IE_LMO_INFO:
			return(mocalib_handle_lmo_info(vctx, vin, in_len));
		case IE_KEY_CHANGED:
			return(mocalib_handle_key_changed(vctx, vin, in_len));
		case IE_TOPOLOGY_CHANGED:
			return(mocalib_handle_topology_changed(vctx, vin, in_len));
		case IE_MOCA_VERSION_CHANGED:
			return(mocalib_handle_moca_version_changed(vctx, vin, in_len));
		case IE_UCFWD_UPDATE:
			return(mocalib_handle_ucfwd_update(vctx, vin, in_len));
		case IE_MOCA_RESET_REQUEST:
			return(mocalib_handle_moca_reset_request(vctx, vin, in_len));
		case IE_NC_ID_CHANGED:
			return(mocalib_handle_nc_id_changed(vctx, vin, in_len));
		case IE_PQOS_CREATE_RESPONSE:
			return(mocalib_handle_pqos_create_response(vctx, vin, in_len));
		case IE_PQOS_CREATE_COMPLETE:
			return(mocalib_handle_pqos_create_complete(vctx, vin, in_len));
		case IE_PQOS_UPDATE_RESPONSE:
			return(mocalib_handle_pqos_update_response(vctx, vin, in_len));
		case IE_PQOS_UPDATE_COMPLETE:
			return(mocalib_handle_pqos_update_complete(vctx, vin, in_len));
		case IE_PQOS_DELETE_RESPONSE:
			return(mocalib_handle_pqos_delete_response(vctx, vin, in_len));
		case IE_PQOS_DELETE_COMPLETE:
			return(mocalib_handle_pqos_delete_complete(vctx, vin, in_len));
		case IE_PQOS_LIST_RESPONSE:
			return(mocalib_handle_pqos_list_response(vctx, vin, in_len));
		case IE_PQOS_QUERY_RESPONSE:
			return(mocalib_handle_pqos_query_response(vctx, vin, in_len));
		case IE_PQOS_MAINTENANCE_COMPLETE:
			return(mocalib_handle_pqos_maintenance_complete(vctx, vin, in_len));
		case IE_FMR_RESPONSE:
			return(mocalib_handle_fmr_response(vctx, vin, in_len));
		case IE_MR_RESPONSE:
			return(mocalib_handle_mr_response(vctx, vin, in_len));
		case IE_MR_COMPLETE:
			return(mocalib_handle_mr_complete(vctx, vin, in_len));
		case IE_LOF:
			return(mocalib_handle_lof(vctx, vin, in_len));
		case IE_MOCAD_PRINTF:
			return(mocalib_handle_mocad_printf(vctx, vin, in_len));
	}
	return(-6);
}

