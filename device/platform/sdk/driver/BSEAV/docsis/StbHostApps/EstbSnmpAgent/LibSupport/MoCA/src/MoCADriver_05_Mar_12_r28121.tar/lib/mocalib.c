/******************************************************************************
 *
 *	Copyright (c) 2009	Broadcom Corporation
 *	All Rights Reserved
 *
<:license-private
 *
 ************************************************************************/
/***************************************************************************
 *
 *	   Copyright (c) 2008-2009, Broadcom Corporation
 *	   All Rights Reserved
 *	   Confidential Property of Broadcom Corporation
 *
 *	THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *	AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *	EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *	Description: Non-generated libmoca functions
 *
 ***************************************************************************/

#include "moca_os.h"

#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include <mocalib.h>
#include "mocaint.h"




void *moca_open(char *ifname)
{
	struct moca_ctx *ctx;
	MoCAOS_ClientHandle fd;

	ctx = (struct moca_ctx *)calloc(sizeof(*ctx), 1);

	if(! ctx)
		return(NULL);
	
	ctx->lock = MUTEX_INIT();
	
	if(ifname) {
		if(strlen(ifname) > MoCAOS_IFNAMSIZE)
		{
			free(ctx);
			return(NULL);
		}
		strcpy(ctx->ifname, ifname);
	} else {
		strcpy(ctx->ifname, MOCA_DEFAULT_IFNAME);
	}

	ctx->mocad_rx_fd = MoCAOS_CLIENT_NULL;

	fd = MoCAOS_ConnectToMocad((MoCAOS_Handle) NULL, MOCA_CMD_SOCK_FMT, ctx->ifname);

	if(fd == MoCAOS_CLIENT_NULL) {
		free(ctx);
		return(NULL);
	}

	ctx->connect_fd = fd;

	return(ctx);
}

void moca_close(void *vctx)
{
	struct moca_ctx *ctx = (struct moca_ctx *) vctx;

	MUTEX_LOCK(ctx->lock);
 
	MoCAOS_CloseClient((MoCAOS_Handle)NULL, ctx->connect_fd);	 
	MoCAOS_CloseClient((MoCAOS_Handle)NULL, ctx->mocad_rx_fd);

	MUTEX_UNLOCK(ctx->lock);
	free(ctx);
}

unsigned long moca_phy_rate(unsigned long nbas, unsigned long cp, unsigned long turbo)
{
	unsigned int bw;

	if (turbo)
		bw = 100000000;
	else
		bw = 50000000;
	return((unsigned long)((nbas * (unsigned long long)bw * 192) / (208 * (256 + cp))));
}

void __moca_copy_be32(void *out, const void *in, int size)
{
	uintptr_t tin = (uintptr_t)in;
	uintptr_t tout = (uintptr_t)out;
	for(; size > 0; size -= 4, tin += 4, tout += 4) {
		
		uint32_t *dst = (uint32_t *)tout;
		*dst = BE32(*((uint32_t *)tin));
	}
}

static int moca_req(struct moca_ctx *ctx, const void *wr, int wr_len)
{
	int ret;
	int len;

	if(ctx->connect_fd == MoCAOS_CLIENT_NULL) {
		MoCAOS_ClientHandle fd;

		fd = MoCAOS_ConnectToMocad((MoCAOS_Handle) NULL, MOCA_CMD_SOCK_FMT, ctx->ifname);
		if(fd == MoCAOS_CLIENT_NULL)
			return(-1);
		ctx->connect_fd = fd;
	}

	if (MoCAOS_SendMMP((MoCAOS_Handle) NULL, (MoCAOS_ClientHandle) ctx->connect_fd, 
			(const unsigned char *)wr, wr_len) != 0)
		return(-2);

	while(1) {
		len = MOCA_BIG_BUF_LEN;
		ret = MoCAOS_ReadMMP((MoCAOS_Handle)NULL, (MoCAOS_ClientHandle)ctx->connect_fd, 
			MoCAOS_TIMEOUT_INFINITE, ctx->in_buf, &len);
		
		if(ret <= 0) {
			/* try to reconnect later */
			ctx->connect_fd = MoCAOS_CLIENT_NULL;
			return(-3);
		}
		return(len);
	}
}

int moca_raw_req(void *vctx, const void *wr, int wr_len,
	void *rd, int max_rd_len)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	int ret;

	MUTEX_LOCK(ctx->lock);
	ret = moca_req(ctx, wr, wr_len);

	if(ret > 0) {
		if(ret > max_rd_len) {
			memcpy(rd, ctx->in_buf, max_rd_len);
			ret = -1;
		} else {
			memcpy(rd, ctx->in_buf, ret);
		}
	}
	MUTEX_UNLOCK(ctx->lock);

	return(ret);
}

int (*__mocad_cmd_hook)(void *vctx, uint8_t msg_type, uint16_t ie_type,
	const void *wr, int wr_len, void *rd, int rd_len, int flags) = NULL;

static int moca_cmd(struct moca_ctx *ctx, uint8_t msg_type, uint16_t ie_type,
	const void *wr, int wr_len, void *rd, int rd_len, int flags)
{
	struct mmp_msg_hdr *mh;
	struct mmp_ie_hdr *ih;
	int ret;
	
	/* allow mocad to use library calls internally */
	if(__mocad_cmd_hook != NULL)
		return(__mocad_cmd_hook(ctx, msg_type, ie_type, wr, wr_len,
			rd, rd_len, flags));

	MUTEX_LOCK(ctx->lock);
	mh = (struct mmp_msg_hdr *)ctx->out_buf;
	mh->msg_type = msg_type;
	mh->msg_id = 0;
	mh->num_ies = BE16(1);

	ih = (struct mmp_ie_hdr *)(mh + 1);
	ih->ie_type = BE16(ie_type);
	ih->ie_len = (uint16_t)BE16(wr_len);

	if(flags & FL_SWAP_WR)
		__moca_copy_be32((void *)(ih + 1), wr, wr_len);
	else
		memcpy((void *)(ih + 1), wr, wr_len);

	ret = moca_req(ctx, ctx->out_buf, wr_len + sizeof(*mh) + sizeof(*ih));
	if(ret < 0)
		goto out;

	mh = (struct mmp_msg_hdr *)ctx->in_buf;
	ih = (struct mmp_ie_hdr *)(mh + 1);

	/* sanity checks on reply */

	if(BE16(mh->num_ies) != 1) {
		ret = -1;
		goto out;
	}

	if(ret <= (int)(sizeof(*mh) + sizeof(*ih))) {
		ret = -2;
		goto out;
	}

	ret -= sizeof(*mh) + sizeof(*ih);

	if(ie_type == BE16(IE_ABORT)) {
		ret = -3;
		goto out;
	}

	if(ret > rd_len) {
		ret = -4;
		goto out;
	}

	if(ie_type != BE16(ih->ie_type)) {
		ret = -5;
		goto out;
	}

	if(rd && ret) {
		if(flags & FL_SWAP_RD)
			__moca_copy_be32(rd, (void *)(ih + 1), ret);
		else
			memcpy(rd, (void *)(ih + 1), ret);
	}
out:
	MUTEX_UNLOCK(ctx->lock);
	return(ret);
}

static int moca_get_raw(void *vctx, uint16_t ie_type,
	const void *in, int in_len, void *out, int out_len, int flags)
{
	int ret;

	ret = moca_cmd((struct moca_ctx *)vctx, MOCA_MSG_GET, ie_type,
		in, in_len, out, out_len, flags);
	if(ret < 0)
		return(ret);
	else
		return(0);
}

static inline int moca_get_inout(void *vctx, uint16_t ie_type,
	const void *in, int in_len, void *out, int out_len)
{
	return(moca_get_raw(vctx, ie_type, in, in_len, out, out_len,
		FL_SWAP_WR | FL_SWAP_RD));
}

static inline int moca_get(void *vctx, uint16_t ie_type,
	void *out, int out_len)
{
	return(moca_get_raw(vctx, ie_type, NULL, 0, out, out_len,
		FL_SWAP_WR | FL_SWAP_RD));
}

static inline int moca_get_inout_noswap(void *vctx, uint16_t ie_type,
	const void *in, int in_len, void *out, int out_len)
{
	return(moca_get_raw(vctx, ie_type, in, in_len, out, out_len, 0));
}

static inline int moca_get_noswap(void *vctx, uint16_t ie_type,
	void *out, int out_len)
{
	return(moca_get_raw(vctx, ie_type, NULL, 0, out, out_len, 0));
}

static int moca_set_raw(void *vctx, uint16_t ie_type,
	const void *in, int in_len, int flags)
{
	int ret;
	uint32_t ack = 0;

	ret = moca_cmd((struct moca_ctx *)vctx, MOCA_MSG_SET, ie_type,
		in, in_len, &ack, sizeof(ack), flags | FL_SWAP_RD);
	if(ret < 0)
		return(ret);
	return(ack);
}

static inline int moca_set_noswap(void *vctx, uint16_t ie_type,
	const void *in, int in_len)
{
	return(moca_set_raw(vctx, ie_type, in, in_len, 0));
}

static inline int moca_set(void *vctx, uint16_t ie_type,
	const void *in, int in_len)
{
	return(moca_set_raw(vctx, ie_type, in, in_len, FL_SWAP_WR));
}


int (*__mocad_table_cmd_hook)(void *vctx, uint16_t ie_type, void **rd) = NULL;

static int moca_table_cmd(void *vctx, uint16_t ie_type, void **rd)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	struct mmp_msg_hdr *mh;
	struct mmp_ie_hdr *ih;
	int ret;

	/* allow mocad to use library calls internally */
	if(__mocad_table_cmd_hook != NULL)
		return(__mocad_table_cmd_hook(vctx, ie_type, rd));

	MUTEX_LOCK(ctx->lock);
	mh = (struct mmp_msg_hdr *)ctx->out_buf;
	mh->msg_type = MOCA_MSG_GET_TABLE;
	mh->msg_id = 0;
	mh->num_ies = BE16(1);

	ih = (struct mmp_ie_hdr *)(mh + 1);
	ih->ie_type = BE16(ie_type);
	ih->ie_len = BE16(0);

	ret = moca_req(ctx, ctx->out_buf, sizeof(*mh) + sizeof(*ih));
	if(ret < 0)
		goto out;

	mh = (struct mmp_msg_hdr *)ctx->in_buf;
	ih = (struct mmp_ie_hdr *)(mh + 1);
	*rd = ih;

	/* sanity checks on reply */

	if(BE16(mh->num_ies) < 1) {
		ret = -2;
		goto out;
	}

	if(ret < (int)(sizeof(*mh) + sizeof(*ih))) {
		ret = -3;
		goto out;
	}

	ret -= sizeof(*mh);

	if(ie_type == BE16(IE_ABORT)) {
		ret = -4;
		goto out;
	}
out:
	MUTEX_UNLOCK(ctx->lock);
	return(ret);
}

static int moca_get_table(void *vctx, uint16_t ie_type,
	void *out, int struct_len, int max_out_len)
{
	int ret, idx = 0;
	uint16_t last_ie = ie_type;
	uint16_t ie_len;

	do {
		unsigned char *buf = NULL;
		struct mmp_ie_hdr *ih;

		ret = moca_table_cmd(vctx, last_ie, (void **)(&buf));
		if(ret <= 0)
			return(ret);

		ie_len = 0;

		while(ret > 0) {
			ih = (struct mmp_ie_hdr *)buf;
			last_ie = BE16(ih->ie_type);
			if((last_ie & 0xff00) != (ie_type & 0xff00))
				return(-5);

			ie_len = BE16(ih->ie_len);
			if(ret < (int)(ie_len + sizeof(*ih)))
				return(-6);
			ret -= ie_len + sizeof(*ih);
			if(ie_len > struct_len)
				return(-7);

			if(ie_len == 0)
				break;

			if(struct_len > max_out_len)
				return(-8);
			
			__moca_copy_be32(out, (void *)(buf + sizeof(*ih)), struct_len);
			buf += sizeof(*ih) + ie_len;
			out = (void *)((char*)out + struct_len);
			max_out_len -= struct_len;
			idx++;
		}
	} while(ie_len != 0);

	return(idx);
}

static int moca_table_op(void *vctx, uint8_t msg_type, uint16_t ie_type,
	const void *in, int in_len)
{
	int ret;
	uint32_t ack = 0;

	ret = moca_cmd((struct moca_ctx *)vctx, msg_type, ie_type,
		in, in_len, &ack, sizeof(ack), FL_SWAP_RD | FL_SWAP_WR);
	if(ret < 0)
		return(ret);
	return(ack);
}

static int __mocalib_dispatch_event(void *vctx, uint16_t ie_type, void *vin,
	int in_len);

static int moca_handle_event(struct moca_ctx *ctx, int len)
{
	struct mmp_msg_hdr *mh;
	struct mmp_ie_hdr *ih;
	char *msg;

	mh = (struct mmp_msg_hdr *)ctx->evt_buf;

	while(len > 0) {
		int msg_len;

		mh->num_ies = BE16(mh->num_ies);

		if(mh->msg_type != MOCA_MSG_TRAP)
			return(-1);

		msg_len = sizeof(*mh);

		while (mh->num_ies > 0) {

			ih = (struct mmp_ie_hdr *)((uintptr_t)mh + msg_len);
			ih->ie_type = BE16(ih->ie_type);
			ih->ie_len = BE16(ih->ie_len);

			msg = (char *)(ih + 1);
			msg_len += sizeof(*ih) + ih->ie_len;

			if(len < msg_len)
				return(-3);

			__mocalib_dispatch_event(ctx, ih->ie_type, msg, ih->ie_len);

			mh->num_ies--;
		}
	
		/* several messages can be aggregated into one read */
		mh = (struct mmp_msg_hdr *)((uintptr_t)mh + msg_len);

		len -= msg_len;
	}
	return(0);
}

int moca_event_loop(void *vctx)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	int ret = -1;
	MoCAOS_ClientHandle fd;
	int len;

	fd = MoCAOS_ConnectToMocad((MoCAOS_Handle) NULL, MOCA_EVT_SOCK_FMT, ctx->ifname);
	if(fd == MoCAOS_CLIENT_NULL)
		goto out1;
	
	ctx->mocad_rx_fd = fd;

	while(1) {
		len = MOCA_BUF_LEN;
		ret = MoCAOS_ReadMMP((MoCAOS_Handle) NULL, (MoCAOS_ClientHandle) fd, 
			MoCAOS_TIMEOUT_INFINITE, ctx->evt_buf, &len);

		if(ret <= 0) {
			break;
		}

		if (strstr((char *)ctx->evt_buf, "DEADDEAD"))
			break;
		
		moca_handle_event(ctx, len);
	}
	ret = 0;
	MUTEX_LOCK(ctx->lock);

	MoCAOS_CloseClient((MoCAOS_Handle) NULL, fd);
	
	MUTEX_UNLOCK(ctx->lock);
out1:
	return(ret);
}

void moca_cancel_event_loop(void *vctx)
{
	struct moca_ctx *ctx = (struct moca_ctx *)vctx;
	char c[] = "DEADDEAD";
	
	MoCAOS_SendMMP((MoCAOS_Handle) NULL, (MoCAOS_ClientHandle) ctx->mocad_rx_fd, 
			(unsigned char *)c, 9);
}

#include "mocalib-gen.c"

const char *moca_l2_error_name(uint32_t l2_error)
{
	switch(l2_error) {
		case MOCA_L2_SUCCESS:
			return("Success");
		case MOCA_L2_TRANSACTION_FAILED:
			return("Transaction failed");
		case MOCA_L2_L2ME_NO_SUPPORT:
			return("L2ME no support");
		case MOCA_L2_PQOS_INGR_NOT_FOUND:
			return("Ingress node not found");
		case MOCA_L2_PQOS_EGR_NOT_FOUND:
			return("Egress node not found");
		case MOCA_L2_TRANSACTION_CANT_START:
			return("Transaction can't start");
	}
	return(NULL);
}

static int __mocalib_dispatch_event(void *vctx, uint16_t ie_type, void *vin,
	int in_len)
{
	/* declared inline so that it doesn't get built into mocad */
	return(mocalib_dispatch_event(vctx, ie_type, vin, in_len));
}
