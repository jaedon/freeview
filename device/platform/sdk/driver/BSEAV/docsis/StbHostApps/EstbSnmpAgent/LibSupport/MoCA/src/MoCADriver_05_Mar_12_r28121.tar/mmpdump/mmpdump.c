/***************************************************************************
 *
 *     Copyright (c) 2011, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *  Description: utility to print out mmp fields
 *
 ***************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <mocalib.h>

#define EATWHITE(x) while((*x == ' ') || (*x == '\t')) x++

unsigned int moca_name_ie(const char *name);
unsigned int moca_field_offset(const char *name);
void *moca_get_fn(unsigned int ie);
int moca_indexed_fn(unsigned int ie);

int line = 0;

void *ctx;

typedef int (*moca_fn) (void *, void *);
typedef int (*moca_idx_fn) (void *, unsigned int, void *);

int ndx=0;

unsigned int getMMP(char *item)
{
    unsigned int ie;
    char *iename;
    char *fieldname;
    moca_fn fn;
    moca_idx_fn ifn;
    int rc;
    static char returnbuf[65535];
    int fieldoffset;

    EATWHITE(item);

    fieldoffset = moca_field_offset(item);

    if (fieldoffset == -1)
    {
        fprintf(stderr,"LINE %d: unknown field '%s'\n", line, item);
        exit(-9);
    }
    iename = item;

    while((*item != '\0') && (*item != '.')) item++;

    if (*item == '.')
    {
       *item = '\0';
       item++;
       fieldname = item;
    }
    else
    {
        fprintf(stderr, "LINE %d: incomplete item name %s\n", line, iename);
        exit(-4);
    }

    ie = moca_name_ie(iename);

    if (ie == 0)
    {
        fprintf(stderr, "LINE %d: unknown IE -- %s\n", line, item);
        exit(-5);
    }

    *(fieldname-1) = '.';
    
    fn = (moca_fn)moca_get_fn(ie);

    if (!fn)
    {
        fprintf(stderr, "LINE %d: unable to get IE -- %s\n", line, item);
        exit(-6);
    }

    rc = moca_indexed_fn(ie);

    if (rc == -1)
    {
        fprintf(stderr, "LINE %d: unable to determine if function is indexed -- %s\n", line, item);
        exit(-7);
    }

    if (rc)
    {
        ifn = (moca_idx_fn)fn;
        rc = ifn(ctx, ndx, (void *)returnbuf);
    }
    else
    {
        rc = fn(ctx, (void *)returnbuf);        
    }

    if (rc)
    {
        fprintf(stderr, "LINE %d: error getting IE -- %s\n", line, item);
        exit(-8);
    }
    
    return(*(unsigned int *)&returnbuf[fieldoffset]);
}

int processCmd(char *cmd)
{
    char *format;
    char *formatmiddle;
    char *token = NULL;
    static char outstring[65536];
    char *c;
    char tmp;
    int ntok = 0;

    c = outstring;
    
    EATWHITE(cmd);    
    

    // first character needs to be '"'
    if (*cmd == '\"')
    {
        cmd++;
        format = cmd;
        
        while ((*cmd != '\0') && (*cmd != '\"'))
            cmd++;

        if (*cmd == '\0')
        {
            fprintf(stderr, "LINE %d: Missing '\"' in format\n", line);
            return(-2);
        }
        *cmd='\0'; // null terminate format string
        cmd++;

        token=strtok(cmd," \t");
        
        while (*format != '\0')
        {                       
            ntok++;
            
            if (token && (strncasecmp("index=", token, 6) == 0))
            {
                ndx=atoi(&token[6]);
            }
            else
            {
                while ((*format != '%') && (*format != '\\') && (*format != '\0')) *c++ = *format++;

                if (*format == '\0') break;

                if (*format == '\\')
                {
                    format++; // skip past 
                    switch (*format)
                    {
                        case 'n' : *c = '\n'; break;
                        case 'r' : *c = '\r'; break;
                        case 't' : *c = '\t'; break;
                        case '\\' : *c = '\\'; break;
                        case 'a' : *c = '\a'; break;
                        case 'b' : *c = '\b'; break;
                        case 'f' : *c = '\f'; break;
                        case 'v' : *c = '\v'; break;
                        case '\'' : *c = '\''; break;
                        case '"' : *c = '\"'; break;
                        case '?' : *c = '\?'; break;
                        case '0' : *c = '\0'; break;
                        default:
                        {
                            fprintf(stderr, "LINE %d: Unknown escape character '%c'\n", line, *format);
                            exit(-10);
                        }
                    }
                    c++;
                    format++;
                }
                else
                {
                    format++; // skip past %
                    
                    if (*format == '\0') break;
                    
                    if (*format == '%') // found a %%, just print %            
                    {
                        *c++ = '%';
                        format++;
                        continue;
                    }

                    formatmiddle = format; // point to char after %

                    // find the last char of the format, e.g. 'd' in %08d
                    while ((*format != '\0') && (index("sdXxcm", *format) == NULL)) format++;

                    format++;
                    tmp = *format;
                    *format = '\0';

                    if (*(format-1) == 'm')
                    {
                        unsigned int eui_hi, eui_lo;
                        char euitoken[256];
                        uint8_t mac[64];
                        char formattedaddr[64];
                        
                        *(format-1) = 's';

                        strcpy(euitoken, token);
                        strcat(euitoken, "_hi");                    
                        eui_hi = getMMP(euitoken);

                        
                        strcpy(euitoken, token);
                        strcat(euitoken, "_lo");
                        eui_lo = getMMP(euitoken);

                        moca_u32_to_mac(mac, eui_hi, eui_lo);
                        sprintf (formattedaddr,"%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x",
                              mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
                        
                        c += sprintf(c, formatmiddle-1, formattedaddr);
                    }
                    else
                        c += sprintf(c, formatmiddle-1, getMMP(token));

                    *format = tmp;
                }
            }

            token=strtok(NULL," \t");
        }
        
        *c = '\0';

        printf((const char *)outstring);
        
        return(0);
    }

    return(-3);
}

int main(int argc, char **argv)
{
    static char cmd[65536] = "";
    FILE *fp=NULL;
    int i;
    int rc;

    ctx = moca_open(NULL);

    if (!ctx)
    {
        fprintf(stderr, "ERROR: unable to connect to mocad\n");
        return(-7);
    }

    if ((argc > 1) && (argv[1][0] == '-'))
    {
        if ((argv[1][1] == 'f') && (argc > 2))
        {
            fp = fopen(argv[2],"r");
            if (!fp)
            {
                fprintf(stderr, "ERROR: unable to open file %s\n", argv[2]);
                return(-1);
            }
        }
    }
    else
    {
        for (i=1;i<argc;i++)
        {
            if (i == 1)
            {
                strcat(cmd,"\"");
            }
            strcat(cmd, argv[i]);
            if (i == 1)
            {
                strcat(cmd,"\"");
            }            
            strcat(cmd, " ");
        }
        return(processCmd(cmd));
    }

    while(!feof(fp))
    {
        if (!fgets(cmd, sizeof(cmd), fp))
            return(0);

        line++;
        rc=processCmd(cmd);

        if (rc)
            return(rc);
    }

    return(0);
}
