#include "SoapMain.h"
#include "SoapCustDtype.h"

#define size_t int	// Mike
#ifndef NULL		// Mike
#ifdef __cplusplus
#define NULL    0
#else
#define NULL    ((void *)0)
#endif
#endif


int GetCustDtypeEntry(char *name)
{
  int i;

  for(i=0; i< MAX_CUSTOM_DATA_TYPE; i++)
    {
      if(!strcmp(CustomDataTypeTable[i].name, name))
	{
	  return i;
	}
    }

  return -1 ; 
}

int SetCustDtypeNameSpace(char *pName)
{
  int i;

  for(i=0; i< MAX_CUSTOM_DATA_TYPE; i++)
    {
      if(!strcmp(CustomDataTypeTable[i].nameSpace,""))
	{
	  // Found empty spot
	  //	  printf("+++++++++++ add namespace at entry %d\n", i);
	  strcpy(CustomDataTypeTable[i].nameSpace,pName);
	  return i;
	}
    }
  return -1 ; 
}

int SetCustDtypeName(int entry, char *pName)
{
  strcpy(CustomDataTypeTable[entry].name,pName);

  return 0;
}


void AddCustDtypeMember(char *pName, char *mName, char *mType)
{
  int i,count,j;
  static int nResize = 1, prevEntry=0;
  char ** pptr;

  i = GetCustDtypeEntry(pName);
  count = CustomDataTypeTable[i].mCount;

#if 0
  printf("Current count = %d: ENTRY: %d\n",count,i);
  printf("Adding %s %s\n",mName, mType);
#endif

  // Move to new entry adjust resize count
  if(i != prevEntry)
    nResize = 1;

  if( count  == MAX_CUSTOM_MEMBER * nResize )
    {
      //myrealloc inclusive 

      pptr = myrealloc(CustomDataTypeTable[i].mName,(nResize*MAX_CUSTOM_MEMBER+MAX_CUSTOM_MEMBER)*sizeof(char *));
      if(pptr == NULL)
		 printf("ERROR: 1. AddCustDtypeMember failed myrealloc\n");

      CustomDataTypeTable[i].mName = pptr;
      pptr = myrealloc(CustomDataTypeTable[i].mType,(nResize*MAX_CUSTOM_MEMBER+MAX_CUSTOM_MEMBER)*sizeof(char *));
      if(pptr == NULL)
		 printf("ERROR: 2. AddCustDtypeMember failed myrealloc\n");

      CustomDataTypeTable[i].mType = pptr;

      //      printf("myrealloc new size = %d\n",nResize*MAX_CUSTOM_MEMBER+MAX_CUSTOM_MEMBER);
 
      for(j=count;j< count + MAX_CUSTOM_MEMBER;j++)
	{
	  //	  printf("Ndx = %d\n",j);
	  CustomDataTypeTable[i].mName[j]     = (char *)mycalloc((size_t)(MAX_NAME_LEN)*sizeof(char *),1);
	
	  if(CustomDataTypeTable[i].mName[j] == NULL)
		 printf("ERROR: 3. AddCustDtypeMember failed myrealloc\n");

	  CustomDataTypeTable[i].mType[j]     = (char *)mycalloc((size_t)(MAX_NAME_LEN)*sizeof(char *),1);
	  if(CustomDataTypeTable[i].mName[j] == NULL)
		 printf("ERROR: 4. AddCustDtypeMember failed myrealloc\n");

	}

      prevEntry = i;

      nResize++;
      
    }

  strcpy(CustomDataTypeTable[i].mName[count],mName);
  strcpy(CustomDataTypeTable[i].mType[count],mType);

  if(strcmp(mName,""))
    CustomDataTypeTable[i].mCount++;

#if 0
  for(j=0; j< CustomDataTypeTable[i].mCount; j++)
    {
      printf("index %d name %s\n",j,CustomDataTypeTable[i].mName[j]);
      printf("index %d type %s\n",j,CustomDataTypeTable[i].mType[j]);
    }
#endif

}

void FreeCustDtypeTblMem()
{
  int i,j;
  CUSTOM_DTYPE_INFO_T *pCdtInfo;

  for(i=0; i< MAX_CUSTOM_DATA_TYPE; i++)
    {
      if(!strcmp(CustomDataTypeTable[i].name,""))
	 continue;

      //      printf("1.Freeing %s index %d addr %lx\n",CustomDataTypeTable[i].nameSpace,i,(unsigned long)CustomDataTypeTable[i].nameSpace);
      myfree1(CustomDataTypeTable[i].nameSpace);
      
      pCdtInfo = GetCustParamInfo(CustomDataTypeTable[i].name);

      //      printf("2. Freeing %s addr %lx\n",CustomDataTypeTable[i].name,(unsigned long)CustomDataTypeTable[i].name);
      myfree1(CustomDataTypeTable[i].name);
      CustomDataTypeTable[i].name = "";

      // <= to include the "" at the end of the table
      for(j=0; j <= pCdtInfo->mCount ;j++)
	{
	  //	  printf("3. Freeing %s\n",CustomDataTypeTable[i].mName[j]);
	  myfree1(CustomDataTypeTable[i].mName[j]);
	  //	  printf("4. Freeing %s\n",CustomDataTypeTable[i].mType[j]);
	  myfree1(CustomDataTypeTable[i].mType[j]);
	}
   }
}

void CreateCustDtypeTbl()
{
  int i,j;
  for(i=0; i< MAX_CUSTOM_DATA_TYPE; i++)
    {
      CustomDataTypeTable[i].nameSpace = (char *)mycalloc((size_t)(MAX_NAMESPACE_LEN)*sizeof(char),1);
      CustomDataTypeTable[i].name      = (char *)mycalloc((size_t)(MAX_NAME_LEN)*sizeof(char),1);
      CustomDataTypeTable[i].mCount    = 0;
      CustomDataTypeTable[i].mName     = (char **)mycalloc((size_t)MAX_CUSTOM_MEMBER*sizeof(char *),1);
      CustomDataTypeTable[i].mType     = (char **)mycalloc((size_t)MAX_CUSTOM_MEMBER*sizeof(char *),1);

      for(j=0;j<MAX_CUSTOM_MEMBER;j++)
	{
	  CustomDataTypeTable[i].mName[j]     = (char *)mycalloc((size_t)(MAX_NAME_LEN)*sizeof(char *),1);
	  CustomDataTypeTable[i].mType[j]     = (char *)mycalloc((size_t)(MAX_NAME_LEN)*sizeof(char *),1);
	}
    }
}


CUSTOM_DTYPE_INFO_T *GetCustParamInfo(char *custName)
{
  int i;

  for(i = 0; i< sizeof(CustomDataTypeTable)/sizeof(CUSTOM_DTYPE_INFO_T);i++)
    {
      //      printf("current cust name %s\n",custName);  
    if(!strcmp(CustomDataTypeTable[i].name,custName))
	{
	  return &CustomDataTypeTable[i];
	}
    }

  return NULL;
}

int IsCustomType(char *type)
{
  int i = 0,result;
  
//  printf("Iscustomtype %s\n",type);
  
  for(i=0; i < sizeof(CustomDataTypeTable)/sizeof(CUSTOM_DTYPE_INFO_T); i++)
  {
    result = strcmp(CustomDataTypeTable[i].name,type);
   	if(result == 0)
      return 1;
  }    
  
  return 0;// Not a custom one
}

