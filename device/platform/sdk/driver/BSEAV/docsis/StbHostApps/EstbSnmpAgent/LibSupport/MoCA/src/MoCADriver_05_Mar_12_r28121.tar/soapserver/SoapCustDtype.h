#ifndef SOAP_CUST_TYPE
#define SOAP_CUST_TYPE

#define MAX_CUSTOM_TYPE_DEPTH 2
#define MAX_CUSTOM_DATA_TYPE 10    // Custom data type allowed
#define MAX_CUSTOM_MEMBER    1     // 


typedef struct CustDtypeInfo
{
  char *nameSpace;
  char *name;        // Type name
  int  mCount;       // Member count
  char **mName;
  char **mType;
}CUSTOM_DTYPE_INFO_T;

void AddCustDtypeMember(char *pName, char *mName, char *mtype);
int SetCustDtypeNameSpace(char *pName);
int SetCustDtypeName(int entry, char *pName);
void InitCustDtypeTbl();
void FreeCustDtypeTblMem();
void CreateCustDtypeTbl();
CUSTOM_DTYPE_INFO_T *GetCustParamInfo(char *custName);
int IsCustomType(char *type);

CUSTOM_DTYPE_INFO_T CustomDataTypeTable[MAX_CUSTOM_DATA_TYPE];

#endif
