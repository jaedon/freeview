
/*#define SHOW_TAG*/
/*#define SIM*/

#include "util.h"
#include <stdio.h>
#ifndef WIN32
#include <unistd.h>
#endif
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#ifndef NON_OS
#include <sys/types.h>
#ifndef WIN32
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#endif
#else
#include "bcmuart.h"	
#endif

#include "nanoxml.h"
#include "SoapMain.h"
#include "hash.h"

#include "methods.h"

#if CFG_TCP
#include "lib_queue.h"
#include "cfe_timer.h"
#include "cfe_error.h"
#include "ui_command.h"
#include "cfe.h"
#include "net_ebuf.h"
#include "net_api.h"

#define ip_addriszero(a) (((a)[0]|(a)[1]|(a)[2]|(a)[3]) == 0)
#endif

#ifdef SIM
 #define SERVICENAME "TestSoap"
#endif

#ifdef SUPPORT_MOCA
#include "mocaSvc.h"
#endif

#ifndef BSTD_UNUSED
#define BSTD_UNUSED(x)  { volatile void *bstd_unused; bstd_unused = (void *)&(x); }
#endif

char *stateName[] =
  {
   "WAIT_FOR_ENVELOPE","WAIT_FOR_BODY","WAIT_FOR_METHOD_NAME",
   "WAIT_FOR_XMLNS","WAIT_FOR_NAMESPACE","WAIT_FOR_PARAM",
   "WAIT_FOR_PARAM_TYPE","WAIT_FOR_ARRAY_SIZE","WAIT_FOR_PARAM_VALUE_CUSTOM","WAIT_FOR_PARAM_VALUE"
  };


#ifdef SUPPORT_MOCA
#ifdef CHIP_6816
char * g_mocaInterface = "moca0";
#else
char * g_mocaInterface = NULL;
#endif
#endif

int SoapMain( int argc, char **argv );

void FreeHashTable(void);
void FreeClient(int id);

METHOD_PROP_T *GetNsMethodProp(char *nameSpace, char *mName);

void DisplayParam(sParam *pSparm);

char * GetNsMethodRetType(char *nameSpace, char *mName);
void DumpParamList( LIST_T *parmList);
int GetNsMethodNumParm(char *nameSpace, char *mName);

SRESULT Open( const char* pszUri, SOCKET *pSocket );
void Run(SOCKET socket);
void SockError(char *msg);
static SRESULT Receive( int clientId, const char** ppszEnvelope, size_t *pSize );
int GetTcpPort( const char* pszURI, int* pnPort  );
int ReadHeader( int clientId, size_t* psizeEnv );
char* ReadContent( int clientId, size_t size );
void InitClientTbl(void);
void CreateClient(int clientId);
char* ResizeTransportBuffer( char* pszBuffer, size_t sizeNew );

SOCKET ServerAddConn(int clientId);
int ServerFindNewConn(void);


void xmlTagBegin(nxml_t handle, const char *tag_name, unsigned len);
void xmlTagEnd(nxml_t handle, const char *tag_name, unsigned len);
void xmlAttrBegin(nxml_t handle, const char *tag_name, unsigned len);
void xmlAttrValue(nxml_t handle, const char *tag_name, unsigned len);
void xmlData(nxml_t handle, const char *tag_name, unsigned len);

int xmlParse(int clientId, char *xmlBuffer, int xmlSize);

char * StrConvert(char *strToConv, char *patt, char *strToReplace);

extern long SoapInitialize_regSvc();
#ifndef CHIP_6816
extern void RdcServiceInitialize(void);
#endif
extern int initializeBase64Tables();

SERVICE_INFO_T svcTbl[MAX_NAMESPACE];
sClientInfo *client[MAX_CLIENTS];

static int debug = 0;

#if 1
void ShowClientInfo(int clientId, int depth)
{
  printf("**********************************************\n");
  printf("current method name %s\n", client[clientId]->curMethodName);
  
  printf("current namespace  %s\n", client[clientId]->curNameSpace);

  printf("parameter type %s\n",client[clientId]->curParamType[depth]);
  printf("parameter name %s\n",client[clientId]->curParamName[depth]);
  printf("parameter value %s\n",client[clientId]->curParamValue[depth]);

  printf("custom  parameter type %s\n",client[clientId]->curCustParamType[depth]);

  printf("custom type start %d\n", client[clientId]->customTypeStart[depth]);

  printf("number of custom parameter received %d\n", client[clientId]->nCustParamRcv[depth]);

  printf("number of custom parameter member count %d\n", client[clientId]->nCustParmMemCnt[depth]);

  printf("custom parameter depth %d\n",client[clientId]->nCustParmDepth);

  printf("Array type start %d\n",client[clientId]->arrayTypeStart);

  printf("Array size %d\n",client[clientId]->arraySize);

  printf("Array element received %d\n",client[clientId]->arrayElmRcv);

  printf("number of parameter received %d\n",client[clientId]->nParamRcv);

  printf("End of document %d\n",client[clientId]->endDoc);

  printf("\n current state = %s\n",stateName[client[clientId]->CurState]);

  printf("\n next state = %s\n",stateName[client[clientId]->NxtState]);
  printf("**********************************************\n");
}

void ShowClientParamInfo(int clientId, int depth)
{
  printf("**********************************************\n");
  printf("current method name %s\n", client[clientId]->curMethodName);
  
  printf("current namespace  %s\n", client[clientId]->curNameSpace);

  printf("parameter type %s\n",client[clientId]->curParamType[depth]);
  printf("parameter name %s\n",client[clientId]->curParamName[depth]);
  printf("parameter value %s\n",client[clientId]->curParamValue[depth]);

  if(client[clientId]->customTypeStart[depth])
    {
      printf("custom  parameter type %s\n",client[clientId]->curCustParamType[depth]);
      printf("custom type start %d\n", client[clientId]->customTypeStart[depth]);
      printf("number of custom parameter received %d\n", client[clientId]->nCustParamRcv[depth]);
      printf("number of custom parameter member count %d\n", client[clientId]->nCustParmMemCnt[depth]);
      printf("custom parameter depth %d\n",client[clientId]->nCustParmDepth);
    }

  if(client[clientId]->arrayTypeStart)
    {
      printf("Array type start %d\n",client[clientId]->arrayTypeStart);
      printf("Array size %d\n",client[clientId]->arraySize);
      printf("Array element received %d\n",client[clientId]->arrayElmRcv);
    }

  printf("number of parameter received %d\n",client[clientId]->nParamRcv);

  printf("End of document %d\n",client[clientId]->endDoc);

  printf("\n current state = %s\n",stateName[client[clientId]->CurState]);

  printf("\n next state = %s\n",stateName[client[clientId]->NxtState]);
  printf("**********************************************\n");
}


void DumpClientInfo(int clientId)
{
  int depth;

  printf("**********************************************\n");
  printf("current method name %s\n", client[clientId]->curMethodName);
  
  printf("current namespace  %s\n", client[clientId]->curNameSpace);

  depth=0;


  for(;;)
    {
      if(strcmp(client[clientId]->curCustParamType[depth],""))
	{
	  printf("custom  parameter type %s\n",client[clientId]->curCustParamType[depth]);
	  printf("parameter type %s\n",client[clientId]->curParamType[depth]);
	  printf("custom type start %d\n", client[clientId]->customTypeStart[depth]);
	  depth++;
	}
      else
	break;
    }

  printf("custom parameter depth %d\n",client[clientId]->nCustParmDepth);

  printf("Array type start %d\n",client[clientId]->arrayTypeStart);

  printf("Array size %d\n",client[clientId]->arraySize);

  printf("Array element received %d\n",client[clientId]->arrayElmRcv);

  printf("number of parameter received %d\n",client[clientId]->nParamRcv);

  printf("End of document %d\n",client[clientId]->endDoc);

  printf("\n current state = %s\n",stateName[client[clientId]->CurState]);

  printf("\n next state = %s\n",stateName[client[clientId]->NxtState]);
  printf("**********************************************\n");
}


void printHelp(void) 
{
   char * helpString = 
    "BBS Remote Server"
    "--help                       This help screen\n"
    "--verbose                    Run in verbose mode\n"
    "--transport-[TRANSPORT URI]  Sets the transport used given the uri\n"
    "\n"
    "[TRANSPORT URI]\n"
    "   tcp:[port]                uses tcp as the send/receive transport (default).\n"
    "                             example: --transport-tcp:1600\n"
    "   serial:[port]             uses a serial port as the send/receive transport.\n"
    "                             example: --transport-serial:COM1\n";
    printf("%s\n", helpString);
}

#endif

#ifndef NON_OS
void handler(int sig)
{
  int clientId;

  BSTD_UNUSED(sig);

  for(clientId=0; clientId < MAX_CLIENTS; clientId++)
      FreeClient(clientId);
      
  FreeHashTable();  

  exit(1);
}
#endif

/* Entry point from Brutus */
#ifndef APP_FRAMEWORK
int ServerMain()
{
    SoapMain(0, NULL);
	return 0;
}
#endif

#ifdef NON_OS
void _exit(int exitcode)
{

}


int MidasMain( int argc, char **argv )	
{
    SoapMain(argc, argv);
}

int SoapMain( int argc, char **argv )
#else
    #ifdef SIM
        soapServer()
    #else
        #ifdef APP_FRAMEWORK
            int app_main( int argc, char **argv )
        #else
            int SoapMain( int argc, char **argv )
        #endif
    #endif
#endif
{

  int i;

#if 0//ndef WIN32
  BSTD_UNUSED(argc);
  BSTD_UNUSED(argv);
#endif
  
  /*Ctrl-C handler */

/*#ifndef NON_OS */
#if (!defined(NON_OS)) || defined(CFG_TCP)
  SRESULT sr;
  SOCKET socket;
#ifndef CFG_TCP
#ifdef WIN32
  WSADATA wsaData;
  WORD wVersionRequested;

  wVersionRequested = MAKEWORD( 2, 2 );
  WSAStartup( wVersionRequested, &wsaData );
#else
  signal(SIGINT, handler);  
#endif
#endif
#endif

  for(i = 0; i < MAX_NAMESPACE; i++)
    {
      strcpy(svcTbl[i].nameSpace,"");
      svcTbl[i].Htbl = NULL;
    }
#if (!defined(NON_OS)) || defined(CFG_TCP)
  sr =  Open( TRANSPORT_URI_STR, &socket );
 

  if ( sr == (long)E_SOAPFAIL )
    {
      printf( "Unable to create a valid transport!\n" );
      return -1;
    }
#endif 

  InitClientTbl();
    
  CreateCustDtypeTbl();

  InitCustDtypeTbl();

  SoapInitialize();

#if (!defined(NON_OS)) || defined(CFG_TCP)
  Run(socket);
#else
  Run(0);
#endif

  return 0;
}

void GetRegisteredNames(char *buf, int buflen)
{
  int i, j, len;
  HashTable *ht;
  LIST_T *list;
  LINK_T *link;
  HashEnt *ent;

  for (i=0; i<MAX_NAMESPACE; i++)
  {
    if (svcTbl[i].Htbl != NULL)
	{
	  len = strlen(buf) + strlen(svcTbl[i].nameSpace) + 20;
	  if (len >= buflen)
		  break;

	  strcpy(buf, "SOAP service name=");
	  strcat(buf, svcTbl[i].nameSpace);
	  strcat(buf, "\n");
	  
	  ht = svcTbl[i].Htbl;
	  for (j=0; j<ht->maxent; j++)
	  {
        list = (LIST_T *)ht->list->item[j];
        for (link = GetHeadLink(list); link != NULL; link=link->next)
		{ 
          ent = (HashEnt *)GetDataFromLink(link);
	      
		  len = strlen(buf) + strlen(ent->mMethodProp->mName) + 2;
		  if (len >= buflen)
			  break;
		  
		  strcat(buf, ent->mMethodProp->mName);
	      strcat(buf, "\n");
		}
	  }

	}
  }
}

int RegisterMethod(char *nameSpace, char *methodName, int numParam, char *retPrefix, 
		   char *retType, char* arrType, FUNC_PTR funcPtr)
{

  int i;

  METHOD_PROP_T *pMprop = (METHOD_PROP_T *)mycalloc((size_t)sizeof(METHOD_PROP_T),1);;
  if (pMprop == NULL)
	  printf("Alloc failed\n");

  strcpy(pMprop->mName,methodName);
  pMprop->nP = (numParam)?0:1;
  pMprop->numParam = numParam;
  strcpy(pMprop->retPrefix,retPrefix);
  strcpy(pMprop->retType,retType);
  strcpy(pMprop->arrType,arrType);
  pMprop->func = funcPtr;

  /* Find entry for the namespace */
  for(i = 0; i < MAX_NAMESPACE; i++)
    {
      /* See if there is already entry for the namespace */
      if((svcTbl[i].Htbl != NULL) && !(strcmp(nameSpace, svcTbl[i].nameSpace)))
	{
	  /* Key is method name */
	  HashPut(svcTbl[i].Htbl, pMprop);
	  /*	  myfree1(pMprop); */
	  return i;
	}
    }

  /* Find entry in the table for it */
  if(i == MAX_NAMESPACE)
    {

      /*Find entry for the namespace*/
      for(i = 0; i < MAX_NAMESPACE; i++)
	{
	  /* See if there is already entry for the namespace */
	  if((svcTbl[i].Htbl == NULL) && !(strcmp(svcTbl[i].nameSpace, "")))
	    {
	      strcpy(svcTbl[i].nameSpace,nameSpace);
	      svcTbl[i].Htbl = HashCreate(HASH_SLOTS_MAX);
	      /* Key is method name */
	      HashPut(svcTbl[i].Htbl, pMprop);
	      /*	      myfree1(pMprop); */
	      return i;
	    }
	}
    }


  return -1;
}

void FreeMethodProp(METHOD_PROP_T *pMprop)
{
  if(pMprop != NULL)
    myfree1(pMprop);
}

#if 0
void DumpHash()
{
  LIST_T *list;
  LINK_T *link;
  HashEnt *ent;
  int i,j;
  HashTable *ht;

  for(j=0; j < MAX_NAMESPACE; j++)
    {
      if(svcTbl[j].Htbl != NULL)
	{
	  for (ht=svcTbl[j].Htbl, i=0; i < ht->maxent; i++)
	    { /* delete each linked list */
	      list = (LIST_T *)ht->list->item[i];	/* get linked list */
	      for(link = list->head; link != NULL; link=link->next)
		{ /* keep going until list is empty */
		  HashEnt *ent = (HashEnt *)GetDataFromLink(link);
		  printf("freeing method name %s slot %d addr %lx\n",ent->mMethodProp->mName,i, (unsigned long)(&ent->mMethodProp));
		  ent = DeleteLink(list, link);
		  myfree1(ent);
		}
	    }
	}

    }
}
#endif

void FreeHashTable()
{
  int i;
  /*    DumpHash(); */
  for(i=0; i < MAX_NAMESPACE; i++)
    {
      if(svcTbl[i].Htbl != NULL)
	{
#if 0
	  pMprop = (METHOD_PROP_T *)HashGet(svcTbl[i].Htbl, svcTbl[i].nameSpace);
	  printf("Freeing namespace %s method name %s\n",svcTbl[i].nameSpace, pMprop->mName);
#endif
	  HashTableFree(svcTbl[i].Htbl,&FreeMethodProp);
	}
      svcTbl[i].Htbl = NULL;
    }


}

HashTable *GetSvcTbl(char *nameSpace)
{
  int i,result;
  for(i = 0; i < MAX_NAMESPACE; i++)
    {
      if((svcTbl[i].Htbl != NULL) && ((result = strcmp(nameSpace, svcTbl[i].nameSpace) == 0)))
	return svcTbl[i].Htbl; /* Found it, return ht ptr */
    }
    
  /* Fail, dump table */
    
  for(i = 0; i < MAX_NAMESPACE; i++)
    {
      if((svcTbl[i].Htbl != NULL))
	printf("Service table entry %d name space %s\n",i,svcTbl[i].nameSpace);
    }
	
  return NULL;
}

void InitClientTbl()
{
  int id;
  
  for(id=0;id<MAX_CLIENTS;id++)
    client[id] = NULL;
}

#if 0
void ResetClient(int id)
{

  int i;

  sClientInfo *pClient = client[id];
  
  pClient->status = 0;

  for(i=0; i< MAX_CUSTOM_TYPE_DEPTH;i++)
    {
      pClient->customTypeStart[i] = 0;
      pClient->nCustParamRcv[i]   = 0;
      pClient->nCustParmMemCnt[i] = 0;
    }

  pClient->nCustParmDepth = 0;
  pClient->arrayTypeStart=0;

  pClient->arraySize=0;
  pClient->arrayElmRcv=0;
  pClient->nParamRcv = 0;
  pClient->endDoc = 0;
  pClient->rspLen = 0;
  pClient->nilArrElm = 0;
 
  pClient->CurState  =   WAIT_FOR_ENVELOPE;
  pClient->NxtState  =   WAIT_FOR_ENVELOPE;

  FreePtrList(pClient->parmList);
 /* Create container or parameters */
  pClient->parmList = CreatePtrList(DEFAULT_NUM_PARAMS);
  
  for(i=0;i < DEFAULT_NUM_PARAMS; i++)
    pClient->parmList->item[i] = CreateList();

  pClient->parmList->nItems = DEFAULT_NUM_PARAMS;
  pClient->parmList->delta = DEFAULT_NUM_PARAMS;

  /* Create container for response */
    FreePtrList(pClient->respList);
  
    pClient->respList = CreatePtrList(DEFAULT_NUM_PARAMS);
  
    for(i=0;i < DEFAULT_NUM_PARAMS; i++)
      pClient->respList->item[i] = CreateList();

    pClient->respList->nItems = DEFAULT_NUM_PARAMS ;
    pClient->respList->delta  = DEFAULT_NUM_PARAMS;

  /*May have been resized just clean up */
  myfree1(pClient->pBuf);
  
  pClient->pBuf   = (char *)mycalloc((size_t)CLIENT_BUF_SIZE,1);

  if(pClient->pBuf == NULL)
    {
      printf("ERROR: reset client. Failed Alloc\n");
      exit(1);
    }  

  myfree1(pClient->pBufRsp);
	
  pClient->pBufRsp = NULL;

}


void FreeClient(int id)
{
  int i;


  sClientInfo *pClient = client[id];

  if(pClient == NULL)
    return;
	
  myfree1(pClient->pBuf);
  myfree1(pClient->pBufRsp);
  myfree1(pClient->handle);

  for(i=0; i<MAX_CUSTOM_TYPE_DEPTH;i++)
    {
      myfree1(pClient->curParamType[i]);
      myfree1(pClient->curParamName[i]);
      myfree1(pClient->curParamValue[i]);
      myfree1(pClient->curCustParamType[i]);
    }

  myfree1(pClient->curParamType);
  myfree1(pClient->curParamName);
  myfree1(pClient->curParamValue);
  myfree1(pClient->curCustParamType);

  myfree1(pClient->customTypeStart);
  myfree1(pClient->nCustParamRcv);
  myfree1(pClient->nCustParmMemCnt);

 
  myfree1(pClient->prefix);
  myfree1(pClient->curMethodName);
  myfree1(pClient->curNameSpace);

  FreePtrList(pClient->parmList);
  FreePtrList(pClient->respList);

  myfree1(pClient);

  client[id] = NULL;

}
#else
void ResetClient(int id)
{

  int i;
  
  sClientInfo *pClient = client[id];
  
  pClient->status = 0;

  for(i=0; i< MAX_CUSTOM_TYPE_DEPTH;i++)
    {
      pClient->customTypeStart[i] = 0;
      pClient->nCustParamRcv[i]   = 0;
      pClient->nCustParmMemCnt[i] = 0;
    }

  pClient->nCustParmDepth = 0;
  pClient->arrayTypeStart=0;

  pClient->arraySize=0;
  pClient->arrayElmRcv=0;
  pClient->nParamRcv = 0;
  pClient->endDoc = 0;
  pClient->rspLen = 0;
  pClient->nilArrElm = 0;
 
  pClient->CurState  =   WAIT_FOR_ENVELOPE;
  pClient->NxtState  =   WAIT_FOR_ENVELOPE;


  FreePtrList(pClient->parmList);

 /* Create container or parameters */
  pClient->parmList = CreatePtrList(DEFAULT_NUM_PARAMS);
  
  for(i=0;i < DEFAULT_NUM_PARAMS; i++)
    pClient->parmList->item[i] = CreateList();

  pClient->parmList->nItems = DEFAULT_NUM_PARAMS;
  pClient->parmList->delta = DEFAULT_NUM_PARAMS;

  /* Create container for response */

    FreePtrList(pClient->respList);

  
    pClient->respList = CreatePtrList(DEFAULT_NUM_PARAMS);
  

    
    for(i=0;i < DEFAULT_NUM_PARAMS; i++)
      pClient->respList->item[i] = CreateList();

    pClient->respList->nItems = DEFAULT_NUM_PARAMS ;
    pClient->respList->delta  = DEFAULT_NUM_PARAMS;

  /*May have been resized just clean up */
  myfree1(pClient->pBuf);
  
  pClient->pBuf   = (char *)mycalloc((size_t)CLIENT_BUF_SIZE,1);

  if(pClient->pBuf == NULL)
    {
 
      while(1)
          printf("ERROR: reset client. Failed Alloc\n");     
    }  

  myfree1(pClient->pBufRsp);
	
  pClient->pBufRsp = NULL;
}


void FreeClient(int id)
{
  int i;


  sClientInfo *pClient = client[id];

  if(pClient == NULL)
    return;
	

  myfree1(pClient->pBuf);
  myfree1(pClient->pBufRsp);
  myfree1(pClient->handle);

  for(i=0; i<MAX_CUSTOM_TYPE_DEPTH;i++)
    {
      myfree1(pClient->curParamType[i]);
      myfree1(pClient->curParamName[i]);
      myfree1(pClient->curParamValue[i]);
      myfree1(pClient->curCustParamType[i]);
    }

  myfree1(pClient->curParamType);
  myfree1(pClient->curParamName);
  myfree1(pClient->curParamValue);
  myfree1(pClient->curCustParamType);

  myfree1(pClient->customTypeStart);
  myfree1(pClient->nCustParamRcv);
  myfree1(pClient->nCustParmMemCnt);

 
  myfree1(pClient->prefix);
  myfree1(pClient->curMethodName);
  myfree1(pClient->curNameSpace);

  FreePtrList(pClient->parmList);
  FreePtrList(pClient->respList);

  myfree1(pClient);

  client[id] = NULL;


}

#endif

void CreateClient(int id)
{
  int i;
  sClientInfo *pClient;

  client[id] = (sClientInfo *)mycalloc((size_t)sizeof(sClientInfo),1);

  if(client[id] == NULL)
    printf("ERROR: 1. CreateClient Fail alloc\n");

  pClient = client[id];

  pClient->rxSock = 0;
  /*  pClient->rx     = NULL; */
  pClient->txSock = 0;

  pClient->pBuf   = (char *)mycalloc((size_t)CLIENT_BUF_SIZE,1);


  pClient->pBufRsp = NULL;

  if(pClient->pBuf == NULL)
    {
      printf("ERROR: 2. Failed Alloc\n");
      /*      exit(1); */
    }  

  pClient->status = 0;

  pClient->handle=NULL;

  pClient->prefix  = (char *)mycalloc((size_t)MAX_METHOD_NAME_LEN,1);
  if( pClient->prefix == NULL)
    printf("ERROR: 3. CreateClient Fail alloc\n");

  pClient->curMethodName = (char *)mycalloc((size_t)MAX_METHOD_NAME_LEN,1);
  if( pClient->curMethodName == NULL)
    printf("ERROR: 4. CreateClient Fail alloc\n");

  pClient->curNameSpace  = (char *)mycalloc((size_t)MAX_NAMESPACE_LEN,1);
  if( pClient->curNameSpace == NULL)
    printf("ERROR: 5. CreateClient Fail alloc\n");

  pClient->curParamType  = (char **)mycalloc((size_t)MAX_CUSTOM_TYPE_DEPTH*sizeof(char *),1);
  if( pClient->curParamType == NULL)
    printf("ERROR: 6. CreateClient Fail alloc\n");

  pClient->curParamName  = (char **)mycalloc((size_t)MAX_CUSTOM_TYPE_DEPTH*sizeof(char *),1);
  if( pClient->curParamName == NULL)
    printf("ERROR: 7. CreateClient Fail alloc\n");

  pClient->curParamValue  = (char **)mycalloc((size_t)MAX_CUSTOM_TYPE_DEPTH*sizeof(char *),1);
  if( pClient->curParamValue == NULL)
    printf("ERROR: 8. CreateClient Fail alloc\n");

  pClient->curCustParamType  = (char **)mycalloc((size_t)MAX_CUSTOM_TYPE_DEPTH*sizeof(char *),1);
  if( pClient->curCustParamType == NULL)
    printf("ERROR: 9. CreateClient Fail alloc\n");

  for(i=0; i<MAX_CUSTOM_TYPE_DEPTH;i++)
    {
      pClient->curParamType[i]     = (char *)mycalloc((size_t)MAX_PARAMETER_TYPE_LEN,1);
      if( pClient->curParamType[i] == NULL)
	printf("ERROR: 10. CreateClient Fail alloc\n");

      pClient->curParamName[i]     = (char *)mycalloc((size_t)MAX_PARAMETER_TYPE_LEN,1);
      if( pClient->curParamName[i] == NULL)
	printf("ERROR: 11. CreateClient Fail alloc\n");

      pClient->curParamValue[i]     = (char *)mycalloc((size_t)MAX_PARAMETER_TYPE_LEN,1);
      if( pClient->curParamValue[i] == NULL)
	printf("ERROR: 12. CreateClient Fail alloc\n");

      pClient->curCustParamType[i] = (char *)mycalloc((size_t)MAX_PARAMETER_TYPE_LEN,1);
      if( pClient->curCustParamType[i] == NULL)
	printf("ERROR: 13. CreateClient Fail alloc\n");

    }

  pClient->customTypeStart = (int *)mycalloc((size_t)MAX_CUSTOM_TYPE_DEPTH*sizeof(int *),1);
  if( pClient->customTypeStart == NULL)
    printf("ERROR: 14. CreateClient Fail alloc\n");
  pClient->nCustParamRcv = (int *)mycalloc((size_t)MAX_CUSTOM_TYPE_DEPTH*sizeof(int *),1);
  if( pClient->nCustParamRcv == NULL)
    printf("ERROR: 15. CreateClient Fail alloc\n");
  pClient->nCustParmMemCnt = (int *)mycalloc((size_t)MAX_CUSTOM_TYPE_DEPTH*sizeof(int *),1);
  if( pClient->nCustParmMemCnt == NULL)
    printf("ERROR: 16. CreateClient Fail alloc\n");

  pClient->nCustParmDepth = 0;
  pClient->arrayTypeStart=0;

  pClient->arraySize=0;
  pClient->arrayElmRcv=0;
  pClient->nParamRcv = 0;
  pClient->endDoc = 0;
  pClient->rspLen = 0;
  
  pClient->nilArrElm = 0;

  pClient->CurState  =   WAIT_FOR_ENVELOPE;
  pClient->NxtState  =   WAIT_FOR_ENVELOPE;

  /* Create container or parameters */
  pClient->parmList = CreatePtrList(DEFAULT_NUM_PARAMS);
  
  for(i=0;i < DEFAULT_NUM_PARAMS; i++)
    pClient->parmList->item[i] = CreateList();

  pClient->parmList->nItems = DEFAULT_NUM_PARAMS;
  pClient->parmList->delta = DEFAULT_NUM_PARAMS;

  /* Create container for response */
  /* Only one list for response */
  pClient->respList = CreatePtrList(DEFAULT_NUM_PARAMS);
  
  for(i=0;i < DEFAULT_NUM_PARAMS; i++)
    pClient->respList->item[i] = CreateList();

  pClient->respList->nItems = DEFAULT_NUM_PARAMS ;
  pClient->respList->delta  = DEFAULT_NUM_PARAMS;

  pClient->pMprop = NULL;
  
#ifdef NON_OS

  pClient->m_hUart = UARTA;		/* default to UARTA 04/17/2007  */
  pSavehUart = (long)(void *)pClient->m_hUart;

#ifdef BCM7440	/* enable UARTC */
      *((unsigned long *) 0xb0404110) |= 0x08000000;
      pClient->m_hUart = ((volatile struct UartChannelNew *)UARTC_ADR_BASE);	
#endif

#ifdef BCM7401	/* enable UARTC */
#ifdef BCHP_REV_B0
  /* for B0, mux is already setup in bsp */
  /* *((unsigned long *) 0xb04040BC) |= 0x00040200; */
#endif
#ifdef BCHP_REV_A0
      *((unsigned long *) 0xb04040a4) |= 0x00040200;
#endif
      pClient->m_hUart = UARTC;	
#if  (BCHP_VER==BCHP_VER_C1) || (BCHP_VER>=BCHP_VER_C3)		/* make sure C3 is working */
	/* UARTC according to C3 RDB http://www.sj.broadcom.com/projects/rdb/snapshot/rdb/bcm7401_c3/current/webs/SUN_TOP_CTRL.html#SUN_TOP_CTRL%20Registers, 32'h0040_40bc*/ 
      *((unsigned long *) 0xb04040bc) |= (unsigned long)(1<<9 + 1<<18);		 	
#endif

#endif

#ifdef BCM3560
      /* 3560 mux  */
      *((unsigned long *) 0xb0404088) |= 0x00000500;
      pClient->m_hUart = UARTB;
#endif

#ifdef BCM3563
           pClient->m_hUart = UARTB;
#endif
	
#ifdef BCM4501
      /* 4501 mux  */
      *((unsigned long *) 0xb0404088) |= 0x00000500;
      pClient->m_hUart = UARTB;
#endif

#if BCHP_CHIP==7400
#if BCHP_VER >= BCHP_VER_B0
	  /* use default UARTA above */
#else
      pClient->m_hUart = UARTB;
	  printf("SOAP using UARTB\n");
#endif
#endif

#if BCHP_CHIP==7405
      pClient->m_hUart = UARTB;
	  printf("SOAP using UARTB\n");
	  /*http://www.sj.broadcom.com/projects/BCM7405/A0/snapshot/bcm7405_a0/doc/chip_webfiles/SUN_TOP_CTRL.html#SUN_TOP_CTRL_PIN_MUX_CTRL_12 */
	*((unsigned long *) 0xb0404130) |= (unsigned long)(1<<29);		 	  /* select the SC_VCC */
#endif

#if BCHP_CHIP==7325
      pClient->m_hUart = UARTB;
	  printf("SOAP using UARTB\n");
#endif

#ifndef USENEWUART	/* only 7400A0 and 7401B0 uses new uart as of 06/23/2006 */
      /*Disable tx/rx */
      *(&pClient->m_hUart->control)= 0;	
      *(&pClient->m_hUart->baudh) = BAUD_115200_HI;
      *(&pClient->m_hUart->baudl) = BAUD_115200_LO;
      *(&pClient->m_hUart->rxstat) = 0;
      *(&pClient->m_hUart->txstat) = 0;
      *(&pClient->m_hUart->control) = BITM8 | TXEN | RXEN;	
      /*skipUartInit = 1; */
#else
      /*printf("Sdw_lcr %x\n",&pClient->m_hUart->sdw_lcr); */
      *(&pClient->m_hUart->sdw_lcr)= 0x80;		/*DLAB*/
      *(&pClient->m_hUart->sdw_dlh_ier) = 0;		/* BAUD_HI*/
      *(&pClient->m_hUart->sdw_rbr_thr_dll) = 44;	/* BAUD_LO*/
      *(&pClient->m_hUart->sdw_iir_fcr) |= 1;           /*Enable FIFO*/
      *(&pClient->m_hUart->sdw_lcr) = 3;	        /*select 8 bit, no parity, 1 stop*/

#endif

	  if (pClient->m_hUart == pSavehUart)
		  printf("Note: SOAP also competing for UARTA.\n");

#endif  
}

PtrList * ResizePtrList(PtrList *list, int m)
{
  int i,cnt;
  void **oldPtr;

  cnt = list->nItems; /* Current count */
  /*  printf("CURRENT count %d request %d\n",cnt,m); */

  if(list == NULL) return NULL;

  oldPtr = list->item;

  list->item = (void **)myrealloc(oldPtr, (cnt + m)*sizeof(void *));
  
  if(list->item == NULL)
   printf("ERROR: ResizePtrList fail alloc\n");
   
  /*  printf("oldPtr %lx new ptr %lx\n",(unsigned long)oldPtr, (unsigned long)list->item); */

  for(i = cnt; i < cnt + m; i++)
    {
      list->item[i] = (void *)CreateList();
      /*      printf("item ptr addr %lx\n",(unsigned long)&list->item[i]); */
    }

  list->nItems += m;

  return list;
}

/*Be careful: This function is recursive and  modifies input string strToConv */
char * StrConvert(char *strToConv, char *patt, char *strToReplace)
{
    char *pStrToConv = strToConv;
    char *s1,*s2, *tmpStr;
    register int ndx=0;
	int len;

	len = strlen(strToConv)+strlen(strToReplace) + 1;

    tmpStr = (char *)mycalloc(len, 1);
	
    if(tmpStr == NULL)
    {
        printf("ERROR: StrConvert !! fail malloc\n");
        return NULL;
    }

    while(*pStrToConv)
    {
        s1 = pStrToConv;
        s2 = patt;

	/*Look for pattern */
        while(*s1 && *s2 && !(*s1-*s2))
            s1++,s2++;
        if(!*s2)
        {
            
            tmpStr=strcat(tmpStr,strToReplace);
            
            pStrToConv += strlen(patt);
            tmpStr=strcat(tmpStr,pStrToConv);
            strcpy(strToConv,tmpStr);

            free(tmpStr);
            /*Recursive call */
            strToConv = StrConvert(strToConv,patt,strToReplace);
            return strToConv;
            
        }

        tmpStr[ndx] = strToConv[ndx];
        tmpStr[ndx+1] = 0;
        pStrToConv++;
        ndx++;
    }

    free(tmpStr);
    return strToConv;
    
}

void AddParam(int clientId)
{

  int  depth;
  LINK_T *linkEnt;
  LIST_T *list;
  char *tmpStr,*tmpStr1;

  sClientInfo *pClient = client[clientId]; 

  sParam *pParam = (sParam *)mycalloc((size_t)sizeof(sParam),1);
  
  if(pParam == NULL)
    printf("ERROR: AddParam failed mycalloc\n");
  

  depth = pClient->nCustParmDepth;

  strcpy(pParam->curParamType, pClient->curParamType[depth]);
  strcpy(pParam->curParamName, pClient->curParamName[depth]);
  
  pParam->curParamValue = (char *)mycalloc(strlen(pClient->curParamValue[depth]),1);


  tmpStr = StrConvert(pClient->curParamValue[depth], "&gt;", ">");
  tmpStr1 = StrConvert(tmpStr, "&lt;", "<");
   
  strcpy(pParam->curParamValue, tmpStr1);

  strcpy(pParam->curCustParamType, pClient->curCustParamType[depth]);
  pParam->arraySize       = pClient->arraySize;
  strcpy(pParam->arraySizeStr, pClient->arraySizeStr);

  linkEnt = CreateLinkEnt(pParam);

  if(linkEnt == NULL)	
    printf("ERROR: Failed to create link\n");

  if(pClient->nParamRcv >= pClient->parmList->nItems)
    ResizePtrList(pClient->parmList,pClient->parmList->delta);

  list = pClient->parmList->item[pClient->nParamRcv];

  AddLinkToTail(list,linkEnt);

  /*  DumpParamList(list); */
  
}

#ifdef WIN32
int snprintf(char *pBuf, int len, char *pFormat, char *tag)
{
	int length;

	if (strcmp(pFormat, "<%s>") == 0) 
	{
		strcpy(pBuf, "<");
		strncat(pBuf, tag, len);
		strcat(pBuf, ">");
		length = strlen(pBuf);
	}
	else if (strcmp(pFormat, "</%s>") == 0)
	{
		strcpy(pBuf, "</");
		strncat(pBuf, tag, len);
		strcat(pBuf, ">");
		length = strlen(pBuf);
	}
	else
	{
		length = 0;
		printf("ERROR: snprintf failed\n");
	}
	return length;
}
#endif

void StartTag(int clientId, char *tag)
{
  sClientInfo *pClient = client[clientId]; 
  char *pBufRsp = pClient->pBufRsp;
  int oldSize   = pClient->rspLen; /* Old size is exact byte count */
  int tagLen    = _strlen(tag);
  int cnt;

  if(pBufRsp == NULL) /*First time only */
      pBufRsp = (char *)mycalloc((size_t)tagLen + 3 + 1,1);
  else
      pBufRsp = myrealloc(pClient->pBufRsp,oldSize+tagLen+3 + 1);
      
  if(pBufRsp == NULL)
	 printf("ERROR: StartTag failed allocation\n");

  cnt = snprintf(pBufRsp+oldSize,tagLen+3+1,"<%s>",tag);
  
  while(cnt  != tagLen+3-1)
  {
	printf("ERROR: starttag snprintf failed expect %d get %d\n",tagLen+3-1,cnt);
	  cnt = snprintf(pBufRsp+oldSize,tagLen+3+1,"<%s>",tag);
  }

  pClient->rspLen += tagLen + 2 ; /* 2 for < and > not including \0 from snprintf call... */
  
  pClient->pBufRsp = pBufRsp;
  
#if 0
  int i;
    for(i=0; i < pClient->rspLen; i++)
      printf("%c",pClient->pBufRsp[i]);
#endif

}

void EndTag(int clientId, char *tag)
{
  sClientInfo *pClient = client[clientId]; 
  char *pBufRsp = pClient->pBufRsp;
  int oldSize   = pClient->rspLen;
  int tagLen    = _strlen(tag);
  int i;

  
  pBufRsp = myrealloc(pClient->pBufRsp,oldSize+tagLen+4+1);
  
  if(pBufRsp == NULL)
	 printf("ERROR: EndTag failed allocation\n");

  i = snprintf(pBufRsp+oldSize,tagLen+4+1,"</%s>",tag);
  
  while(i != tagLen+4-1)
  {
  	printf("Error***** snprintf failed expect %d get %d\n",tagLen+4-1,i); 
	  i = snprintf(pBufRsp+oldSize,tagLen+4-1,"</%s>",tag);
  }	  
  

  pClient->rspLen += tagLen + 3 ; /* 3 for </ and > */
  
  pClient->pBufRsp = pBufRsp;

#if 0 
  for(i=0; i < pClient->rspLen;i++)
  	printf("%c",pClient->pBufRsp[i]);

  printf("\nExit endtag\n");
#endif
  
#if 0
  if(!(strcmp("Envelope",tag)))
  {
    printf("Rep Len %d\n",pClient->rspLen); 

    for(i=0; i < pClient->rspLen; i++)
      printf("%c",pClient->pBufRsp[i]);
  }
#endif
  
}

#define SCRATCH_ALLOC_SIZE 2048

int BuildMethodRspStr(int clientId, char *scratch, RSP_STR_TYPE rspStrType)
{
  sClientInfo *pClient = client[clientId];  
  char *start = scratch;
  int cnt,expCnt;
  cnt = sprintf(scratch,"%s:%sResponse ",pClient->prefix,pClient->curMethodName);
  expCnt = _strlen(pClient->prefix) + _strlen(pClient->curMethodName) + 10;

  while(cnt == -1)
    {
      printf("************************ERROR expect %d get %d\n",expCnt,cnt);
      printf("Str %s\n",scratch);
      cnt = sprintf(scratch,"%s:%sResponse ",pClient->prefix,pClient->curMethodName);
    }  		
  	
  /*  scratch += _strlen(scratch); */

  scratch += expCnt;



  if((rspStrType == BUILD_METHOD_RSP_STR_WITH_XMLNS) || 
     (rspStrType == BUILD_METHOD_RSP_STR_WITH_VOID_RSP))
    {
      /* +1 to scratch to avoid problem in sprintf .. sometime it overwrites the last */
      /* character of the prior string */
	  
      cnt = sprintf(scratch," xmlns:%s=\"%s\"%s",pClient->prefix,pClient->curNameSpace,
		    (rspStrType == BUILD_METHOD_RSP_STR_WITH_VOID_RSP)?"/":"");
	  
#if 0
      expCnt =   _strlen(pClient->prefix);
      printf("expcnt %d\n",expCnt);
      expCnt +=   _strlen(pClient->curNameSpace);
      printf("expcnt %d\n",expCnt);
      expCnt += (rspStrType == BUILD_METHOD_RSP_STR_WITH_VOID_RSP)?1:0;
      printf("expcnt %d\n",expCnt);
      expCnt += 10;
      printf("expcnt %d cnt %d\n",expCnt,cnt);
      printf("strsofar %s current Str = %s\n",start,scratch);
#endif	  	  		
      while(cnt == -1)
	{
	  printf("++++++++++ERROR expect %d get %d\n",expCnt,cnt);
	  printf("strsofar %s scratch %s start %lx scratch %lx\n",start,scratch,
		 (unsigned long)&start[0], (unsigned long)&scratch[0]);
	  		
	  cnt = sprintf(scratch," xmlns:%s=\"%s\"%s",pClient->prefix,pClient->curNameSpace,
			(rspStrType == BUILD_METHOD_RSP_STR_WITH_VOID_RSP)?"/":"");
		      
	  printf("Str after %s cnt = %d strsofar %s scratch %lx start %lx\n",scratch,cnt,start,
		 (unsigned long)&scratch[0],(unsigned long)&start[0]);

	}
  	   
  	   
	      
    }
   

#if 0
  for(i=0; i < scratch - start; i++)
    printf("%c",start[i]);
  printf("\n");	
  else
#endif  

    return _strlen(start);
}


int BuildRetType(int clientId, char *scratch,char *pRetType)
{
  sClientInfo *pClient = client[clientId];
  char tmpStr[1024], *pTmpStr=NULL;
  CUSTOM_DTYPE_INFO_T *pCustInfo;
  int custType = IsCustomType(pRetType);
  int cnt;

  if(custType)
    {
      pTmpStr=tmpStr;
      pCustInfo = GetCustParamInfo(pRetType);

      cnt = sprintf(tmpStr,"%s:%s\" xmlns:%s=\"%s",
		    pClient->pMprop->retPrefix,
		    pRetType,
		    pClient->pMprop->retPrefix,
		    pCustInfo->nameSpace);
	      
      while(cnt == -1)
	cnt = sprintf(tmpStr,"%s:%s\" xmlns:%s=\"%s",
		      pClient->pMprop->retPrefix,
		      pRetType,
		      pClient->pMprop->retPrefix,
		      pCustInfo->nameSpace);
	  	      
    }

  cnt = sprintf(scratch,"return type=\"%s\"",
		(pTmpStr==NULL)? pRetType:pTmpStr);
	  
  while(cnt == -1)
    cnt = sprintf(scratch,"return type=\"%s\"",
		  (pTmpStr==NULL)? pRetType:pTmpStr);
  

  return _strlen(scratch);

}

   int BuildRetElement(int clientId, char *scratch,char *pRetType, char *pRetName)
  {
    sClientInfo *pClient = client[clientId];
    char tmpStr[1024], *pTmpStr=NULL;
    CUSTOM_DTYPE_INFO_T *pCustInfo;
    int custType = IsCustomType(pRetType);
    int cnt;

    if(custType)
      {
	pTmpStr=tmpStr;
	pCustInfo = GetCustParamInfo(pRetType);

	cnt = sprintf(tmpStr,"%s:%s\" xmlns:%s=\"%s",
		      pClient->pMprop->retPrefix,
		      pRetType,
		      pClient->pMprop->retPrefix,
		      pCustInfo->nameSpace);
	      
	while(cnt == -1)
	  cnt = sprintf(tmpStr,"%s:%s\" xmlns:%s=\"%s",
			pClient->pMprop->retPrefix,
			pRetType,
			pClient->pMprop->retPrefix,
			pCustInfo->nameSpace);
	  	      
      }

    cnt = sprintf(scratch,"%s type=\"%s\"",
		  pRetName, (pTmpStr==NULL)? pRetType:pTmpStr);
	  
    while(cnt == -1)
      cnt = sprintf(scratch,"%s type=\"%s\"",
		    pRetName, (pTmpStr==NULL)? pRetType:pTmpStr);
  

    return _strlen(scratch);

  }
  

int AddValue(int clientId, char *value)
{

  sClientInfo *pClient = client[clientId];
  int oldSize = pClient->rspLen;
  int cnt;

  /*Check for &gt;  and &lt; for converstion*/
  
  pClient->pBufRsp = myrealloc(pClient->pBufRsp,oldSize+_strlen(value)+1);
  
  if(pClient->pBufRsp == NULL)
    printf("ERROR: AddValue failed allocation\n");

  /*  strncpy(pClient->pBufRsp+oldSize,value,_strlen(value)); */
  cnt = sprintf(pClient->pBufRsp+oldSize,"%s",value);
  
  while(cnt == -1)
    {
      printf("Err1: Truncated\n");
      cnt = sprintf(pClient->pBufRsp+oldSize,"%s",value);
    }	  
 
  pClient->rspLen += _strlen(value);

  return _strlen(value);
}

int BuildRetTypeArray(int clientId, char *scratch, char *pArrType, char *arrSize)
{
  char tmpStr[1024], *pTmpStr=NULL;
  sClientInfo *pClient = client[clientId];
  int custType = IsCustomType(pArrType);
  int cnt;
  
  pTmpStr = tmpStr;
  
  if(custType)
    {
      CUSTOM_DTYPE_INFO_T *pCustInfo;

      pCustInfo = GetCustParamInfo(pArrType);

      cnt = sprintf(tmpStr,"%s:%s[%s]\" xmlns:%s=\"%s",
		    pClient->pMprop->retPrefix,
		    pArrType,arrSize,
		    pClient->pMprop->retPrefix,
		    pCustInfo->nameSpace);
	      
      while(cnt == -1)
	{
	  printf("Err2: Truncated\n");
	  cnt = sprintf(tmpStr,"%s:%s[%s]\" xmlns:%s=\"%s",
			pClient->pMprop->retPrefix,
			pArrType,arrSize,
			pClient->pMprop->retPrefix,
			pCustInfo->nameSpace);
	}
 
    }
  else
    {
      cnt = sprintf(tmpStr,"%s[%s]",pArrType,arrSize);
    
      while(cnt == -1)
	{
	  printf("Err3: Truncated\n");
	  cnt = sprintf(tmpStr,"%s[%s]",pArrType,arrSize);
	}
    
    } 

  cnt = sprintf(scratch,"return type=\"Array\" arrayType=\"%s\"",tmpStr);
  while(cnt == -1)
    {
      printf("Err4: Truncated\n");
      cnt = sprintf(scratch,"return type=\"Array\" arrayType=\"%s\"",tmpStr);

    }

  return _strlen(scratch);

}

char tmp[SCRATCH_ALLOC_SIZE];
 
void SerializeBody(int clientId)
{
  int i;

  sClientInfo *pClient = client[clientId];  
  char *start;
  char *scratch;
  int custMemNdx,custType, typeVoid, arrayType;
  METHOD_PROP_T *pMprop = pClient->pMprop;

  char *pRetType = pMprop->retType;

  scratch = start = &tmp[0];

  /*  pMprop = pClient->pMprop; */

  if((typeVoid = strcmp(pRetType,"")) != 0)
    {
      i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_XMLNS);
      
      StartTag(clientId,tmp);

      custType  = IsCustomType(pRetType);
      arrayType = (strcmp(pRetType,"Array")==0)?1:0;
      
      if(arrayType)
      	custType = IsCustomType(pMprop->arrType);
      
      if(!custType && !arrayType)
	{
 	  LIST_T *list;
	  sParam *pSparm;
	  /* NOT a custom type and not array */
	  BuildRetType(clientId, tmp, pRetType);
	  StartTag(clientId,tmp);

	  /* ONLY one response type */
	  list = pClient->respList->item[0];

	  pSparm = (sParam *)GetDataFromLink(list->head);

	  i = AddValue(clientId, pSparm->curParamValue);

	  EndTag(clientId,"return");

	  i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_NO_XMLNS);

	  EndTag(clientId,tmp);
	  
	}
      else 	if(!custType && arrayType)
 
	{
	  /* Array of non custom */

	  sParam *pSparm;

	  LIST_T *list = pClient->respList->item[0];
	  LINK_T *link;
   
    	  
	  pSparm = (sParam *)GetDataFromLink(list->head);

	  pMprop = pClient->pMprop;

	  i = BuildRetTypeArray(clientId, tmp, pMprop->arrType, pSparm->arraySizeStr);

	  StartTag(clientId, tmp);

	  /* May want to check for the proper count of array element: TODO */
	  for (link = list->head; link != NULL; link = link->next)
	    {
	      /*Get all elements */
	      pSparm = (sParam *)GetDataFromLink(link);
	      StartTag(clientId,"i");
	      AddValue(clientId,pSparm->curParamValue);
	      EndTag(clientId, "i");
	    }

	  EndTag(clientId, "return");

	  i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_NO_XMLNS);

	  EndTag(clientId,tmp);

	}
      else 	if(custType && arrayType)

	{
	  /* Array of custom */

	  char curCustName[MAX_PARAMETER_TYPE_LEN];
	  sParam *pSparm;
	  LIST_T *list = pClient->respList->item[0];
	  LINK_T *link;
	  int    count,cnt;
	  int dEntry;
	  CUSTOM_DTYPE_INFO_T *pCDTtbl;

	  /*take a snapshot */
	  strcpy(curCustName,pMprop->arrType);

	  pSparm = (sParam *)GetDataFromLink(list->head);

	  pMprop = pClient->pMprop;

	  /* Array of non custom */
	  i = BuildRetTypeArray(clientId, tmp, pMprop->arrType, pSparm->arraySizeStr);

	  StartTag(clientId, tmp);

	  dEntry = GetCustDtypeEntry(curCustName);

	  pCDTtbl  = &CustomDataTypeTable[dEntry];
	  
	  /* May want to check for the proper count of array element: TODO */
	  for (link = list->head; link != NULL;)
	    {
	      /*Get all elements */
	      StartTag(clientId,"i");
	      pSparm = (sParam *)GetDataFromLink(link);

	      for(count=0; count <  pCDTtbl->mCount; count++, link=link->next)
		{
		  pSparm = (sParam *)GetDataFromLink(link);

		  cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
		  
		  while(cnt == -1)
		    {
		      printf("Err5: Truncated\n");
		      cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
		    }

		  StartTag(clientId,tmp);

		  AddValue(clientId,pSparm->curParamValue);

		  EndTag(clientId,pSparm->curParamName);

		}
	      EndTag(clientId, "i");
	    }

	  EndTag(clientId, "return");

	  i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_NO_XMLNS);

	  EndTag(clientId,tmp);

	}
      else 	if(custType)
	{
	  /* Just custom type */
	  char curCustName[MAX_PARAMETER_TYPE_LEN];
	  LIST_T *list = pClient->respList->item[0];
	  LINK_T *link;

	  sParam *pSparm;
	  int depth = 0,cnt;
	  char custTypeForClose[MAX_CUSTOM_TYPE_DEPTH][MAX_PARAMETER_TYPE_LEN];

	  /*take a snapshot */
	  strcpy(curCustName,pRetType);

	  i = BuildRetType(clientId, tmp, pRetType);
	  StartTag(clientId,tmp);

	  /* ONLY one response type */

	  for (custMemNdx = 0, link = list->head; link != NULL; link = link->next, custMemNdx++)
	    {
	      pSparm = (sParam *)GetDataFromLink(link);

	      /*check for nested custom */
	      if(!strcmp(curCustName,pSparm->curCustParamType))
		{
		  cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
			  
		  while(cnt == -1)
		    {
		      printf("Err6: Truncated\n");
		      cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
				
		    }
			  
		  StartTag(clientId,tmp);

		}
	      else
		{

		  /*Nested get parent's info*/
		  int dEntry = GetCustDtypeEntry(curCustName);
		  CUSTOM_DTYPE_INFO_T *pCDTtbl = &CustomDataTypeTable[dEntry];

		  /* Keep for end tag */
		  strcpy(custTypeForClose[depth++],pCDTtbl->mName[custMemNdx]);

		  cnt = sprintf(scratch,"%s type=\"%s:%s\"",pCDTtbl->mName[custMemNdx],
				pMprop->retPrefix,pCDTtbl->mType[custMemNdx]);
			
		  while(cnt == -1)
		    {
		      printf("Err7: Truncated\n");
		      cnt = sprintf(scratch,"%s type=\"%s:%s\"",pCDTtbl->mName[custMemNdx],
				    pMprop->retPrefix,pCDTtbl->mType[custMemNdx]);
		    }	  
	  
		  StartTag(clientId,tmp);
		  cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
		  while(cnt == -1)
		    {
		      printf("Err8: Truncated\n");
		      cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
		    } 
				

		  StartTag(clientId,tmp);
		  strcpy(curCustName,pSparm->curCustParamType);
		}

	      AddValue(clientId,pSparm->curParamValue);
	      EndTag(clientId,pSparm->curParamName);
	      
	    }

	  /* Just out of for loop*/
	  if(depth)
	    {
	      for(i=depth; i;)
		{
		  EndTag(clientId,custTypeForClose[--i]);  
		}
	    }
	  EndTag(clientId,"return");

	  i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_NO_XMLNS);
	  EndTag(clientId,tmp);

	}

    }
  else
    {

      i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_VOID_RSP);
      StartTag(clientId,tmp);

    }

  return; /* End with Envelope and body */
}


   void SerializeReturns(int clientId, int rNdx, bool lastRetVal)
  {
    int i;

    sClientInfo *pClient = client[clientId];  
    char *start;
    char *scratch;
    char *pRetType;
    int custMemNdx,custType, typeVoid, arrayType;
    LIST_T *list;
    LINK_T *link;
    sParam *pSparm;
    char retName[8];
    char *pRetName = &retName[0];

    
    METHOD_PROP_T *pMprop = pClient->pMprop;
    

    /*
	Only the first return type is register
	this first return value is enclosed by <return> in soap msg
	the client will extract it as an lval of the call [ ret = abc();]
	The rest of the return value will be serialize as element with some name
	after the first one in order from left to right -- see caller's prototype
   */
	if(rNdx == 0)
	{
	    pRetType = pMprop->retType;
	    scratch = start = &tmp[0];

    }
   	else
   	{   
   		/*Get type from element*/
    	list = pClient->respList->item[rNdx];
    	link = list->head;
		pSparm = (sParam *)GetDataFromLink(link);

    	pRetType = pSparm->curParamType;

		tmp[0] = '\0';
	    scratch = start = &tmp[0];
   	} 
   
    if((typeVoid = strcmp(pRetType,"")) != 0)
      {
	
	if(rNdx == 0)
	{
		i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_XMLNS);      
		StartTag(clientId,tmp);
		strcpy(pRetName,"return");
	}
	else
	{
		strcpy(pRetName,"out");
		_ltoa((long)rNdx,tmp,10);
		_strcat(pRetName,tmp);
	}

	custType  = IsCustomType(pRetType);
	arrayType = (strcmp(pRetType,"Array")==0)?1:0;
      
	if(arrayType)
	  custType = IsCustomType(pMprop->arrType);
      
	if(!custType && !arrayType)
	  {
	    LIST_T *list;
	    sParam *pSparm;
	    /* NOT a custom type and not array */
	    if(rNdx == 0)
	    	BuildRetType(clientId, tmp, pRetType);
		else
		{
	    	BuildRetElement(clientId, tmp, pRetType,  pRetName);

	    }
			    	
	    StartTag(clientId,tmp);

	    list = pClient->respList->item[rNdx];

	    pSparm = (sParam *)GetDataFromLink(list->head);

	    i = AddValue(clientId, pSparm->curParamValue);

	    if(lastRetVal)
	    {

	   		EndTag(clientId,pRetName);
		    i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_NO_XMLNS);
		    
		    EndTag(clientId,tmp);
	    }
	    else
		    EndTag(clientId,pRetName);
	  

	  }
	else 	if(!custType && arrayType)
 
	  {
	    /* Array of non custom */

	    sParam *pSparm;

	    LIST_T *list = pClient->respList->item[rNdx];
	    LINK_T *link;
   
    	  
	    pSparm = (sParam *)GetDataFromLink(list->head);

	    pMprop = pClient->pMprop;

	    i = BuildRetTypeArray(clientId, tmp, pMprop->arrType, pSparm->arraySizeStr);

	    StartTag(clientId, tmp);

	    /* May want to check for the proper count of array element: TODO */
	    for (link = list->head; link != NULL; link = link->next)
	      {
		/*Get all elements*/
		pSparm = (sParam *)GetDataFromLink(link);
		StartTag(clientId,"i");
		AddValue(clientId,pSparm->curParamValue);
		EndTag(clientId, "i");
	      }

	    if(lastRetVal)
		{

	    i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_NO_XMLNS);
		}
	    EndTag(clientId,pRetName);

	  }
	else 	if(custType && arrayType)

	  {
	    /* Array of custom */

	    char curCustName[MAX_PARAMETER_TYPE_LEN];
	    sParam *pSparm;
	    LIST_T *list = pClient->respList->item[rNdx];
	    LINK_T *link;
	    int    count,cnt;
	    int dEntry;
	    CUSTOM_DTYPE_INFO_T *pCDTtbl;

	    /*printf("ARRAy of custom\n"); */
	    /*take a snapshot */
	    strcpy(curCustName,pMprop->arrType);

	    pSparm = (sParam *)GetDataFromLink(list->head);

	    pMprop = pClient->pMprop;

	    /* Array of non custom */
	    i = BuildRetTypeArray(clientId, tmp, pMprop->arrType, pSparm->arraySizeStr);

	    StartTag(clientId, tmp);

	    dEntry = GetCustDtypeEntry(curCustName);

	    pCDTtbl  = &CustomDataTypeTable[dEntry];
	  
	    /* May want to check for the proper count of array element: TODO */
	    for (link = list->head; link != NULL;)
	      {

		/*Get all elements*/
		StartTag(clientId,"i");
		pSparm = (sParam *)GetDataFromLink(link);

		for(count=0; count <  pCDTtbl->mCount; count++, link=link->next)
		  {
		    pSparm = (sParam *)GetDataFromLink(link);

		    cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
		  
		    while(cnt == -1)
		      {
			printf("Err5: Truncated\n");
			cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
		      }

		    StartTag(clientId,tmp);

		    AddValue(clientId,pSparm->curParamValue);

		    EndTag(clientId,pSparm->curParamName);

		  }
		EndTag(clientId, "i");
	      }

	    if(lastRetVal)
		{
/*	    EndTag(clientId, "return"); */

	    i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_NO_XMLNS);
		}
	    EndTag(clientId,pRetName);

	  }
	else 	if(custType)
	  {
	    /* Just custom type */
	    char curCustName[MAX_PARAMETER_TYPE_LEN];
	    LIST_T *list = pClient->respList->item[rNdx];
	    LINK_T *link;

	    sParam *pSparm;
	    int depth = 0,cnt;
	    char custTypeForClose[MAX_CUSTOM_TYPE_DEPTH][MAX_PARAMETER_TYPE_LEN];

	    /*take a snapshot*/
	    strcpy(curCustName,pRetType);

   	    if(rNdx == 0)
	    	BuildRetType(clientId, tmp, pRetType);
		else
	    	BuildRetElement(clientId, tmp, pRetType,pRetName);

	    StartTag(clientId,tmp);

	    /* ONLY one response type */

	    for (custMemNdx = 0, link = list->head; link != NULL; link = link->next, custMemNdx++)
	      {
		pSparm = (sParam *)GetDataFromLink(link);

		/*check for nested custom */
		if(!strcmp(curCustName,pSparm->curCustParamType))
		  {
		    cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
			  
		    while(cnt == -1)
		      {
			printf("Err6: Truncated\n");
			cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
				
		      }
			  
		    StartTag(clientId,tmp);

		  }
		else
		  {
		    /*		  printf("2. here %d\n",custMemNdx); */

		    /*Nested get parent's info */
		    int dEntry = GetCustDtypeEntry(curCustName);
		    CUSTOM_DTYPE_INFO_T *pCDTtbl = &CustomDataTypeTable[dEntry];

		    /* Keep for end tag */
		    strcpy(custTypeForClose[depth++],pCDTtbl->mName[custMemNdx]);
		    /*		  i = BuildRetTypeNested(clientId,tmp,pCDTtbl->mType[custMemNdx],pCDTtbl->mName[custMemNdx]);*/

		    cnt = sprintf(scratch,"%s type=\"%s:%s\"",pCDTtbl->mName[custMemNdx],
				  pMprop->retPrefix,pCDTtbl->mType[custMemNdx]);
			
		    while(cnt == -1)
		      {
			printf("Err7: Truncated\n");
			cnt = sprintf(scratch,"%s type=\"%s:%s\"",pCDTtbl->mName[custMemNdx],
				      pMprop->retPrefix,pCDTtbl->mType[custMemNdx]);
		      }	  
	  
		    StartTag(clientId,tmp);
		    cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
		    while(cnt == -1)
		      {
			printf("Err8: Truncated\n");
			cnt = sprintf(tmp,"%s type=\"%s\"",pSparm->curParamName,pSparm->curParamType);
		      } 
				

		    StartTag(clientId,tmp);
		    strcpy(curCustName,pSparm->curCustParamType);
		  }

		AddValue(clientId,pSparm->curParamValue);
		EndTag(clientId,pSparm->curParamName);
	      
	      }

	    /* Just out of for loop */
	    /* Endtags */
	    if(depth)
	      {
		for(i=depth; i;)
		  {
		    EndTag(clientId,custTypeForClose[--i]);  
		  }
	      }
	      
  	    if(lastRetVal)
  		{
/*	    EndTag(clientId,"return"); */

	    i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_NO_XMLNS);
	    }
	    EndTag(clientId,pRetName);

	  }

      }
    else
      {

	i = BuildMethodRspStr(clientId,tmp,BUILD_METHOD_RSP_STR_WITH_VOID_RSP);
	StartTag(clientId,tmp);

      }

    return; /* End with Envelope and body */
  }


void AddFaultCode(char *fcode)
{
   BSTD_UNUSED(fcode);
}

void AddFaultString(char *fstring)
{
   BSTD_UNUSED(fstring);
}

void GenFault(int clientId)
{
  StartTag(clientId,"Envelope");
  StartTag(clientId,"Body"); 
  StartTag(clientId,"Fault"); 
  StartTag(clientId,"faultcode"); 
  AddValue(clientId, "E:Receive");
  EndTag(clientId,"faultcode");
  StartTag(clientId,"faultstring");   
  AddValue(clientId,"The requested method was not found");
  EndTag(clientId,"faultstring");   
  EndTag(clientId,"Fault"); 
  EndTag(clientId,"Body");
  EndTag(clientId,"Envelope");
}

void GenResp(int clientId)
{

  int rNdx;
  sClientInfo *pClient = client[clientId];
  
  StartTag(clientId,"Envelope");
  StartTag(clientId,"Body");
  
    if(client[clientId]->respList->nItems == 1 ) /*Single value return */
	    SerializeBody(clientId);
	else
	{
	

		for(rNdx = 0; rNdx < pClient->respList->nItems; rNdx++)
			SerializeReturns(clientId, rNdx, ((rNdx == pClient->respList->nItems - 1)? 1:0));

	}
  
  
  EndTag(clientId,"Body");
  EndTag(clientId,"Envelope");
  

}


#define TRANSPORT_HEADER_SIZE 5

int CreateTransportHeader( size_t size, char* pszHeader )
{
	/* Header is always sent big endian */

	pszHeader[0] = STX;

#if BYTEORDER == 1234 || defined(_WIN32)

	pszHeader[4] = (size >>  0) & 0x000000FF;
	pszHeader[3] = (size >>  8) & 0x000000FF;
	pszHeader[2] = (size >> 16) & 0x000000FF;
	pszHeader[1] = (size >> 24) & 0x000000FF;
#else
	pszHeader[1] = (size >>  0) & 0x000000FF;
	pszHeader[2] = (size >>  8) & 0x000000FF;
	pszHeader[3] = (size >> 16) & 0x000000FF;
	pszHeader[4] = (size >> 24) & 0x000000FF;
#endif

	/* return the size of the header */
	return 5;
}

#if (!defined(NON_OS)) || defined(CFG_TCP)
#ifdef CFG_TCP
void SendResp(int s, int clientId)
{
  int i;
  sClientInfo *pClient = client[clientId];  
  char header[TRANSPORT_HEADER_SIZE];
  char *txbuf = (char *)mycalloc((size_t)sizeof(char)*(TRANSPORT_HEADER_SIZE + pClient->rspLen) + 1,1);

  if(txbuf == NULL)	
	  printf("ERROR: SendResp failed mycalloc\n");
  
  CreateTransportHeader((size_t)pClient->rspLen, header);

  for(i=0; i<TRANSPORT_HEADER_SIZE;i++)
      sprintf(&txbuf[i],"%c",header[i]);

  strncpy(&txbuf[TRANSPORT_HEADER_SIZE],pClient->pBufRsp,pClient->rspLen);
  tcp_send(s, txbuf, pClient->rspLen+TRANSPORT_HEADER_SIZE);
  myfree1(txbuf);
}
#else
/*#ifdef NON_OS*/
void SendResp(int clientId)
{
  int i;
  sClientInfo *pClient = client[clientId];  
  
  char header[TRANSPORT_HEADER_SIZE];

  char *txbuf = (char *)mycalloc((size_t)sizeof(char)*(TRANSPORT_HEADER_SIZE + pClient->rspLen) + 1,1);

  if(txbuf == NULL)	
    printf("ERROR: SendResp failed mycalloc\n");
  
  CreateTransportHeader((size_t)pClient->rspLen, header);

 for(i=0; i<TRANSPORT_HEADER_SIZE;i++)
  {
      sprintf(&txbuf[i],"%c",header[i]);
  }


  if(debug)
     printf("RESP< %s\n\n", pClient->pBufRsp);

  strncpy(&txbuf[TRANSPORT_HEADER_SIZE],pClient->pBufRsp,pClient->rspLen);
  
  i = send(pClient->rxSock,txbuf,pClient->rspLen+TRANSPORT_HEADER_SIZE,0); /* No flag same as write */
  
  myfree1(txbuf);
  
}
#endif
#else
void SendSerialResp(int clientId, char *pBufRsp, int rspLen)
{
  int i,cnt;    
  char header[TRANSPORT_HEADER_SIZE];
  char *txbuf;

RebuildResp:
  txbuf  = (char *)mycalloc((size_t)sizeof(char)*(TRANSPORT_HEADER_SIZE + rspLen) + 1,1);

  if(txbuf == NULL)	
    printf("ERROR: SendResp failed mycalloc\n");
  
  CreateTransportHeader((size_t)rspLen, header);
  
  for(i=0; i<TRANSPORT_HEADER_SIZE;i++)
    {
      cnt = sprintf(&txbuf[i],"%c",header[i]);
      
      while(cnt == -1)
	{
	  printf("Err9: Truncated\n");
	  cnt = sprintf(&txbuf[i],"%c",header[i]);
	}       	
    }

  memcpy(&txbuf[TRANSPORT_HEADER_SIZE],pBufRsp,rspLen);

  txbuf[rspLen+TRANSPORT_HEADER_SIZE]='\0';

  cnt = strlen(&txbuf[TRANSPORT_HEADER_SIZE]);
  
  if(cnt != rspLen)
  	{
      	printf("******* MEMCPY error retry\n");
      	printf("RSP STRLN = %d len = %d\n",cnt,rspLen);
  		myfree1(txbuf);
  		goto RebuildResp;
  	}

  i = Write(clientId, txbuf, rspLen+TRANSPORT_HEADER_SIZE);
  
  myfree1(txbuf);
  
}

int Write( int clientId, char *buf, size_t buflen )
{
  register size_t sizeBytesWritten = 0;
  char tmp[4];
  sClientInfo *pClient = client[clientId];
  register volatile unsigned long stat;
  register char *pBuf = buf;
  register size_t blen = buflen;
  int i;
#ifdef USENEWUART
  register volatile unsigned long *pTxStat = &(pClient->m_hUart->sdw_lsr);
  register unsigned char *pTxData = (char *)(&pClient->m_hUart->sdw_rbr_thr_dll);
#else
  register volatile unsigned long *pTxStat = &pClient->m_hUart->txstat;
  register char *pTxData = (char *)(&pClient->m_hUart->txdata);
#endif
  
	
#if 0 /* Maybe this is a bug in the libarary..  */
  printf("Sending rsp len %x str %s\n",buflen,buf);
  printf("resp ");
  for(i = 0; i < blen; i++)
    printf("%c",buf[i]);
  /*	 tmp[0] = buf[i]; */
 
  printf("\n"); 
#endif	
  while ( sizeBytesWritten < blen ) 
    {
      stat = *(pTxStat);

      /* delay loop to fix bug in UART */
      for (i = 0; i < 100; i++);

#ifdef USENEWUART
      if(((stat & THRE) == THRE) && (sizeBytesWritten < buflen))
#else
      if(((stat & TXDREGEMT) == TXDREGEMT) && (sizeBytesWritten < buflen))
#endif
	*(pTxData) = pBuf[sizeBytesWritten++];
    }

  return sizeBytesWritten;
}


void Close(clientId)
{
  sClientInfo *pClient = client[clientId];

  if ( pClient->m_hUart )
    {
#ifndef USENEWUART
      *(&pClient->m_hUart->control) = 0;
      pClient->m_hUart = NULL;
#endif
    }
}

void uartb_printf(char *p)
{
	int i, len;

	len = strlen(p);
	for (i=0; i<len; i++)
	{
		/*uartb_out(*(p+i)); */
	}
}

SRESULT Receive(int clientId, const char **ppszEnvelope, size_t* pSize)
{
  sClientInfo *pClient = client[clientId];
  int i;
  char tmp[1024], input_char;
#ifdef USENEWUART
  volatile unsigned long *statAddr = (unsigned long *)&pClient->m_hUart->sdw_lsr;
#else
  volatile unsigned long *statAddr = &pClient->m_hUart->rxstat;
#endif
  /* Wait for data to be available. */
  unsigned long stat = *statAddr;

		/*while (1)
		{
			input_char = det_in_char();
			printf("%c", input_char);
		}*/


#ifdef USENEWUART
  while ((stat & DR) != DR)
#else
  while ((stat & RXDATARDY) != RXDATARDY)
#endif
    {

#ifdef USENEWUART
    if((stat & DR) != DR)
      break;
#else
      if(stat & 8 == 8)
	printf("OVERFLOW %x\n",stat);
				
      if((stat & RXDATARDY) == RXDATARDY)
	break;
#endif
      stat = *statAddr;
  }

  if ( !ReadHeader( clientId, pSize ) )
    return E_SOAPFAIL;
  
  if ( CLIENT_BUF_SIZE < *pSize )
    client[clientId]->pBuf = ResizeTransportBuffer( client[clientId]->pBuf, *pSize );

  *ppszEnvelope = ReadContent(clientId, *pSize );

  if ( !*ppszEnvelope )
    {
      printf("ERROR: Fail ReadContent\n");
      return E_SOAPFAIL;
    }

  return SOAP_OK;
}

#endif

METHOD_PROP_T *GetNsMethodProp(char *nameSpace, char *mName)
{
  HashTable *pHtbl;
  METHOD_PROP_T *pMprop;

  pHtbl = GetSvcTbl(nameSpace);
  /* Namespace not registered */
  if(pHtbl == NULL)
    {
      printf("ERROR: Namespace %s not registered\n",nameSpace);
      return (METHOD_PROP_T *)-1;
    }
  pMprop = (METHOD_PROP_T *)HashGet(pHtbl, mName);
  
  /* retry */
  if(pMprop == NULL)
    {
      printf("RETRY------ name %s\n",mName);
      pMprop = (METHOD_PROP_T *)HashGet(pHtbl, mName);
    }
  
  /* Service not registered */
  if(pMprop == NULL)
    {
      printf("ERROR: Method name %s not registered\n",mName);	
      return (METHOD_PROP_T *)-1;
    }
    
  return pMprop;

}
#if 0
int GetNsMethodNumParm(char *nameSpace, char *mName)
{
  METHOD_PROP_T *pMprop;
  pMprop = GetNsMethodProp(nameSpace, mName);
  if(pMprop == (METHOD_PROP_T *)-1)
    return -1;

  return pMprop->numParam;
}

char * GetNsMethodRetType(char *nameSpace, char *mName)
{
  METHOD_PROP_T *pMprop;
  pMprop = GetNsMethodProp(nameSpace, mName);

  if(pMprop == (METHOD_PROP_T *)-1)
    return NULL;

  return pMprop->retType;
}

void DoGenResp(int clientId)
{
  sClientInfo *pClient = client[clientId]; 
  LINK_T *link;
  sParam *pSparm;
  int numParm,i;

  numParm = pClient->pMprop->numParam;

  for(i = 0; i < numParm; i++)
    {
      LIST_T *list = pClient->parmList->item[i];

      for (link = list->head; link != NULL; link = link->next)
	{
	sParam *pResp;
	LINK_T *linkEnt;
	LIST_T *list;
	  pSparm = (sParam *)GetDataFromLink(link);

	  pResp = (sParam *)mycalloc((size_t)sizeof(sParam),1);
	  
	  if(pResp == NULL)
	  	printf("ERROR: DoGenResp failed allocation\n");

	  memcpy(pResp,pSparm,sizeof(sParam));

	  linkEnt = CreateLinkEnt(pResp);

	  list = pClient->respList->item[0];

	  AddLinkToTail(list,linkEnt);

	  /*	  DumpParamList(list); */
	}
    }

}

#endif
#if 0
void DisplayParam(sParam *pSparm)
{

  printf("curParamType = %s\n",pSparm->curParamType);
  printf("curParamName = %s\n",pSparm->curParamName);
  printf("curParamValue = %s\n",pSparm->curParamValue);
  printf("curCustParamType = %s\n",pSparm->curCustParamType);
  printf("arraySize       = %d\n",pSparm->arraySize);
#if 0
  printf("customTypeStart = %d\n",pSparm->customTypeStart);
  printf("nCustParamRcv   = %d\n",pSparm->nCustParamRcv);
  printf("nCustParmMemCnt = %d\n",pSparm->nCustParmMemCnt);
  printf("nCustParmDepth  = %d\n",pSparm->nCustParmDepth);
  printf("arrayTypeStart  = %d\n",pSparm->arrayTypeStart);
  printf("arrayElmRcv     = %d\n",pSparm->arrayElmRcv);
  printf("nParamRcv       = %d\n",pSparm->nParamRcv);
#endif
}


void DumpParamList( LIST_T *list)
{
  LINK_T *link;
  sParam *pSparm;

  printf("----------------- START Dumping param list ------------\n");
  for (link = list->head; link != NULL; link = link->next)
    {
      pSparm = (sParam *)GetDataFromLink(link);
      DisplayParam(pSparm);
      printf("            ++++++++++             \n");
    }
  printf("----------------- END Dumping param list ------------\n");
}

#endif
/*#ifndef NON_OS*/
#if (!defined(NON_OS)) || defined(CFG_TCP)

#ifdef CFG_TCP
void ProcessRxData(int s, int clientId, char *pszEnvelope, int sizeReq)
{
	  int parseStat;

	  *(pszEnvelope +sizeReq) = '\0';
	  parseStat = xmlParse(clientId, (char *)pszEnvelope, sizeReq);
	  if(parseStat != -1)
	  {
	      (*(client[clientId]->func))(clientId);
	      GenResp(clientId);
	  }
	  else
		  GenFault(clientId);

	  SendResp(s, clientId);
	  ResetClient(clientId);
}

void Run(SOCKET socket)
{
    int connflag, s, res, clientId;
    int quiet = 1; 
    int discard = 0;
    int nodelay = 1;
    int rxdata;
    uint8_t data[20];
    uint16_t remport;
    uint8_t remaddr[IP_ADDR_LEN];
	char* pszEnvelope;
	size_t sizeReq;
	s = socket;

    for (;;) 
	{

		connflag = false;
		for (;;) 
		{
			if (console_status()) break;
			tcp_status(s,&connflag,NULL,NULL);
			if (connflag == TCPSTATUS_CONNECTED) break;
			POLL();
		}

		if (connflag != TCPSTATUS_CONNECTED) 
		{
			printf("Error, no connection received from remote host\n");
			tcp_close(s);
			return;
		}

		tcp_peeraddr(s,remaddr,&remport);
		clientId = ServerAddConn(s);

		if (nodelay) 
			tcp_setflags(s, TCPFLG_NODELAY);

		connflag = true;
		for (;;) 
		{
			if (Receive(clientId, (const char** )&pszEnvelope, &sizeReq ) == SOAP_OK)
				ProcessRxData(s, clientId, pszEnvelope, sizeReq);
			if (client[clientId]->status == 2)
			{
				ResetClient(clientId);
				FreeClient(clientId);
				tcp_close(s);
				
				s = tcp_socket();
				if (s < 0) 
				{
					printf("Error, could not create socket");
					break;
				}
				res = tcp_listen(s, 1600);
				if (res < 0) 
				{
					printf("Error, could not listen");
					tcp_close(s);
				}
				break;
			}
		}
	}
}

#else
void Run(SOCKET socket)
{
  fd_set rxSet;
  fd_set wkSet;
  int    i,mFd,cSock,lenInet,n,clientId,parseStat;
  struct timeval tv;
  struct sockaddr_in adrClnt;
  char*  pszEnvelope;
  size_t sizeReq;
  int done;

  FD_ZERO(&rxSet);
  FD_SET(socket, &rxSet);
  
  mFd = socket + 1;


  for(;;)
  {
      FD_ZERO(&wkSet);

      /* Get a snapshot */
      for(i = 0; i < mFd; ++i)
      {
          if(FD_ISSET(i, &rxSet))
              FD_SET(i,&wkSet);
      }

#ifdef WIN32
      tv.tv_sec = 10;
      tv.tv_usec = 0;
#else
      tv.tv_sec = 0;
      tv.tv_usec = 0;
#endif

      /* Change last parameter to NULL so that it would block */
      n = select(mFd, &wkSet, NULL, NULL, NULL);

      if(n == -1)
      {
          printf("ERROR: %s \n",strerror(errno));	  
          SockError("Select");
          exit(1);
      }
      else if (!n)
      {
#ifdef SIM
          wait_sim_cycles();
#endif
          continue; /* TIMEOUT */
      }


      /* OK now */
      if(FD_ISSET(socket, &wkSet))
      {

          lenInet = sizeof adrClnt;

          cSock = accept(socket, (struct sockaddr *)&adrClnt, (unsigned int *)&lenInet);



          if(cSock == -1)
              SockError("Accept failed");
 
          /*Add connected client to the client table*/

          clientId = ServerAddConn(cSock);

          if(cSock > 50)
              printf("Warning, sockets exceeding 50 count...\n");

          if ( clientId == -1)
          {
              /* Too many clients; close and continue */
#ifdef WIN32
              closesocket(cSock);
#else
              close(cSock);
              while(1);
#endif
              continue;
          }

          /* new mFd for next snapshot */
          if(cSock + 1 > mFd)
          {
              mFd = cSock + 1;
          }

          /* register connected socket in the rxSet */
          FD_SET(cSock,&rxSet);

      }
      else
      {
      }
      /* Processing each client */
      for(clientId = 0,done=0; clientId < MAX_CLIENTS && !done; ++clientId)
      {
          if(client[clientId] == NULL)
          {
              continue;
          }

          /*Don't process listening socket */
          if(client[clientId]->rxSock == socket)
          {
              continue;
          }

          if(FD_ISSET(client[clientId]->rxSock,&wkSet))
          { 

              if (Receive(clientId, (const char** )&pszEnvelope, &sizeReq ) == SOAP_OK)
              {
                  /* Assume the client keep the connection open if everything is OK */

                  parseStat = xmlParse(clientId, (char *)pszEnvelope, sizeReq);

                  if(parseStat != -1)
                  {

                      (*(client[clientId]->func))(clientId);
                      GenResp(clientId);
                  }
                  else
                      GenFault(clientId);

                  SendResp(clientId);


                  ResetClient(clientId);

#if 0

                  /*Wait for current client disconnection */
                  while(1)
                  {
                      bytes = recv(client[clientId]->rxSock, &c, 1, 0);
                      if ((bytes == 0) || (bytes == (int)SOCKET_ERROR))
                          break;
                  }

                  ResetClient(clientId);
                  FreeClient(clientId);
                  /* Client request disconnect */

                  /* Close the connected socket and leave the listening one alone */
                  FD_CLR(cSock,&rxSet);

#ifdef WIN32
                  closesocket(cSock);
#else
                  close(cSock);
#endif

#endif
                  continue;
              }
              else if(client[clientId]->status == 2)
              {
                  /* Client request disconnect */
                  /* Close the connected socket and leave the listening one alone */
                  FD_CLR(client[clientId]->rxSock,&rxSet);

#ifdef WIN32
                  closesocket(client[clientId]->rxSock);
#else
                  close(client[clientId]->rxSock);
#endif

                  ResetClient(clientId);
                  FreeClient(clientId);

                  /*InitClientTbl(); */
                  break;
              }
              else
                  exit(1);
          }
          else
          {
          }
      }

  }

    }
#endif

#else
/* only allow on client */
void Run(SOCKET socket)
{
  int clientId,parseStat,runCnt=0,rspLen;
  char*  pszEnvelope;
  char *tmpBuf;
  size_t sizeReq;
   
  clientId = ServerAddConn(socket);

  for(;;)
    {

	    if (Receive(clientId, (const char** )&pszEnvelope, &sizeReq ) == SOAP_OK)
		{
		  /* Assume the client keep the connection open if everything is OK */
		  parseStat = xmlParse(clientId, (char *)pszEnvelope, sizeReq);
		  if(parseStat != -1)
		    {
  		       (*(client[clientId]->func))(clientId);
 
		      GenResp(clientId);
		    }
		  else
		  {
		    GenFault(clientId);
		    }
		    
#if 1
		    tmpBuf = (char *)mycalloc((size_t)sizeof(char)*client[clientId]->rspLen+1,1);

		    if(tmpBuf == NULL)
		    	printf("ERROR: Fail alloc\n");
	
		    rspLen = client[clientId]->rspLen;
	  	  memcpy(tmpBuf,client[clientId]->pBufRsp, rspLen);
	  	  ResetClient(clientId);

		  SendSerialResp(clientId,tmpBuf,rspLen);

	      myfree1(tmpBuf);
#else
		  SendSerialResp(clientId,client[clientId]->pBufRsp,client[clientId]->rspLen);
		  ResetClient(clientId);
#endif	      
	      
		  continue;
		}
	      else if(client[clientId]->status == 2)
		{
		  FreeClient(clientId);
		}
	      else
			exit(1);
	    }
	}

#endif


SRESULT Open( const char* pszUri, SOCKET *pSocket )
{

#ifndef NON_OS
  int nPort = 0,n=1;

  struct sockaddr_in addr;

  if (!GetTcpPort( pszUri, &nPort))
    return E_SOAPFAIL;


  if ((*pSocket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    SockError("socket");

  addr.sin_family = AF_INET;		/* host byte order */
  addr.sin_port = htons(nPort);		/* short, network byte order */
  addr.sin_addr.s_addr = INADDR_ANY;

  memset(&addr.sin_zero, 0, 8);		/* zero the rest of the struct */

  if (setsockopt(*pSocket, SOL_SOCKET, SO_REUSEADDR, (char*)&n, sizeof(n)) == -1)
    SockError("setsockopt");

  if (bind(*pSocket, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1)
    SockError("bind");

  if (listen(*pSocket, 1 ) == -1)
    SockError("listen");

#else

#ifdef CFG_TCP
  int nPort = 0, s, res;

  SoapIfConfig();

  if (!GetTcpPort( pszUri, &nPort))
    return E_SOAPFAIL;

  s = tcp_socket();
  *pSocket = s;

  if (s < 0) 
  {
	printf("Error, could not create socket");
    return E_SOAPFAIL;
  }

  res = tcp_listen(s, nPort);
  if (res < 0) 
  {
	printf("Error, could not listen");
	tcp_close(s);
    return E_SOAPFAIL;
  }
#endif

#endif    

  return SOAP_OK;
}

#if (!defined(NON_OS)) || defined(CFG_TCP)

#ifdef CFG_TCP
SRESULT Receive( int clientId, const char** ppszEnvelope, size_t *pSize )
{
	int i;

	if ( !ReadHeader( clientId, pSize ) )
		return E_SOAPFAIL;
	if ( CLIENT_BUF_SIZE < *pSize )
		client[clientId]->pBuf = ResizeTransportBuffer( client[clientId]->pBuf, *pSize );
	*ppszEnvelope = ReadContent( clientId, *pSize );

	return ( *ppszEnvelope ) ? SOAP_OK : E_SOAPFAIL;
 }

size_t Read( int clientId, char *buf, size_t buflen )
{
    int connflag, rxdata, res, i, j, c = 0;
	register size_t sizeBytesRead = 0;
	char tmp[4*4096];
	int s = client[clientId]->rxSock;
	int bytes = 0;

	if ( buflen == 0 )
		return bytes;
	
	*buf = 0;
	connflag = true;
	rxdata = 0;
	while ( sizeBytesRead < buflen ) 
	{
		tcp_status(s,&connflag,&rxdata,NULL);
		if (connflag != TCPSTATUS_CONNECTED) 
		{
			client[clientId]->status = 2;
			POLL();
			return 0;
		}

		if (rxdata != 0) 
		{
			res = tcp_recv(s, tmp, buflen);
			if (res > 0) 
			{
				sizeBytesRead += res;
				for (i=0, j=0; i<res; i++, j++)
				{
					buf[c+j] = tmp[i];
				}
				c += res;
			}
			else if (res < 0) 
			{
				printf("TCP read error\n");
				POLL();
				return 0;
			}
			else
			{
				POLL();
				return 0;
			}
		}
		else
		{
			POLL();
			return 0;
		}
	}

	return sizeBytesRead;
}
#else
void SockError(char *msg)
  {
    printf("%s\n",msg);
    exit(1);
  }

SRESULT Receive( int clientId, const char** ppszEnvelope, size_t *pSize )
{
	if ( !ReadHeader( clientId, pSize ) )
		return E_SOAPFAIL;
	if ( CLIENT_BUF_SIZE < *pSize )
		client[clientId]->pBuf = ResizeTransportBuffer( client[clientId]->pBuf, *pSize );
	*ppszEnvelope = ReadContent( clientId, *pSize );
    
	return ( *ppszEnvelope ) ? SOAP_OK : E_SOAPFAIL;
 }

size_t Read( int clientId, char *buf, size_t buflen )
{
	int bytes = 0;
	if ( buflen == 0 )
		return bytes;

	*buf = 0;
	/* recv with flag == 0 is the same as read. But Window does not support */
	/* read(); */
    bytes = recv(client[clientId]->rxSock, buf, buflen, 0);
    
	if(bytes >= 0)
		buf[bytes] = 0;

	if ((bytes == 0) || (bytes == (int)SOCKET_ERROR))
	{
	  /* other side dropped the connection */
	  client[clientId]->status = 2;
	  return 0;
	}
	
	return bytes;
}
#endif

#else 
size_t Read( int clientId, char *buf, size_t buflen )
{
	register size_t sizeBytesRead = 0;
	unsigned long cnt = 0;
	sClientInfo *pClient = client[clientId];
#ifdef USENEWUART
	register unsigned long *pRxStat = (unsigned long *)&pClient->m_hUart->sdw_lsr;
	register unsigned char *pRxData = (char *)&pClient->m_hUart->sdw_rbr_thr_dll;
	int i;
	unsigned long stat = *pRxStat;
#else
	register char *pRxStat = (char *)&pClient->m_hUart->rxstat;
	register char *pRxData = (char *)&pClient->m_hUart->rxdata;
	int i;
	register volatile char	stat;
#endif
	
	stat = *(pRxStat);
	
	while ( sizeBytesRead < buflen ) 
	{

#ifdef USENEWUART
		while ((stat & DR) != DR)
#else
		while((stat & RXDATARDY) != RXDATARDY)
#endif
	    {

#ifdef USENEWUART
			if(stat == 0xF)
#else
			if(stat == 0xc)
#endif			
				goto read_err;

		    stat = *(pRxStat);
	    }
	    
#ifdef USENEWUART
		while(((stat & DR) == DR) && (sizeBytesRead < buflen))
#else		
		while(((stat & RXDATARDY) == RXDATARDY) && (sizeBytesRead < buflen))
#endif		
		{
			buf[sizeBytesRead++] = *(pRxData);
  		    stat = *(pRxStat);
/*			for(i=0; i<100; i++);
			uartb_out(buf[sizeBytesRead-1]); */
		}
		

	}

	return sizeBytesRead;
	
read_err:
	printf("ERROR: Read fail stat %x cnt %d\n",stat,cnt);
    return 0;	
}
#endif

int ReadHeader( int clientId, size_t* psizeEnv ) 
{
	size_t sizeReceived;
	char c[2], cToken;
        unsigned char recvBuf[5];
	int i;
	
	cToken = STX;

	while ( true )
	{
		sizeReceived = Read( clientId, c, 1 );
		if ( sizeReceived != 1 )
		  {
			break; /* disconnected */
		  }

#if BYTEORDER == 1234 || defined(_WIN32)

        if ( c[0] == cToken )
        {
            for ( i=0;i<4;i++ )
            {
		        sizeReceived = Read( clientId, (char*)&recvBuf[i], 1 );
		        if ( sizeReceived != 1 )
			  {
			    while(1);
			        sizeReceived = 0; /* disconnected */
			  }
            }

            *psizeEnv = (recvBuf[0] << 24);
            *psizeEnv |= (recvBuf[1] << 16);
            *psizeEnv |= (recvBuf[2] << 8);
            *psizeEnv |= recvBuf[3];
            break;
        }
        else
         printf("First read not STX %x\n",cToken);
#else
        if ( c[0] == cToken )
        {
                char tmpStr[5];
	        sizeReceived = Read( clientId, (char*)tmpStr, 4 );
	        if ( sizeReceived != 4 )
		        sizeReceived = 0; /* disconnected */

		*psizeEnv=(size_t)strtol(tmpStr,NULL,10);
	        break;
        }
#endif
    }

	return ( sizeReceived > 0 ) ? true : false;
}

char* ReadContent( int clientId, size_t size )
{
	size_t sizeTotalReceived=0;
	size_t sizeReceived;
	while ( sizeTotalReceived < size )
	{
		sizeReceived = Read( clientId, (char *)(client[clientId]->pBuf + sizeTotalReceived), size-sizeTotalReceived );
		if ( sizeReceived == 0 )
		{
			printf("Error, detected NULL\n");
			return NULL; /* disconnected */
		}
		sizeTotalReceived+=sizeReceived;
	}
	if(debug)
		printf("REQ > %s\n", client[clientId]->pBuf);

	*(client[clientId]->pBuf + sizeTotalReceived) = '\0';

	return client[clientId]->pBuf;
}

char* ResizeTransportBuffer( char* pszBuffer, size_t sizeNew )
{
	if ( pszBuffer )
           myfree1(pszBuffer);

	pszBuffer = (char *)mycalloc((size_t)sizeNew+1,1);
	
	if(pszBuffer == NULL)
	{
		printf("ERROR: ResizeTransportBuffer fail mycalloc byte count = %d\n",sizeNew+1);
		
	}

	return pszBuffer;
}

/*#ifndef NON_OS  */
#if (!defined(NON_OS)) || defined(CFG_TCP)
int GetTcpPort( const char* pszURI, int* pnPort )
{
  char szPort[32];
  int nLen, nMaxLen=31;

  /* Check for the correct protocol */
  char* pColon = strstr( pszURI, ":" );
  char* pStart = pColon + 1;
  char* pEnd = (char*)pszURI + _strlen(pszURI);

  if ( !pColon )
    return false; /* Invalid URI */

  if ( pStart < pEnd )
    {
      nLen = MIN( (pEnd - pStart), nMaxLen );
      _strncpy( szPort, pStart, nLen );
      szPort[nLen] = 0;
    }

  *pnPort = _strtol(szPort);

  return true;
}

#endif

SOCKET ServerAddConn(SOCKET cSock)
{
  	int nc = ServerFindNewConn();
  				
	if (nc<0)
		return nc;

	CreateClient(nc);

	client[nc]->rxSock = cSock;


	return nc;
}


int ServerFindNewConn(void)
{
	int i;

	for(i=0; i<MAX_CLIENTS; i++)
		if (client[i] == NULL) return i;

	return -1;
}



/* Caller to this function:
   1. had read XML file content and written content to char* xmlBuffer.
   2. a. call xmlParse to do verification of XML content OR 
      b. to do conversion of XML content to PSI database.
   3. a. after calling for (2a), caller flashes text file to flash, and reboot modem.
      b. caller runs with new PSI as normal.

   Input to xmlParse: xmlBuffer containing XML data.
                      xmlSize is size of xmlBuffer.
                      verify = 1, this is operation (2a); otherwise, this is (2b).
   Output: SUCCESS or FAILURE of parsing status.
*/
int xmlParse(int clientId, char *xmlBuffer, int xmlSize) 
{   
  int parseStat=0;

  nxml_settings settings;

  settings.tag_begin = xmlTagBegin;
  settings.attribute_begin = xmlAttrBegin;
  settings.attribute_value = xmlAttrValue;
  settings.data = xmlData;
  settings.tag_end = xmlTagEnd;

  /* open parser */
  if(client[clientId]->handle == NULL)
    nxml_open(clientId, &client[clientId]->handle,&settings);

  if (&client[clientId]->handle == NULL) {

    printf("xmlParse(): error register nxml parser.\n");
    return 1;
  }

#if 0
  { int i;
  printf("xmlBuffer:\n");
  for (i=0; i<xmlSize; i++) {
    printf("%c",xmlBuffer[i]);
  }
  }
#endif

  /* nxml_write returns 0, that means it's done or there's something wrong */
  parseStat = nxml_write(client[clientId]->handle, xmlBuffer, xmlSize);

#if 0
  if (parseStat == 0)
   {
     printf("Done with the current parse\n");
   }
#endif
     /* close parser */
  nxml_close(client[clientId]->handle);

  client[clientId]->handle = NULL;

  return parseStat;
}

/* when xmlTagBegin is called,
   1. tag_name = a) appID name b) objectId name
   2. action needed:
   determine if this is an appId or objectId or nothing
   if (appId)  
      a) check to see if App exists; if no, return and continue
      b) if (verify), return and continue; else do appOpen
*/
void xmlTagBegin(nxml_t handle, const char *tag_name, unsigned len)
{
  char *array, *s;
  int clientId;
  sClientInfo *pClient;
  
  array = (char *)mycalloc((size_t)sizeof(char)*(len + 1),1);
  
  if(array == NULL)
    printf("ERROR: xmlTagBegin fail mycalloc\n");

#ifdef SHOW_TAG
  printf("\nxmlTagBegin(tagname %s tagLen %d, handle->state %d)",
	 tag_name, len,handle->state);
#endif
	
  strncpy(array,tag_name,len);
  array[len] = '\0';

  /* Get clientId */
  clientId = handle->clientId;

  pClient = client[clientId];

  /* Update state */
  pClient->CurState = pClient->NxtState ;

  /*  printf("\n 1 current state = %s\n",stateName[pClient->CurState]); */

  switch(pClient->CurState)
    {
    case   WAIT_FOR_ENVELOPE:
      {
	if(strncmp(array,"Envelope",len) == 0)
	  {
	    /*	    printf("\nGet Envelope"); */
	    pClient->NxtState = WAIT_FOR_BODY;
	  }
	else
	  printf("ERROR: ILLEGAL STATE TRANSITION\n");
      }
      break;
    case   WAIT_FOR_BODY:
      {
	if(strncmp(array,"Body",len) == 0)
	  {
	    pClient->NxtState = WAIT_FOR_METHOD_NAME;
	  }
	else
	  printf("ERROR: ILLEGAL STATE TRANSITION\n");
      }
      break;
    case    WAIT_FOR_METHOD_NAME:
      {
	s = (char *)strpbrk(array,":");

	if(s)
	  {

	    strcpy((char *)(pClient->curMethodName),&array[s-array+1]);
	    strncpy((char *)(pClient->prefix),array,s-array);
	    pClient->prefix[s-array] = '\0';




	    pClient->NxtState = WAIT_FOR_XMLNS; /* see attribute */

	  }
      }
      break;
    case WAIT_FOR_PARAM:
      strcpy(pClient->curParamName[pClient->nCustParmDepth], array);
      break;
    case WAIT_FOR_PARAM_VALUE_CUSTOM:
      if(pClient->customTypeStart[pClient->nCustParmDepth])
	strcpy(pClient->curParamName[pClient->nCustParmDepth], array);

      pClient->NxtState =  WAIT_FOR_PARAM;

      /*      printf("Get CUSTOM data type\n"); */
      break;    
    default:
      {
    	/* It's OK for uinitialize array element */
	if(pClient->nilArrElm == 0)  
	  printf("Should not be here\n");
	else
	  {
	    if((pClient->arrayTypeStart == 1) &&
	       (pClient->customTypeStart[pClient->nCustParamRcv[pClient->nCustParmDepth]] != 1))
	      {
		pClient->arrayElmRcv++;
		if(pClient->arraySize  == pClient->arrayElmRcv)
		  {
		    pClient->nParamRcv++; /* Bump up the parameter received by one */

		    if(pClient->nParamRcv == pClient->pMprop->numParam)
		      {
			pClient->NxtState =  WAIT_FOR_ENVELOPE; 
			printf("DONE going back to wait for new envelope\n");
		      }
		    else
		      pClient->NxtState =  WAIT_FOR_PARAM;		   
					
		    pClient->arrayTypeStart = 0;
		  }
	      }
	  }
		
	pClient->NxtState =  WAIT_FOR_PARAM;
      }
         
    }

  myfree1(array);
}


/* when xmlTagEnd is called,
   1. signals end of  a) app (handle->state == state_end_tag_name), tagName is name of appId
                      b) object (handle->state is state_attr_name), tagName is invalid, len = 0
   2. action needed:
      if (end of app), move internal state to state_app_begin.
      if (end of object), do 2nd phase verification to make sure the whole object configuration
         is set.   If mandatory field is missing, log error and return fatal right away. Otherwise,
         if (!verify), call CFM's objStore for this object.
*/
void xmlTagEnd(nxml_t handle, const char *tag_name, unsigned len)
{

#if 0
  printf("\n**xmlTagEnd(): len %d\n",len);
#endif

  sClientInfo *pClient = client[handle->clientId];

  if (len != 0) {
    /* end of app or end of table */
    if(!strcmp(tag_name,"Envelope>"))
      {
	/* Update state */

	pClient->endDoc   = 1;

	pClient->NxtState = WAIT_FOR_ENVELOPE ;

		/*ShowClientInfo(handle->clientId, pClient->nCustParmDepth); */
		/*DumpClientInfo(handle->clientId); */

	
      }
  }
}

/* when xmlAttrBegin is called,
   a) object field name is received; save this name, expect value to be return next.
      Action: change internal state to state_attribute_value?
*/
void xmlAttrBegin(nxml_t handle, const char *tag_name, unsigned len)
{
  char *array;
  sClientInfo *pClient;
  
  array = (char *)mycalloc((size_t)sizeof(char)*(len+1),1);
  
  if(array == NULL)
  	printf("ERROR: xmlAttrBegin fail mycalloc\n");

#ifdef SHOW_TAG
 printf("\nxmlAttrBegin():attrName %s, len %d\n",tag_name,len);
#endif
 
  strncpy(array,tag_name,len);
  array[len] = '\0';

  /* Get clientId */

  pClient = client[handle->clientId];
  /* Update state */

  pClient->CurState = pClient->NxtState ;


  switch(pClient->CurState)
    {
    case WAIT_FOR_XMLNS:
      {
	pClient->NxtState =  WAIT_FOR_NAMESPACE;
      }
    break;
    case WAIT_FOR_PARAM:
      {
	/*Should be type here*/
	/*	printf("MUST see (type = type) type = %s\n",array); */
	  if(!strcmp("nil",array))
	  {
	   /* printf("TYPE = NIL\n"); */
	    pClient->nilArrElm = 1;  
	  }

	pClient->NxtState =  WAIT_FOR_PARAM_TYPE;
	
	
      }
      break;
    case WAIT_FOR_ARRAY_SIZE:
      /* Next transition should be attvalue */

       pClient->NxtState   =  WAIT_FOR_ARRAY_SIZE;
      break;

    default:
      printf("Should not be here\n");
    }
    
    myfree1(array);
}

/* when xmlAttrValue is called,
   a) object field value is received; do atomic set for objName, attrName.
      Action: change internal state to ?
*/
void xmlAttrValue(nxml_t handle, const char *tag_name, unsigned len)
{
  char* attrValue;
  int  i,j,numParm,depth;
  char *s,*e;

  sClientInfo *pClient = client[handle->clientId];
  
  attrValue = (char *)mycalloc((size_t)sizeof(char)*(len+1),1);
  
  if(attrValue == NULL)
  	printf("ERROR: xmlAttrValue fail mycalloc\n");

#ifdef SHOW_TAG

  printf("\nxmlAttrValue() value %s len %d\n", tag_name, len); 
#endif

  /* name contains attribute name of objectId i.d. vpi="0", name is vpi */

  strncpy(attrValue,tag_name,len);
  
  attrValue[len] = '\0';

  depth = pClient->nCustParmDepth;


  /* Update state */
  pClient->CurState = pClient->NxtState ;

  switch(pClient->CurState)
    {
    case WAIT_FOR_NAMESPACE:
      {

	strcpy(pClient->curNameSpace,attrValue);

	/*AT this point should have both namespace and method name*/
	/*Get method property pointer*/
	pClient->pMprop = GetNsMethodProp(pClient->curNameSpace, pClient->curMethodName);

	numParm = (pClient->pMprop != (METHOD_PROP_T *)-1 )?pClient->pMprop->numParam: -1;

	if(numParm != -1)
	  { 
	    if (!numParm)
	      pClient->NxtState =  WAIT_FOR_ENVELOPE;
	    else
	      pClient->NxtState =  WAIT_FOR_PARAM;

	    /*Init function pointer*/
	    pClient->func = pClient->pMprop->func;

	  }
	else
	  {
	    /* This is the first time we have bot method name and namespace */
	    printf("ERROR: Method %s not registered in namespace %s\n",pClient->curMethodName, pClient->curNameSpace);
        printf("\nxmlAttrValue() value %s len %d\n", attrValue, len); 

	    /* Set error to force nanoxml to exit */
	    pClient->handle->error = 1;
	  }

      }
      break;
    case WAIT_FOR_PARAM_TYPE:
      {
      int custType = IsCustomType(attrValue);
	int curParmRxDepth = pClient->nCustParamRcv[depth];
#if 0

	printf("DEPTH = %d, current depth %d\n",depth,curParmRxDepth);
	/*Parameter value*/
	if(pClient->customTypeStart[curParmRxDepth] == 1)
	  printf("Custom Parameter %d type %s\n",curParmRxDepth, attrValue);
	else
	  printf("Parameter %d type %s\n",pClient->nParamRcv, attrValue);
#endif
	/* if custome type has not started at the current depth yet then check for it */
	/* if it is a custom type then the next call will be to tagbegin */
	/* at that point the collection process stay the same as the non-custom one */

	if(pClient->customTypeStart[curParmRxDepth] == 0)
	  {
	    if (custType)
	      {
		strcpy(pClient->curCustParamType[depth],attrValue);

		pClient->customTypeStart[curParmRxDepth] = 1; /* Custom data type */

		/* Next callback is the begintag */
		pClient->NxtState   =  WAIT_FOR_PARAM_VALUE_CUSTOM;
	      }
	    else
	      {

		strcpy(pClient->curParamType[depth],attrValue);

		/*Check for array type and collect it size */
		if(!strcmp(attrValue,"Array"))
		  pClient->NxtState   =  WAIT_FOR_ARRAY_SIZE;
		else
		  pClient->NxtState   =  WAIT_FOR_PARAM_VALUE; /* Regular non-custom type */
	      }
		
	  }
	else
	  {
	    /*For nested custom data type */
	    int custType = IsCustomType(attrValue);
	    if (custType)
	      {
		pClient->nCustParmDepth++;
		depth = pClient->nCustParmDepth;

		strcpy(pClient->curCustParamType[depth],attrValue);
		pClient->customTypeStart[depth] = 1; /* Custom data types */
		pClient->NxtState   =  WAIT_FOR_PARAM_VALUE_CUSTOM;
	      }
	    else
	      {
		strcpy(pClient->curParamType[depth],attrValue);
		pClient->NxtState   =  WAIT_FOR_PARAM_VALUE; /* Custom data type started */
	      }
	  }

      }
      break;
    case WAIT_FOR_ARRAY_SIZE:
      {
	/*Check for array type and collect it size */
	{
	  /* Get array dimension... This must be change if we decide to support SOAP 1.2 */
	  /* Ignore get array size.. assum that it is arrayType="anyType[10]" */

	  s = (char *)strpbrk(tag_name,"[");
	  e = (char *)strstr( tag_name, "]" );	/* Make sure parameter value is bounded */
		  
	  for(i=1,j=0; i <e-s;i++,j++)
	    sprintf(((char *)attrValue)+j,"%c",*(s+i));

	  attrValue[i] = '\0';
		   
	  pClient->arraySize = atoi(attrValue);
	  strcpy(pClient->arraySizeStr,attrValue);

	  pClient->arrayTypeStart = 1;

		  
	}

	pClient->NxtState =  WAIT_FOR_PARAM;
      }
      break;
    default:
      printf("ERROR: ILLEGAL STATE TRANSITION\n");          

    }
    
    myfree1(attrValue);

}



void xmlData(nxml_t handle, const char *tag_name, unsigned len)
{
  char* pEnd; 
  int   clientId, dLen,depth; 
  int   numParm;
  char* pdata;

  CUSTOM_DTYPE_INFO_T *pCustTinfo;

  sClientInfo *pClient = client[handle->clientId];

  BSTD_UNUSED(len);

  clientId = handle->clientId;

  /* Update state */
  pClient->CurState = pClient->NxtState ;


  depth = pClient->nCustParmDepth;

  switch(pClient->CurState)
    {

    case WAIT_FOR_PARAM_VALUE:
      {
	int curParmRxDepth = pClient->nCustParamRcv[depth];

	/* Make sure parameter value is bounded */
	pEnd = strstr( tag_name, "<" );/* End on the ending of current tag-- assumed well-formed  */
	dLen = pEnd - tag_name;

	pdata = (char *) mycalloc((size_t)dLen+1,1);

	if(pdata == NULL)
	  {
	    printf("ERROR: FAILED alloc\n");
	  }
	strncpy(pdata,tag_name,dLen);
	pdata[dLen] = '\0';


	if(dLen + 1 > MAX_PARAMETER_TYPE_LEN)
	{
		/*Resize */
		pClient->curParamValue[curParmRxDepth] = ResizeTransportBuffer( pClient->curParamValue[curParmRxDepth], dLen );

	}


	/* Working on a regular array of non custom element  */
	if((pClient->arrayTypeStart == 1) &&
	   (pClient->customTypeStart[curParmRxDepth] != 1))
	  {
	    /* Array type started but all element has not been collected */
	    if(pClient->nilArrElm == 0 )
	      {
		numParm = pClient->pMprop->numParam;
		/*Check to see if we're done collecting */
		strcpy(pClient->curParamValue[curParmRxDepth],pdata);
		pClient->arrayElmRcv++;
		myfree1(pdata);
		if(numParm != -1)
		  {
		    if(pClient->arraySize  == pClient->arrayElmRcv)
		      {
			/* Take a snapshot */
			AddParam(clientId);
			pClient->nParamRcv++; /* Bump up the parameter received by one */
			numParm = pClient->pMprop->numParam;

			if(pClient->nParamRcv == numParm)
			    pClient->NxtState =  WAIT_FOR_ENVELOPE; 
			else
			    pClient->NxtState =  WAIT_FOR_PARAM;
		    
			pClient->arrayTypeStart = 0;
		      }			
		    else
		      {
			/* Take a snapshot */
			AddParam(clientId);
			pClient->NxtState =  WAIT_FOR_PARAM;
		      }
		  }
		else
		  {
		    printf("2. ERROR: Method %s not registered\n",pClient->curMethodName);
		    exit(1);
		  }
	      }
	    else
	      {
		pClient->arrayElmRcv++;

	      }
	  }

	/* Working array of custom type */
	else if((pClient->arrayTypeStart == 1) &&
		(pClient->customTypeStart[curParmRxDepth] == 1))
	  {
	    /* Custom type started but all member has not been collected */

	    pCustTinfo = GetCustParamInfo(pClient->curCustParamType[depth]);

	    strcpy(pClient->curParamValue[depth],pdata);

	    ++pClient->nCustParmMemCnt[depth];	


	    myfree1(pdata);

	    if(strcmp(pCustTinfo->mName[pClient->nCustParmMemCnt[depth]],""))
	      {
		pClient->NxtState   =  WAIT_FOR_PARAM;

		/*		pClient->arrayElmRcv++; */
		AddParam(clientId);

	      }
	    else
	      {
		/* Hit the end of custom type */

		pClient->nCustParamRcv[depth]++;   /* Count one custom */
	        pClient->nCustParamRcv[depth] = 0;  /* For an array type need to clear this count per array entry */

		/*		numParm = GetNsMethodNumParm(pClient->curNameSpace,pClient->curMethodName); */
		numParm = pClient->pMprop->numParam;

		if(numParm != -1)
		  {	
		    if(pClient->nParamRcv == numParm)
		      {
			pClient->NxtState =  WAIT_FOR_ENVELOPE; 
		      }
		    else
		      pClient->NxtState =  WAIT_FOR_PARAM;

		  }
		else
		  {
		    printf("ERROR: Method %s not registered\n",pClient->curMethodName);
		    exit(1);
		  }

		pClient->arrayElmRcv++;

		AddParam(clientId);

		if(pClient->arraySize == pClient->arrayElmRcv)
		  {
		    pClient->nParamRcv++; /* Bump up the parameter received by one */

		  }

	        pClient->nCustParamRcv[depth] = 0;  /* For an array type need to clear this count per array entry */
		pClient->nCustParmMemCnt[depth] = 0; /* Reset member count */
		/*pClient->customTypeStart[pClient->nCustParamRcv[depth]] = 0; End */



		/*Count only the top level of the nested is done */
		if(depth != 0)
		  {
		    pClient->nCustParmDepth--;
		    depth = pClient->nCustParmDepth;
		    pClient->nCustParmMemCnt[depth]++;
		  }
	    
	      }

	  }

	/* Not working on an array or any custom data type */
	else if ((pClient->arrayTypeStart != 1) && 
		 (pClient->customTypeStart[curParmRxDepth] != 1))
	  {

	    strcpy(pClient->curParamValue[curParmRxDepth],pdata);

	    AddParam(clientId);
	    pClient->nParamRcv++;
	    
	    /*	    numParm = GetNsMethodNumParm(pClient->curNameSpace,pClient->curMethodName); */
	    numParm = pClient->pMprop->numParam;


	    if(numParm != -1)
	      {
		if(numParm == pClient->nParamRcv)
		  {
		    pClient->NxtState =  WAIT_FOR_ENVELOPE; /* DONE... */
		  }
		else
		  pClient->NxtState =  WAIT_FOR_PARAM;
	      }
	    else
	      {
		printf("ERROR: Method %s not registered\n",pClient->curMethodName);
		exit(1);
	      }


	    myfree1(pdata);

	  }

	/* Working on custom type */
	else if((pClient->arrayTypeStart != 1) &&
		(pClient->customTypeStart[curParmRxDepth] == 1))
	  {
	    /* Custom type started but all member has not been collected */

	    /*Check to see if we're done collecting */

	    /*	    		   pClient->curCustParamType[depth]); */

	    pCustTinfo = GetCustParamInfo(pClient->curCustParamType[depth]);


	    ++pClient->nCustParmMemCnt[depth];


	    strcpy(pClient->curParamValue[depth],pdata);


	    myfree1(pdata);
	    if(strcmp(pCustTinfo->mName[pClient->nCustParmMemCnt[depth]],""))
	      {
		pClient->NxtState   =  WAIT_FOR_PARAM;

		AddParam(clientId);


	      }
	    else
	      {

		/* Hit the end of custom type */
		pClient->nCustParamRcv[depth]++;   /* Count one custom */


		numParm = pClient->pMprop->numParam;
		
		if(pClient->nParamRcv == numParm - 1)
		  {
		    pClient->NxtState =  WAIT_FOR_ENVELOPE; 
		  }
		else
		  pClient->NxtState =  WAIT_FOR_PARAM;

		AddParam(clientId);

		pClient->nParamRcv++; /* Bump up the parameter received by one */

		pClient->nCustParmMemCnt[depth] = 0; /* Reset member count */
		pClient->customTypeStart[pClient->nCustParamRcv[depth]] = 0; /*End */

		/*Count only the top level of the nested is done*/
		if(depth != 0)
		  {
		    pClient->nCustParmDepth--;
		    depth = pClient->nCustParmDepth;
		    pClient->nCustParmMemCnt[depth]++;
		  }
	      }


	  }
      }
      break;
    default:
      printf("ERROR: ILLEGAL STATE TRANSITION\n");          
      

    }


}

/*Prototype: */
/*void AddCustDtypeMember(char *custName, char *varName, char *varType); */

void InitCustDtypeTbl()
{ 
  int entry;

  entry = SetCustDtypeNameSpace("http://soapinterop.org/xsd");
  SetCustDtypeName(entry, "MyStruct");
  AddCustDtypeMember("MyStruct", "varInt","int");
  AddCustDtypeMember("MyStruct", "varFloat","float"); 
  AddCustDtypeMember("MyStruct", "varBool","boolean");
  AddCustDtypeMember("MyStruct", "",""); /* End */

  entry = SetCustDtypeNameSpace("http://soapinterop.org/xsd");
  SetCustDtypeName(entry, "NestedStruct");
  AddCustDtypeMember("NestedStruct", "varInt","int");
  AddCustDtypeMember("NestedStruct", "varFloat","float"); 
  AddCustDtypeMember("NestedStruct", "varBool","boolean");
  AddCustDtypeMember("NestedStruct", "varStruct","MyStruct");
  AddCustDtypeMember("NestedStruct", "",""); /* End */

}

#if 0
asm unsigned long gets4(void)
{
   .set noreorder
   move   v0,$20   /* get CPU Config Register */
   nop
   jr      ra
   nop
   .set reorder
}
#endif

#define ALIGNMENT_SIZE_BYTE 32 /*cache line size */

void *mycalloc(size_t nelem, size_t elsize)
{
	void *ret;
	int newSize = nelem*elsize;

	if((newSize %ALIGNMENT_SIZE_BYTE) != 0)
		newSize = newSize + (ALIGNMENT_SIZE_BYTE-(newSize%ALIGNMENT_SIZE_BYTE));

	do
	{
		ret = calloc(newSize,1);
	}while(ret == NULL);

  	return ret;
}

void myfree1(void *ptr)
{
	free(ptr);
}

void *myrealloc(void *ptr, size_t size)
{
	void *ret;
	size_t newSize = size;


	if((newSize % ALIGNMENT_SIZE_BYTE) != 0)
		newSize = newSize + (ALIGNMENT_SIZE_BYTE-newSize%ALIGNMENT_SIZE_BYTE);

/*newSize = size;		 */
	do
	{
	ret =  realloc(ptr, newSize);
/*							  (unsigned long)ptr, newSize,size); */
	}while(ret == NULL);
	return ret;									  
	
}

void *mymalloc(size_t size)
{
	void *ret;
	size_t newSize = size;


	if((newSize % ALIGNMENT_SIZE_BYTE) != 0)
		newSize = newSize + (ALIGNMENT_SIZE_BYTE-newSize%ALIGNMENT_SIZE_BYTE);

	do
	{
		ret = malloc(newSize);
		printf("alloc %lx size %d\n",(unsigned long)ret,newSize);

	}while(ret == NULL);

	
	return ret;
}

#ifdef CFG_TCP
int SoapIfConfig()
{
	char *devname = "eth0";
    int err;
    dhcpreply_t *reply = NULL;
    uint8_t *addr;

	net_uninit();

    err = net_init(devname);
	if (err < 0) 
	{
		printf("Could not activate device %s: %d\n", devname, err);
		return err;
	}

	err = dhcp_bootrequest(&reply);

	if (err < 0) 
	{
		printf("ifconfig test:DHCP registration failed on device %s\n",devname);
		/*net_uninit(); */
		return CFE_ERR_NETDOWN;
	}

	net_setparam(NET_IPADDR,reply->dr_ipaddr);
	net_setparam(NET_NETMASK,reply->dr_netmask);
	net_setparam(NET_GATEWAY,reply->dr_gateway);
	net_setparam(NET_NAMESERVER,reply->dr_nameserver);
	net_setparam(NET_DOMAIN,(unsigned char *)reply->dr_domainname);

	dhcp_set_envvars(reply);

	if (reply) dhcp_free_reply(reply);

	/*ui_showifconfig(); */
	net_setnetvars();

    addr = net_getparam(NET_IPADDR);
    if (addr) 
    {
		if (ip_addriszero(addr)) 
			printf(" Error, SOAP IP address not");
		else 
			printf(" SOAP ready at %d.%d.%d.%d\n", addr[0], addr[1], addr[2], addr[3]);
	}

	return 0;	 /* success */
}
#endif

#ifdef SIM
long  SoapInitialize()
{
#if 1 /* this is the real one */
  RegisterMethod(SERVICENAME,"WriteRegister16",3,"","","",&WriteRegister16);
  RegisterMethod(SERVICENAME,"WriteRegister32",3,"","","",&WriteRegister32);
  RegisterMethod(SERVICENAME,"ReadRegister16",2,"","short","",&ReadRegister16);
  RegisterMethod(SERVICENAME,"ReadRegister32",2,"","long","",&ReadRegister32);
#else /*Fake address for 3560 prove of concept */
  RegisterMethod(SERVICENAME,"WriteRegister16",3,"","","",&FakeWriteRegister16);
  RegisterMethod(SERVICENAME,"WriteRegister32",3,"","","",&FakeWriteRegister32);
  RegisterMethod(SERVICENAME,"ReadRegister16",2,"","short","",&FakeReadRegister16);
  RegisterMethod(SERVICENAME,"ReadRegister32",2,"","long","",&FakeReadRegister32);

#endif
}
#else
/****************************************************************************************/
long SoapInitialize()
{
   initializeBase64Tables();
   SoapInitialize_regSvc();
#ifndef CHIP_6816
   RdcServiceInitialize();
#endif
#ifdef SUPPORT_MOCA
   RegisterMethod(SERVICENAME, "Help",                 0, "", "string",    "", &MoCAHelp);    
   RegisterMethod(SERVICENAME, "Version",              0, "", "string",    "", &MoCAVersion);    
   RegisterMethod(SERVICENAME, "GetStatus",            0, "", "string",    "", &GetStatus);
   RegisterMethod(SERVICENAME, "GetStatistics",        0, "", "string",    "", &GetStatistics);
   RegisterMethod(SERVICENAME, "GetPhyProfile",        2, "", "string",    "", &GetPhyProfile);
   RegisterMethod(SERVICENAME, "ResetStatistics",      0, "", "long",      "", &ResetStatistics);
   RegisterMethod(SERVICENAME, "GetIQData",            5, "", "string",    "", &GetIQData);
   RegisterMethod(SERVICENAME, "GetIRData",            5, "", "string",    "", &GetIRData);    
   RegisterMethod(SERVICENAME, "GetBLData",            3, "", "string",    "", &GetBLData);
   RegisterMethod(SERVICENAME, "GetSNRData",           2, "", "string",    "", &GetSNRData);
   RegisterMethod(SERVICENAME, "GetSNRAveData",        2, "", "string",    "", &GetSNRAveData);
   RegisterMethod(SERVICENAME, "MoCAStart",            1, "", "long",      "", &MoCAStart);
   RegisterMethod(SERVICENAME, "MoCAStop",             0, "", "long",      "", &MoCAStop);
   RegisterMethod(SERVICENAME, "MoCAExecute",          5, "", "long",      "", &MoCAExecute);
   RegisterMethod(SERVICENAME, "GetAnyTimeConfig",     1, "", "string",    "", &GetAnyTimeConfig);
   RegisterMethod(SERVICENAME, "SetAnyTimeConfig",     2, "", "long",      "", &SetAnyTimeConfig);

   printf("SOAP MoCA Service ready\n");
#endif
   return SOAP_OK;
}
#endif

/****************************************************************************************/
/* Returns 0 - success, non-0 - error */
int main(int argc, char **argv)
{
   int c, foreground=0;

   while ((c = getopt(argc, argv, "dfi:")) != -1)
   {
      switch (c)
      {
      case 'f':
         foreground = 1;
         break;

      case 'd':
         debug = 1;
         break;

#ifdef SUPPORT_MOCA
      case 'i':
         g_mocaInterface = optarg;
         break;
#endif

      default:
         printf("soapserver: ignoring option %c\n", c);
         break;
      }
   }

   if (foreground)
   {
      /*
       * CMS wants the app to run in the foreground, otherwise, we see
       * an extra zombie process in the ps listing.
       * OK, this is a little tricky now.  If we detect the -f option,
       * we must have been launched from CMS.  So assume there are no
       * other options.  Only pass in argv[0], which is the name of the app.
       */
      SoapMain(1, argv);
   }
   else
   {
	pid_t pID = fork();   
	if (pID == 0)      // child   
	{      
		SoapMain(argc, argv);
		_exit(0);
	}    
	else if (pID < 0)  // failed to fork    
	{        
		exit(1);      
	}    
	else			   // parent 
	{
		exit(0);
	}
   }
	return 0;
}


