#ifndef SOAPMAIN_H
#define SOAPMAIN_H

#include "util.h"
#include <stdio.h>
#ifdef WIN32
#include <Winsock2.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <string.h>
#include <time.h>


#include "nanoxml.h"
#include "hash.h"

#ifndef SIM
#ifdef BRCM_CMS_BUILD
#define bool char /* for portability. some system define bool as int.. */
#else
#include <bstd.h>
#endif
#else
#define bool char /* for portability. some system define bool as int.. */
#endif


#define true  1
#define false 0

#define BYTEORDER  1234

#define MAX_CLIENTS 10
#define MAX_NAMESPACE 5
#define TRANSPORT_URI_STR "tcp:1600"
#define SRESULT long
#define E_SOAPFAIL 0xFFFFFFFF
#define SOAP_OK    0
#define MAX_PENDING_CONNECTS 10
#define CLIENT_BUF_SIZE (256*4)
#ifndef WIN32
#define SOCKET_ERROR -1
#endif
#define STX	0x02
#define MAX_METHOD_NAME_LEN 80
#define MAX_NAMESPACE_LEN   80
#define MAX_NAME_LEN   80
#define MAX_QNAME_LEN       80
#define MAX_PARAMETER_TYPE_LEN 140
#define MAX_DATA_TYPE_LEN   80
#define DEFAULT_NUM_PARAMS   1

typedef struct 
{
  char curParamType[MAX_PARAMETER_TYPE_LEN];
  char curParamName[MAX_PARAMETER_TYPE_LEN];
/*  char curParamValue[MAX_PARAMETER_TYPE_LEN]; */
  char *curParamValue;
  char curCustParamType[MAX_PARAMETER_TYPE_LEN];
  int  arraySize;
  char arraySizeStr[8]; /* allow 8 digits */

}sParam;

typedef struct MyStruct
{
  int	varInt;
  float	varFloat;
  bool	varBool;
}MyStruct;

typedef struct NestedStruct
{
  int		varInt;
  float		varFloat;
  bool		varBool;
  MyStruct	varStruct;
} NestedStruct;

#ifndef WIN32
typedef int SOCKET;
#endif

typedef enum  {
  WAIT_FOR_ENVELOPE=0,
  WAIT_FOR_BODY,
  WAIT_FOR_METHOD_NAME,
  WAIT_FOR_XMLNS,
  WAIT_FOR_NAMESPACE,
  WAIT_FOR_PARAM,
  WAIT_FOR_PARAM_TYPE,
  WAIT_FOR_ARRAY_SIZE,
  WAIT_FOR_PARAM_VALUE_CUSTOM,
  WAIT_FOR_PARAM_VALUE,
  DOC_END
} CLIENT_STATE;

typedef enum {
  BUILD_METHOD_RSP_STR_WITH_XMLNS=0,
  BUILD_METHOD_RSP_STR_WITH_NO_XMLNS=1,
  BUILD_METHOD_RSP_STR_WITH_VOID_RSP=2
}RSP_STR_TYPE;

typedef struct
{

  SOCKET rxSock;
  /*  FILE   *rx; */
  SOCKET txSock;
  char   *pBuf; /* used to receive stream */
  char   *pBufRsp;
  int    status;
  nxml_t handle;

  char *prefix;
  char *curMethodName;

  char *curNameSpace;

  char **curParamType;

  char **curParamName;

  char **curParamValue;


  char **curCustParamType;

  int *customTypeStart;

  int *nCustParamRcv;

  int *nCustParmMemCnt;

  int    nCustParmDepth;

  int    arrayTypeStart; /* No nested array */

  int    arraySize;
  char   arraySizeStr[8]; /*allow 8 digits */
  int    arrayElmRcv;

  int    nParamRcv;

  int    endDoc;
  int    rspLen;

  CLIENT_STATE    CurState;
  CLIENT_STATE    NxtState;

  PtrList *parmList;  
  PtrList *respList;

  METHOD_PROP_T *pMprop;

  FUNC_PTR func;
  int nilArrElm;

#ifdef NON_OS

   #ifdef BCM7401
       #if (BCHP_REV_B0==1) || (BCHP_REV_C0==1) || (BCHP_VER>=BCHP_VER_C1)
           #define USENEWUART
       #endif
   #elif defined(BCM7400A0)
       #ifndef USENEWUART
           #define USENEWUART
       #endif
   #elif (BCHP_CHIP==7400)
		#ifdef BCHP_REV_B0
           #define USENEWUART
		#endif
   #elif (BCHP_CHIP==7405)
        #define USENEWUART
   #elif defined(BCM7440)
		#define USENEWUART
   #elif defined(BCM7325)
		#define USENEWUART
   #else
	/* assume old UART for other chips */
   #endif

#ifdef USENEWUART /* only 7400A0 and 7401B0 uses new uart as of 06/23/2006 */
  volatile struct UartChannelNew *m_hUart;	
#else
  volatile struct UartChannel *m_hUart;	
#endif

  long	m_lTimeout;
#endif  /* NON_OS */

}sClientInfo;



typedef struct serviceInfoTbl
{
  char nameSpace[MAX_NAMESPACE_LEN];
  HashTable *Htbl;  
}SERVICE_INFO_T;

int GetCustDtypeEntry(char *);
void *mycalloc(size_t nelem, size_t elsize);
void myfree1(void *ptr);
void *myrealloc(void *ptr, size_t size);
void *mymalloc(size_t size);
long SoapInitialize(void);
int RegisterMethod(char *nameSpace, char *methodName, int numParam, char *retPrefix, 
		   char *retType, char* arrType, FUNC_PTR funcPtr );


#include "methods.h"

#endif

