

#define bool char

#define true 1
#define false 0


#include "util.h"

typedef unsigned char    uchar;                              // Define unsigned char as uchar.

static char base64encode[64];
static int  base64decode[256];
static char base64pad = '=';


///////////////////////////////////////////////////////////////////////////////
// String.h

#ifndef USE_STRING_H

#if 0
char* _strcpy(char *dest, const char *src)
{
	char *work = dest;
	if (src && dest)
	{
		while ((*work++ = *src++))
			;
	}
	return dest;
}

char * _strncpy(char *dest, const char *src, size_t n)
{
	char *work = dest;
	if (src && dest)
	{
		while (n-- && (*work++ = *src++))
			;
	}
	return dest;
}

char* _strcat(char *string1, const char *string2)
{
  char *p= string1 + _strlen(string1);
  while(*string2)
  {
    *p = *string2;
    string2++;
    p++;
  }
  *p = '\0';
  return(string1);
}

size_t _strlen(const char *str)
{
	size_t ret = 0;
	if (str)
	{
		while (*str++)
			++ret;
	}
	return ret;
}

int _strcmp(const char *a, const char *b)
{
	int ret = 0;
	if (a && b)
	{
		while (*a && *b && *a == *b)
			++a, ++b;
		ret = *a - *b;
	}
	else if (a)
		ret = 1;
	else if (b)
		ret = -1;
	return ret;
}

int _strncmp(const char *a, const char *b, unsigned int n)
{
	int ret = 0;
	if (a && b)
	{
		while (n > 0 && *a && *b && *a == *b)
			++a, ++b, --n;
		if (n == 0)
			ret = 0;
		else
			ret = *a - *b;
	}
	else if (a)
		ret = 1;
	else if (b)
		ret = -1;
	return ret;
}

char* _strstr(const char *string, const char *strCharSet)
{
	if (string && strCharSet)
	{
		if (*strCharSet == 0)
			return (char *)string;

		// step along the main string
		while (*string)
		{
			const char *nn = strCharSet;
			const char *hh = string;
			// see if substring characters match
			while (*nn++ == *hh++)
			{
				if (*nn == 0)
					// we got all the way to the end of the substring
					// so we must've won
					return (char *)string;
			}
			++string;
		}
	}
	return 0;
}

char* _strchr(const char *s, int c)
{
	if (s)
	{
		do
			if (*s == c)
				return (char*)s;
		while (*s++);
	}
	return 0;
}

size_t _strcspn(const char *string1, const char *string2)
{
  char *p;
  size_t pos = 0;
  short found = 0;
  while(*string1 && (!found))
  {
    p = (char *)string2;
    while(*p)
    {
      if(*string1 == *p)
      {
        found = 1;
        break;
      }
      p++;
    }
    if(!found)
    {
      pos++;
      string1++;
    }
  }
  return(pos);
}

size_t _strspn(const char *string1, const char *string2)
{
  char *p;
  int found = 1;
  size_t slen = 0;
  while(*string1 && (found))
  {
    found = 0;
    p = (char *)string2;
    while(*p)
    {
      if(*string1 == *p)
      {
        slen++;
        found = 1;
        break;
      }
      p++;
    }
    if(found)
    {
      string1++;
    }
  }
  return(slen);
}

void* _memcpy(void *dest, const void *src, size_t count)
{
  char *p1, *p2;
  p1 = (char *)src;
  p2 = (char *)dest;
  while(count)
  {
    *p2 = *p1;
    p1++;
    p2++;
    count--;
  }
  return(dest);
}

void* _memset(void *dest, int c, size_t count)
{
  char *p = (char*)dest;
  while(count)
  {
    *p = (char)c;
    p++;
    count--;
  }
  return(dest);
}

void* _memmove(void *dest, const void *src, size_t count)
{
  char *p1, *p2;
  if(src != dest)
  {
    p1 = (char *)src;
    p2 = (char *)dest;
    if(dest > src)
    {
      p1 += (count - 1);
      p2 += (count - 1);
      while(count)
      {
        *p2 = *p1;
        p1--;
        p2--;
        count--;
      }
    } else {
      while(count)
      {
        *p2 = *p1;
        p1++;
        p2++;
        count--;
      }
    }
  }
  return(dest);
}

int _memcmp(const void *buf1, const void *buf2, size_t count)
{
  char *p1, *p2;
  int result = 0;
  p1 = (char *)buf1;
  p2 = (char *)buf2;
  while(count)
  {
    if(*p1 != *p2)
    {
      result = 1;
      if(*p1 < *p2)
      {
        result = -1;
      }
      break;
    }
    p1++;
    p2++;
    count--;
  }
  return(result);
}

#endif // USE_STRING_H


///////////////////////////////////////////////////////////////////////////////
// Float.h or Math.h

int _isnan(double d)
{
   unsigned long *ptr = (unsigned long *) (&d);
   unsigned long exp;
   unsigned long sign;
   unsigned long lsw;
   unsigned long msw;
   
   sign = ptr[1] & 0x80000000;
   exp = (ptr[1] & 0x7ff00000) >> 20;
   msw = ptr[1] & 0x000fffff;
   lsw = ptr[0];
   
   if (exp == 0x7ff)
   {
      if (msw || lsw)
         return 1;
   }
      
   return 0;
}

int _finite(double d)
{
   unsigned long *ptr = (unsigned long *) (&d);
   unsigned long exp;
   unsigned long sign;
   unsigned long lsw;
   unsigned long msw;
   
   sign = ptr[1] & 0x80000000;
   exp = (ptr[1] & 0x7ff00000) >> 20;
   msw = ptr[1] & 0x000fffff;
   lsw = ptr[0];
   
   if (exp == 0x7ff)
      return 0;
      
   return 1;
}

//////////////////////////////////////////////////////////////////////////////////////////
// The following functions are custom or modifications of the standard C-Runtime functions.
// They take into account special SOAP characters

// search from the right
char* _strrchr(const char *s, char c)
{
	char *w = 0;
	if (s)
	{
		do
			if (*s == c)
				w = (char*)s;
		while (*s++);
	}
	return w;
}
#endif

#if !defined(WIN32)

int _stricmp(const char *a, const char *b)
{
	int ret = 0;
	if (a && b)
	{
		int ua;
		int ub;
		do
		{
			ua = MAKEUPPER(*a++);
			ub = MAKEUPPER(*b++);
		}
		while (ua && ub && ua == ub);
		ret = ua - ub;
	}
	else if (a)
		ret = 1;
	else if (b)
		ret = -1;
	return ret;
}
#endif

int _isspace(char c)
{
	switch (c)
	{
	case '\r':	// carriage return
	case '\n':	// newline
	case '\t':	// tab
	case '\v':	// vertical tab
	case '\f':	// form feed
	case ' ':   // space
		return 1;
	}
	return 0;
}


long _strtol(const char *str)
{
    char *endptr = 0;
	const char *startptr = str;
	long ret;

	errno = 0;
	ret	= strtol(startptr, &endptr, 10);

    if (endptr)
    {
        while (_isspace(*endptr))
            ++endptr;

        if ( startptr == endptr || *endptr != 0 )
            return 0;
    }

	if ( errno == ERANGE )
		return 0;

	return ret;
}

double _strtod(const char *str)
{
	char *endptr = 0;
	const char *startptr = str;
	double ret;

	if (_stricmp(str, "INF") == 0)
		return HUGE_VAL;
	else if (_stricmp(str, "-INF") == 0)
		return -HUGE_VAL;
	else if (_stricmp(str, "NaN") == 0) // Not a number
		return 0;


	errno = 0;
	ret = strtod(startptr, &endptr);

	if (endptr)
	{
		while (_isspace(*endptr))
			++endptr;

		if (startptr == endptr || *endptr != 0)
			return 0.0; //Could not convert string to floating point
	}

	if (errno == ERANGE)
		return 0.0; //Double floating-point overflow/underflow

	return ret;
}



#if !defined(WIN32)
char* _ltoa( long value, char *str, int radix )
{


  // check if we're negative
  bool neg;
  int rem;
  char *b;
  char *ptr = str;

  // radix is fixed at 10 but passed in for compatibility with C-runtime
  radix = 10;
  // handle first char before we make the
  // number positive
  rem = value % radix;
  neg = (value < 0); /* Wei: move this line here */
  value /= radix;

//  neg = (value < 0); /* Wei: this line should be moved up */

  // since we just did the divide, we know we're
  // not max int.  so it's now safe to do a=-a.
  if (neg)
    {
      rem = -rem;
      value = -value;
      *ptr++ = '-';
    }

  //
  // store begining of string
  // we have to reverse
  b = ptr;
  *ptr++ = rem + '0';

  // while we have a non-zero value
  // get the base remainder
  while (value != 0)
    {
      *ptr++ = (int)(value % radix) + '0';
      value /= radix;
    }

  // null terminate
  *ptr = 0;

  // now reverse the string
  while (b < --ptr)
    {
      char keep = *b;
      *b++ = *ptr;
      *ptr = keep;
    }

  return str;
}

size_t _strlen(const char *str)
{
	size_t ret = 0;
	if (str)
	{
		while (*str++)
			++ret;
	}
	return ret;
}

#endif



int initializeBase64Tables()
{
	int i;

	// initialize the encoding table
	for (i = 0; i < 26; ++i)
	{
		base64encode[i] = 'A' + i;
		base64encode[26 + i] = 'a' + i;
	}

	for (i = 0; i < 10; ++i)
		base64encode[52 + i] = '0' + i;

	base64encode[62] = '+';
	base64encode[63] = '/';


	// initialize the decoding table
	for (i = 0; i < 256; ++i)
		base64decode[i] = (char)0x80;
	for (i = 'A'; i <= 'Z'; ++i)
		base64decode[i] = i - 'A';
	for (i = 'a'; i <= 'z'; ++i)
		base64decode[i] = 26 + i - 'a';
	for (i = '0'; i <= '9'; ++i)
		base64decode[i] = 52 + i - '0';

	base64decode['+'] = 62;
	base64decode['/'] = 63;
	base64decode[(int)base64pad] = 0;

	return 1;
}

#if 0

int nextChar(const char*& str)
{
	int c = 0;

	// skip over white space
	while (_isspace(*str))
		++str;

	// only increment pointer if
	// we're not at the end of string
	if ((c = *str))
		++str;

	return c;
}
#endif


bool Decode(const char* str, char *bytes, size_t byteslen)
{
	size_t outlen = 0;

	bool done = false;
	//const char *str = strx;

	while (!done)
	{
		int		in[4];
		char	out[3];
		int		valid = 3;

		//in[0] = nextChar(str);
		//in[1] = nextChar(str);
		//in[2] = nextChar(str);
		//in[3] = nextChar(str);
		in[0] = *str++;
		in[1] = *str++;
		in[2] = *str++;
		in[3] = *str++;

		if (in[0] == 0)
			break;

		if (in[2] == base64pad)
			valid = 1;
		else if (in[3] == base64pad)
			valid = 2;

		in[0] = base64decode[in[0]];
		in[1] = base64decode[in[1]];
		in[2] = base64decode[in[2]];
		in[3] = base64decode[in[3]];

		if (in[0] == 0x80 ||
			in[1] == 0x80 ||
			in[2] == 0x80 ||
			in[3] == 0x80)
			return false; //Invalid character in base64 string

		out[0] = (in[0] << 2) | (in[1] >> 4);
		out[1] = (in[1] << 4) | (in[2] >> 2);
		out[2] = (in[2] << 6) |  in[3];

		if (outlen + valid > byteslen)
			return false; // Input array for base64 decoding not big enough

		outlen += valid;

		if (valid == 1)
		{
			*bytes++ = out[0];
			done = true;
		}
		else if (valid == 2)
		{
			*bytes++ = out[0];
			*bytes++ = out[1];
			done = true;
		}
		else // valid == 3
		{
			*bytes++ = out[0];
			*bytes++ = out[1];
			*bytes++ = out[2];
		}
	}

	byteslen = outlen;

	return true;
}

bool Encode(char *bytes, size_t size, char *out)
{

	unsigned char *in = (unsigned char *)bytes;


	while (size >= 3)
	{
		*out++ = base64encode[in[0] >> 2];
		*out++ = base64encode[((in[0] & 3) << 4) | (in[1] >> 4)];
		*out++ = base64encode[((in[1] & 0xF) << 2) | (in[2] >> 6)];
		*out++ = base64encode[in[2] & 0x3F];
		size -= 3;
		in += 3;
	}
	if (size == 2)
	{
		*out++ = base64encode[in[0] >> 2];
		*out++ = base64encode[((in[0] & 3) << 4) | (in[1] >> 4)];
		*out++ = base64encode[(in[1] & 0xF) << 2];
		*out++ = base64pad;
	}
	else if (size == 1)
	{
		*out++ = base64encode[in[0] >> 2];
		*out++ = base64encode[(in[0] & 3) << 4];
		*out++ = base64pad;
		*out++ = base64pad;
	}
	*out = 0;
	return 0;
}
