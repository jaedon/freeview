#ifndef _BSTD_H_
#define _BSTD_H_

typedef int bool;

#endif
