

/*
 *				****  Hash ****
 *
 * This file implements a hash table
 * It uses the LIST_T package
 *
 * (c) 2001 Bill Pringle, all rights reserved
 * Permission granted to use this and related files
 * for non-commercial purposes
 */

#include <stdio.h>
#include <stdlib.h>

//#include "list.h"
#include "SoapMain.h"
#include "util.h"
#include "hash.h"


static unsigned int HashKey(HashTable *ht, char *key);
static HashEnt *HashEntCreate(METHOD_PROP_T *pMprop);
//void HashEntmyfree1(HashEnt *ent, void (freefcn(void *data)));
void HashEntmyfree1(HashEnt *ent, void (freefcn(METHOD_PROP_T *freefcn)));
static void HashAdd(HashTable *ht, int val, HashEnt *ent);
static HashEnt *HashFind(HashTable *ht, char *key);
static int HashFindLink(LINK_T *link, void *key);

/**********************************************************
 * Public Routines
 *********************************************************/

/*
 * Create a new Hash Table
 */
HashTable *HashCreate(int maxent)
{
	HashTable *ret;		/* return value */
   int i;

   ret = (HashTable *)mycalloc(sizeof (HashTable),1);
   if (ret != NULL)
   { /* memory allocated - initialize */
   	if (maxent < 1) maxent = HASH_SLOTS_MAX;
      ret->maxent = maxent;	/* max number of entries */
      ret->list = CreatePtrList(maxent);
      if (ret->list == NULL)
      { /* problems - out of memory */
      	myfree1(ret);
         ret = NULL;
      }
      else
      {
      	for (i=0; i < maxent; i++)
         {
         	ret->list->item[i] = CreateList();
         }
      }
   }
   else
    printf("ERROR: HashCreate fail alloc\n");

   return ret; /* return structure */
}

void HashTableFree(HashTable *ht, void (freefcn(METHOD_PROP_T *freefcn)))
{
  LIST_T *list;
  LINK_T *link;
  HashEnt *ent;
  int i;

  if (ht == NULL) return;	/* bad args */

  for (i=0; i < ht->maxent; i++)
    { /* delete each linked list */
      list = (LIST_T *)ht->list->item[i];	/* get linked list */
      while ((link = GetHeadLink(list)) != NULL)
	{ /* keep going until list is empty */
	  ent = DeleteLink(list, link);	/* get hash entry */
	  //	  printf("freeing method name %s\n",ent->mMethodProp->mName);
	  HashEntmyfree1(ent, freefcn);	/* free entry */
	}
      myfree1(list);	/* now free actual list */
      ht->list->item[i] = NULL;	/* just to be neat */
    }

  /* ProdPtrList empty, free it */
  FreePtrList(ht->list);

  /* hash table empty, now free it */
  myfree1(ht);
}


/*
 * Add data to Hash Table
 */
void HashPut(HashTable *ht, METHOD_PROP_T *pMprop)
{ /* add entry to hash table */
	unsigned int val;		/* hash value */
   HashEnt *ent;
 
   val = HashKey(ht, pMprop->mName);	/* get hash value */
   //   printf("++val = %d for key %s\n",val,pMprop->mName);
   ent = HashEntCreate(pMprop); /* create entry */
   HashAdd(ht, val, ent);	/* add to hash table */
}

/*
 * Get data from Hash Table
 */
void *HashGet(HashTable *ht, char *key)
{
   HashEnt *ret; /* we don't need this, but it makes debugging easier */

   ret = HashFind(ht, key);	/* find entry matching key value */
   if (ret == NULL) return NULL;
   //	return (void *)&(ret->mMethodProp);		/* return to caller */
	return (void *)(ret->mMethodProp);		/* return to caller */
}

/*******************************************************
 * Private Routines
 *******************************************************/

/*
 * HashKey
 *
 * This function will compute a hash value from a key
 * It can be done any way you want, this is just a sample
 */
static unsigned int HashKey(HashTable *ht, char *key)
{ /* generate hash value from key */
	unsigned int ret;		/* has value */
   int t1=0, t2, i, maxent;

   if (ht == NULL || key == NULL) return -1; /* bad args */
   maxent = ht->maxent;
   if (maxent < 1) return -1;	/* corrupt hash table */

   for (i=0; key[i] != '\0'; i++)
   {
   	t2 = key[i];	/* get next character */
      t1 ^= t2;		/* add to lower byte */
      /* if another byte left, add to upper byte */
      if (key[i+1] != '\0')
      {
	      t2 = key[++i];	/* get next byte */
	      t2 <<= 4;			/* shift into second byte */
         t1 += t2;		/* add to upper byte */
      }
   }
   ret = t1 % ht->maxent;	/* hash value */

   return ret;	/* final hash value */
}

/*
 * HashEntCreate
 *
 * This routine will create a new entry for the hash table
 */
static HashEnt *HashEntCreate(METHOD_PROP_T *pMprop)
{
  HashEnt *ret;		/* return value */

  //  printf("PMprop = %lx\n",(unsigned long)pMprop);
  //  printf("Method name %s addr %lx\n",pMprop->mName, (unsigned long)pMprop);
  ret = (HashEnt *)mycalloc(sizeof(HashEnt),1);
  if (ret != NULL)
    { 
#if 0
      /* initialize memory */
      ret->key = strdup(pMprop->mName);

      strcpy(ret->mMethodProp.mName,pMprop->mName);
      ret->mMethodProp.nP    = pMprop->nP;
      ret->mMethodProp.numParam = pMprop->numParam;
      strcpy(ret->mMethodProp.retPrefix,pMprop->retPrefix);
      strcpy(ret->mMethodProp.retType,pMprop->retType);
      strcpy(ret->mMethodProp.arrType, pMprop->arrType);
      ret->mMethodProp.func =  pMprop->func;
      
      if (ret->key == NULL)
	{ /* problems - out of memory */
	  myfree1(ret);
	  ret = NULL;
	}
#endif
      /* initialize memory */
      //      ret->key = strdup(pMprop->mName);
      ret->key = (char *)calloc(strlen(pMprop->mName)+1,1);
	  if(ret->key == NULL)
	      printf("ERROR: 1. HashEntCreate fail alloc\n");

      strcpy(ret->key,pMprop->mName);
      ret->mMethodProp = pMprop;
    }
    else
    printf("ERROR: 2. HashEntCreate fail alloc\n");

  return ret;
}

void HashEntmyfree1(HashEnt *ent, void (freefcn(METHOD_PROP_T *freefcn)))
{ 
  /* free hash table entry */
  if (ent == NULL) return;	/* bad arg */

  if (ent->key != NULL) myfree1(ent->key);	/* free key */

  freefcn(ent->mMethodProp);

  myfree1(ent);

}


/*
 * HashAdd
 *
 * Add entry to Hash Table
 */
static void HashAdd(HashTable *ht, int val, HashEnt *ent)
{
  LIST_T *list;
  LINK_T *link;

  /* validate parameters */
  //   if (ht == NULL || val < 1 || ent == NULL) return;
  
  if (ht == NULL || ent == NULL) return;

  /* make sure there is a linked list for entry */
  if (ht->list->item[val] == NULL) return; /* should never happen */

  list = (LIST_T *)ht->list->item[val];	/* get linked list */
  link = CreateLinkEnt(ent);	/* create link for entry */
  /*
   * We are about to add this entry to the linked list
   *
   * We could add the entry anywhere
   *
   * We add to the head on the guess that more recent adds
   * will be likely to be retrieved than older ones
   *
   * We could also insert the entry into the correct place
   * within the list to keep the keys in sorted order
   */
  AddLinkToHead(list, link);	/* add to list */

#if 0
  for(tmpLink = list->head; tmpLink != NULL;tmpLink = tmpLink->next)
    printf("Adding name %s to slot %d \n", ent->mMethodProp->mName, val);
#endif
}

static HashEnt *HashFind(HashTable *ht, char *key)
{
	int val;
   HashEnt *ret=NULL;
   LIST_T *list;
   LINK_T *link;

   val = HashKey(ht, key);	/* get hash value for key */
   list = ht->list->item[val];	/* get linked list for hash value */
	link = FindLinkEnt(list, key, HashFindLink);
   if (link != NULL)
   { /* entry found - get it */
   	ret = (HashEnt *)GetDataFromLink(link);
   }

   return ret;	/* return entry */
}

static int HashFindLink(LINK_T *link, void *key)
{ /* find entry matching key - use strcmp type compare */
   HashEnt *ent;
   int ret;

   ent = (HashEnt *)GetDataFromLink(link);
   ret = strcmp(ent->key, (char *)key);
   
   return ret;
}


