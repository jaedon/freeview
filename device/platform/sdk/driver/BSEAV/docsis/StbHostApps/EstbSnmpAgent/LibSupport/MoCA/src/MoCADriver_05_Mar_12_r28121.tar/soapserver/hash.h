/*
 *				****  Hash ****
 *
 * This is the header file for the  Hash Table
 *
 * (c) 2001 Bill Pringle, all rights reserved
 * Permission granted to use this and related files
 * for non-commercial purposes
 */

#ifndef HASH_H
#define HASH_H

typedef struct { /* generic pointer info list */
  int nItems;			/* number of items */
  int maxItems;			/* max. items */
  int delta;			/* amount to increase when full */
  void **item;			/* actual table */
} PtrList;

typedef struct links_struct
{
  struct links_struct *next;
  struct links_struct *prev;
  void   *data;
} LINK_T;

typedef struct list_struct
{
  LINK_T *head;
  LINK_T *tail;
  LINK_T *curr;
  unsigned long count; // Number of item in the list
} LIST_T;

LIST_T *CreateList(void);
void InitList(LIST_T *list);
LINK_T *CreateLinkEnt(void *data);
int  AddLinkToHead(LIST_T *list, LINK_T *entry);
int  AddLinkToTail(LIST_T *list, LINK_T *entry);
LINK_T *FindLinkEnt(LIST_T *list, void *key, int (*FindFunc)(LINK_T *link, void *key));
LINK_T * GetHeadLink(LIST_T *list);
void *DeleteLink(LIST_T *list, LINK_T *link);
int  RemoveLink(LIST_T *list, LINK_T *link);
void *GetDataFromLink(LINK_T *link);
PtrList *CreatePtrList(int nItems);
void FreeLink(LINK_T *link);
void FreePtrList(PtrList *list);


//#include  "list.h"


#define HASH_SLOTS_MAX 17
#define MAX_METHOD_NAME_LEN 80
#define RET_PREFIX_LEN 10
#define RET_TYPE_ATTR_LEN 80

typedef int (*FUNC_PTR )(int);

typedef struct
{
  char   mName[MAX_METHOD_NAME_LEN];
  int    nP;        // No parameter set == noparameter, clear has them
  int    numParam;  // Number of parameters
  char   retPrefix[MAX_METHOD_NAME_LEN];
  char   retType[RET_TYPE_ATTR_LEN];
  char   arrType[RET_TYPE_ATTR_LEN];
  
  FUNC_PTR func;

}METHOD_PROP_T;

typedef struct hash {
   int maxent;			/* max. size of hash table */
   PtrList *list;
} HashTable;

typedef struct HashEnt {
   char *key;
  //   void *data;  // Name of the function
  //   void *pFunc; // Function pointer
   METHOD_PROP_T *mMethodProp;

} HashEnt;

HashTable *HashCreate(int maxent);
//void HashTableFree(HashTable *ht, void (freefcn(void *data)));
void HashTableFree(HashTable *ht, void (freefcn(METHOD_PROP_T *)));
//void HashPut(HashTable *ht, char *key, int nP, int numParam); // keyp is method name
void HashPut(HashTable *ht, METHOD_PROP_T *pMprop); // keyp is method name
void *HashGet(HashTable *ht, char *key);

#endif
