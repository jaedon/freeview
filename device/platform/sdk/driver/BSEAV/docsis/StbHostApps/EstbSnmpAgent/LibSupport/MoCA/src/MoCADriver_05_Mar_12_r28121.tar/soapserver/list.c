#include "SoapMain.h"
//#include "list.h"
#include <stdlib.h>
#include <stdio.h>


LIST_T *CreateList(void)
{
  LIST_T *list;

  if((list = (LIST_T *)mycalloc(sizeof(LINK_T),1)) != NULL)
	    InitList(list);
   else
   	    printf("ERROR: CreateList fail mymalloc\n");

  return list;
}


void InitList(LIST_T *list)
{
  list->head = list->tail = list->curr = NULL;
}

LINK_T *CreateLinkEnt(void *data)
{
  LINK_T *link;

  if((link = (LINK_T *)mycalloc(sizeof(LINK_T),1)) != NULL)
    {
//      printf("x\n");
      link->next = link->prev = NULL;
//	  printf("y\n");
      link->data = data;
  //    printf("z\n");
    }
   else
   	    printf("ERROR: CreateLinkEnt fail mymalloc\n");

  return link;
}

int  AddLinkToHead(LIST_T *list, LINK_T *entry)
{
  //Just check for the heck of it
  if(entry == NULL || list == NULL)
    return 1;

  entry->next = list->head; // Point to head of the list
  entry->prev = NULL;       // It's the head, no prev
  
  if(list->head != NULL)
    list->head->prev = entry;

  list->head = entry;

  if(list->tail == NULL)
    list->tail = entry;

  return 0;
      
}

int  AddLinkToTail(LIST_T *list, LINK_T *entry)
{
  //Just check for the heck of it
  if(entry == NULL || list == NULL)
    return 1;

  entry->next = NULL;       // No Next
  entry->prev = list->tail;       // It's the head, no prev
  
  if(list->tail != NULL)
    list->tail->next = entry; //Fwd link

  list->tail = entry; // New tail

  if(list->head == NULL)
    list->head = entry;

  return 0;
  
}

// Find entry in link that match key using FindFunc
LINK_T *FindLinkEnt(LIST_T *list, void *key, int (*FindFunc)(LINK_T *link, void *key))
{
  LINK_T *link;

  for(link = list->head;
      link != NULL && (FindFunc)(link,key); link = link->next);

  return link;
}

LINK_T * GetHeadLink(LIST_T *list)
{
  if(list == NULL)
    return NULL;

  return list->head;
}

void *DeleteLink(LIST_T *list, LINK_T *link)
{
  void *data; 

  if(list == NULL || link == NULL)
    return NULL;

  data = link->data;
  //Delete the link
  if(RemoveLink(list, link) == 0)
    FreeLink(link);

  return data;

}

int RemoveLink(LIST_T *list, LINK_T *link)
{ 
  if (list == NULL || link == NULL) return 1; 

  //Check for head/tail 
  if (list->head == link) list->head = link->next; 
  if (list->tail == link) list->tail = link->prev; 

  // Take the link out
  if (link->prev != NULL) link->prev->next = link->next;
  if (link->next != NULL) link->next->prev = link->prev;

  // Take care of the current entry
  if (list->curr == link) list->curr = NULL; 
  return 0;
}

void *GetDataFromLink(LINK_T *link)
{
  if (link == NULL)
    return NULL;

  return link->data;
}

PtrList *CreatePtrList(int nItems)
{
    PtrList *ret;

  ret = (PtrList *)mycalloc(sizeof(PtrList),1);
  
  if (ret == NULL)
  {
	printf("ERROR: 1. CreatePtrList fail mymalloc\n") ;
  	return NULL;	/* can't allocate */
  }
  if (nItems > 0)
    { /* non-empty list - get memory for lists */
      ret->item = (void **)mycalloc(nItems * sizeof(void *),1);
      if (ret->item == NULL)
		{ /* out of memory */
		printf("ERROR: 2. CreatePtrList fail mymalloc\n") ;

	  	myfree1(ret);
	  	return NULL;
		}
    }
  else
    { /* empty list - set pointer to NULL */
      ret->item = NULL;
    }
//  ret->nItems = 0;
  ret->nItems   = nItems;
  ret->maxItems = nItems;
  /* set default growth factor */
  if (nItems > 0) ret->delta = nItems;
  else ret->delta = 10;
  return ret;

}

void FreeLink(LINK_T *link)
{
  myfree1(link);
}

void ClearPtrList(PtrList *list)
{
  int i;
  LINK_T *link;
  LIST_T *pList;
  sParam *pSParam;

  if (list == NULL) return;

 // printf("LIST items == %d\n",list->nItems);
  
  for (i=0; i < list->nItems; i++)
    {
      if (list->item[i] != NULL) 
	{
	  // Walk through this list
	  pList = list->item[i];
	  while((link= GetHeadLink(pList)) != NULL)
	    {
	      pSParam  = (sParam *)DeleteLink(pList, link);	/* get hash entry */
//	      printf("Freeing %x\n",pSParam);
		  myfree1(pSParam->curParamValue);
	      myfree1(pSParam);
	    }
	  
	}

	myfree1(list->item[i]);
    }
  list->nItems = 0;
}

void FreePtrList(PtrList *list)
{
  if (list == NULL) return;
  ClearPtrList(list);
  if (list->item != NULL) myfree1(list->item);
  myfree1(list);
}
