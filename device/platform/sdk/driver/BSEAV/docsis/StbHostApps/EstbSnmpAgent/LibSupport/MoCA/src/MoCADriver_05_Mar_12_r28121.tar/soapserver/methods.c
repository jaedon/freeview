#include "SoapMain.h"
#include "methods.h"

MyStruct **AllocMyStructArray(int size)
{
  int i;
  MyStruct **ret;

  ret = (MyStruct **)mycalloc(size*sizeof(MyStruct *),1);
  if(ret == NULL)
   printf("ERROR: AllocMyStructArray failed\n");

  for(i=0; i < size ; i++)
  	{
            ret[i] = (MyStruct *)mycalloc(sizeof(MyStruct),1);
		
            if(ret[i] == NULL)
                printf("ERROR: AllocMyStructArray failed\n");
        }

  return ret;
}

char **allocArrayStr(int size)
{
  int i;
  char **ret;

  ret = (char **)mycalloc(size*sizeof(char *),1);
  if(ret == NULL)
   printf("ERROR: 1. AllocArrayStr failed\n");

  for(i=0; i < size; i++)
    {
      ret[i] = (char *)mycalloc(DEFAULT_STR_LEN,1);
      if(ret[i] == NULL)
	   printf("ERROR: 2. AllocArrayStr failed\n");

    }
  return ret;
}

void freeArrayStr(char **array, int size)
{
  int i;

  for(i=0; i < size; i++)
    {
      myfree1(array[i]);
    }

  myfree1(array);
}


void GetParamArray(int clientId, int pNdx, void *array, ARRAY_TYPE arrType)
{
  //array is a pointer to the starting address of an array

  sParam *pSparm;
  int i;
  LIST_T *list = client[clientId]->parmList->item[pNdx];
  LINK_T *link;

  for(link = list->head,i=0; link != NULL; link = link->next,i++)
    {
      pSparm = (sParam *)GetDataFromLink(link);
      switch(arrType)
	{
	case ATYPE_SHORT:
	case ATYPE_INT:
	  {
	    short *tmpPtr = (short *)array;

	    (tmpPtr[i]) = atoi(pSparm->curParamValue);

	  }
	  break;
	case ATYPE_LONG:
	  {
	    long *tmpPtr = (long *)array;
	    (tmpPtr[i]) = strtol(pSparm->curParamValue,NULL,10);
	  }
	  break;
	case ATYPE_FLOAT:
#ifndef NO_FLOAT
	  {
	    float *tmpPtr = (float *)array;
//	    (tmpPtr[i]) = strtof(pSparm->curParamValue,NULL);
	    (tmpPtr[i]) = (float)strtod(pSparm->curParamValue,NULL);

	  }
#endif
	  break;
	case ATYPE_DOUBLE:
#ifndef NO_FLOAT
	  {
	    double *tmpPtr = (double *)array;
	    (tmpPtr[i]) = strtod(pSparm->curParamValue,NULL);
	  }
#endif
	  break;
	}
    }
}

void GetParamArrayMyStruct(int clientId, int pNdx, MyStruct **array)
{
  int i;

  for(i=0; i<client[clientId]->arraySize;i++)
    {
      //      printf ("loop %d\n",i);
      GetParamMyStruct(clientId, 0, array[i]);
    }
}


void GetParamArrayString(int clientId, int pNdx, char **array)
{
  sParam *pSparm;
  int i;
  LIST_T *list = client[clientId]->parmList->item[pNdx];
  LINK_T *link;

  for(link = list->head,i=0; link != NULL; link = link->next,i++)
    {
      pSparm = (sParam *)GetDataFromLink(link);

      if(DEFAULT_STR_LEN < strlen(pSparm->curParamValue))
	{
	  myfree1(array[i]);
	  array[i] = (char *)mycalloc(strlen(pSparm->curParamValue) + 1, 1);

	  if(array[i] == NULL)
	   printf("ERROR: GetParamArrayString failed\n");

	}
	
      strcpy(array[i],pSparm->curParamValue);
    }
}

void GetParamStr(int clientId, int pNdx, char **parm)
{
  sParam *pSparm;
  pSparm = (sParam *)GetDataFromLink(((LIST_T *)(client[clientId]->parmList->item[pNdx]))->head);

  if(strlen(pSparm->curParamValue) > strlen(*parm) + 1)
    {
      myfree1(*parm);
      *parm = (char *)mycalloc(strlen(pSparm->curParamValue) + 1,1);

	  if(*parm == NULL)
	   printf("ERROR: GetParamStr failed\n");

    }
      
  strcpy(*parm, pSparm->curParamValue);
}

void GetParamLong(int clientId, int pNdx, long *parm)
{

  sParam *pSparm;

  pSparm = (sParam *)GetDataFromLink(((LIST_T *)(client[clientId]->parmList->item[pNdx]))->head);
  
  //printf("Long val %x\n",pSparm->curParamValue);

  *parm = strtoul(pSparm->curParamValue,NULL,10);
  
}

void GetParamBool(int clientId, int pNdx, bool *parm)
{
  sParam *pSparm;
  LINK_T *link = ((LIST_T *)(client[clientId]->parmList->item[pNdx]))->head;
  pSparm = (sParam *)GetDataFromLink(link);
  *parm = strcmp(pSparm->curParamValue,"true")?0:1;
}

void SetParamBool(int clientId, bool val)
{

  char tmpStr[80];

  strcpy(tmpStr,(val==0)?"false":"true");

  AddToRspList(clientId, tmpStr, "boolean","","");
  
}

void SetParamShort(int clientId, short val)
{
  char tmpStr[80];
  sprintf(tmpStr,"%d",val);

  AddToRspList(clientId,tmpStr, "short","","");
}

void SetParamInt(int clientId, int val)
{
  char tmpStr[80];
  sprintf(tmpStr,"%d",val);

  AddToRspList(clientId,tmpStr, "int","","");
}

#ifndef NO_FLOAT
void SetParamFloat(int clientId, float val)
{
  char tmpStr[128];
  sprintf(tmpStr,"%10.10f",val);
  AddToRspList(clientId,tmpStr,"float","","");
}

void SetParamDouble(int clientId, double val)
{
  char tmpStr[128];
  int cnt;
  cnt = sprintf(&tmpStr[0],"%10.20lf",val);
  
  while(cnt == -1)
  {
  	printf("Error double conversion\n");
	  cnt = sprintf(&tmpStr[0],"%10.20lf",val);}
  	
//  printf("Add double %s size %d\n",tmpStr, strlen(tmpStr));
  AddToRspList(clientId,tmpStr,"double","","");
}
#endif

void AddToRspList(int clientId, char *val, char *type, char *name, char *custType)
{
  sClientInfo *pClient = client[clientId]; 
  LINK_T *linkEnt;
  LIST_T *list;
  sParam *pSparm;

  pSparm = (sParam *)mycalloc(sizeof(sParam),1);
  
  if(pSparm == NULL)
   printf("ERROR: AddToRspList failed\n");

  InitParmStruct(pSparm,type,name,val,custType,pClient->arraySizeStr);
 
  linkEnt = CreateLinkEnt(pSparm);
  
  if(linkEnt == NULL)	
      printf("ERROR: AddToRspList Failed to create link\n");
  
  list = pClient->respList->item[0];

  AddLinkToTail(list,linkEnt);

}

//respNdx start from 0
void AddResp(int clientId, char *val, char *type, char *name, char *custType, int respNdx)
{
  sClientInfo *pClient = client[clientId]; 
  LINK_T *linkEnt;
  LIST_T *list;
  sParam *pSparm;
  
  pSparm = (sParam *)mycalloc(sizeof(sParam),1);
  
  if(pSparm == NULL)
   printf("ERROR: AddToRspList failed\n");

  InitParmStruct(pSparm,type,name,val,custType,pClient->arraySizeStr);
 
  linkEnt = CreateLinkEnt(pSparm);
  
  if(linkEnt == NULL)	
      printf("ERROR: AddToRspList Failed to create link\n");
      
      
    if(respNdx > pClient->respList->nItems - 1)
      ResizePtrList(pClient->respList,pClient->respList->delta);
  
  list = pClient->respList->item[respNdx];

  AddLinkToTail(list,linkEnt);

}

void GetParamShort(int clientId, int pNdx, short *parm)
{
  sParam *pSparm;
  LINK_T *link = ((LIST_T *)(client[clientId]->parmList->item[pNdx]))->head;

  pSparm = (sParam *)GetDataFromLink(link);

  *parm = atoi(pSparm->curParamValue);

}

void GetParamInt(int clientId, int pNdx, int *parm)
{
  sParam *pSparm;
  LINK_T *link = ((LIST_T *)(client[clientId]->parmList->item[pNdx]))->head;

  pSparm = (sParam *)GetDataFromLink(link);

  *parm = atoi(pSparm->curParamValue);

}

#ifndef NO_FLOAT
void GetParamFloat(int clientId, int pNdx, float *parm)
{
  sParam *pSparm;
  LINK_T *link = ((LIST_T *)(client[clientId]->parmList->item[pNdx]))->head;
  pSparm = (sParam *)GetDataFromLink(link);
  
  *parm = (float)strtod(pSparm->curParamValue,NULL);
}

void GetParamDouble(int clientId, int pNdx, double *parm)
{
  sParam *pSparm;
  LINK_T *link = ((LIST_T *)(client[clientId]->parmList->item[pNdx]))->head;
  pSparm = (sParam *)GetDataFromLink(link);

  *parm = strtod(pSparm->curParamValue,NULL);
}
#endif

void GetParamMyStruct(int clientId, int pNdx, MyStruct *parm)
{
  sParam *pSparm;
  int memCnt;
  LIST_T *list = client[clientId]->parmList->item[pNdx];
  LINK_T *link;

  for(link = list->head,memCnt=0; link != NULL; link = link->next,memCnt++)
    {
      pSparm = (sParam *)GetDataFromLink(link);

      switch(memCnt)
	{
	  case 0:
	    parm->varInt = atoi(pSparm->curParamValue);
	    break;
#ifndef NO_FLOAT
	  case 1:
	    parm->varFloat = (float)strtod(pSparm->curParamValue,NULL);
	    break;
#endif
	  case 2:
	    parm->varBool = strcmp(pSparm->curParamValue,"true")?0:1;
	    break;
	}

    }
     
}

void GetParamNestedStruct(int clientId, int pNdx, NestedStruct *parm)
{
  sParam *pSparm;
  int memCnt;
  LIST_T *list = client[clientId]->parmList->item[pNdx];
  LINK_T *link;

  for(link = list->head,memCnt=0; link != NULL; link = link->next,memCnt++)
    {
      pSparm = (sParam *)GetDataFromLink(link);

      switch(memCnt)
	{
	case 0:
	  parm->varInt = atoi(pSparm->curParamValue);
	  break;
#ifndef NO_FLOAT
	case 1:
	  parm->varFloat = (float)strtod(pSparm->curParamValue,NULL);
	  break;
#endif
	case 2:
	  parm->varBool = strcmp(pSparm->curParamValue,"true")?0:1;
	  break;
	case 3:
	    {
	      int nMCnt;

	      CUSTOM_DTYPE_INFO_T *pCustInfo = GetCustParamInfo("MyStruct");

	      for(nMCnt=0; nMCnt < pCustInfo->mCount; link = link->next,nMCnt++)
		{
		  pSparm = (sParam *)GetDataFromLink(link);

		  switch(nMCnt)
		    {
		    case 0:
		      parm->varStruct.varInt = atoi(pSparm->curParamValue);
		      break;
#ifndef NO_FLOAT
		    case 1:
		      parm->varStruct.varFloat = (float)strtod(pSparm->curParamValue,NULL);
		      break;
#endif
		    case 2:
		      parm->varStruct.varBool = strcmp(pSparm->curParamValue,"true")?0:1;
		      break;
		    }
		  // Avoid doubly link update
		  if(nMCnt == pCustInfo->mCount - 1)
		    break;

		}
     
	    }
	  break;	  
	}

    }
     
}


void InitParmStruct(sParam *pSparm, char *pType,char *pName, char *pVal,char *custType, char *arrSize)
{
  strcpy(pSparm->curParamType, pType);
  strcpy(pSparm->curParamName, pName);
  
  pSparm->curParamValue = (char *)mycalloc(strlen(pVal),1);
 
  strcpy(pSparm->curParamValue, pVal);

  strcpy(pSparm->curCustParamType,custType);

  if(strcmp(arrSize,""))
    {
      strcpy(pSparm->arraySizeStr, arrSize);
      pSparm->arraySize = atoi(arrSize);
    }
}

void SetParamStr(int clientId, char **str)
{
    int cnt,srcNdx,destNdx;
    char tmpbuf[2*1024];
    char * pszBuf=tmpbuf;
    char *pGt;
 
    //Check first charactor for XML "<"
    srcNdx  = 0;
    destNdx = 0;

    //printf("In string %s\n",str[0]);

    pGt = strstr(str[0],"<");

    if(pGt != NULL)
    {
	pGt = str[0];

        cnt = strlen(pGt);
 
        //loop through the string and replace "<" with "&lt;" and ">" with "&gt;"
        while(cnt--)
        {
	    //printf("*%c = \n",*(pGt + srcNdx));
            if((*(pGt + srcNdx) != '<') && (*(pGt + srcNdx) != '>'))
            {
		pszBuf[destNdx++] = *(pGt + srcNdx++);
            }
            else
            {
                pszBuf[destNdx++] = '&';
                if(*(pGt + srcNdx) == '<')
                {	
                    pszBuf[destNdx++] = 'l';
                    pszBuf[destNdx++] = 't';
                }
                else
                {	
                    pszBuf[destNdx++] = 'g';
                    pszBuf[destNdx++] = 't';
                }
                pszBuf[destNdx++] = ';';

                srcNdx++;

            }
        }

        pszBuf[destNdx] = '\0';
     
        AddToRspList(clientId, pszBuf, "string","","");

    }
    else
        AddToRspList(clientId, *str, "string","","");

}

void SetParamLong(int clientId, long lval)
{
  char tmpStr[80];
  AddToRspList(clientId,_ltoa(lval,tmpStr,10),"long","","");
}

void SetParamMyStruct(int clientId, MyStruct *parm)
{

  int memCnt,cnt;
  
  CUSTOM_DTYPE_INFO_T *pCustInfo = GetCustParamInfo("MyStruct");
  char tmpStr[80];
  
  for(memCnt=0; memCnt<pCustInfo->mCount; memCnt++)
    {
      //      printf("Set:::: memcnt %d rspstr %s\n",memCnt, client[clientId]->pBufRsp);
    switch(memCnt)
	{
	case 0:
	{
         cnt = sprintf(tmpStr,"%d",parm->varInt);
         
         while(cnt == -1)
         {
         	 printf("Error int conversion\n");
	         cnt = sprintf(tmpStr,"%d",parm->varInt);
	     }   

    	}
	  break;
#ifndef NO_FLOAT
	case 1:
	{
	    cnt = sprintf(tmpStr,"%10.10f",parm->varFloat);
         while(cnt == -1)
         {
         	 printf("Error float conversion\n");
		    cnt = sprintf(tmpStr,"%10.10f",parm->varFloat);
		 }     	 
	    
	}    
	  break;
#endif
	case 2:
	  {
	     cnt = sprintf(tmpStr,"%s",(parm->varBool==0)?"false":"true");
	     
	     while(cnt == -1)
	     {
	             printf("Error bool conversion\n");
	     cnt = sprintf(tmpStr,"%s",(parm->varBool==0)?"false":"true");
		}	             

	  }   
	  break;
	}

      AddToRspList(clientId,tmpStr, pCustInfo->mType[memCnt],
			 pCustInfo->mName[memCnt],pCustInfo->name);

    }
}

void SetParamArrayMyStruct(int clientId, MyStruct **parm)
{

  int memCnt,i;
  
  CUSTOM_DTYPE_INFO_T *pCustInfo = GetCustParamInfo("MyStruct");
  char tmpStr[80];
  
  for(i=0; i < client[clientId]->arraySize; i++)
    {
      for(memCnt=0; memCnt<pCustInfo->mCount; memCnt++)
	{
	  //      printf("Set:::: memcnt %d rspstr %s\n",memCnt, client[clientId]->pBufRsp);
	  switch(memCnt)
	    {
	    case 0:
	      sprintf(tmpStr,"%d",parm[i]->varInt);
	      break;
#ifndef NO_FLOAT
	    case 1:
	      sprintf(tmpStr,"%10.10f",parm[i]->varFloat);
	      break;
#endif
	    case 2:
	      sprintf(tmpStr,"%s",(parm[i]->varBool==0)?"false":"true");
	      break;
	    }

	  AddToRspList(clientId,tmpStr, pCustInfo->mType[memCnt],
		       pCustInfo->mName[memCnt],pCustInfo->name);

	}
      myfree1(parm[i]);
    }
     
  myfree1(parm);
}

void SetParamNestedStruct(int clientId, NestedStruct *parm)
{

  int memCnt;

  CUSTOM_DTYPE_INFO_T *pCustInfo = GetCustParamInfo("NestedStruct");
  char tmpStr[80];

#ifndef NO_FLOAT
  int cnt;
#endif
  
  for(memCnt=0; memCnt< pCustInfo->mCount; memCnt++)
    {
      //      printf("Set:::: memcnt %d rspstr %s\n",memCnt, client[clientId]->pBufRsp);
      switch(memCnt)
	{
	case 0:
	  sprintf(tmpStr,"%d",parm->varInt);
	  break;
#ifndef NO_FLOAT
	case 1:
	  {
	  	cnt = sprintf(tmpStr,"%10.10f",parm->varFloat);
	  	while(cnt == -1)
	  	{
			printf("Error float conversion\n");
		  	cnt = sprintf(tmpStr,"%10.10f",parm->varFloat);
	  	}
	  }
	  break;
#endif
	case 2:
	  sprintf(tmpStr,"%s",(parm->varBool==0)?"false":"true");
	  break;
	case 3:
	  {
	    int nMCnt;

	    for(nMCnt = 0; nMCnt < 3; nMCnt++)
	      {
		switch(nMCnt)
		  {
		  case 0:
		    sprintf(tmpStr,"%d",parm->varStruct.varInt);
		    break;
#ifndef NO_FLOAT
		  case 1:
		    sprintf(tmpStr,"%10.10f",parm->varStruct.varFloat);
		    break;
#endif
		  case 2:
		    sprintf(tmpStr,"%s",(parm->varStruct.varBool==0)?"false":"true");
		    break;
		  }

		AddToRspList(clientId,tmpStr, pCustInfo->mType[nMCnt],
		   pCustInfo->mName[nMCnt],"MyStruct");

	      }
	  }
	}

      if(memCnt != 3)
      AddToRspList(clientId,tmpStr, pCustInfo->mType[memCnt],
		   pCustInfo->mName[memCnt],pCustInfo->name);

    }
     
}

void SetParamArray(int clientId, void *array, ARRAY_TYPE arrType)
{
  //array is a pointer to the starting address of an array
  
  int i;

  char type[128],tmpStr[128];//Make this resizeable

  for(i=0; i<client[clientId]->arraySize;i++)
    {
      //      printf("---------\n");
      switch(arrType)
	{
	case ATYPE_SHORT:
	case ATYPE_INT:
	  sprintf(tmpStr,"%d",((short *)array)[i]);
	  //	  printf("ADDing %s\n",tmpStr);
	  sprintf(type, "%s",(arrType==ATYPE_SHORT)?"short":"int");
	  break;
	case ATYPE_LONG:
	  _ltoa(((long *)array)[i],tmpStr,10);
	    //	  sprintf(tmpStr,"%l",((long *)array)[i]);
	  sprintf(type, "%s","long");
	  break;
	case ATYPE_FLOAT:
#ifndef NO_FLOAT
	  sprintf(tmpStr,"%10.10f",((float *)array)[i]);
	  sprintf(type, "%s","float");
#endif
	  break;
	case ATYPE_DOUBLE:
#ifndef NO_FLOAT
	  sprintf(tmpStr,"%10.20lf",((double *)array)[i]);
	  sprintf(type, "%s","double");
#endif
	  break;
	}

      AddToRspList(clientId,tmpStr,type,"","");	  
    }
}

//Automatically free alloced array
void SetParamArrayString(int clientId, char **array)
{
  int i;
  
  for(i=0; i<client[clientId]->arraySize;i++)
    {
      AddToRspList(clientId,array[i],"string","","");	  
      //      myfree1(array[i]);
    }

  //  myfree1(array);
}

//#include "testsoap.h"
//#include "basicserv.h"

//extern int ATAReadTf(int reqId);
//extern int ATAGetParm(int reqId);
//extern int SetBufPatt(int reqId);
//extern int ViewBuf(int reqId);
//extern int RwSector(int reqId);
//extern int CompBuf(int reqId);
//extern int RWCmpLoopTest(int reqId);
//extern int GetErrString(int reqId);
//extern int MdioRegRd(int reqId);
//extern int MdioRegWr(int reqId);
//extern int SataRegRd(int reqId);
//extern int SataRegWr(int reqId);
//extern int PciCfgRd(int reqId);
//extern int PciCfgWr(int reqId);
