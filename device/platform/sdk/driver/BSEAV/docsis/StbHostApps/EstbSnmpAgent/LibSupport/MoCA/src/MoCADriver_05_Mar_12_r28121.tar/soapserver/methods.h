#ifndef METHOD_H
#define METHOD_H
#include <stdlib.h>
#include "SoapCustDtype.h"
//#define MAX_PARAM_STR_LEN 80

#define DEFAULT_STR_LEN 1024

typedef enum 
{
  ATYPE_SHORT=0,ATYPE_INT,ATYPE_LONG,ATYPE_FLOAT,ATYPE_DOUBLE
  
}ARRAY_TYPE;

extern SERVICE_INFO_T svcTbl[MAX_NAMESPACE];
extern sClientInfo *client[MAX_CLIENTS];
extern void *mycalloc(size_t nelem, size_t elsize);
extern void myfree1(void *ptr);
extern void *myrealloc(void *ptr, size_t size);
extern void *mymalloc(size_t size);
extern  PtrList * ResizePtrList(PtrList *list, int m);

void GetParamLong(int clientId, int pNdx, long *parm);
void GetParamStr(int clientId, int pNdx, char **parm);
void GetParamBool(int clientId, int pNdx, bool *parm);
void GetParamShort(int clientId, int pNdx, short *parm);
void GetParamInt(int clientId, int pNdx, int *parm);
void GetParamFloat(int clientId, int pNdx, float *parm);
void GetParamDouble(int clientId, int pNdx, double *parm);
void GetParamMyStruct(int clientId, int pNdx, MyStruct *parm);
void GetParamNestedStruct(int clientId, int pNdx, NestedStruct *parm);
void GetParamArray(int clientId, int pNdx, void *array, ARRAY_TYPE arrType);
void GetParamArrayString(int clientId, int pNdx, char **array);
void GetParamArrayMyStruct(int clientId, int pNdx, MyStruct **array);

void SetParamArray(int clientId, void *array, ARRAY_TYPE arrType);
void SetParamArrayString(int clientId, char**array);
void SetParamLong(int clientId, long lval);
void SetParamStr(int clientId, char **str);
void SetParamBool(int clientId, bool val);
void SetParamShort(int clientId, short val);
void SetParamInt(int clientId, int val);
void SetParamFloat(int clientId, float val);
void SetParamDouble(int clientId, double val);
void SetParamMyStruct(int clientId, MyStruct *parm);
void SetParamNestedStruct(int clientId, NestedStruct *parm);
void SetParamArrayMyStruct(int clientId, MyStruct **parm);

void AddToRspList(int clientId, char *tmpStr, char *type, char *name, char *custType);
void InitParmStruct(sParam *pResp, char *pType,char *pName, char *pVal,char *custType, char *arrSize);

char **allocArrayStr(int size);
void freeArrayStr(char **array, int size);
void AddResp(int clientId, char *val, char *type, char *name, char *custType, int respNdx);

extern int IsCustomType(char *type);
extern void DumpParamList(LIST_T *list);

extern CUSTOM_DTYPE_INFO_T *GetCustParamInfo(char *custName);

#ifdef SIM
#include "SimApi.h"
#endif

#endif
