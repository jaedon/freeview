/*
<:copyright-broadcom 
 
 Copyright (c) 2008 Broadcom Corporation 
 All Rights Reserved 
 No portions of this material may be reproduced in any form without the 
 written permission of: 
          Broadcom Corporation 
          5300 California Avenue
          Irvine, California 92617 
 All information contained in this document is Broadcom Corporation 
 company private, proprietary, and trade secret. 
 
:>
*******************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#ifndef WIN32
#include <sys/time.h>
#endif

#ifdef WIN32
#include "../SoapMain.h"
#include "../SoapUtil.h"
#else
#include "SoapMain.h"
#include "SoapUtil.h"
#endif

#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <error.h>
#include <stdint.h>
#include <sys/mman.h>
#include <mocalib.h>
#include "devctl_moca.h"
#include "mocaSvc.h"

#ifdef CHIP_6816
#include "board.h"
#include "cms.h"
#include "cms_log.h"
#include "cms_psp.h"
#else
#define CMSRET_SUCCESS          0
#endif

static SVCMOCASTATUS moCAStatus;
static SVCMOCASTATISTICS moCAStatistics;
static SVCPHYPROFILE moCAPhyProfile;
static SVCIQCONFIG moCAIQConfig;
static SVCSNRCONFIG moCASNRConfig ;
static SVCSNRAVECONFIG moCASNRAveConfig ;
/* Max Constellation is set in 2 function calls, but both values 
 * are needed for the set. Always use the last value set from BBS */
static SINT32 maxConstNodeId = MoCA_DEF_CONSTELLATION_NODE;
static UINT32 maxConstInfo   = MoCA_DEF_CONSTELLATION_INFO;
static void * mocaCtx = NULL;

extern char * g_mocaInterface;
extern void GetRegisteredNames(char * buf, int buflen);

void setContext(char * mocaInterface)
{
   if (mocaCtx == NULL)
   {
      mocaCtx = MoCACtl_Open(mocaInterface);

      if (mocaCtx == NULL)
      {
         printf("Unable to get moca context for interface %s\n",
            (mocaInterface ? mocaInterface : "(null)"));           
      }
   }
}

/****************************************************************************************/
/* char * Help() */
int MoCAHelp(int reqId)
{
    char **str = allocArrayStr(1);

    // careful, the latest SOAP implementation only allocates max 1K buffer limit
    GetRegisteredNames(str[0], 1024);

    SetParamStr(reqId, str);
    freeArrayStr(str,1);

    return SOAP_OK;
}

/****************************************************************************************/
/* char * Version() */
int MoCAVersion(int reqId)
{
    char **str = allocArrayStr(1);

    strcpy(str[0], MOCAVERSION);

    SetParamStr(reqId, str);
    freeArrayStr(str,1);

    return SOAP_OK;
}

/****************************************************************************************/
int ResetStatistics(int reqId)
{
     CmsRet nRet = CMSRET_SUCCESS;
     MoCA_STATISTICS Stats ;

     setContext(g_mocaInterface);
     
     nRet = MoCACtl2_GetStatistics ( mocaCtx, &Stats, 1 ) ;

     SetParamInt(reqId, 0);
     return SOAP_OK;
}

/****************************************************************************************/
int GetStatus(int reqId)
{
     char *pReturn;
     uint32_t nSize, nEncodeSize ;
     CmsRet nRet = CMSRET_SUCCESS;
     MoCA_STATUS status;

     nSize = sizeof(SVCMOCASTATUS);

     nEncodeSize = (uint32_t) ((nSize*4/3) + 3);

     pReturn = (char*)mycalloc(nEncodeSize,1);

     if ( ( nEncodeSize % 4 ) != 0 )
            nEncodeSize += ( 4 - nEncodeSize % 4 ) + 1;

     setContext(g_mocaInterface);

     nRet = MoCACtl2_GetStatus( mocaCtx, &status ) ;
     if (nRet == CMSRET_SUCCESS) {


            moCAStatus.VendorId                 = LE32(status.generalStatus.vendorId) ;
            moCAStatus.HardwareVersion      = LE32(status.generalStatus.hwVersion) ;
            moCAStatus.SoftwareVersion      = LE32(status.generalStatus.swVersion) ;
            moCAStatus.SelfMoCAVersion      = LE32(status.generalStatus.selfMoCAVersion) ;
            moCAStatus.NetworkMoCAVersion = LE32(status.generalStatus.networkVersionNumber) ;
            moCAStatus.QAM256Supported    = LE32(status.generalStatus.qam256Support) ;
            moCAStatus.NetworkStatus      = LE32(status.generalStatus.operStatus) ;
            moCAStatus.LinkStatus         = LE32(status.generalStatus.linkStatus) ;
            moCAStatus.ConnectedNodes     = LE32(status.generalStatus.connectedNodes) ;
            moCAStatus.NodeId   = LE32(status.generalStatus.nodeId) ;
            moCAStatus.NCNodeId           = LE32(status.generalStatus.ncNodeId) ;
            moCAStatus.CoreUpTime         = LE32(status.miscStatus.MoCAUpTime) ;
            moCAStatus.LinkUpTime         = LE32(status.miscStatus.linkUpTime) ;
            moCAStatus.BackupNCNodeId     = LE32(status.generalStatus.backupNcId) ;
            moCAStatus.RFFreq             = LE32(status.generalStatus.rfChannel) ;
            moCAStatus.BWStatus             = LE32(status.generalStatus.bwStatus) ; 
            moCAStatus.nodesUsableBitmask = LE32(status.generalStatus.nodesUsableBitmask) ; 
            moCAStatus.networkTabooMask = LE32(status.generalStatus.networkTabooMask) ;
            moCAStatus.networkTabooStart  = LE32(status.generalStatus.networkTabooStart) ;
            moCAStatus.macAddrLow = LE32(((uint32_t)status.miscStatus.macAddr[3]<<0)  | 
                                         ((uint32_t)status.miscStatus.macAddr[2]<<8)  | 
                                         ((uint32_t)status.miscStatus.macAddr[1]<<16) | 
                                         ((uint32_t)status.miscStatus.macAddr[0]<<24));
            moCAStatus.macAddrHi = LE32(((uint32_t)status.miscStatus.macAddr[5]<<0) | 
                                        ((uint32_t)status.miscStatus.macAddr[4]<<8));
            moCAStatus.isNC                 = LE32(status.miscStatus.isNC) ; 
            moCAStatus.driverUpTime         = LE32(status.miscStatus.driverUpTime) ; 
            moCAStatus.linkResetCount       = LE32(status.miscStatus.linkResetCount) ;
            moCAStatus.lmoInfoAvailable   = LE32(status.miscStatus.lmoInfoAvailable) ;
            moCAStatus.txGcdPowerReduction = LE32(status.generalStatus.txGcdPowerReduction);
            moCAStatus.pqosEgressNumFlows = LE32(status.generalStatus.pqosEgressNumFlows);
     }
     else {
            memset (&moCAStatus, 0, sizeof (SVCMOCASTATUS)) ;
     }

     Encode( (char*)&moCAStatus, nSize, pReturn);
     SetParamStr(reqId, &pReturn);

     myfree1(pReturn);
     return SOAP_OK;
}

/****************************************************************************************/
int GetStatistics(int reqId)
{

     char *pReturn;
     uint32_t nSize, nEncodeSize ;
     CmsRet nRet = CMSRET_SUCCESS;
     MoCA_STATISTICS Stats ;

     nSize = sizeof(SVCMOCASTATISTICS);

     nEncodeSize = (uint32_t) ((nSize*4/3) + 3);

     pReturn = (char*)mycalloc(nEncodeSize,1);

     if ( ( nEncodeSize % 4 ) != 0 )
            nEncodeSize += ( 4 - nEncodeSize % 4 ) + 1;

     setContext(g_mocaInterface);

     nRet = MoCACtl2_GetStatistics ( mocaCtx, &Stats, 0 ) ;
     if (nRet == CMSRET_SUCCESS) {
    
            moCAStatistics.InUcPkts                 = LE32(Stats.generalStats.inUcPkts);
            moCAStatistics.InDiscardPktsEcl = LE32(Stats.generalStats.inDiscardPktsEcl);
            moCAStatistics.InDiscardPktsMac = LE32(Stats.generalStats.inDiscardPktsMac);
            moCAStatistics.InUnKnownPkts        = LE32(Stats.generalStats.inUnKnownPkts);
            moCAStatistics.InMcPkts                 = LE32(Stats.generalStats.inMcPkts);
            moCAStatistics.InBcPkts                 = LE32(Stats.generalStats.inBcPkts);
            moCAStatistics.InOctets_hi          = LE32(Stats.BitStats64.inOctets_hi);
            moCAStatistics.InOctets_low         = LE32(Stats.generalStats.inOctets_low);
            moCAStatistics.OutUcPkts                = LE32(Stats.generalStats.outUcPkts);
            moCAStatistics.OutDiscardPkts   = LE32(Stats.generalStats.outDiscardPkts);
            moCAStatistics.OutBcPkts                = LE32(Stats.generalStats.outBcPkts);
            moCAStatistics.OutOctets_hi         = LE32(Stats.BitStats64.outOctets_hi);
            moCAStatistics.OutOctets_low        = LE32(Stats.generalStats.outOctets_low);
            moCAStatistics.NCHandOffs           = LE32(Stats.generalStats.ncHandOffs);
            moCAStatistics.NCBackups                = LE32(Stats.generalStats.ncBackups);

            moCAStatistics.RxMapPkts                = LE32(Stats.extendedStats.rxMapPkts);      // Extended statistics starts here onwards
#if 0
            for (i = 0; i < MoCA_MAX_NODES; i++) {
                moCAStatistics.RxRRs [i]            = LE32(Stats.extendedStats.rxRRPkts [i]);
            }
#endif
            moCAStatistics.RxBeacons            = LE32(Stats.extendedStats.rxBeacons);
            moCAStatistics.RxControlPkts        = LE32(Stats.extendedStats.rxCtrlPkts);
            moCAStatistics.TxBeacons            = LE32(Stats.extendedStats.txBeacons);
            moCAStatistics.TxMaps               = LE32(Stats.extendedStats.txMaps);
            moCAStatistics.TxLCS                = LE32(Stats.extendedStats.txLinkCtrlPkts);
            moCAStatistics.ResyncAttempts   = LE32(Stats.extendedStats.resyncAttempts);
            moCAStatistics.GMIITxBufFull     = LE32(Stats.extendedStats.gMiiTxBufFull);
            moCAStatistics.MoCARxBufFull     = LE32(Stats.extendedStats.MoCARxBufFull);
            moCAStatistics.ThisHandoffs     = LE32(Stats.extendedStats.thisHandOffs);
            moCAStatistics.ThisBackups      = LE32(Stats.extendedStats.thisBackups);
     }
     else {
            memset (&moCAStatistics, 0, sizeof (SVCMOCASTATISTICS)) ;
     }

     Encode( (char*)&moCAStatistics, nSize, pReturn);
     SetParamStr(reqId, &pReturn);

     myfree1(pReturn);
     return SOAP_OK;
}

/****************************************************************************************/
/* MoCAStart(base64 string containing SVCMOCASTART moCAStart structure)
   Inputs: moCAStart structure containing INIT_TIME configuration to start MoCA
   Outputs: 0 to indicate moCA start successful, 1 to indicate failure
*/
int MoCAStart(int reqId)
{
   uint32_t nSize, nEncodeSize;
   char** pBufferName;
   char *pAddress;
   SVCMOCASTART *pmoCAStart;
   CmsRet nRet = CMSRET_SUCCESS;
   MoCA_INITIALIZATION_PARMS InitParms ;
   UINT64              configMask = 0 ;
   MoCA_CONFIG_PARAMS  configParms ;
   PMoCA_CONFIG_PARAMS pCfgParms = NULL ;

   nSize = sizeof(SVCMOCASTART);

   nEncodeSize = (uint32_t)( (nSize*4/3) + 3);
   if ( ( nEncodeSize % 4 ) != 0 )
      nEncodeSize += ( 4 - nEncodeSize % 4 ) + 1;

   pAddress = (char*)mycalloc(nSize, 1);
   pBufferName = (char**)allocArrayStr(nEncodeSize);
   GetParamStr(reqId, 0, pBufferName);

   /* Get structure address */
   Decode(*pBufferName, pAddress, nSize);

   /* free string buffer and create register buffer */
   freeArrayStr(pBufferName, nEncodeSize);
   pmoCAStart = (SVCMOCASTART*) pAddress;

   /* access structure here */
   memset(&InitParms, 0, sizeof(InitParms));

   setContext(g_mocaInterface);

   if (mocaCtx != NULL)
   {    
      MoCACtl2_GetPersistent(mocaCtx, "MoCAINITPARMS", (char *) &InitParms, sizeof (MoCA_INITIALIZATION_PARMS));
      
      if (MoCACtl2_GetPersistent(mocaCtx, "MoCACFGPARMS", (char *) &configParms, sizeof (MoCA_CONFIG_PARAMS)) > 0) {
         configParms.outOfOrderLmo = 0xFF ;
         configMask = MoCA_CFG_NON_LAB_PARAM_ALL_MASK ;
         pCfgParms = &configParms ;
      }
   }
         
   InitParms.ncMode                 = LE32 (pmoCAStart->ncMode) ;
   InitParms.autoNetworkSearchEn    = LE32 (pmoCAStart->autoNetworkSearch) ;
   InitParms.privacyEn              = LE32 (pmoCAStart->privacyEnable) ;
   InitParms.txPwrControlEn         = LE32 (pmoCAStart->txPwrCtlEnable) ;
   InitParms.constTransmitMode      = LE32 (pmoCAStart->continousPwrTxMode) ;
   InitParms.nvParams.lastOperFreq  = LE32 (pmoCAStart->lof) ;
   InitParms.maxTxPowerPackets      = LE32 (pmoCAStart->maxTxPowerPackets) ;
   InitParms.maxTxPowerBeacons      = LE32 (pmoCAStart->maxTxPowerBeacons) ;
   InitParms.beaconChannel          = LE32 (pmoCAStart->beaconChannel) ;
   InitParms.passwordSize           = LE32 (pmoCAStart->passwordSize) ;
   memcpy (&InitParms.password[0], pmoCAStart->password, 
      MIN(InitParms.passwordSize, MoCA_MAX_PASSWORD_LEN)) ;
   InitParms.mcastMode              = LE32 (pmoCAStart->multicastMode) ;
   InitParms.labMode                = LE32 (pmoCAStart->labMode) ;
   InitParms.tabooFixedMaskStart    = LE32 (pmoCAStart->tabooStartChan) ;
   InitParms.tabooFixedChannelMask  = LE32 (pmoCAStart->tabooChanMask) ;
   InitParms.padPower               = LE32 (pmoCAStart->padPower) ;
   InitParms.operatingVersion       = LE32 (pmoCAStart->operatingVersion) ;
   InitParms.preferedNC             = LE32 (pmoCAStart->preferedNC) ;


   configParms.outOfOrderLmo = 0xFF ;
   configMask = MoCA_CFG_NON_LAB_PARAM_ALL_MASK ;

   pCfgParms = &configParms ;

   nRet = MoCACtl2_Initialize ( mocaCtx, &InitParms, pCfgParms, configMask ) ;

   SetParamInt(reqId, nRet);    // return 0 as successful
   myfree1(pAddress);
   return SOAP_OK;
}

int MoCAStop(int reqId)
{
   CmsRet nRet = CMSRET_SUCCESS;

   setContext(g_mocaInterface);

   nRet = MoCACtl2_Uninitialize ( mocaCtx ) ;

   if (nRet == CMSRET_SUCCESS) {
      memset (&moCASNRAveConfig, 0, sizeof (SVCSNRAVECONFIG)) ;
      memset (&moCASNRConfig, 0, sizeof (SVCSNRCONFIG)) ;
      memset (&moCAIQConfig, 0, sizeof (SVCIQCONFIG)) ;
   }
   else {
       printf("Soap moca stop failed\n");
   }

    SetParamInt(reqId, nRet);   // return 0 as successful
    return SOAP_OK;
}

/****************************************************************************************/
/* GetIQData(nNodeId, nACMTSymbol, nRxBurstType, nDisplayMode, nLength)
   Inputs:
        nNodeId = 0-15
        nACMTSymbol = 0-9
        nRxBurstType = 0-UC, 1-MAP, 2-BBL, 3-Beacon
        nDisplayMode = 0-All Carriers, 1-Sub Carriers
        nLength = 256 (requesting 256 IQ points)
   Outputs:
        pRegisterData[] containing 256 samples of 32 bit data, where MSB 16 bit of I data, & LSB 16 bit of Q data
        i.e. returning 1K data (256 points * 4 bytes)
*/

int GetIQData(int reqId)
{
   char *pReturn;
   uint32_t nSize, nData, nEncodeSize, nLength, i, nNodeId, nACMTSymbol, nRxBurstType, nDisplayMode;
   uint32_t* pRegisterData;
   SVCIQCONFIG iqConfig ;
   MoCA_CONFIG_PARAMS configParams ;
   BCMMoCA_STATUS bmStatus = MoCASTS_SUCCESS ;
   MoCA_IQ_DATA   iqData ;
   UINT32         data [256] ;
   UINT16          iVal, qVal ;

   GetParamInt(reqId, 0, (int32_t*)&nNodeId);
   GetParamInt(reqId, 1, (int32_t*)&nACMTSymbol);
   GetParamInt(reqId, 2, (int32_t*)&nRxBurstType);
   GetParamInt(reqId, 3, (int32_t*)&nDisplayMode);
   GetParamInt(reqId, 4, (int32_t*)&nLength);
   nSize = nLength * 4;
   nEncodeSize = (uint32_t)( (nSize*4/3) + 3);

   iqConfig.nNodeId = nNodeId ;
   iqConfig.nACMTSymbol = MMP_ACMT_SYM_NUM (nACMTSymbol) ;
   iqConfig.nRxBurstType = MMP_BURST_TYPE (nRxBurstType) ;
   iqConfig.nDisplayMode = nDisplayMode ;
   iqConfig.nLength = nLength ;

   //printf("NodeId=%d, ACMTSymbol=%d, RxBurstType=%d, DisplayMode=%d, Length=%d\n",
         //iqConfig.nNodeId, iqConfig.nACMTSymbol, iqConfig.nRxBurstType, iqConfig.nDisplayMode, iqConfig.nLength);

   /* Allocate memory */
   pRegisterData = (uint32_t*)mycalloc(nLength, 4);
   pReturn = (char*)mycalloc(nEncodeSize, 1);

   if ( ( nEncodeSize % 4 ) != 0 )
      nEncodeSize += ( 4 - nEncodeSize % 4 ) + 1;

   setContext(g_mocaInterface);

   if (memcmp (&iqConfig, &moCAIQConfig, sizeof (SVCIQCONFIG)) != 0) {
      /* Configure the IQ DIAGRAM with MoCA and wait before reading the data
       * */
      configParams.iq.nodeId = iqConfig.nNodeId ;
      configParams.iq.burstType = iqConfig.nRxBurstType ;
      configParams.iq.acmtSymNum = iqConfig.nACMTSymbol ;
      bmStatus = MoCACtl2_SetCfg (mocaCtx, &configParams, MoCA_CFG_PARAM_IQ_DIAGRAM_SET_MASK ) ;
      if (bmStatus == MoCASTS_SUCCESS)
         memcpy (&moCAIQConfig, &iqConfig, sizeof (SVCIQCONFIG)) ;
   }

   /* Get the IQ data from the core */
   if (bmStatus == MoCASTS_SUCCESS) {

      iqData.pData = (UINT8 *) &data [0] ;
      bmStatus = MoCACtl2_GetIQData (mocaCtx, &iqData) ;

      if (bmStatus == MoCASTS_SUCCESS) {
         for (i=0;i<nLength;i++)
         {
            char *c = (char *) &data[i];
            iVal = (UINT16)c[1] | ((UINT16)c[0] << 8);
            qVal = (UINT16)c[3] | ((UINT16)c[2] << 8);
            
            if ( MoCA_IS_VALID_SUBCARRIER(i) ) {

               /*printf(" %04X %04X  -- ",iVal, qVal);*/
                
               // convert from signed to unsigned
               if ( iVal >= 4096 ) iVal = iVal - 4096;
               else                iVal = iVal + 4096;

               if ( qVal >= 4096 ) qVal = qVal - 4096;
               else                qVal = qVal + 4096; 
            
               nData = (UINT32)(iVal << 16) | (UINT32) qVal ;
            }
            else {
               nData = 0xFFFFFFFF ;
            }
               
            /* each IQ data is a 32 bit data, with I data of 16 MSB, & Q data of 16 LSB) */
            nData = LE32(nData);
            /*printf("nData[%d]=0x%8.8lx\n", i, (unsigned long)nData); */
            pRegisterData[i] = nData;
            /*printf("pRegisterData[%d]=%X\n", i, pRegisterData[i]); */
            /* pRegisterData[i] = *((volatile uint32_t *)(nAddr)); */
            //nAddr += 4;
            /* BKNI_Sleep(1); */
         }
      }
   }

   if (bmStatus != MoCASTS_SUCCESS) {
      printf ("IQ dummy \n") ;
      for (i=0;i<nLength;i++)
      {
         /* each IQ data is a 32 bit data, with I data of 16 MSB, & Q data of 16 LSB) */
         nData = ((uint32_t)(i << (uint32_t)16)) | ((uint32_t)i);   /* return dummy data */
         nData = LE32(nData);
         /*printf("nData[%d]=0x%8.8lx\n", i, (unsigned long)nData); */
         pRegisterData[i] = nData;
         //printf("pRegisterData[%d]=%d\n", i, pRegisterData[i]);
         /* pRegisterData[i] = *((volatile uint32_t *)(nAddr)); */
         //nAddr += 4;
         /* BKNI_Sleep(1); */
      }
   }
   Encode( (char*)pRegisterData, nSize, pReturn );
   SetParamStr(reqId, &pReturn);

   myfree1(pReturn);
   myfree1(pRegisterData);
   return SOAP_OK;
}


/****************************************************************************************/
/* GetIRData(nNodeId, nLength, nDisplayMode)
   Inputs:
        nNodeId = 0-15
        nDisplayMode = 0-IR Graphs, 1-Abs graph
        nLength = 256 (requesting 256 points)
   Outputs:
        pRegisterData[] containing 256 samples of 32 bit data
*/

int GetIRData(int reqId)
{
   char *pReturn;
   uint32_t nSize, nEncodeSize, nLength, i, nNodeId, nDisplayMode;
   uint32_t* pRegisterData;
   BCMMoCA_STATUS bmStatus = MoCASTS_SUCCESS ;
   MoCA_CIR_DATA  irData ;
   UINT32         data [256] ;
   SINT32          real, imag ;

   GetParamInt(reqId, 0, (int32_t*)&nNodeId);
   GetParamInt(reqId, 1, (int32_t*)&nLength);
   GetParamInt(reqId, 2, (int32_t*)&nDisplayMode);


   nSize = nLength * 4;
   
   nEncodeSize = (uint32_t)( (nSize*4/3) + 3);

   //printf("NodeId=%d, ACMTSymbol=%d, RxBurstType=%d, DisplayMode=%d, Length=%d\n",
         //iqConfig.nNodeId, iqConfig.nACMTSymbol, iqConfig.nRxBurstType, iqConfig.nDisplayMode, iqConfig.nLength);

   /* Allocate memory */
   pRegisterData = (uint32_t*)mycalloc(nSize, 1);
   pReturn = (char*)mycalloc(nEncodeSize, 1);

   if ( ( nEncodeSize % 4 ) != 0 )
      nEncodeSize += ( 4 - nEncodeSize % 4 ) + 1;

   setContext(g_mocaInterface);

   /* Get the IR data from the core */
   if (bmStatus == MoCASTS_SUCCESS) {

      irData.nodeId = nNodeId;
      irData.size = nSize;
      irData.pData = (UINT8 *) &data [0] ;
      bmStatus = MoCACtl2_GetCIRData (mocaCtx, &irData) ;

      if (bmStatus == MoCASTS_SUCCESS) 
      {
        for (i=0; i<256;i++)
        {
            /* The data is to be displayed in BBS in reverse order. 
             * I.e. data[255] is first data point */
            real = (uint32_t)(irData.pData[(255 - i)*4+1]) | 
                   ((uint32_t)(irData.pData[(255 - i)*4+0]) << 8);
            imag = (uint32_t)(irData.pData[(255 - i)*4+3]) | 
                   ((uint32_t)(irData.pData[(255 - i)*4+2]) << 8);

            if (real > 0x7fff)
                real = (0x10000-real);

            if (imag > 0x7fff)
                imag = (0x10000-imag);

            if (nDisplayMode == 1)            
            {
                pRegisterData[i] = LE32((((uint32_t)imag & 0xFFFF) << 16) | ((uint32_t)real & 0xFFFF));
            }
            else
            {
                pRegisterData[i] = LE32((uint32_t)sqrt((double)real*(double)real + (double)imag*(double)imag));
            }

//            printf("%d  %02X %02X %02X %02X -- %d   %d    %d (%d)   %d\n",nNodeId, irData.pData[i*4+0], irData.pData[i*4+1], 
//                irData.pData[i*4+2], irData.pData[i*4+3], real, imag, (uint32_t)sqrt((double)real*(double)real + (double)imag*(double)imag), pRegisterData[i], (int)((double)real*(double)real + (double)imag*(double)imag));
         }
      }
   }

   if (bmStatus != MoCASTS_SUCCESS) {
      printf ("IR dummy \n") ;
      for (i = 0; i < 256; i++)
      {
         /* The data is to be displayed in BBS in reverse order. 
          * I.e. data[255] is first data point */
         real = i * 32;
         imag = (255 - i) * 32;

         if (nDisplayMode == 1)            
         {
             pRegisterData[i] = LE32((((uint32_t)imag & 0xFFFF) << 16) | ((uint32_t)real & 0xFFFF));
         }
         else
         {
             pRegisterData[i] = LE32((uint32_t)sqrt((double)real*(double)real + (double)imag*(double)imag));
         }
      }
   }

//    printf("display mode = %d\n", nDisplayMode);
    
   Encode( (char*)pRegisterData, nSize, pReturn );
   SetParamStr(reqId, &pReturn);

   myfree1(pReturn);
   myfree1(pRegisterData);
   return SOAP_OK;
}


/****************************************************************************************/
/* GetBLData(nNodeId, nBurstType, nLength)
   Inputs:
        nNodeId = 0-15
        nBurstType = 0- Tx UC, 1- Rx UC, 2- Rx BC, 3-Rx Map, 4-Tx BC, 5-Tx Map
        nLength = 256 (requesting 256 Bit Loading data points)
   Outputs:
        pRegisterData[] containing 256 points where each point can be 0-8.
        i.e. returning 1K data (256 points * 4 bytes), each point representing a sub carrier QAM number in
        the range of 0 to 8.
*/
int GetBLData(int reqId)
{
   char *pReturn;
   uint32_t nSize, nData, nEncodeSize, nLength, i, j, k, nNodeId, nBurstType;
   uint32_t* pRegisterData;
   uint32_t* pu32BitLoading ;
   CmsRet nRet ;
   MoCA_NODE_STATUS_ENTRY nodeStatus [MoCA_MAX_NODES] ;
   MoCA_NODE_COMMON_STATUS_ENTRY nodeCommonStatus ;

   GetParamInt(reqId, 0, (int32_t*)&nNodeId);

   GetParamInt(reqId, 1, (int32_t*)&nBurstType);
   GetParamInt(reqId, 2, (int32_t*)&nLength);
   nSize = nLength * 4;
   nEncodeSize = (uint32_t)( (nSize*4/3) + 3);

   //printf("NodeId=%d, BurstType=%d, Length=%d\n", nNodeId, nBurstType, nLength);

   nodeStatus[0].nodeId = nNodeId ;

   /* Allocate memory */
   pRegisterData = (uint32_t*)mycalloc(nLength, 4);
   pReturn = (char*)mycalloc(nEncodeSize, 1);

   if ( ( nEncodeSize % 4 ) != 0 )
      nEncodeSize += ( 4 - nEncodeSize % 4 ) + 1;

   setContext(g_mocaInterface);

   if (nBurstType <= BIT_LOADING_RX_MAP) {
      nRet = MoCACtl2_GetNodeStatus (mocaCtx, &nodeStatus[0]) ;
   }
   else {
      UINT32   tblSize ;
      nRet = MoCACtl2_GetNodeTblStatus ( mocaCtx, &nodeStatus [0], &nodeCommonStatus, &tblSize ) ;
    }

   if (nRet == CMSRET_SUCCESS) {
      if (nBurstType == BIT_LOADING_TX_UC)
         pu32BitLoading = &nodeStatus[0].txUc.bitLoading [0] ;
      else if (nBurstType == BIT_LOADING_RX_UC)
         pu32BitLoading = &nodeStatus[0].rxUc.bitLoading [0] ;
      else if (nBurstType == BIT_LOADING_RX_BC)
         pu32BitLoading = &nodeStatus[0].rxBc.bitLoading [0] ;
      else if (nBurstType == BIT_LOADING_RX_MAP)
         pu32BitLoading = &nodeStatus[0].rxMap.bitLoading [0] ;
      else if (nBurstType == BIT_LOADING_TX_BC)
         pu32BitLoading = &nodeCommonStatus.txBc.bitLoading [0] ;
      else 
         pu32BitLoading = &nodeCommonStatus.txMap.bitLoading [0] ;

      for (i=0, j=0, k=0;i<nLength;i++)
      {
         nData = pu32BitLoading [j] ;
         nData = (nData >> (k * 4)) & 0xf ;
         nData = LE32(nData);
         pRegisterData[i] = nData;
         k++ ;
         if (k == 8) {
            j++ ;
            k = 0 ;
         }
      }
      //printf("GetNode Bitloading pass \n") ;
    }
   else {

      for (i=0;i<nLength;i++)
      {
         nData = ((uint32_t) i % 8);        /* return dummy data */
         nData = LE32(nData);
         pRegisterData[i] = nData;
      }
      //printf("GetNode Bitloading fail \n") ;
   }

   Encode( (char*)pRegisterData, nSize, pReturn );
   SetParamStr(reqId, &pReturn);

   myfree1(pReturn);
   myfree1(pRegisterData);
   return SOAP_OK;
}

/****************************************************************************************/
/* GetPhyProfile(nNodeId, nBurstType)
   Inputs:
        nNodeId = 0-15  (16 for all nodes)
        nBurstType = 0 for "Tx Unicast", 1 for "Rx Unicast", 2 for "Rx Broadcast", 3 for "Rx Map,
            4 for "Tx Broadcast", 5 for "Tx Map"
   Outputs:
        structure containing NBAS, Preamble Type, CP, Tx Power, Rx Gain.
        Tx Power only valid for nBurstType=Tx types
        Rx Gain only valid for nBurstType=Rx types
*/
int GetPhyProfile(int reqId)
{
    char *pReturn;
    uint32_t nSize, nEncodeSize, nNodeId, nBurstType;
    uint32_t val;
   CmsRet nRet ;
   MoCA_NODE_STATUS_ENTRY nodeStatus [MoCA_MAX_NODES] ;
   MoCA_NODE_COMMON_STATUS_ENTRY nodeCommonStatus ;
   MoCA_NODE_EXTENDED_STATUS     *pStatus ;

    GetParamInt(reqId, 0, (int32_t*)&nNodeId);
    GetParamInt(reqId, 1, (int32_t*)&nBurstType);

    nSize = sizeof(SVCPHYPROFILE);
    nEncodeSize = (uint32_t) ((nSize*4/3) + 3);
    pReturn = (char*)mycalloc(nEncodeSize,1);
    if ( ( nEncodeSize % 4 ) != 0 )
        nEncodeSize += ( 4 - nEncodeSize % 4 ) + 1;

   nodeStatus[0].nodeId = nNodeId ;

   setContext(g_mocaInterface);

   if (nBurstType <= BIT_LOADING_RX_MAP) {
      nRet = MoCACtl2_GetNodeStatus (mocaCtx, &nodeStatus[0]) ;
   }
   else {
      UINT32   tblSize ;
      nRet = MoCACtl2_GetNodeTblStatus ( mocaCtx, &nodeStatus [0], &nodeCommonStatus, &tblSize ) ;
   }

   val = 0x0 ;

   if (nRet == CMSRET_SUCCESS) {
      if (nBurstType == BIT_LOADING_TX_UC)
         pStatus = &nodeStatus[0].txUc ;
      else if (nBurstType == BIT_LOADING_RX_UC)
         pStatus = &nodeStatus[0].rxUc ;
      else if (nBurstType == BIT_LOADING_RX_BC)
         pStatus = &nodeStatus[0].rxBc ;
      else if (nBurstType == BIT_LOADING_RX_MAP)
         pStatus = &nodeStatus[0].rxMap ;
      else if (nBurstType == BIT_LOADING_TX_BC)
         pStatus = &nodeCommonStatus.txBc ;
      else 
         pStatus = &nodeCommonStatus.txMap ;

      moCAPhyProfile.nBas = LE32(pStatus->nBas);
      moCAPhyProfile.preambleType = LE32(pStatus->preambleType);
      moCAPhyProfile.cp = LE32(pStatus->cp);
      moCAPhyProfile.txPower = LE32(pStatus->txPower);
      moCAPhyProfile.rxGain = LE32(pStatus->rxGain);
   }
   else {
      moCAPhyProfile.nBas = LE32(val);
      moCAPhyProfile.preambleType = LE32(val);
      moCAPhyProfile.cp = LE32(val);
      moCAPhyProfile.txPower = LE32(val);
      moCAPhyProfile.rxGain = LE32(val);
   }
    
    Encode( (char*)&moCAPhyProfile, nSize, pReturn);
    SetParamStr(reqId, &pReturn);

    myfree1(pReturn);
    return SOAP_OK;
}

/****************************************************************************************/
/* MoCAExecute(functionAddress, parameter0, parameter1, parameter2, parameter3)
   Inputs:
        functionAddress = MoCA MIPS address of function to execute 
        parameter0 - parameter3 = 4 parameters to pass to function to execute
   Outputs:
        return value from executing function 
*/
int MoCAExecute(int reqId)
{
   uint32_t nAddress, nParm0, nParm1, nParm2, nParm3;
   CmsRet nRet = CMSRET_SUCCESS;
   MoCA_CONFIG_PARAMS configParams ;
   BCMMoCA_STATUS bmStatus = MoCASTS_SUCCESS ;

   GetParamLong(reqId, 0, (void *)&nAddress);
   GetParamInt(reqId, 1, (int32_t*)&nParm0);
   GetParamInt(reqId, 2, (int32_t*)&nParm1);
   GetParamInt(reqId, 3, (int32_t*)&nParm2);
   GetParamInt(reqId, 4, (int32_t*)&nParm3);

   //printf("nAddress=%x, nParm0=%x, nParm1=%x, nParm2=%x, nParm3=%x\n", nAddress, nParm0, nParm1, nParm2,
         //nParm3) ;

   configParams.callFunc.funcAddr = nAddress ;
   configParams.callFunc.param1 = nParm0 ;
   configParams.callFunc.param2 = nParm1 ;
   
   setContext(g_mocaInterface);

   bmStatus = MoCACtl2_SetCfg (mocaCtx, &configParams, MoCA_CFG_PARAM_LAB_CALL_FUNC_MASK) ;

   if (bmStatus != MoCASTS_SUCCESS) {
      printf ("soap, MoCA call function fail. \n") ;
   }

   SetParamInt(reqId, nRet);

   return SOAP_OK;
}

/* This table was creating using a spreadsheet formula: =POWER(2,31)*(POWER(10,(A2/-10)))
   Where A2 is the SNR in DBs. The first entry represents the Hex equivalent of 0.5dB,
   the second represents 1.5dB and so on. */
static UINT32 moCASNRChart[ MoCA_MAX_SNR_IN_DB + 1] = 
{
   0x721482BF, 0x5A9DF7AB, 0x47FACCF0, 0x392CED8D, 0x2D6A866F, 0x241346F5, 0x1CA7D767, 0x16C310E3, 
   0x12149A5F, 0x0E5CA14C, 0x0B687379, 0x090FCBF7, 0x0732AE18, 0x05B7B15A, 0x048AA70B, 0x039B8718, 
   0x02DD958A, 0x0246B4E3, 0x01CEDC3C, 0x016FA9BA, 0x01240B8C, 0x00E7FACB, 0x00B8449C, 0x00925E89, 
   0x007443E7, 0x005C5A4F, 0x00495BC1, 0x003A4549, 0x002E4939, 0x0024C42C, 0x001D345A, 0x001732AD, 
   0x00126D42, 0x000EA30D, 0x000BA063, 0x00093C3B, 0x000755F9, 0x0005D3BA, 0x0004A0EC, 0x0003AD37,
   0
};

/****************************************************************************************/
/* getSnrDBFromHex
   Inputs: 
         hexSnr = hexadecimal SNR value returned from MoCA API
   Outputs:
         UINT32 of SNR value from 0 to 40

   This function searches the moCASNRChart for the smallest entry that less than the 
   passed in SNR value.
*/   
static UINT32 getSnrDBFromHex ( UINT32 hexSnr )
{
   UINT32 index = MoCA_MAX_SNR_IN_DB / 2; /* Start at halfway point */
   UINT32 upperBound, lowerBound;
   UINT32 found = 0;

   upperBound = MoCA_MAX_SNR_IN_DB;
   lowerBound = 0;

   if ( hexSnr > moCASNRChart[ 0 ])
      return ( 0 );

   /* Binary search */
   while ( found == 0 )
   {
      if ( (moCASNRChart[index] > hexSnr) && (moCASNRChart[index+1] <= hexSnr) )
      {
         //printf("Found SNR value for 0x%x: %u\n", hexSnr, (index + 1));
         found = 1;
      }
      else if ( moCASNRChart[index] >= hexSnr )
      {
         lowerBound = index;
         index += (upperBound - index + 1) / 2;
         //printf("SNR 0x%x: Moving to index %u, lowerBound = %u\n", hexSnr, index, lowerBound );
      }
      else
      {
         upperBound = index;
         index -= (index - lowerBound + 1) / 2;
         //printf("SNR 0x%x: Moving to index %u, upperBound = %u\n", hexSnr, index, upperBound );
      }
   }

   return ( index + 1 );
}

/****************************************************************************************/
/* GetSNRData()
   Inputs:
        nNodeId = 0-7
        nLength = 256*8 (requesting 256*8 data points, 32 bits per point, 256 points per probe, total of 8 probes)
   Outputs:
        pRegisterData[] containing 256*8 SNR points(32 bits value per SNR point),
        where each SNR point represents each sub carrier, in the range of 0-40.

        There are a total of 4 or 8 probes; 4 probes during admission, or 8 probes during a LMO event.
        Each probe will contain 256 SNR points * 32 bits = 1K of data returned. So a total of 8K
        will be returned for 8 probes. For 4 probes data, make sure to return 4 probes of data
        followed by 4 probes of 0 values(ie always returns 8K data).
*/
int GetSNRData(int reqId)
{
   char *pReturn;
   uint32_t nSize, nData, nEncodeSize, nLength, i, nNodeId;
   uint32_t* pRegisterData;
   SVCSNRCONFIG snrConfig ;
   MoCA_CONFIG_PARAMS configParams ;
   BCMMoCA_STATUS bmStatus = MoCASTS_SUCCESS ;
   MoCA_SNR_DATA   snrData ;
   UINT32          data [256*8] ;

   GetParamInt(reqId, 0, (int32_t*)&nNodeId);
   GetParamInt(reqId, 1, (int32_t*)&nLength);
   nSize = nLength * 4;
   nEncodeSize = (uint32_t)( (nSize*4/3) + 3);

   //printf("nNodeId=%x, nLength=%x \n", nNodeId, nLength) ;

   snrConfig.nNodeId = nNodeId ;
   snrConfig.nLength = nLength ;

   /* Allocate memory */
   pRegisterData = (uint32_t*)mycalloc(nLength, 4);
   pReturn = (char*)mycalloc(nEncodeSize, 1);

   if ( ( nEncodeSize % 4 ) != 0 )
      nEncodeSize += ( 4 - nEncodeSize % 4 ) + 1;

   setContext(g_mocaInterface);

   if (memcmp (&snrConfig, &moCASNRConfig, sizeof (SVCSNRCONFIG)) != 0) {
      /* Configure the SNR GRAPH set with MoCA and wait before reading the data
       * */
      configParams.MoCASnrGraphSetNodeId = nNodeId ;
      bmStatus = MoCACtl2_SetCfg (mocaCtx, &configParams,MoCA_CFG_PARAM_SNR_GRAPH_SET_MASK ) ;
      if (bmStatus == MoCASTS_SUCCESS)
         memcpy (&moCASNRConfig, &snrConfig, sizeof (SVCSNRCONFIG)) ;
   }

   /* Get the SNR data from the core */

   if (bmStatus == MoCASTS_SUCCESS) {
      snrData.pData = (UINT8 *) &data [0];
      snrData.probe = MoCA_MAX_PROBES ;
      bmStatus = MoCACtl2_GetSNRData (mocaCtx, &snrData) ;

      if (bmStatus == MoCASTS_SUCCESS) {
         for (i=0;i<nLength;i++) {
            if ( MoCA_IS_VALID_SUBCARRIER( i & 0xFF ) ) {
               nData = getSnrDBFromHex(data[i]);
            }
            else {
               nData = 0;
            }
            
            nData = LE32(nData);
            pRegisterData[i] = nData;
         }
      }
   }

   if (bmStatus != MoCASTS_SUCCESS) {
      printf ("SNR dummy \n") ;
      for (i=0;i<nLength;i++)
      {
         /* return dummy data */
         if (i < 256)       /* probe 1*/
            nData = (uint32_t)40 - ((uint32_t) (i % 5));
         else if (i < 512)  /* probe 2*/
            nData = (uint32_t)35 - ((uint32_t) (i % 5));
         else if (i < 768)  /* probe 3*/
            nData = (uint32_t)30 - ((uint32_t) (i % 5));
         else if (i < 1024) /* probe 4*/
            nData = (uint32_t)25 - ((uint32_t) (i % 5));
         else if (i < 1280) /* probe 5*/
            nData = (uint32_t)20 - ((uint32_t) (i % 5));
         else if (i < 1536) /* probe 6*/
            nData = (uint32_t)15 - ((uint32_t) (i % 5));
         else if (i < 1792) /* probe 7*/
            nData = (uint32_t)10 - ((uint32_t) (i % 5));
         else               /* probe 8*/
            nData = (uint32_t)5 - ((uint32_t) (i % 5));

         nData = LE32(nData);
         pRegisterData[i] = nData;
      }
   }

   Encode( (char*)pRegisterData, nSize, pReturn );
   SetParamStr(reqId, &pReturn);

   myfree1(pReturn);
   myfree1(pRegisterData);
   return SOAP_OK;
}

/****************************************************************************************/
/* GetSNRAveData()
   Inputs:
      nNodeId = 0-7
        nLength = 256 (requesting 256 data points, 32 bit per point)
   Outputs:
        pRegisterData[] containing 256 SNR points(32 bit value) in the range of 0-40, total of 1K returned.
        Each point is the averaging value of all 8 probes.
*/
int GetSNRAveData(int reqId)
{
   char *pReturn;
   uint32_t nSize, nData, nEncodeSize, nLength, i, nNodeId ;
   uint32_t* pRegisterData;
   SVCSNRAVECONFIG snrAveConfig ;
   MoCA_CONFIG_PARAMS configParams ;
   BCMMoCA_STATUS bmStatus = MoCASTS_SUCCESS ;
   MoCA_SNR_DATA   snrData ;
   UINT32          data [256*8] ;

   GetParamInt(reqId, 0, (int32_t*)&nNodeId);
   GetParamInt(reqId, 1, (int32_t*)&nLength);
   nSize = nLength * 4;
   nEncodeSize = (uint32_t)( (nSize*4/3) + 3);

   //printf("nNodeId=%x, nLength=%x \n", nNodeId, nLength) ;

   snrAveConfig.nNodeId = nNodeId ;
   snrAveConfig.nLength = nLength ;

   /* Allocate memory */
   pRegisterData = (uint32_t*)mycalloc(nLength, 4);
   pReturn = (char*)mycalloc(nEncodeSize, 1);

   if ( ( nEncodeSize % 4 ) != 0 )
      nEncodeSize += ( 4 - nEncodeSize % 4 ) + 1;

   setContext(g_mocaInterface);

   if (memcmp (&snrAveConfig, &moCASNRAveConfig, sizeof (SVCSNRAVECONFIG)) != 0) {
      /* Configure the SNR GRAPH set with MoCA and wait before reading the data
       * */
      configParams.MoCASnrGraphSetNodeId = nNodeId ;
      bmStatus = MoCACtl2_SetCfg (mocaCtx, &configParams,MoCA_CFG_PARAM_SNR_GRAPH_SET_MASK ) ;
      if (bmStatus == MoCASTS_SUCCESS)
         memcpy (&moCASNRAveConfig, &snrAveConfig, sizeof (SVCSNRAVECONFIG)) ;
   }

   /* Get the SNR data from the core */

   if (bmStatus == MoCASTS_SUCCESS) {
      snrData.pData = (UINT8 *) &data [0];
      snrData.probe = MoCA_MAX_PROBES ;
      bmStatus = MoCACtl2_GetSNRData (mocaCtx, &snrData) ;

      if (bmStatus == MoCASTS_SUCCESS) {
         for (i=0;i<nLength;i++) {
            if ( MoCA_IS_VALID_SUBCARRIER( i ) ) {               
               nData = (data [i]+ data [256+i] + data [(2*256)+i] + data [(3*256)+i] +
                        data [(4*256)+i] + data [(5*256)+i] + data [(6*256)+i] 
                        + data[(7*256)+i]) ;
               nData  /= 8 ;
               nData = getSnrDBFromHex(nData);
            }
            else {
               nData = 0;
            }
            nData = LE32(nData);
            pRegisterData[i] = nData ;
         }
      }
   }


   if (bmStatus != MoCASTS_SUCCESS) {
      printf ("SNR Ave dummy \n") ;
      for (i=0;i<nLength;i++)
      {
         nData = ((uint32_t) i % 40);       /* return dummy data */
         nData = LE32(nData);
         pRegisterData[i] = nData;
      }
   }

   Encode( (char*)pRegisterData, nSize, pReturn );
   SetParamStr(reqId, &pReturn);

   myfree1(pReturn);
   myfree1(pRegisterData);
   return SOAP_OK;
}

/****************************************************************************************/
/* long SetAnyTimeConfig(char *key, char *value) */
int SetAnyTimeConfig(int reqId)
{
    long retVal, lVal;
    float fVal ;
    char tmp[512];
    char **key = allocArrayStr(1);
    char **value = allocArrayStr(1);
    MoCA_CONFIG_PARAMS  configParams ;
    CmsRet              nRet ;
    UINT64              configMask = 0x0LL ;
    MoCA_TRACE_PARAMS   traceParams ;
    UINT32              i;


    GetParamStr(reqId, 0, key);
    GetParamStr(reqId, 1, value);
    //printf("key=%s, value=%s\n", *key, *value);

    setContext(g_mocaInterface);

    memset (&configParams, 0, sizeof (MoCA_CONFIG_PARAMS)) ;
    nRet = MoCACtl2_GetCfg (mocaCtx, &configParams, MoCA_CFG_PARAM_ALL_MASK) ;

    if (nRet == CMSRET_SUCCESS) {
 
      if (strcmp(*key, "MAX_FRAME_SIZE") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_MAX_FRAME_SIZE_MASK ;
         configParams.maxFrameSize = lVal ;
      }
      else if (strcmp(*key, "MAX_TRANSMIT_TIME") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_MAX_TRANS_TIME_MASK ;
         configParams.maxTransmitTime = lVal ;
      }
      else if (strcmp(*key, "MIN_BW_ALARM_THRESHOLD") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_MIN_BW_ALARM_THRE_MASK ;
         configParams.minBwAlarmThreshold = lVal ;
      }
      else if (strcmp(*key, "OOO_LMO") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_OUT_OF_ORDER_LMO_MASK ;
         configParams.outOfOrderLmo = lVal ;
      }
      else if (strcmp(*key, "CONTINUOUS_IE_RR_INSERT") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_CONT_IE_RR_INS_MASK ;
         configParams.continuousIERRInsert = lVal ;
      }
      else if (strcmp(*key, "CONTINUOUS_IE_MAP_INSERT") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_CONT_IE_MAP_INS_MASK ;
         configParams.continuousIEMapInsert = lVal ;
      }
      else if (strcmp(*key, "MAX_PKT_AGGR") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_MAX_PKT_AGGR_MASK ;
         configParams.maxPktAggr = lVal ;
      }
      else if (strcmp(*key, "PMK_EXCHANGE_INTERVAL") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_PMK_EXCHG_INTVL_MASK ;
         configParams.pmkExchangeInterval = lVal ;
      }
      else if (strcmp(*key, "TEK_EXCHANGE_INTERVAL") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_TEK_EXCHG_INTVL_MASK ;
         configParams.tekExchangeInterval = lVal ;
      }
      else if (strcmp(*key, "RESERVATION_HIGH") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_PRIO_ALLOCATIONS_MASK ;
         configParams.prioAllocation.resvHigh = lVal ;
      }
      else if (strcmp(*key, "RESERVATION_MEDIUM") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_PRIO_ALLOCATIONS_MASK ;
         configParams.prioAllocation.resvMed = lVal ;
      }
      else if (strcmp(*key, "RESERVATION_LOW") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_PRIO_ALLOCATIONS_MASK ;
         configParams.prioAllocation.resvLow = lVal ;
      }
      else if (strcmp(*key, "LIMITATION_HIGH") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_PRIO_ALLOCATIONS_MASK ;
         configParams.prioAllocation.limitHigh = lVal ;
      }
      else if (strcmp(*key, "LIMITATION_MEDIUM") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_PRIO_ALLOCATIONS_MASK ;
         configParams.prioAllocation.limitMed = lVal ;
      }
      else if (strcmp(*key, "LIMITATION_LOW") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_PRIO_ALLOCATIONS_MASK ;
         configParams.prioAllocation.limitLow = lVal ;
      }
      else if (strcmp(*key, "SNR_MARGIN") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_MASK ;
         configParams.snrMargin = fVal*2 ;
      }
      else if (strcmp(*key, "SNR_MARGIN_0") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[0]  = fVal*2 ; 
      }
      else if (strcmp(*key, "SNR_MARGIN_1") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[1]  = fVal*2 ; 
      }
      else if (strcmp(*key, "SNR_MARGIN_2") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[2]  = fVal*2 ; 
      }
      else if (strcmp(*key, "SNR_MARGIN_3") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[3]  = fVal*2 ; 
      }
      else if (strcmp(*key, "SNR_MARGIN_4") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[4]  = fVal*2 ; 
      }
      else if (strcmp(*key, "SNR_MARGIN_5") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[5]  = fVal*2 ; 
      }
      else if (strcmp(*key, "SNR_MARGIN_6") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[6]  = fVal*2 ; 
      }
      else if (strcmp(*key, "SNR_MARGIN_7") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[7]  = fVal*2 ; 
      }
      else if (strcmp(*key, "SNR_MARGIN_8") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[8]  = fVal*2 ; 
      }
      else if (strcmp(*key, "SNR_MARGIN_9") == 0)
      {
         fVal = atof(*value);
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
         configParams.snrMarginOffset[9]  = fVal*2 ; 
      }
      else if (strcmp(*key, "NOMINAL_MAP_CYCLE") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_MIN_MAP_CYCLE_MASK ;
         configParams.minMapCycle = lVal ;
      }
      else if (strcmp(*key, "MAX_INC_MAP_CYCLE") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_MAX_MAP_CYCLE_MASK ;
         configParams.maxMapCycle = lVal ;
      }
      else if (strcmp(*key, "TARGET_PHY_RATE_QAM128") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_TARGET_PHY_RATE_QAM128_MASK ;
         configParams.targetPhyRateQAM128 = lVal ;
      }
      else if (strcmp(*key, "TARGET_PHY_RATE_QAM256") == 0)
      {
         lVal = atol(*value);
         configMask |= MoCA_CFG_PARAM_TARGET_PHY_RATE_QAM256_MASK ;
         configParams.targetPhyRateQAM256 = lVal ;
      }
      else if (strcmp(*key, "MOCA_CORE_TRACE_ENABLE") == 0)
      {
         lVal = atol(*value);

         nRet = MoCACtl2_GetTraceConfig (mocaCtx, &traceParams) ;
         if (nRet == CMSRET_SUCCESS) {
            if (lVal == 0)
               traceParams.traceLevel &= ~MOCA_TRC_LEVEL_CORE ;
            else
               traceParams.traceLevel |= MOCA_TRC_LEVEL_CORE ;

            nRet = MoCACtl2_SetTraceConfig (mocaCtx, &traceParams) ;
         }
         goto _skip ;
      }
      else if (strcmp(*key, "MAX_CONSTELLATION_NODE") == 0)
      {
         maxConstNodeId = atol(*value);
         // Don't set the config mask, only do the set when 
         // MAX_CONSTELLATION_INFO is set.
      }
      else if (strcmp(*key, "MAX_CONSTELLATION_INFO") == 0)
      {
         maxConstInfo = atol(*value) + 1;
         configMask |= MoCA_CFG_PARAM_MAX_CONSTELLATION_MASK;
         if (maxConstNodeId == -1)
         {
            for (i = 0; i < MoCA_MAX_NODES; i++)
            {
               configParams.constellation[i] = maxConstInfo;
            }
         }
         else if (maxConstNodeId < MoCA_MAX_NODES)
         {
            configParams.constellation[maxConstNodeId] = maxConstInfo;
         }
         else
         {
            printf("Error, SetAnyTimeConfig failed, invalid node ID %i\n",
               maxConstNodeId);
            nRet = CMSRET_INVALID_PARAM_VALUE ;
            goto _skip ;
         }
      }
      else
      {
         printf("Error, SetAnyTimeConfig failed, invalid key (%s) specified\n", *key);
         nRet = CMSRET_INVALID_PARAM_TYPE ;
         goto _skip ;
      }

      if (configMask != 0)
         nRet = MoCACtl2_SetCfg (mocaCtx, &configParams, configMask) ;
   } /* bmStatus == SUCCESS */

_skip :
   if (nRet != CMSRET_SUCCESS) {
      retVal = E_DISPATCH_INVALIDPARAM;
    }
   else 
      retVal = 0;

    AddResp(reqId, _ltoa(retVal, tmp, 10), "long", "", "", 0);
    freeArrayStr(key, 1);
    freeArrayStr(value, 1);
    return SOAP_OK;
}

/****************************************************************************************/
/* long GetAnyTimeConfig(char *key, out char *value) */
int GetAnyTimeConfig(int reqId)
{
    char **key = allocArrayStr(1);
   char **retStr = allocArrayStr(1);
   MoCA_CONFIG_PARAMS  configParams ;
   CmsRet              nRet ;
   MoCA_TRACE_PARAMS   traceParams ;

    GetParamStr(reqId, 0, key);

   setContext(g_mocaInterface);
   
   memset (&configParams, 0, sizeof (MoCA_CONFIG_PARAMS)) ;
   nRet = MoCACtl2_GetCfg (mocaCtx, &configParams, MoCA_CFG_PARAM_ALL_MASK) ;

   if (nRet == CMSRET_SUCCESS) {

      //printf ("Get Config : nRet = %d \n", nRet) ;

      if (strcmp(*key, "MAX_FRAME_SIZE") == 0)
      {
         sprintf (*retStr, "%u", configParams.maxFrameSize) ;
      }
      else if (strcmp(*key, "MAX_TRANSMIT_TIME") == 0)
      {
         sprintf (*retStr, "%u", configParams.maxTransmitTime) ;
      }
      else if (strcmp(*key, "MIN_BW_ALARM_THRESHOLD") == 0)
      {
         sprintf (*retStr, "%u", configParams.minBwAlarmThreshold) ;
      }
      else if (strcmp(*key, "OOO_LMO") == 0)
      {
         sprintf (*retStr, "%u", configParams.outOfOrderLmo) ;
      }
      else if (strcmp(*key, "CONTINUOUS_IE_RR_INSERT") == 0)
      {
         sprintf (*retStr, "%u", configParams.continuousIERRInsert) ;
      }
      else if (strcmp(*key, "CONTINUOUS_IE_MAP_INSERT") == 0)
      {
         sprintf (*retStr, "%u", configParams.continuousIEMapInsert) ;
      }
      else if (strcmp(*key, "MAX_PKT_AGGR") == 0)
      {
         sprintf (*retStr, "%u", configParams.maxPktAggr) ;
      }
      else if (strcmp(*key, "PMK_EXCHANGE_INTERVAL") == 0)
      {
         sprintf (*retStr, "%u", configParams.pmkExchangeInterval) ;
      }
      else if (strcmp(*key, "TEK_EXCHANGE_INTERVAL") == 0)
      {
         sprintf (*retStr, "%u", configParams.tekExchangeInterval) ;
      }
      else if (strcmp(*key, "RESERVATION_HIGH") == 0)
      {
         sprintf (*retStr, "%u", configParams.prioAllocation.resvHigh) ;
      }
      else if (strcmp(*key, "RESERVATION_MEDIUM") == 0)
      {
         sprintf (*retStr, "%u", configParams.prioAllocation.resvMed) ;
      }
      else if (strcmp(*key, "RESERVATION_LOW") == 0)
      {
         sprintf (*retStr, "%u", configParams.prioAllocation.resvLow) ;
      }
      else if (strcmp(*key, "LIMITATION_HIGH") == 0)
      {
         sprintf (*retStr, "%u", configParams.prioAllocation.limitHigh) ;
      }
      else if (strcmp(*key, "LIMITATION_MEDIUM") == 0)
      {
         sprintf (*retStr, "%u", configParams.prioAllocation.limitMed) ;
      }
      else if (strcmp(*key, "LIMITATION_LOW") == 0)
      {
         sprintf (*retStr, "%u", configParams.prioAllocation.limitLow) ;
      }
      else if (strcmp(*key, "SNR_MARGIN") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMargin*0.5)) ;
      }
      else if (strcmp(*key, "SNR_MARGIN_0") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[0]*0.5));
      }
      else if (strcmp(*key, "SNR_MARGIN_1") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[1]*0.5));
      }
      else if (strcmp(*key, "SNR_MARGIN_2") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[2]*0.5));
      }
      else if (strcmp(*key, "SNR_MARGIN_3") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[3]*0.5));
      }
      else if (strcmp(*key, "SNR_MARGIN_4") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[4]*0.5));
      }
      else if (strcmp(*key, "SNR_MARGIN_5") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[5]*0.5));
      }
      else if (strcmp(*key, "SNR_MARGIN_6") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[6]*0.5));
      }
      else if (strcmp(*key, "SNR_MARGIN_7") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[7]*0.5));
      }
      else if (strcmp(*key, "SNR_MARGIN_8") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[8]*0.5));
      }
      else if (strcmp(*key, "SNR_MARGIN_9") == 0)
      {
         snprintf (*retStr, 80, "%f", (configParams.snrMarginOffset[9]*0.5));
      }
      else if (strcmp(*key, "NOMINAL_MAP_CYCLE") == 0)
      {
         sprintf (*retStr, "%u", configParams.minMapCycle) ;
      }
      else if (strcmp(*key, "MAX_INC_MAP_CYCLE") == 0)
      {
         sprintf (*retStr, "%u", configParams.maxMapCycle) ;
      }
      else if (strcmp(*key, "MAX_DEC_MAP_CYCLE") == 0)
      {
         sprintf (*retStr, "%u", configParams.maxMapCycle) ;
      }
      else if (strcmp(*key, "TARGET_PHY_RATE_QAM128") == 0)
      {
         sprintf (*retStr, "%u", configParams.targetPhyRateQAM128) ;
      }
      else if (strcmp(*key, "TARGET_PHY_RATE_QAM256") == 0)
      {
         sprintf (*retStr, "%u", configParams.targetPhyRateQAM256) ;
      }
      else if (strcmp(*key, "MAX_CONSTELLATION_NODE") == 0)
      {
         sprintf (*retStr, "%u", maxConstNodeId) ;
      }
      else if (strcmp(*key, "MAX_CONSTELLATION_INFO") == 0)
      {
         sprintf (*retStr, "%u", (configParams.constellation[maxConstNodeId] - 1)) ;
      }
      else if (strcmp(*key, "MOCA_CORE_TRACE_ENABLE") == 0)
      {
         nRet = MoCACtl2_GetTraceConfig (mocaCtx, &traceParams) ;
         if (nRet == CMSRET_SUCCESS) {
            if (traceParams.traceLevel & MOCA_TRC_LEVEL_CORE)
               sprintf (*retStr, "%u", 1) ;
            else
               sprintf (*retStr, "%u", 0) ;
         }
      }
      else
      {
         printf("Error, GetAnyTimeConfig failed, invalid key (%s) specified\n", *key);
         nRet = CMSRET_INVALID_PARAM_TYPE ;
      }
   } /* nRet == SUCCESS */

   if (nRet == CMSRET_SUCCESS) {
      SetParamStr(reqId, retStr);
   }
   else {
      strcpy(*retStr, "1"); // E_DISPATCH_INVALIDPARAM
      SetParamStr(reqId, retStr);
   }

   freeArrayStr(key, 1);
   freeArrayStr(retStr,1);
   return SOAP_OK;
}
/****************************************************************************************/

