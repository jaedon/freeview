/*
<:copyright-broadcom 
 
 Copyright (c) 2008 Broadcom Corporation 
 All Rights Reserved 
 No portions of this material may be reproduced in any form without the 
 written permission of: 
          Broadcom Corporation 
          5300 California Avenue
          Irvine, California 92617 
 All information contained in this document is Broadcom Corporation 
 company private, proprietary, and trade secret. 
 
:>
*******************************************************************************************/

#ifndef __MOCASVC_H__
#define __MOCASVC_H__

#define MOCAVERSION         "1.8" // MMP 1.8
#define E_DISPATCH_INVALIDPARAM     1
#define SOAP_OK             0
#define SERVICENAME         "moca"
#define BUFFERSIZE          70
#define MoCA_MAX_SNR_IN_DB  40



#define BURST_TYPE_UC     0
#define BURST_TYPE_MAP    1
#define BURST_TYPE_BBL    2
#define BURST_TYPE_BEACON 3

#define MMP_BURST_TYPE_UC     7
#define MMP_BURST_TYPE_MAP    6
#define MMP_BURST_TYPE_BBL    8
#define MMP_BURST_TYPE_BEACON 1

#define MMP_BURST_TYPE(x)    ((x==BURST_TYPE_UC) ? MMP_BURST_TYPE_UC :        \
                              ((x==BURST_TYPE_MAP) ? MMP_BURST_TYPE_MAP :        \
                               ((x==BURST_TYPE_BBL) ? MMP_BURST_TYPE_BBL : MMP_BURST_TYPE_BEACON))) ;

#define ACMT_SYM_NUM_LAST_SYM          0
#define ACMT_SYM_NUM_SYM_BEFORE_LAST   1

#define MMP_ACMT_SYM_NUM_LAST_SYM            1
#define MMP_ACMT_SYM_NUM_SYM_BEFORE_LAST     2

#define MMP_ACMT_SYM_NUM(x)   ((x==ACMT_SYM_NUM_LAST_SYM) ? MMP_ACMT_SYM_NUM_LAST_SYM :   \
                               MMP_ACMT_SYM_NUM_SYM_BEFORE_LAST)

#define MoCA_IS_VALID_SUBCARRIER( x ) ((((x) > 3) && ((x) < 116)) || (((x) > 140) && ((x) < 253)))

#define BIT_LOADING_TX_UC     0
#define BIT_LOADING_RX_UC     1
#define BIT_LOADING_RX_BC     2
#define BIT_LOADING_RX_MAP    3
#define BIT_LOADING_TX_BC     4  /* All nodes */
#define BIT_LOADING_TX_MAP    5  /* All nodes */


typedef struct
{
    int mem_fd;
    char *mmap_addr;
    unsigned long addr;
    unsigned int size;
    unsigned int offset;
} MAP_INFO;


typedef struct
{
    uint32_t VendorId;
    uint32_t HardwareVersion;
    uint32_t SoftwareVersion;
    uint32_t SelfMoCAVersion;
    uint32_t NetworkMoCAVersion;
    uint32_t QAM256Supported;
    uint32_t NetworkStatus;
    uint32_t LinkStatus;
    uint32_t ConnectedNodes;
    uint32_t NodeId;
    uint32_t NCNodeId;
    uint32_t CoreUpTime;
    uint32_t LinkUpTime;
    uint32_t BackupNCNodeId;
    uint32_t RFFreq;
    uint32_t BWStatus;
    uint32_t nodesUsableBitmask;
    uint32_t networkTabooMask;
    uint32_t networkTabooStart;
    uint32_t txGcdPowerReduction;
    uint32_t pqosEgressNumFlows;
    uint32_t macAddrLow ;
    uint32_t macAddrHi ;   /* High bytes padded with 0 */
    uint32_t isNC ;
    uint32_t driverUpTime ;
    uint32_t linkResetCount ;
    uint32_t lmoInfoAvailable ;
} SVCMOCASTATUS;

typedef struct
{
     uint32_t InUcPkts;
     uint32_t InDiscardPktsEcl;
     uint32_t InDiscardPktsMac;
     uint32_t InUnKnownPkts;
     uint32_t InMcPkts;
     uint32_t InBcPkts;
     uint32_t InOctets_hi;
     uint32_t InOctets_low;
     uint32_t OutUcPkts;
     uint32_t OutDiscardPkts;
     uint32_t OutBcPkts;
     uint32_t OutOctets_hi;
     uint32_t OutOctets_low;
     uint32_t NCHandOffs;
     uint32_t NCBackups;

     uint32_t RxMapPkts;        // Extended statistics starts here onwards
     uint32_t RxBeacons;
     uint32_t RxControlPkts;
     uint32_t TxBeacons;
     uint32_t TxMaps;
     uint32_t TxLCS;
     uint32_t ResyncAttempts;
     uint32_t GMIITxBufFull;
     uint32_t MoCARxBufFull;
     uint32_t ThisHandoffs;
     uint32_t ThisBackups;
} SVCMOCASTATISTICS;

typedef struct 
{
   uint32_t ncMode;
   uint32_t autoNetworkSearch;
   uint32_t privacyEnable;
   uint32_t txPwrCtlEnable;
   uint32_t continousPwrTxMode;
   uint32_t lof;
   int32_t  maxTxPowerBeacons;
   int32_t  maxTxPowerPackets;   
   uint32_t nwSearchMask;
   uint32_t passwordSize;
   char password[20];
   uint32_t multicastMode;
   uint32_t labMode;
   uint32_t tabooStartChan;
   uint32_t boMode;
   uint32_t mrNonDefSeqNum;
   uint32_t rfType;
   uint32_t tabooChanMask;
   int32_t  padPower;
   uint32_t operatingVersion ;
   uint32_t preferedNC ;
   uint32_t mocaLoopbackEn;
   uint32_t res0;
   uint32_t beaconChannel;
   uint32_t res1;
   uint32_t res2;
   uint32_t res3;
   uint32_t res4;
   uint32_t res5;   
} SVCMOCASTART;

typedef struct
{
    uint32_t nBas;
    uint32_t preambleType;
    uint32_t cp;
    int32_t txPower;
    uint32_t rxGain;
} SVCPHYPROFILE;


typedef struct
{
    uint32_t nNodeId;
    uint32_t nACMTSymbol;
    uint32_t nRxBurstType;
    int32_t  nDisplayMode;
    uint32_t nLength;
} SVCIQCONFIG;

typedef struct
{
    uint32_t nNodeId;
    uint32_t nLength;
} SVCSNRCONFIG;

typedef struct
{
    uint32_t nNodeId;
    uint32_t nLength;
} SVCSNRAVECONFIG;



int MoCAHelp(int reqId);
int MoCAVersion(int reqId);
int ResetStatistics(int reqId);
int GetStatus(int reqId);
int GetStatistics(int reqId);
int MoCAStart(int reqId);
int MoCAStop(int reqId);
int GetIQData(int reqId);
int GetIRData(int reqId);
int GetBLData(int reqId);
int GetPhyProfile(int reqId);
int MoCAExecute(int reqId);
int GetSNRData(int reqId);
int GetSNRAveData(int reqId);
int SetAnyTimeConfig(int reqId);
int GetAnyTimeConfig(int reqId);

/****************************************************************************************/

#endif

