/***************************************************************************
 *     Copyright (c) 2003-2008, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 * $brcm_Workfile: rdcSvc.c $
 * $brcm_Revision: Hydra_Software_Devel/1 $
 * $brcm_Date: 5/20/08 9:29p $
 *
 * Module Description:
 *
 * Revision History:
 *
 * $brcm_Log: /TestTools/CSoapServer/93563/linux/rdcSvc.c
 * 
 ***************************************************************************/

#include "stdio.h"
#include "SoapMain.h"
#include "SoapUtil.h"

#define RDC_SERVICE "rdcsvc"

int SetRdcBlockOut(int reqId)
{
    SetParamLong(reqId, E_SOAPFAIL);    
    return 0;
}

int GetRdcBlockOut(int reqId)
{
    SetParamLong(reqId, E_SOAPFAIL);    
    return 0;
}

void RdcServiceInitialize(void)
{
    /* Register Sevices */
    RegisterMethod(RDC_SERVICE, "SetRdcBlockOut", 3, "", "long", "", &SetRdcBlockOut);
    RegisterMethod(RDC_SERVICE, "GetRdcBlockOut", 1, "", "string", "", &GetRdcBlockOut);
}


