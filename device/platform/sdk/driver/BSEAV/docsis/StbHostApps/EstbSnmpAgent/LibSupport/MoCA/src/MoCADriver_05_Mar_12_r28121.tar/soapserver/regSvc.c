/*
<:copyright-broadcom 
 
 Copyright (c) 2008 Broadcom Corporation 
 All Rights Reserved 
 No portions of this material may be reproduced in any form without the 
 written permission of: 
          Broadcom Corporation 
          5300 California Avenue
          Irvine, California 92617 
 All information contained in this document is Broadcom Corporation 
 company private, proprietary, and trade secret. 
 
:>
*******************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <error.h>
#include <stdint.h>
#include <sys/mman.h>
#include "SoapMain.h"
#include "SoapUtil.h"

#define REG_SERVICE "regsvc"

#define DEV_WR(addr, data) do { \
	*((volatile uint32_t *)(addr)) = data; \
	} while(0)
#define DEV_RD(addr) (*((volatile uint32_t *)(addr)))

#define BYTE_WR(addr, data) do { \
	*((volatile uint8_t *)(addr)) = data; \
	} while(0)
#define BYTE_RD(addr) (*((volatile uint8_t *)(addr)))

#ifdef __LITTLE_ENDIAN
#define LE32(x)			(x)
#else
#define LE32(x) \
({ \
	uint32_t __x = (x); \
	((uint32_t)( \
		(((uint32_t)(__x) & (uint32_t)0x000000ffUL) << 24) | \
		(((uint32_t)(__x) & (uint32_t)0x0000ff00UL) <<  8) | \
		(((uint32_t)(__x) & (uint32_t)0x00ff0000UL) >>  8) | \
		(((uint32_t)(__x) & (uint32_t)0xff000000UL) >> 24) )); \
})
#endif

static uintptr_t map_phys(uintptr_t addr)
{
	static uintptr_t base = 0xffffffff;
	static int fd = -1;
	static int pagesize = 0, pagemask;
	static void *mapping;

	if(fd == -1) {
		fd = open("/dev/mem", O_RDWR | O_SYNC);
		if(fd < 0) {
			printf("can't open /dev/mem: %s\n", strerror(errno));
			exit(1);
		}
		pagesize = getpagesize();
		pagemask = ~(pagesize - 1);
	}

	if((addr & pagemask) == (base & pagemask))
		return((uintptr_t)mapping + (addr & ~pagemask));
	
	if(mapping)
		munmap(mapping, pagesize);
	base = addr & pagemask;

	mapping = mmap(NULL, pagesize, (PROT_READ | PROT_WRITE),
					MAP_SHARED, fd, base);
	if(mapping == (void *)-1) {
		printf("mmap failed: %s\n", strerror(errno));
		exit(1);
	}
	return((uintptr_t)mapping + (addr & ~pagemask));
}

/*************************************************************************/

int ReadRegister(int reqId)
{
#if 1
	unsigned int addr;
	uintptr_t mapping;

	GetParamInt(reqId, 0, (int *)&addr);
	addr &= ~3;

	mapping = map_phys(addr);
	if(mapping) {
		SetParamLong(reqId, DEV_RD(mapping));
		return(SOAP_OK);
	} else {
		return(E_SOAPFAIL);
	}
#else
	/* 7420 test */
	unsigned int addr;

	GetParamInt(reqId, 0, (int *)&addr);
	if(addr == 0x10000000 || addr == 0x10404000)
		SetParamLong(reqId, 0x74200000);
	else
		SetParamLong(reqId, 0);
	return(SOAP_OK);
#endif
}

int WriteRegister(int reqId)
{
	unsigned int addr, data;
	uintptr_t mapping;

	GetParamInt(reqId, 0, (int *)&addr);
	GetParamInt(reqId, 1, (int *)&data);
	addr &= ~3;

	mapping = map_phys(addr);
	if(mapping) {
		DEV_WR(mapping, data);
		SetParamLong(reqId, SOAP_OK);
		return(SOAP_OK);
	} else {
		SetParamLong(reqId, E_SOAPFAIL);
		return(E_SOAPFAIL);
	}
}

int ReadRegisterCollection(int reqId)
{
	unsigned int count, i;
	uint32_t *addr_list, *data_list;
	char *base64;

	GetParamInt(reqId, 0, (int *)&count);

	addr_list = (void *)mycalloc(count, sizeof(uint32_t));
	if(! addr_list) {
		printf("can't allocate memory for %d addresses\n", count);
		return(E_SOAPFAIL);
	}
	data_list = (void *)mycalloc(count, sizeof(uint32_t));
	if(! data_list) {
		printf("can't allocate memory for %d data results\n", count);
		myfree1(addr_list);
		return(E_SOAPFAIL);
	}
	base64 = (void *)mycalloc(count, sizeof(uint32_t) * 2);
	if(! base64) {
		printf("can't allocate memory for base64 string\n");
		myfree1(addr_list);
		myfree1(data_list);
		return(E_SOAPFAIL);
	}

	GetParamStr(reqId, 1, &base64);
	Decode(base64, (char *)addr_list, count * sizeof(uint32_t));

	for(i = 0; i < count; i++) {
		uintptr_t addr = LE32(addr_list[i]), mapping;
		mapping = map_phys(addr);
		if(mapping)
			data_list[i] = LE32(DEV_RD(mapping));
	}

	Encode((char *)data_list, count * sizeof(uint32_t), base64);
	SetParamStr(reqId, &base64);

	myfree1(base64);
	myfree1(addr_list);
	myfree1(data_list);

	return(SOAP_OK);
}

int WriteRegisterCollection(int reqId)
{
	unsigned int count, i;
	uint32_t *addr_list, *data_list;
	char *base64;

	GetParamInt(reqId, 0, (int *)&count);

	addr_list = (void *)mycalloc(count, sizeof(uint32_t));
	if(! addr_list) {
		printf("can't allocate memory for %d addresses\n", count);
		return(E_SOAPFAIL);
	}
	data_list = (void *)mycalloc(count, sizeof(uint32_t));
	if(! data_list) {
		printf("can't allocate memory for %d data entries\n", count);
		myfree1(addr_list);
		return(E_SOAPFAIL);
	}
	base64 = (void *)mycalloc(count, sizeof(uint32_t) * 2);
	if(! base64) {
		printf("can't allocate memory for base64 string\n");
		myfree1(addr_list);
		myfree1(data_list);
		return(E_SOAPFAIL);
	}

	GetParamStr(reqId, 1, &base64);
	Decode(base64, (char *)addr_list, count * sizeof(uint32_t));

	GetParamStr(reqId, 2, &base64);
	Decode(base64, (char *)data_list, count * sizeof(uint32_t));

	for(i = 0; i < count; i++) {
		uintptr_t addr = LE32(addr_list[i]), mapping;
		uint32_t data = LE32(data_list[i]);

		mapping = map_phys(addr);
		if(mapping)
			DEV_WR(addr, data);
	}
	SetParamLong(reqId, SOAP_OK);

	myfree1(base64);
	myfree1(addr_list);
	myfree1(data_list);

	return(SOAP_OK);
}

int ReadMemory(int reqId)
{
	unsigned long addr, count, i;
	uint8_t *data_list;
	char *base64;

	GetParamLong(reqId, 0, (long *)&addr);
	GetParamLong(reqId, 1, (long *)&count);

	data_list = (void *)mycalloc(count, 1);
	if(! data_list) {
		printf("can't allocate memory for %ld data results\n", count);
		return(E_SOAPFAIL);
	}
	base64 = (void *)mycalloc(count, 2);
	if(! base64) {
		printf("can't allocate memory for base64 string\n");
		myfree1(data_list);
		return(E_SOAPFAIL);
	}

	for(i = 0; i < count; i++) {
		uintptr_t mapping = map_phys(addr);
		if(mapping)
			data_list[i] = BYTE_RD(mapping);
		addr++;
	}

	Encode((char *)data_list, count, base64);
	SetParamStr(reqId, &base64);

	myfree1(base64);
	myfree1(data_list);

	return(SOAP_OK);
}

int WriteMemory(int reqId)
{
	unsigned long addr, count, i;
	uint8_t *data_list;
	char *base64;

	GetParamLong(reqId, 0, (long*)&addr);
	GetParamLong(reqId, 1, (long*)&count);
	SetParamLong(reqId, count);

	data_list = (void *)mycalloc(count, 1);
	if(! data_list) {
		printf("can't allocate memory for %ld data results\n", count);
		return(E_SOAPFAIL);
	}
	base64 = (void *)mycalloc(count, 2);
	if(! base64) {
		printf("can't allocate memory for base64 string\n");
		myfree1(data_list);
		return(E_SOAPFAIL);
	}
	GetParamStr(reqId, 2, &base64);
	Decode(base64, (char *)data_list, count);

	for(i = 0; i < count; i++) {
		uintptr_t mapping = map_phys(addr);
		if(mapping)
			BYTE_WR(mapping, data_list[i]);
		addr++;
	}

	Encode((char *)data_list, count, base64);
	SetParamLong(reqId, count);

	myfree1(base64);
	myfree1(data_list);

	return(SOAP_OK);
}

/*************************************************************************/

long SoapInitialize_regSvc()
{
	initializeBase64Tables();

	// Methods
	RegisterMethod(REG_SERVICE, "ReadRegister", 1, "", "long", "", &ReadRegister);
	RegisterMethod(REG_SERVICE, "ReadRegisterCollection", 2, "", "string", "", &ReadRegisterCollection);
	RegisterMethod(REG_SERVICE, "WriteRegister", 2, "", "long", "", &WriteRegister);
	RegisterMethod(REG_SERVICE, "WriteRegisterCollection", 3, "", "long", "", &WriteRegisterCollection);
	RegisterMethod(REG_SERVICE, "ReadMemory", 2, "", "string", "", &ReadMemory);
	RegisterMethod(REG_SERVICE, "WriteMemory", 3, "", "long", "", &WriteMemory);

	return SOAP_OK;
}
