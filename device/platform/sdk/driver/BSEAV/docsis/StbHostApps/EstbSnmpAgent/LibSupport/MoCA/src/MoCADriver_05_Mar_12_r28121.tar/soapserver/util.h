#ifndef _UTIL_H
#define _UTIL_H

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#ifdef __cplusplus       
	extern "C" {
#endif

#define USE_STRING_H

// stdio.h
	#define _vfprintf	vfprintf
	#define _sprintf	sprintf

// stdlib.h
#if !defined(WIN32)
	extern char* _ltoa( long value, char *str, int radix );
#endif

// string.h
#if defined(USE_STRING_H)
	#include <string.h>
	#define _strcpy		strcpy	
	#define _strncpy	strncpy
	#define _strcat		strcat
	#define _strncat	strncat
	#define _strlen		strlen
	#define _strcmp		strcmp
	#define _strncmp	strncmp
	#define _strstr		strstr
	#define _strchr		strchr
	#define _strcspn	strcspn
	#define _strspn		strspn
	#define _memset		memset
	#define _memcpy		memcpy
	#define _memcmp		memcmp
	#define _memmove	memmove
	#if !defined(WIN32) // Not all C libraries support this function
		extern int	_stricmp(const char *a, const char *b);
	#endif
#else
	extern char*	_strcpy(char *dest, const char *src);
	extern char *	_strncpy(char *dest, const char *src, size_t n);
	extern char*	_strcat(char *string1, const char *string2);
	extern size_t	_strlen(const char *str);
	extern int		_strcmp(const char *a, const char *b);
	extern int		_strncmp(const char *a, const char *b, unsigned int n);
	extern int		_stricmp(const char *a, const char *b);
	extern char*	_strstr(const char *string, const char *strCharSet);
	extern char*	_strchr(const char *s, int c);
	extern size_t	_strcspn(const char *string1, const char *string2);
	extern size_t	_strspn(const char *string1, const char *string2);
	extern void*	_memcpy(void *dest, const void *src, size_t count);
	extern void*	_memset(void *dest, int c, size_t count);
	extern void*	_memmove(void *dest, const void *src, size_t count);
	extern int		_memcmp(const void *buf1, const void *buf2, size_t count);
#endif

// float.h or math.h - Note: not all crt libraries define these
extern int	_isnan(double d);
extern int	_finite(double d);

// Customized C-runtime functions
extern char*	_strrchr(const char *s, char c);
extern int		_isspace(char c);
extern long		_strtol(const char *str);
extern double	_strtod(const char *str);

#ifndef HUGE_VAL // would be in math.h if it's included
	#define HUGE_VAL	1.7976931348623157e+308 // MAX_DOUBLE
#endif

#ifndef ERANGE  // would be in math.h if it's included
	#define ERANGE      34
#endif

// String helper macros
#define MAKEUPPER(_c)   ( ((_c) >= 'a' && (_c) <= 'z') ? (_c)-'a'+'A' : (_c) )
#define MAX(a,b) (( (a) > (b) ) ? (a) : (b))
#define MIN(a,b) (( (a) > (b) ) ? (b) : (a))

#ifdef __cplusplus       
}
#endif


#endif
