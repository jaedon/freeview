#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/dma-mapping.h>
#include <linux/slab.h>


static int device_open(struct inode *inode, struct file *file)
{
    printk("Opened\n");
	try_module_get(THIS_MODULE);
	return 0;
}

static int device_release(struct inode *inode, struct file *file)
{
	module_put(THIS_MODULE);
	return 0;
}

long device_ioctl(struct file *file, unsigned int cmd, 
                            unsigned long arg)

//(struct inode *inode,   /* see include/linux/fs.h */
//         struct file *file, /* ditto */
//         unsigned int cmd,    /* number and param for ioctl */
//         unsigned long arg)
{
    unsigned int size;
    unsigned char *buf;
    unsigned int addr=0;

    if (cmd == 0)
    {
        if (copy_from_user(&size, (void __user *)arg, sizeof(size)))
            return(-EFAULT);

        buf = kmalloc(size, GFP_KERNEL);
        if (buf) 
        {
            addr = dma_map_single(NULL,
                buf, size, DMA_FROM_DEVICE);
            
            printk(KERN_INFO  
                "Allocated Physical Address 0x%08x for TPCAP buffer (at virt addr 0x%08x)\n", addr, (unsigned int)buf);
            
            for (;size > 0; size--)
                *buf++ = 0xAA;
        } 
        else
        {
            printk(KERN_WARNING "Unable to allocate memory for TPCAP\n");        
        }
        
        return(addr);
    }
    else
    {
        printk("memalloc.ko: Invalid ioctl\n");
    }

    return(0);
}


struct file_operations Fops = 
{
	.unlocked_ioctl = device_ioctl,
	.open = device_open,
	.release = device_release,
};

#define MAJOR_NUM 112
#define MINOR_NUM 0
#define DEVICE_NAME "memalloc"


int init_module()
{
	int ret_val;
	/* 
	 * Register the character device (atleast try) 
	 */
	ret_val = register_chrdev(MAJOR_NUM, DEVICE_NAME, &Fops);
printk("registered\n");
	/* 
	 * Negative values signify an error 
	 */
	if (ret_val < 0) {
		printk(KERN_ALERT "%s failed with %d\n",
		       "Sorry, registering the character device ", ret_val);
		return ret_val;
	}

	return 0;
}

/* 
 * Cleanup - unregister the appropriate file from /proc 
 */
void cleanup_module()
{
	/* 
	 * Unregister the device 
	 */
	unregister_chrdev(MAJOR_NUM, DEVICE_NAME);

}

