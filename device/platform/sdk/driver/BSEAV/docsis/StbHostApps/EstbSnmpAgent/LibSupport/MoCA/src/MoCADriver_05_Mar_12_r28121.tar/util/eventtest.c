/***************************************************************************
 *
 *     Copyright (c) 2008-2009, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *  Description: Basic unit test for libmoca event interface
 *
 ***************************************************************************/

#include <mocalib.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

void dump_buf(unsigned char *buf, int len)
{
	int i, j;

	for(i = 0; i < len; i += 0x10) {
		printf("%04x: ", i);
		for(j = 0; (j < 0x10) && ((i + j) < len); j++)
			printf("%02x ", buf[i + j]);
		printf("\n");
	}
}

static void *moca_ctx;

void cancel_loop(int sig)
{
	moca_cancel_event_loop(moca_ctx);
}

static void link_up_state_cb(void *arg, uint32_t state)
{
	printf("Link is now %s\n", state ? "UP" : "DOWN");
}

static void admission_status_cb(void *arg, uint32_t state)
{
	printf("New admission state: %x\n", state);
}

static void topology_changed_cb(void *arg, uint32_t active_nodes)
{
	printf("Topology changed: active_nodes 0x%x\n", active_nodes);
}

static void pqos_create_response_cb(void *arg, struct moca_pqos_create_response *in)
{
	struct moca_gen_status gs;
	struct moca_pqos_ingr_add_flow req;
	void *vctx = arg;
	uint32_t nodeId = 0;
	int ret;

	printf("PQoS Create command received by MoCA core.\n");
	printf("flow id            %.8x%.8x\n", in->flowid_hi, in->flowid_lo);
	printf("responsecode       %d\n", in->responsecode);
	printf("decision           %d\n", in->decision);
	printf("flowtag            %d\n", in->flowtag);
	printf("ingressnodeid      %d\n", in->ingressnodeid);
	printf("egressnodebitmask  %.8x\n", in->egressnodebitmask);
	printf("flowda             %.8x%.8x\n", in->flowda_hi, in->flowda_lo);
	printf("maxpeakdatarate    %d\n", in->maxpeakdatarate);
	printf("tpacketsize        %d\n", in->tpacketsize);
	printf("maxburstsize       %d\n", in->maxburstsize);
	printf("tleasetime         %d\n", in->tleasetime);
	printf("totalstps          %d\n", in->totalstps);
	printf("totaltxps          %d\n", in->totaltxps);
	printf("flowstps           %d\n", in->flowstps);
	printf("flowtxps           %d\n", in->flowtxps);

	moca_get_gen_status(vctx, &gs);
	if (gs.node_id == in->ingressnodeid) {
		req.flowid_hi = in->flowid_hi;
		req.flowid_lo = in->flowid_lo;
		req.flowtag = in->flowtag;
		req.qtag = 0;
		req.tpeakdatarate = in->maxpeakdatarate;
		req.tpacketsize = in->tpacketsize;
		req.tburstsize = in->maxburstsize;
		req.tleasetime = in->tleasetime;
		while (in->egressnodebitmask && (nodeId < MOCA_MAX_NODES)) {
			if (in->egressnodebitmask & 0x01)
				break;
			in->egressnodebitmask >>= 1;
			nodeId++;
		}
		req.egressnodeid = nodeId;
		req.flowsa_hi = 0;
		req.flowsa_lo = 0;
		req.flowda_hi = in->flowda_hi;
		req.flowda_lo = in->flowda_lo;
		req.flowvlanpri = 0xff;
		req.flowvlanid = 0xfff;
		req.committedstps = in->flowstps;
		req.committedtxps = in->flowtxps;

		ret = moca_set_pqos_ingr_add_flow(vctx, &req);
		if (ret != 0)
			printf("Creating MoCA Ingress flow error!\n");
	}
}

static void pqos_create_complete_cb(void *arg, struct moca_pqos_create_complete *in)
{
	struct moca_gen_status gs;
	struct moca_pqos_ingr_add_flow req;
	void *vctx = arg;
	uint32_t nodeId = 0;
	int ret;

	printf("PQoS Create command complete.\n");
	printf("flow id            %.8x%.8x\n", in->flowid_hi, in->flowid_lo);
	printf("responsecode       %d\n", in->responsecode);
	printf("decision           %d\n", in->decision);
	printf("flowtag            %d\n", in->flowtag);
	printf("ingressnodeid      %d\n", in->ingressnodeid);
	printf("egressnodebitmask  %.8x\n", in->egressnodebitmask);
	printf("flowda             %.8x%.8x\n", in->flowda_hi, in->flowda_lo);
	printf("maxpeakdatarate    %d\n", in->maxpeakdatarate);
	printf("tpacketsize        %d\n", in->tpacketsize);
	printf("maxburstsize       %d\n", in->maxburstsize);
	printf("tleasetime         %d\n", in->tleasetime);
	printf("totalstps          %d\n", in->totalstps);
	printf("totaltxps          %d\n", in->totaltxps);
	printf("flowstps           %d\n", in->flowstps);
	printf("flowtxps           %d\n", in->flowtxps);

	moca_get_gen_status(vctx, &gs);
	if (gs.node_id == in->ingressnodeid) {
		req.flowid_hi = in->flowid_hi;
		req.flowid_lo = in->flowid_lo;
		req.flowtag = in->flowtag;
		req.qtag = 0;
		req.tpeakdatarate = in->maxpeakdatarate;
		req.tpacketsize = in->tpacketsize;
		req.tburstsize = in->maxburstsize;
		req.tleasetime = in->tleasetime;
		while (in->egressnodebitmask && (nodeId < MOCA_MAX_NODES)) {
			if (in->egressnodebitmask & 0x01)
				break;
			in->egressnodebitmask >>= 1;
			nodeId++;
		}
		req.egressnodeid = nodeId;
		req.flowsa_hi = 0;
		req.flowsa_lo = 0;
		req.flowda_hi = in->flowda_hi;
		req.flowda_lo = in->flowda_lo;
		req.flowvlanpri = 0xff;
		req.flowvlanid = 0xfff;
		req.committedstps = in->flowstps;
		req.committedtxps = in->flowtxps;

		ret = moca_set_pqos_ingr_add_flow(vctx, &req);
		if (ret != 0)
			printf("Creating MoCA Ingress flow error!\n");
	}
}

static void pqos_update_response_cb(void *arg, struct moca_pqos_update_response *in)
{
	struct moca_pqos_ingr_update req;
	void *vctx = arg;
	int ret;

	printf("PQoS Update command received by MoCA core.\n");
	printf("flow id            %.8x%.8x\n", in->flowid_hi, in->flowid_lo);
	printf("responsecode       %d\n", in->responsecode);
	printf("decision           %d\n", in->decision);
	printf("flowtag            %d\n", in->flowtag);
	printf("flowda             %.8x%.8x\n", in->flowda_hi, in->flowda_lo);
	printf("maxpeakdatarate    %d\n", in->maxpeakdatarate);
	printf("tpacketsize        %d\n", in->tpacketsize);
	printf("maxburstsize       %d\n", in->maxburstsize);
	printf("tleasetime         %d\n", in->tleasetime);
	printf("totalstps          %d\n", in->totalstps);
	printf("totaltxps          %d\n", in->totaltxps);
	printf("flowstps           %d\n", in->flowstps);
	printf("flowtxps           %d\n", in->flowtxps);

	req.flowid_hi = in->flowid_hi;
	req.flowid_lo = in->flowid_lo;
	req.flowtag = in->flowtag;
	req.flowda_hi = in->flowda_hi;
	req.flowda_lo = in->flowda_lo;
	req.tpeakdatarate = in->maxpeakdatarate;
	req.tpacketsize = in->tpacketsize;
	req.tburstsize = in->maxburstsize;
	req.tleasetime = in->tleasetime;
	req.committedstps = in->flowstps;
	req.committedtxps = in->flowtxps;

	ret = moca_set_pqos_ingr_update(vctx, &req);
	if (ret != 0)
		printf("Updating MoCA Ingress flow error!\n");
}

static void pqos_update_complete_cb(void *arg, struct moca_pqos_update_complete *in)
{
	struct moca_pqos_ingr_update req;
	void *vctx = arg;
	int ret;

	printf("PQoS Update command complete.\n");
	printf("flow id            %.8x%.8x\n", in->flowid_hi, in->flowid_lo);
	printf("responsecode       %d\n", in->responsecode);
	printf("decision           %d\n", in->decision);
	printf("flowtag            %d\n", in->flowtag);
	printf("flowda             %.8x%.8x\n", in->flowda_hi, in->flowda_lo);
	printf("maxpeakdatarate    %d\n", in->maxpeakdatarate);
	printf("tpacketsize        %d\n", in->tpacketsize);
	printf("maxburstsize       %d\n", in->maxburstsize);
	printf("tleasetime         %d\n", in->tleasetime);
	printf("totalstps          %d\n", in->totalstps);
	printf("totaltxps          %d\n", in->totaltxps);
	printf("flowstps           %d\n", in->flowstps);
	printf("flowtxps           %d\n", in->flowtxps);

	req.flowid_hi = in->flowid_hi;
	req.flowid_lo = in->flowid_lo;
	req.flowtag = in->flowtag;
	req.flowda_hi = in->flowda_hi;
	req.flowda_lo = in->flowda_lo;
	req.tpeakdatarate = in->maxpeakdatarate;
	req.tpacketsize = in->tpacketsize;
	req.tburstsize = in->maxburstsize;
	req.tleasetime = in->tleasetime;
	req.committedstps = in->flowstps;
	req.committedtxps = in->flowtxps;

	ret = moca_set_pqos_ingr_update(vctx, &req);
	if (ret != 0)
		printf("Updating MoCA Ingress flow error!\n");
}

static void pqos_delete_response_cb(void *arg, struct moca_pqos_delete_response *in)
{
	struct moca_pqos_ingr_delete req;
	void *vctx = arg;
	int ret;

	printf("PQoS Delete command received by MoCA core.\n");
	printf("flow id            %.8x%.8x\n", in->flowid_hi, in->flowid_lo);
	printf("responsecode       %d\n", in->responsecode);

	req.flowid_hi = in->flowid_hi;
	req.flowid_lo = in->flowid_lo;

	ret = moca_set_pqos_ingr_delete(vctx, &req);
	if (ret != 0)
		printf("Deleting MoCA Ingress flow error!\n");
}

static void pqos_delete_complete_cb(void *arg, struct moca_pqos_delete_complete *in)
{
	struct moca_pqos_ingr_delete req;
	void *vctx = arg;
	int ret;

	printf("PQoS Delete command complete.\n");
	printf("flow id            %.8x%.8x\n", in->flowid_hi, in->flowid_lo);
	printf("responsecode       %d\n", in->responsecode);

	req.flowid_hi = in->flowid_hi;
	req.flowid_lo = in->flowid_lo;

	ret = moca_set_pqos_ingr_delete(vctx, &req);
	if (ret != 0)
		printf("Deleting MoCA Ingress flow error!\n");
}

static void pqos_list_response_cb(void *arg, struct moca_pqos_list_response *in)
{
	int i;
	uint32_t *flowid;

	printf("PQoS List command received by MoCA core.\n");
	printf("responsecode       %d\n", in->responsecode);
	printf("ingressnodeid      %d\n", in->ingressnodeid);
	flowid = &in->flowid0_hi;

	for (i = 0; i < 32; i++)
	{
		if (flowid[i*2] != 0 || flowid[i*2+1] != 0)
		{
			printf("flow id %d         %.8x%.8x\n", i, flowid[i*2], flowid[i*2+1]);
		}
	}
}

static void pqos_query_response_cb(void *arg, struct moca_pqos_query_response *in)
{
	printf("PQoS Query command received by MoCA core.\n");
	printf("responsecode       %d\n", in->responsecode);
	printf("leasetimeleft      %d\n", in->leasetimeleft);
	printf("flow id            %02x:%02x:%02x:%02x:%02x:%02x\n", 
		in->flowid[0], in->flowid[1], in->flowid[2], 
		in->flowid[3], in->flowid[4], in->flowid[5]);
	printf("tpacketsize        %d\n", in->tpacketsize);
	printf("ingressnodeid      %d\n", in->ingressnodeid);
	printf("egressnodeid       %d\n", in->egressnodeid);
	printf("flowtag            %d\n", in->flowtag);
	printf("packetda           %02x:%02x:%02x:%02x:%02x:%02x\n", 
		in->packetda[0], in->packetda[1], in->packetda[2], 
		in->packetda[3], in->packetda[4], in->packetda[5]);
	printf("tpeakdatarate      %d\n", in->tpeakdatarate);
	printf("tleasetime         %d\n", in->tleasetime);
	printf("tburstsize         %d\n", in->tburstsize);
}

static void pqos_maintenance_complete_cb(void *arg, struct moca_pqos_maintenance_complete *in)
{
	printf("PQoS Maintenance complete.\n");
	printf("iocovercommit      %d\n", in->iocovercommit);
	printf("allocatedstps      %d\n", in->allocatedstps);
	printf("allocatedtxps      %d\n", in->allocatedtxps);
}

static void fmr_response_cb(void *arg, struct moca_fmr_response *in)
{
	int i, j;
	uint32_t *responded_node;
	uint16_t *fmrinfo_node;

	printf("FMR command received by MoCA core.\n");
	printf("responsecode       %d\n", in->responsecode);

	for (i = 0; i < 9; i++)
	{
		responded_node = (void *)&in->responded_node_0 + ((sizeof(in->responded_node_0)*i) + (sizeof(in->fmrinfo_node_0)*i));
		fmrinfo_node = (uint16_t *)(responded_node + 1);
		if (*responded_node != 0xFF)
		{
			printf("\nresponded_node_id %d\n", *responded_node);
			for (j = 0; j < 16; j++ )
			{
				printf("GAP  %d     OFDMb  %d\n", fmrinfo_node[j] >> 11, fmrinfo_node[j] & 0x7FF);
			}
		}
	}
}

static void lof_cb(void *arg, uint32_t lof)
{
	printf("New LOF: %u Mhz\n", lof);
}

int main(int argc, char **argv)
{
	void *vctx;

	moca_ctx = vctx = moca_open(NULL);

	signal(SIGINT, &cancel_loop);

	moca_register_link_up_state_cb(vctx, &link_up_state_cb, NULL);
	moca_register_admission_status_cb(vctx, &admission_status_cb, NULL);
	moca_register_topology_changed_cb(vctx, &topology_changed_cb, NULL);
	moca_register_lof_cb(vctx, &lof_cb, NULL);
	moca_register_pqos_create_response_cb(vctx, &pqos_create_response_cb, vctx);
	moca_register_pqos_create_complete_cb(vctx, &pqos_create_complete_cb, vctx);
	moca_register_pqos_update_response_cb(vctx, &pqos_update_response_cb, vctx);
	moca_register_pqos_update_complete_cb(vctx, &pqos_update_complete_cb, vctx);
	moca_register_pqos_delete_response_cb(vctx, &pqos_delete_response_cb, vctx);
	moca_register_pqos_delete_complete_cb(vctx, &pqos_delete_complete_cb, vctx);
	moca_register_pqos_list_response_cb(vctx, &pqos_list_response_cb, NULL);
	moca_register_pqos_query_response_cb(vctx, &pqos_query_response_cb, NULL);
	moca_register_pqos_maintenance_complete_cb(vctx, &pqos_maintenance_complete_cb, NULL);
	moca_register_fmr_response_cb(vctx, &fmr_response_cb, NULL);

	moca_event_loop(vctx);

	printf("Exiting...\n");

	moca_close(vctx);
	return(0);
}
