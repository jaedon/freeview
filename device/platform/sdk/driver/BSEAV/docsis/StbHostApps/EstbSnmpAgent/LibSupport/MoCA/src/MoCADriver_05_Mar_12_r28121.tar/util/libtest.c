/***************************************************************************
 *
 *     Copyright (c) 2008-2009, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *  Description: Basic unit test for libmoca get/set calls
 *
 ***************************************************************************/

#include <mocalib.h>
#include <stdio.h>
#include <stdlib.h>

void dump_buf(unsigned char *buf, int len)
{
	int i, j;

	for(i = 0; i < len; i += 0x10) {
		printf("%04x: ", i);
		for(j = 0; (j < 0x10) && ((i + j) < len); j++)
			printf("%02x ", buf[i + j]);
		printf("\n");
	}
}

#define __UNUSED __attribute__((unused))

int main(int argc, char **argv)
{
	void *vctx __UNUSED;
	struct moca_gen_status gstat __UNUSED;
	struct moca_init_time i __UNUSED;
	struct moca_gen_stats gs __UNUSED;
	struct moca_ext_stats es __UNUSED;
	struct moca_lab_iq_diagram_set iq __UNUSED;
	struct moca_tx_profile tx __UNUSED;
	int ret, mask __UNUSED;
	char *buf __UNUSED;

	vctx = moca_open(NULL);
	/* NOTE: no error checking */

	ret = moca_get_init_time(vctx, &i);
	
#if 1
	/* dump out general status info in hex */
	ret = moca_get_gen_status(vctx, &gstat);
	printf("gen_status ret = %d\n", ret);
	dump_buf((void *)&gstat, sizeof(gstat));

	ret = moca_get_gen_stats(vctx, &gs);
	printf("gen_stats ret = %d\n", ret);
	dump_buf((void *)&gs, sizeof(gs));

	ret = moca_get_ext_stats(vctx, &es);
	printf("ext_stats ret = %d\n", ret);
	dump_buf((void *)&es, sizeof(es));
#endif

#if 0
	/* dump SNR/IQ data */
	ret = moca_get_gen_status(vctx, &gstat);
	mask = gstat.connected_nodes ^ (1 << gstat.node_id);

	iq.nodeid = ffs(mask) - 1;
	iq.bursttype = 7;
	iq.acmtsymnum = 1;
	
	printf("My node ID = %d, monitoring SNR/IQ for node %d\n",
		gstat.node_id, iq.nodeid);

	ret = moca_set_lab_snr_graph_set(vctx, iq.nodeid);
	ret = moca_set_lab_iq_diagram_set(vctx, &iq);

	buf = malloc(9 * 1024);

	memset(buf, 0, 9 * 1024);

	moca_get_iq_data(vctx, (void *)buf);
	printf("\nIQ via API:\n");
	dump_buf(buf, 1 * 1024);

	moca_get_snr_data(vctx, (void *)buf);
	printf("\nSNR via API:\n");
	dump_buf(buf, 1 * 1024);
	printf("...\n");
	dump_buf(&buf[7 * 1024], 1 * 1024);
#endif

	moca_close(vctx);
	return(0);
}
