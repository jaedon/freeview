  /*
   <:copyright-broadcom 

   Copyright (c) 2007 Broadcom Corporation 
   All Rights Reserved 
   No portions of this material may be reproduced in any form without the 
   written permission of: 
   Broadcom Corporation 
   5300 California Avenue
   Irvine, California 92617 
   All information contained in this document is Broadcom Corporation 
   company private, proprietary, and trade secret. 

   :>
   */
/***************************************************************************
 * File Name  : mocactl.c
 *
 * Description: Linux command line utility that controls the Broadcom
 *              BCM6816 MoCA driver. It does the following:
 *              - starts and stops the MoCA subsystem.
 *              - configures the MoCA subsystem.
 *              - retrieves status of the MoCA subsystem.
 *              - retrieves statistics of the MoCA subsystem.
 ***************************************************************************/

/** Includes. **/

#include <stdio.h>
#include <errno.h>
#include "devctl_moca.h"
#include <math.h>

#if defined(__gnu_linux__)
#include <sys/time.h>
#endif

#if defined(WIN32)
#include <winsock2.h>
#define snprintf _snprintf
#endif

#include "mocalib.h"

#include "mocalib-cli.h"

#ifndef CHIP_6816
#include "tpcap.h"
#endif

#include "moca_os.h"

/** Defines. **/

#define MoCACTL_VERSION                      "2.0.28"

/** More Typedefs. **/

struct moca_ifname_map
{
   char  *input;
   char  *ifname;
};

struct moca_lmo_cb_params
{
   void * ctx;
   UINT32 flags;
   UINT32 snr_node_id;
   UINT32 bitloading_id;
   UINT32 nodestatus_id;   
   UINT32 print_as_db;
};

/** Prototypes. **/

static int StartHandler( POPTION_INFO pOptions, int nNumOptions );
static int ReStartHandler( POPTION_INFO pOptions, int nNumOptions );
static int StopHandler( POPTION_INFO pOptions, int nNumOptions );
static int ConfigHandler( POPTION_INFO pOptions, int nNumOptions );
static int ShowHandler( POPTION_INFO pOptions, int nNumOptions );
static int WolHandler( POPTION_INFO pOptions, int nNumOptions );
static CmsRet ShowHandlerInitParms( POPTION_INFO pOpt );
static CmsRet ShowHandlerConfig( POPTION_INFO pOpt );
static CmsRet ShowHandlerStatus( POPTION_INFO pOpt );
static CmsRet ShowHandlerStats( POPTION_INFO pOpt );
static CmsRet ShowHandlerTraceConfig( POPTION_INFO pOpt );
static CmsRet ShowHandlerNodeStatus( POPTION_INFO pOpt );
static CmsRet ShowHandlerNodeStats( POPTION_INFO pOpt );
static CmsRet ShowHandlerMoCARegister( POPTION_INFO pOpt );
static int ShowTblHandler( POPTION_INFO pOptions, int nNumOptions );
static CmsRet ShowTblHandlerNodeStatus( POPTION_INFO pOpt );
static CmsRet ShowTblHandlerNodeStats( POPTION_INFO pOpt );
static CmsRet ShowTblHandlerUcFwd( POPTION_INFO pOpt );
static CmsRet ShowTblHandlerSrcAddr( POPTION_INFO pOpt );
static CmsRet ShowTblHandlerMcFwd( POPTION_INFO pOpt );
static int TraceHandler( POPTION_INFO pOptions, int nNumOptions );
static int RestoreDefaultsHandler( POPTION_INFO pOptions, int nNumOptions );
static int McFwdHandler( POPTION_INFO pOptions, int nNumOptions );
static int VersionHandler( POPTION_INFO pOptions, int nNumOptions );
static int FmrHandler (POPTION_INFO pOptions, int nNumOptions );
static int MrHandler (POPTION_INFO pOptions, int nNumOptions );
static int ChSelHandler (POPTION_INFO pOptions, int nNumOptions );
static int PQoSCHandler( POPTION_INFO pOptions, int nNumOptions );
static int PQoSUHandler( POPTION_INFO pOptions, int nNumOptions );
static int PQoSDHandler( POPTION_INFO pOptions, int nNumOptions );
static int PQoSLHandler( POPTION_INFO pOptions, int nNumOptions );
static int PQoSQHandler( POPTION_INFO pOptions, int nNumOptions );
static int PQoSSHandler( POPTION_INFO pOptions, int nNumOptions );
static int FnCallHandler( POPTION_INFO pOptions, int nNumOptions ) ;
static int LabHandler( POPTION_INFO pOptions, int nNumOptions ) ;
static int E2MHandler( POPTION_INFO pOptions, int nNumOptions );
static int TpcapHandler( POPTION_INFO pOptions, int nNumOptions );
static int TpcapDumpHandler( POPTION_INFO pOptions, int nNumOptions );
static int CpuRateHandler( POPTION_INFO pOptions, int nNumOptions );
static int HelpHandler( POPTION_INFO pOptions, int nNumOptions );

static CmsRet RetrieveMCFwdTbl (void) ;

/** Globals. **/

static COMMAND_INFO g_Cmds[] =
{
   {"start", {"--nc", "--autoScan", "--singleCh", "--privacy", "--tpc", "--constTxMode",
                "--maxTxPower", "--password", "--nodeType",
                "--lof", "--mcastMode","--labMode", "--continuousRxModeAttn",
                "--tabooFixedMaskStart", "--tabooFixedChannelMask", 
                "--tabooLeftMask", "--tabooRightMask", "--padPower",
                "--version", "--preferedNC", "--preferredNC", "--ledMode", "--backoffMode",   
                "--lowPriQNum", "--egrMcFilter", "--qam256Capability",
                "--rfType", "--beaconChannel", "--mrNonDefSeqNum", "--freqMask", "--pnsFreqMask",
                "--otfEn", "--turboEn", "--wait", "--beaconPwrReduction", "--beaconPwrReductionEn",
                "--beaconPwrReductionEn", "--flowControlEn", "--mtmEn", "--qam1024En", "--T50TimeMin", "--T50TimeMax",
                "--res1", "--res2", "--res3", "--res4", "--res5", ""}, StartHandler},
   {"restart", {"--nc", "--autoScan", "--singleCh", "--privacy", "--tpc", "--constTxMode",
                  "--maxTxPower", "--password",  "--nodeType",
                  "--lof", "--mcastMode", "--labMode", "--continuousRxModeAttn",
                  "--tabooFixedMaskStart", "--tabooFixedChannelMask", 
                  "--tabooLeftMask", "--tabooRightMask", "--padPower",
                  "--version", "--preferedNC", "--preferredNC", "--ledMode", "--backoffMode", 
                  "--lowPriQNum", "--egrMcFilter", "--qam256Capability",                 
                  "--rfType", "--beaconChannel", "--mrNonDefSeqNum", "--freqMask", "--pnsFreqMask",
                  "--otfEn", "--turboEn", "--wait", "--beaconPwrReduction", "--beaconPwrReductionEn",
                  "--beaconPwrReductionEn", "--flowControlEn", "--mtmEn", "--qam1024En", "--T50TimeMin", "--T50TimeMax",
                  "--res1", "--res2", "--res3", "--res4", "--res5", ""}, ReStartHandler},
   {"stop", {""}, StopHandler},
   {"config", {"--frameSize", "--maxTxTime", "--minBwThreshold", "--snrMgn",
                 "--outOfOrderLMO", "--ieRRInsert", "--ieMapInsert",
                 "--maxAggr", "--sapm", "--rlapm", "--maxConstellationNode", "--maxConstellationInfo",
                 "--pmk", "--tek", "--prio", "--phyRate128", "--phyRate256", "--phyRateTurbo", "--phyRateTurboPlus",
                 "--nbasCappingEn", "--minMapCycle", "--maxMapCycle", "--freqShiftMode", "--selectiveRR", "--loopbackEn",
                 "--snrMgnOffset", "--mocareg", "--tpcap", "--powersave", "--rxTxPacketsPerQM", "--extraRxPacketsPerQM", "--res1", "--res2",
                 "--res3", "--rxPowerTuning", "--egrMcFilterEntry", "--enCapable", "--diplexer", 
                 "--enMaxRateInMaxBo", "--rlapmCap", "--hostQOSEn", "--sapm_LTE", "--sapm_GSM", ""}, ConfigHandler},
   {"show", {"--initparms", "--config", "--status", "--stats", "--traceconfig", "--nodestatus", "--nodestats", "--mocareg", ""}, ShowHandler},
   {"showtbl", {"--nodestatus", "--nodestats", "--mcfwd", "--ucfwd", "--srcaddr", ""}, ShowTblHandler},
   {"fn-call", {"--address", "--params", ""}, FnCallHandler},
   {"chsel", {"--freq", ""}, ChSelHandler},
   {"mr", {"--seq", "--time", ""}, MrHandler},
   {"fmr", {"--s", "--a", ""}, FmrHandler}, 
   {"pqosc", { "--ig", "--eg", "--listener1", "--listener2", "--listener3", "--listener4", 
               "--packetDA", "--peak", "--psize", "--burst", "--time", "--flowtag", 
               "--talker", "--vlan_id", "--vlan_prio", ""}, PQoSCHandler},
   {"pqosu", { "--flow_id", "--peak", "--psize", "--burst", "--time", "--flowtag", ""}, PQoSUHandler},
   {"pqosd", {"--flow_id", ""}, PQoSDHandler},
   {"pqosl", {"--ig", "--a", ""}, PQoSLHandler},
   {"pqosq", {"--flow_id", ""}, PQoSQHandler},
   {"pqoss", {""}, PQoSSHandler},
   {"trace", {"--none", "--entry", "--exit", "--dbg", "--mmpdump", "--trap", "--time", "--all", 
              "--info", "--core", "--default", "--verbose", ""}, TraceHandler},
   {"restore_defaults", {""}, RestoreDefaultsHandler},
   {"mcfwd", {"--create", "--delete", ""}, McFwdHandler},
   {"lab", {"--snr", "--cir", "--db", "--bitloading", "--nodestatus", "--monitor", ""}, LabHandler},
   {"e2m", {"--nums"}, E2MHandler},
   {"tpcap", {"--port", "--bursttype", "--mode", "--nsamples", "--node",
              "--macphy", "--clock", "--rate", "--lpbk", "--wait"}, TpcapHandler},
   {"tpcapdump", {"--file", "--display"}, TpcapDumpHandler},
   {"cpurate", {"--rate"}, CpuRateHandler},
   {"wol", {"--enable", "--disable"}, WolHandler},
   {"--version", {""}, VersionHandler},    
   {"--help", {"--advanced", ""}, HelpHandler},
   {""}
} ;

static char g_szPgmName [80] = {0} ;

static void * g_mocaHandle = NULL;

static struct moca_ifname_map g_mocaIfNames[MAX_IFNAME_INPUTS] =
{
   {"0",      "moca0"},
   {"moca0",  "moca0"},
   {"lan",    "moca0"},
   {"1",      "moca10"},
   {"moca1",  "moca10"},
   {"10",     "moca10"},
   {"moca10", "moca10"},
   {"wan",    "moca10"},
   {NULL,    NULL}, /* Keep at end of array for easy searching */
};

static unsigned int pqos_cond; 

#ifdef CHIP_6816
static int g_NvModeEnabled = TRUE;
#else
static int g_NvModeEnabled = FALSE;
#endif

static char * getMoCAIfName( char * argv )
{
#if defined(__EMU_HOST_11__)
   /* In the emulator a number can be passed in to identify
      which instance should be accessed. If this argument is
      not a number, simply return NULL.  You can also specify
		  the channel number in this format node:channel	*/
   char *endptr;
   char *endptr2;
   long val;

   val = strtol(argv, &endptr, 0);

   if ((endptr == argv) || ((*endptr != '\0') && (*endptr != ':'))) {
      return(NULL);
   }

	 if (*endptr == ':') {
	    val = strtol(endptr+1, &endptr2, 0);
			if ((endptr2 == endptr +1) || (*endptr2 != '\0'))
			   return(NULL);
	 }
	 else if (*endptr != '\0')
	    return(NULL);

   return(argv);
#else
   UINT32 i;
   char * pRet = NULL;

   /* Search the g_mocaIfNames array for a match */
   for ( i = 0; g_mocaIfNames[i].input != NULL; i++ )
   {
      if (strcmp(argv, g_mocaIfNames[i].input) == 0)
      {
         pRet = g_mocaIfNames[i].ifname;
         break;
      }
   }

   return (pRet);
#endif
};
/***************************************************************************
 * Function Name: main
 * Description  : Main program function.
 * Returns      : 0 - success, non-0 - error.
 ***************************************************************************/
int main(int argc, char **argv)
{
   int nExitCode = 0;
   PCOMMAND_INFO pCmd;
   int i;
   char *pMoCAIfName = NULL;
#if defined(WIN32)
   char *c;
#endif


#if defined(WIN32)
   // strip the path from the program name
   while (c=strchr(*argv, '\\')) *argv = c+1;
#endif

   /* Save the name that started this program into a global variable. */
   strcpy( g_szPgmName, *argv );

   if( argc == 1 )
   {
      g_mocaHandle = MoCACtl_Open( NULL );

      HelpHandler( NULL, 0 );

      if (g_mocaHandle)
         MoCACtl_Close( g_mocaHandle );
      
      g_mocaHandle = NULL;

      return(0);
   }
   argc--, argv++;

   /* the first parameter may be a moca interface number. If not present,
    * assume interface 0 */
   if ( argc )
   {
        for (i = 0; (i < 2) && argc; i++) // two possible pre-parameters, -p and ifname
        {
          if (strcmp (*argv, "-p") == 0)
          {
              g_NvModeEnabled = TRUE;
              argc--;
              argv++;
          }
          else if (pMoCAIfName == NULL)
          {
              pMoCAIfName = getMoCAIfName( *argv );
              if (pMoCAIfName != NULL)
                  argc--, argv++;
              else
                  pMoCAIfName = NULL;

              g_mocaHandle = MoCACtl_Open( pMoCAIfName );

              if (pMoCAIfName == NULL)
                break;
          }
       }
   }

   if (g_mocaHandle != NULL)
   {
      while( argc && nExitCode == 0 )
      {
         if( mocacli_get_arg_type( *argv, g_Cmds, NULL ) == ARG_TYPE_COMMAND )
         {
            int argnext = 0;
            pCmd = mocacli_get_command( *argv, g_Cmds );
            nExitCode = mocacli_process_command(g_szPgmName, pCmd, --argc, ++argv, g_Cmds, &argnext);
            argc -= argnext;
            argv += argnext;
         }
         else
         {
            nExitCode = CMSRET_INVALID_ARGUMENTS;
            fprintf( stderr, "%s: invalid command\n", g_szPgmName );
         }
      }

      MoCACtl_Close( g_mocaHandle );
      g_mocaHandle = NULL;
   }
   else
   { 
      fprintf(stderr,"%s: Cannot connect to mocad.  Is it running?\n", g_szPgmName );
      nExitCode = CMSRET_DISCONNECTED;
   }
    

   return( nExitCode );
}

/***************************************************************************
 * Function Name: DumpOpt
 * Description  : Debug function that dumps the options and parameters
 *                for a particular command.
 * Returns      : None.
 ***************************************************************************/
void DumpOption( char *pszCmdName, POPTION_INFO pOptions, int nNumOptions )
{
   POPTION_INFO pOpt;
   int i, j;

   fprintf( stderr, "cmd=%s\n", pszCmdName );
   for( i = 0; i < nNumOptions; i++ )
   {
      pOpt = pOptions + i;
      fprintf(stderr, "opt=%s, %d parms=",pOpt->pszOptName,pOpt->nNumParms);
      for( j = 0; j < pOpt->nNumParms; j++ )
      {
         fprintf( stderr, pOpt->pszParms[j] );
         fprintf( stderr, " " );
      }
      fprintf( stderr, "\n" );
   }
   fprintf( stderr, "\n" );
}


/***************************************************************************
 * Function Name: StartHandler
 * Description  : Processes the mocactl start command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int StartHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet                    nRet = CMSRET_SUCCESS;
   UINT64                    initMask = 0x0 ;
   UINT64                    tMask = 0x0;
   MoCA_INITIALIZATION_PARMS InitParms;   
   MoCA_CONFIG_PARAMS        configParms ;
   MoCA_TRACE_PARAMS         traceParms ;
   MoCA_STATUS               status;
   UINT64                    configMask = 0LL ;
   UINT32                    o_rftype;
   UINT32                    o_turboEn;
   UINT32                    o_terminal;
   UINT32                    o_dontstartmoca;

   memset(&InitParms, 0x00, sizeof(InitParms));

   /* Make sure MoCA is stopped before doing anything */
   memset(&status, 0x00, sizeof(status));
   nRet = MoCACtl2_GetStatus(g_mocaHandle, &status);
   if (nRet != CMSRET_SUCCESS)
   {
      fprintf( stderr, "%s: Unable to get MoCA status (%d)\n",
            g_szPgmName, nRet );
      return(nRet);      
   }
   else if (status.generalStatus.selfMoCAVersion != 0)
   {
      fprintf( stderr, "%s: MoCA is already running. Use '%s stop' first.\n",
            g_szPgmName, g_szPgmName );
      return(CMSRET_REQUEST_DENIED);
   }
   
   MoCACtl2_GetInitParms( g_mocaHandle, &InitParms);

   o_dontstartmoca = InitParms.initOptions.dontStartMoca;
   
   o_rftype = InitParms.rfType;
   o_turboEn = InitParms.turboEn;
   o_terminal = InitParms.terminalIntermediateType;

   InitParms.initOptions.dontStartMoca = 0;

   nRet = mocacli_parse_init_parms (g_szPgmName, pOptions, nNumOptions, &InitParms, &initMask);

   if (( nRet == CMSRET_SUCCESS ) && (o_dontstartmoca != 2)) 
   {
      if (((o_rftype != 0xFFFFFFFF) && (o_rftype != InitParms.rfType)) ||
           (InitParms.turboEn != o_turboEn) || (InitParms.terminalIntermediateType != o_terminal))
      {
          // reset to defaults if user changes rfType
          printf("WARNING: rfType, turbo mode or node_type changed, setting config and init parms to defaults\n");

          if ((o_rftype != 0xFFFFFFFF) && (o_rftype != InitParms.rfType))
          {
              tMask = MoCA_INIT_PARAM_BEACON_CHANNEL_MASK;
              InitParms.beaconChannel  = 0;
          }

          MoCACtl2_SetInitParms(g_mocaHandle, &InitParms, 
            initMask & (tMask | MoCA_INIT_PARAM_RF_TYPE_MASK|
                        MoCA_INIT_PARAM_TURBO_EN_MASK|
                        MoCA_INIT_PARAM_TERMINAL_INTERMEDIATE_TYPE_MASK) );

          MoCACtl2_RestoreDefaults(g_mocaHandle);

          MoCACtl2_GetInitParms( g_mocaHandle, &InitParms); 

          InitParms.initOptions.dontStartMoca = 0;
          
          // reparse for any changed parameters
          nRet = mocacli_parse_init_parms (g_szPgmName, pOptions, nNumOptions, &InitParms, &initMask);

          // if LOF not set, use 0
          if (InitParms.nvParams.lastOperFreq == MoCA_FREQ_UNSET)
          {
             if (InitParms.rfType == MoCA_RF_TYPE_C4_BAND)
                InitParms.nvParams.lastOperFreq = 1000;
             else
                InitParms.nvParams.lastOperFreq = 0;
          }
      }
   }
   
   MoCACtl2_GetTraceConfig( g_mocaHandle, &traceParms);
   traceParms.bRestoreDefault = FALSE ;
   nRet = MoCACtl2_SetTraceConfig( g_mocaHandle, &traceParms ) ;

   if (InitParms.initOptions.dontStartMoca==1)
      printf("WARNING: Initializing MoCA with --wait 1 flag.  MoCA not starting\n");
   
   if( nRet == CMSRET_SUCCESS ) {
      nRet = MoCACtl2_Initialize( g_mocaHandle, &InitParms, NULL, 0 ) ;
   }

   if ((nRet == CMSRET_SUCCESS) && (g_NvModeEnabled)) {
      if (InitParms.constTransmitMode == MoCA_NORMAL_OPERATION)
         MoCACtl2_SetPersistent(g_mocaHandle, "MoCAINITPARMS", (char *) &InitParms, sizeof (MoCA_INITIALIZATION_PARMS)) ;
      
         configMask = MoCA_CFG_NON_LAB_PARAM_ALL_MASK ;
         MoCACtl2_GetCfg( g_mocaHandle, &configParms, configMask);
      
         MoCACtl2_SetPersistent(g_mocaHandle, "MoCACFGPARMS", (char *) &configParms, sizeof (MoCA_CONFIG_PARAMS)) ;      
   }

   return( nRet );
} /* StartHandler */
    
/***************************************************************************
 * Function Name: StopHandler
 * Description  : Processes the mocactl stop command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int StopHandler( POPTION_INFO pOptions, int nNumOptions )
{
   return( MoCACtl2_Uninitialize( g_mocaHandle ) );
} /* StopHandler */


/***************************************************************************
 * Function Name: ReStartHandler
 * Description  : Processes the mocactl restart command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int ReStartHandler( POPTION_INFO pOptions, int nNumOptions )
{
   MoCACtl2_Uninitialize( g_mocaHandle );

   return (StartHandler( pOptions, nNumOptions));
} /* ReStartHandler */

/***************************************************************************
 * Function Name: ConfigHandler
 * Description  : Processes the mocactl config command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int ConfigHandler ( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS;
   MoCA_CONFIG_PARAMS configParms, nvConfigParms ;
   MoCA_CONFIG_PARAMS tmpParms;   
   MoCA_INITIALIZATION_PARMS initParms;
   UINT64 configMask ;

   memset (&configParms, 0x00, sizeof(configParms)) ;
   configMask = 0x0LL ;

   MoCACtl2_GetInitParms( g_mocaHandle, &initParms ) ;

   nRet = MoCACtl2_GetCfg(g_mocaHandle, &tmpParms, MoCA_CFG_PARAM_SAPM_TABLE_MASK 
                           | MoCA_CFG_PARAM_RLAPM_TABLE_MASK | MoCA_CFG_PARAM_RLAPM_EN_MASK 
                           | MoCA_CFG_PARAM_EGR_MC_ADDR_FILTER_MASK);

   /* sapm_GSM hack. we need the current frequency, store it in tmp.res1 */
   tmpParms.res1 = initParms.nvParams.lastOperFreq;
   
   if ( mocacli_parse_config_parms( g_szPgmName, pOptions, nNumOptions, 
                                    &configParms, &configMask, &tmpParms ) != 0 )
      nRet = CMSRET_INVALID_ARGUMENTS;
   else
      nRet = CMSRET_SUCCESS;
   
   if( nRet == CMSRET_SUCCESS ) {

      if ((configMask & MoCA_CFG_PARAM_SNR_MARGIN_MASK) &&
          !(configMask & MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK)) {
         /* Use the SNR Margin offsets stored in flash if not supplied at the CLI.
            If no values exist in flash, send zeroes for SNR margin offset. */
         if (MoCACtl2_GetPersistent(g_mocaHandle, "MoCACFGPARMS", (char *) &nvConfigParms, sizeof (MoCA_CONFIG_PARAMS)) > 0) {
            memcpy ( &configParms.snrMarginOffset[0], &nvConfigParms.snrMarginOffset[0], 
                     sizeof(nvConfigParms.snrMarginOffset) ) ;
         }
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK ;
      }
      else if ((configMask & MoCA_CFG_PARAM_SNR_MARGIN_OFFSET_MASK) &&
               !(configMask & MoCA_CFG_PARAM_SNR_MARGIN_MASK)) {
         /* Use the SNR Margin stored in flash if not supplied at the CLI.
            If no values exist in flash, send zeroes for SNR margin. */
         if (MoCACtl2_GetPersistent(g_mocaHandle, "MoCACFGPARMS", (char *) &nvConfigParms, sizeof (MoCA_CONFIG_PARAMS)) > 0) {
            memcpy ( &configParms.snrMargin, &nvConfigParms.snrMargin, 
                     sizeof(nvConfigParms.snrMargin) ) ;
         }
         configMask |= MoCA_CFG_PARAM_SNR_MARGIN_MASK ;          
      }

      if( nRet == CMSRET_SUCCESS ) {
         nRet = MoCACtl2_SetCfg( g_mocaHandle, &configParms, configMask ) ;
      }
      else {
         fprintf( stderr, "%s: Config failed (%d)\n", 
            g_szPgmName, nRet );
      }

      if ((nRet == CMSRET_SUCCESS) && (configMask & MoCA_CFG_PARAM_LAB_REG_MEM_MASK)) {
         fprintf( stderr, "%s: Register 0x%08x = 0x%08x\n", 
            g_szPgmName, configParms.RegMem.input, configParms.RegMem.value[0] );
      }
   }   

   if (nRet == CMSRET_SUCCESS) {
     memset (&configParms, 0x00, sizeof(configParms)) ;

     if (initParms.constTransmitMode == MoCA_NORMAL_OPERATION) {
        /* Only try to save the current configuration in normal mode,
         * in const tx mode, we don't know what we're going to get */
        if (g_NvModeEnabled) {
           nRet = MoCACtl2_GetCfg( g_mocaHandle, &configParms, MoCA_CFG_PARAM_ALL_MASK ) ;
           configParms.outOfOrderLmo = MoCA_MAX_NODES ;
           if (nRet == CMSRET_SUCCESS) {
              MoCACtl2_SetPersistent(g_mocaHandle, "MoCACFGPARMS", (char *) &configParms, sizeof (MoCA_CONFIG_PARAMS)) ;
           }
        }

      }
   }

   return( nRet );
} /* ConfigHandler */


/***************************************************************************
 * Function Name: ShowHandler
 * Description  : Processes the mocactl show command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int ShowHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS;

   while( nRet == CMSRET_SUCCESS && nNumOptions )
   {
      if( !strcmp( pOptions->pszOptName, "--initparms" ) )
      {
         nRet = ShowHandlerInitParms( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--config" ) )
      {
         nRet = ShowHandlerConfig( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--status" ) )
      {
         nRet = ShowHandlerStatus( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--stats" ) )
      {
         nRet = ShowHandlerStats( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--traceconfig" ) )
      {
         nRet = ShowHandlerTraceConfig( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--nodestatus" ) )
      {
         nRet = ShowHandlerNodeStatus( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--nodestats" ) )
      {
         nRet = ShowHandlerNodeStats( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--mocareg" ) )
      {
         nRet = ShowHandlerMoCARegister( pOptions ) ;
      }

      nNumOptions-- ;
      pOptions++ ;
   }

   return( nRet ) ;
} /* ShowHandler */

/***************************************************************************
 * Function Name: ShowHandlerInitParms
 * Description  : Processes the mocactl operate show --initparms command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowHandlerInitParms( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS;
   uint16_t pwdHash = 0;

   if( pOpt->nNumParms == 0 )
   {
      MoCA_INITIALIZATION_PARMS InitParms;

      /* Read the current global configuration. */
      nRet = MoCACtl2_GetInitParms( g_mocaHandle, &InitParms ) ;
      if (nRet == CMSRET_SUCCESS) {
         mocacli_print_init_parms( &InitParms );

         /* Print password hash value */
         pwdHash = moca_password_hash((char *)InitParms.password);
         printf ("Password Hash              : %04x \n", pwdHash);
         printf ("=============================================\n");
      }
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf(stderr,"%s: invalid parameter for option show initconfig %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet );
} /* ShowHandlerInitParms */

/***************************************************************************
 * Function Name: ShowHandlerConfig
 * Description  : Processes the mocactl operate show --config command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowHandlerConfig( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS;
   UINT32 showAbsSnrTable = 0 ;

   if( pOpt->nNumParms == 1 ) {
      if ( !strcmp( pOpt->pszParms[0], "--abs" ) ) {
         showAbsSnrTable = 1 ;
      }
   }

   if (( pOpt->nNumParms == 0 ) || (pOpt->nNumParms == 1)) {

      MoCA_CONFIG_PARAMS Cfg;
      MoCA_INITIALIZATION_PARMS mocaInit;

      nRet = MoCACtl2_GetInitParms( g_mocaHandle, &mocaInit);

      if (nRet != CMSRET_SUCCESS)
         mocaInit.rfType = MoCA_RF_TYPE_E_BAND;

      memset( &Cfg, 0x00, sizeof(Cfg) );

      /* Read the current global configuration. */
      nRet = MoCACtl2_GetCfg( g_mocaHandle, &Cfg, MoCA_CFG_PARAM_ALL_MASK ) ;      
      if (nRet == CMSRET_SUCCESS) {
         mocacli_print_config( &Cfg, showAbsSnrTable, mocaInit.rfType);
      }
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf(stderr,"%s: invalid parameters for option show config %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet );
} /* ShowHandlerConfig */


/***************************************************************************
 * Function Name: ShowHandlerTraceConfig
 * Description  : Processes the mocactl operate show --traceconfig command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowHandlerTraceConfig( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS;

   if( pOpt->nNumParms == 0 )
   {
      MoCA_TRACE_PARAMS traceCfg;

      memset( &traceCfg, 0x00, sizeof(traceCfg) );
      /* Read the current global configuration. */
      nRet = MoCACtl2_GetTraceConfig( g_mocaHandle, &traceCfg ) ;
      if (nRet == CMSRET_SUCCESS) {
         mocacli_print_trace_config(&traceCfg);
      }
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf(stderr,"%s: invalid parameter for option show trace config %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet );
} /* ShowHandlerTraceConfig */

#define NO_OF_SECS_IN_MIN        60
#define NO_OF_MINS_IN_HR         60

void convertUpTime (UINT32 timeInSecs, UINT32 *pTimeInHrs, UINT32 *pTimeInMin, UINT32 *pTimeInSecs)
{
   *pTimeInHrs  = timeInSecs / (NO_OF_SECS_IN_MIN * NO_OF_MINS_IN_HR) ;
   timeInSecs   = timeInSecs % (NO_OF_SECS_IN_MIN * NO_OF_MINS_IN_HR) ;
   *pTimeInMin  = timeInSecs / NO_OF_SECS_IN_MIN ;
   timeInSecs   = timeInSecs % NO_OF_SECS_IN_MIN ;
   *pTimeInSecs = timeInSecs ;
   return ;
}

UINT8 macaddr_getbyte(UINT32 *macaddr, int byte)
{
    MAC_ADDRESS mac;

    moca_u32_to_mac(mac, macaddr[0], macaddr[1]);

    return (mac[byte]);
}

/***************************************************************************
 * Function Name: ShowHandlerStatus
 * Description  : Processes the mocactl operate show --status command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowHandlerStatus( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS;
   int count ;
   UINT32 noOfNodes = 0 ;

   if( pOpt->nNumParms == 0 )
   {
      MoCA_STATUS status;
      UINT32 coreversionMajor, coreversionMinor, coreversionBuild ;
      UINT32 timeH, timeM, timeS ;

      memset( &status, 0x00, sizeof(status) );

      /* Read the current status */
      nRet = MoCACtl2_GetStatus( g_mocaHandle, &status ) ;
      if (nRet == CMSRET_SUCCESS) {
         coreversionMajor = status.generalStatus.swVersion >> 28 ;
         coreversionMinor = (status.generalStatus.swVersion << 4) >> 28 ;
         coreversionBuild = (status.generalStatus.swVersion << 8) >> 8 ;

         printf ("           MoCA Status(General)     \n");
         printf ("==================================  \n");
         printf ("vendorId                  : %d \t\t", status.generalStatus.vendorId) ;
         printf ("HwVersion                 : 0x%x \n", status.generalStatus.hwVersion) ;
         printf ("SwVersion                 : %d.%d.%d \t", coreversionMajor, coreversionMinor,
               coreversionBuild) ;
         printf ("self MoCA Version         : 0x%x \n", status.generalStatus.selfMoCAVersion)  ;
         printf ("networkVersionNumber      : 0x%x \t", status.generalStatus.networkVersionNumber)  ;
         printf ("qam256Support             : %s \n", (status.generalStatus.qam256Support == MoCA_QAM_256_SUPPORT_ON) ? "supported" : "unknown" )  ;
         if (status.generalStatus.operStatus == MoCA_OPER_STATUS_ENABLED)
            printf ("operStatus                : Enabled \t") ;
         else
            printf ("operStatus                : Hw Error \t") ;
         if (status.generalStatus.linkStatus == MoCA_LINK_UP)
            printf ("linkStatus                : Up \n") ;
         else
            printf ("linkStatus                : Down \n") ;
         printf ("connectedNodes BitMask    : 0x%x \t", status.generalStatus.connectedNodes)  ;
         if (status.generalStatus.nodeId >= MoCA_MAX_NODES)
            printf ("nodeId                    : N/A \n") ;
         else
            printf ("nodeId                    : %u \n", status.generalStatus.nodeId)  ;
         if (status.generalStatus.ncNodeId >= MoCA_MAX_NODES)
            printf ("ncNodeId                  : N/A \n") ;
         else
            printf ("ncNodeId                  : %u \t\t", status.generalStatus.ncNodeId)  ;
         convertUpTime (status.miscStatus.MoCAUpTime, &timeH, &timeM, &timeS) ;
         printf ("upTime                    : %02uh:%02um:%02us\n", timeH, timeM, timeS) ;
         convertUpTime (status.miscStatus.linkUpTime, &timeH, &timeM, &timeS) ;
         printf ("linkUpTime                : %02uh:%02um:%02us\t", timeH, timeM, timeS) ;
         if (status.generalStatus.backupNcId >= MoCA_MAX_NODES)
            printf ("backupNcId                : N/A \n") ;
         else
            printf ("backupNcId                : %u \n", status.generalStatus.backupNcId)  ;
         printf ("rfChannel                 : %u Mhz\t", status.generalStatus.rfChannel)  ;
         printf ("bwStatus                  : 0x%x \n", status.generalStatus.bwStatus)  ;
         printf ("NodesUsableBitMask        : 0x%x \t", status.generalStatus.nodesUsableBitmask)  ;
         printf ("NetworkTabooMask          : 0x%x \n", status.generalStatus.networkTabooMask)  ;
         printf ("NetworkTabooStart         : %d \t\t", status.generalStatus.networkTabooStart)  ;
         printf ("txGcdPowerReduction       : %d \n", status.generalStatus.txGcdPowerReduction) ;
         printf ("pqosEgressNumFlows        : %d \t\t", status.generalStatus.pqosEgressNumFlows) ;
         /* find the number of connected nodes from the connected nodes bitmask */
         for (count = 0 ; count < MoCA_MAX_NODES ; count++) {
            if (status.generalStatus.connectedNodes & (0x1 << count))
               noOfNodes++ ;
         }
         printf ("Num of connectedNodes     : %d \n", noOfNodes) ;
         printf ("ledStatus                 : %x \n", status.generalStatus.ledStatus) ;
         printf ("==================================  \n");
         printf ("           MoCA Status(Extended)    \n");
         printf ("==================================  \n");

         

         convertUpTime (status.extendedStatus.lastPmkExchange, &timeH, &timeM, &timeS) ;
         printf ("lastPmkExchange           : %02uh:%02um:%02us\n", timeH, timeM, timeS ) ;
         printf ("lastPmkInterval           : %d sec\n", status.extendedStatus.lastPmkInterval ) ;        

         convertUpTime (status.extendedStatus.lastTekExchange, &timeH, &timeM, &timeS) ;
         printf ("lastTekExchange           : %02uh:%02um:%02us\n", timeH, timeM, timeS ) ;
         printf ("lastTekInterval           : %d sec\n", status.extendedStatus.lastTekInterval ) ;          

         printf ("PMK Even Key              : %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x %s\n",
               status.extendedStatus.pmkEvenKey[0], status.extendedStatus.pmkEvenKey[1],
               status.extendedStatus.pmkEvenKey[2], status.extendedStatus.pmkEvenKey[3],
               status.extendedStatus.pmkEvenKey[4], status.extendedStatus.pmkEvenKey[5],
               status.extendedStatus.pmkEvenKey[6], status.extendedStatus.pmkEvenKey[7],
               status.extendedStatus.pmkEvenOdd==0?"(ACTIVE)":"") ;
         printf ("PMK Odd Key               : %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x %s\n",
               status.extendedStatus.pmkOddKey[0], status.extendedStatus.pmkOddKey[1],
               status.extendedStatus.pmkOddKey[2], status.extendedStatus.pmkOddKey[3],
               status.extendedStatus.pmkOddKey[4], status.extendedStatus.pmkOddKey[5],
               status.extendedStatus.pmkOddKey[6], status.extendedStatus.pmkOddKey[7],
               status.extendedStatus.pmkEvenOdd==1?"(ACTIVE)":"") ;
         printf ("TEK Even Key              : %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x %s\n",
               status.extendedStatus.tekEvenKey[0], status.extendedStatus.tekEvenKey[1],
               status.extendedStatus.tekEvenKey[2], status.extendedStatus.tekEvenKey[3],
               status.extendedStatus.tekEvenKey[4], status.extendedStatus.tekEvenKey[5],
               status.extendedStatus.tekEvenKey[6], status.extendedStatus.tekEvenKey[7],
               status.extendedStatus.tekEvenOdd==0?"(ACTIVE)":"") ;
         printf ("TEK Odd Key               : %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x %s\n",
               status.extendedStatus.tekOddKey[0], status.extendedStatus.tekOddKey[1],
               status.extendedStatus.tekOddKey[2], status.extendedStatus.tekOddKey[3],
               status.extendedStatus.tekOddKey[4], status.extendedStatus.tekOddKey[5],
               status.extendedStatus.tekOddKey[6], status.extendedStatus.tekOddKey[7],
               status.extendedStatus.tekEvenOdd==1?"(ACTIVE)":"") ;
         printf ("==================================  \n");
         printf ("           MoCA Status(Misc)    \n");
         printf ("==================================  \n");
         printf ("MAC GUID                  : %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\n",
               status.miscStatus.macAddr[0],
               status.miscStatus.macAddr[1],
               status.miscStatus.macAddr[2],
               status.miscStatus.macAddr[3],
               status.miscStatus.macAddr[4],
               status.miscStatus.macAddr[5]) ;
         printf ("Are we Network Controller : %s \n", (status.miscStatus.isNC == 1) ? "yes" : "no") ;
         convertUpTime (status.miscStatus.driverUpTime, &timeH, &timeM, &timeS) ;
         printf ("Driver Up Time            : %02uh:%02um:%02us \n", timeH, timeM, timeS) ;
         printf ("Link Reset Count          : %u \n", status.miscStatus.linkResetCount) ;
         printf ("==================================  \n");
      }
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf(stderr,"%s: invalid parameter for option show status %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet );
} /* ShowHandlerStatus */


/***************************************************************************
 * Function Name: ShowHandlerStats
 * Description  : Processes the mocactl show --stats [reset] command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowHandlerStats( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS;
   UINT32 ulReset = 0;
   int count;
   int i;
   MoCA_NODE_STATISTICS_EXT_ENTRY cummulativeExtStats;
   MoCA_NODE_STATISTICS_EXT_ENTRY nodeStats ;

   memset(&cummulativeExtStats, 0, sizeof(cummulativeExtStats));

   if(( pOpt->nNumParms == 1 ) && !strcmp( pOpt->pszParms[0], "reset" ) ) 
      ulReset = 1;

   if(pOpt->nNumParms <= 1) {

      MoCA_STATISTICS Stats ;

      nRet = MoCACtl2_GetStatistics( g_mocaHandle, &Stats, 0)  ;
      if (nRet == CMSRET_SUCCESS) {
         printf ("       MoCA Stats(General)          \n");
         printf ("==================================  \n");
         printf ("inUcPkts             : %u \t", Stats.generalStats.inUcPkts) ;
         printf ("inDiscardPktsEcl     : %u \n", Stats.generalStats.inDiscardPktsEcl) ;
         printf ("inDiscardPktsMac     : %u \t", Stats.generalStats.inDiscardPktsMac) ;
         printf ("inUnKnownPkts        : %u \n", Stats.generalStats.inUnKnownPkts) ;
         printf ("inMcPkts             : %u \t", Stats.generalStats.inMcPkts) ;
         printf ("inBcPkts             : %u \n", Stats.generalStats.inBcPkts) ;
         printf ("inOctets_hi          : %u \t", Stats.BitStats64.inOctets_hi) ;
         printf ("inOctets_low         : %u \n", Stats.generalStats.inOctets_low) ;
         printf ("outUcPkts            : %u \t", Stats.generalStats.outUcPkts) ;
         printf ("outDiscardPkts       : %u \n", Stats.generalStats.outDiscardPkts) ;
         printf ("outBcPkts            : %u \t", Stats.generalStats.outBcPkts) ;
         printf ("outOctets_hi         : %u \n", Stats.BitStats64.outOctets_hi) ;
         printf ("outOctets_low        : %u \t", Stats.generalStats.outOctets_low) ;
         printf ("ncHandOffs           : %u \n", Stats.generalStats.ncHandOffs) ;
         printf ("ncBackups            : %u \n", Stats.generalStats.ncBackups) ;
         for (count = 0; count < 10; count++) {
            printf ("aggrPktStatsTx[%u]    : %u pkts \t", count, Stats.generalStats.aggrPktStatsTx[count]*(count+1)) ;
            printf ("aggrPktStatsRx[%u]    : %u pkts \n", count, Stats.generalStats.aggrPktStatsRx[count]*(count+1)) ;            
         }
         printf ("ReceivedDataFiltered : %u \n", Stats.generalStats.receivedDataFiltered) ;         
         printf ("LowDropData          : %u \n", Stats.generalStats.lowDropData) ;         

         printf ("==================================  \n");
         printf ("       MoCA Stats(Extended)         \n");
         printf ("==================================  \n");
         printf ("rxMapPkts            : %u \t", Stats.extendedStats.rxMapPkts) ;
         printf ("rxRRPkts             : %u \n", Stats.extendedStats.rxRRPkts) ;
         printf ("rxBeacons            : %u \t", Stats.extendedStats.rxBeacons) ;
         printf ("rxCtrlPkts           : %u \n", Stats.extendedStats.rxCtrlPkts) ;
         printf ("txBeacons            : %u \t", Stats.extendedStats.txBeacons) ;
         printf ("txMaps               : %u \n", Stats.extendedStats.txMaps) ;
         printf ("txLinkCtrlPkts       : %u \t", Stats.extendedStats.txLinkCtrlPkts) ;
         printf ("resyncAttempts       : %u \n", Stats.extendedStats.resyncAttempts) ;
         printf ("gMiiTxBufFull        : %u \t", Stats.extendedStats.gMiiTxBufFull) ;
         printf ("MoCARxBufFull        : %u \n", Stats.extendedStats.MoCARxBufFull) ;
         printf ("thisHandOffs         : %u \t", Stats.extendedStats.thisHandOffs) ;
         printf ("thisBackups          : %u \n", Stats.extendedStats.thisBackups) ;
         printf ("fcCounter[0]         : %u \t", Stats.extendedStats.fcCounter[0]) ;
         printf ("fcCounter[1]         : %u \n", Stats.extendedStats.fcCounter[1]) ;
         printf ("fcCounter[2]         : %u \t", Stats.extendedStats.fcCounter[2]) ;
         printf ("txProtocolIe         : %u \n", Stats.extendedStats.txProtocolIe) ;
         printf ("rxProtocolIe         : %u \t", Stats.extendedStats.rxProtocolIe) ;
         printf ("txTimeIe             : %u \n", Stats.extendedStats.txTimeIe) ;
         printf ("rxTimeIe             : %u \t", Stats.extendedStats.rxTimeIe) ;
         printf ("rxLcAdmReqCrcErr     : %u \n", Stats.extendedStats.rxLcAdmReqCrcErr) ;

         printf ("==================================  \n");
         printf ("       MoCA Errors                  \n");
         printf ("==================================  \n");       

         for (count=0;count<MoCA_MAX_NODES;count++)
         {
             unsigned int *dest = (unsigned int *) &cummulativeExtStats;
             unsigned int *src = (unsigned int *) &nodeStats;
            
             nodeStats.nodeId = count ;
             nRet = MoCACtl2_GetNodeStatisticsExt( g_mocaHandle, &nodeStats, 0) ;

             if (nRet == CMSRET_SUCCESS)
             {
                for(i=0;i<sizeof(nodeStats)/sizeof(unsigned int);i++)
                    *(dest++) += *(src++);                    
             }
         }

         // This will reset all stats, including MoCA_STATISTICS
         if (ulReset)
            nRet = MoCACtl2_GetNodeStatisticsExt( g_mocaHandle, &nodeStats, 1) ;
         
         printf ("RX_UC_CRC_ERROR                  : %d \n", cummulativeExtStats.rxUcCrcError);
         printf ("RX_UC_TIMEOUT_ERROR              : %d \n", cummulativeExtStats.rxUcTimeoutError);  
         printf ("RX_BC_CRC_ERROR                  : %d \n", cummulativeExtStats.rxBcCrcError);
         printf ("RX_BC_TIMEOUT_ERROR              : %d \n", cummulativeExtStats.rxBcTimeoutError);
         
         printf ("RX_MAP_CRC_ERROR                 : %d \n", cummulativeExtStats.rxMapCrcError);
         printf ("RX_MAP_TIMEOUT_ERROR             : %d \n", cummulativeExtStats.rxMapTimeoutError);
         printf ("RX_BEACON_CRC_ERROR              : %d \n", cummulativeExtStats.rxBeaconCrcError);
         printf ("RX_BEACON_TIMEOUT_ERROR          : %d \n", cummulativeExtStats.rxBeaconTimeoutError);
         printf ("RX_RR_CRC_ERROR                  : %d \n", cummulativeExtStats.rxRrCrcError);
         printf ("RX_RR_TIMEOUT_ERROR              : %d \n", cummulativeExtStats.rxRrTimeoutError);
         
         printf ("RX_LC_CRC_ERROR                  : %d \n", cummulativeExtStats.rxLcCrcError);
         printf ("RX_LC_TIMEOUT_ERROR              : %d \n", cummulativeExtStats.rxLcTimeoutError);
         
         printf ("RX_P1_ERROR                      : %d \n", cummulativeExtStats.rxP2Error);
         printf ("RX_P2_ERROR                      : %d \n", cummulativeExtStats.rxP2Error);
         printf ("RX_P3_ERROR                      : %d \n", cummulativeExtStats.rxP3Error);
         printf ("RX_P1_GCD_ERROR                  : %d \n", cummulativeExtStats.rxP1GcdError);
      }
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf( stderr, "%s: invalid parameter for option show stats %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet ) ;
} /* ShowHandlerStats */


/***************************************************************************
 * Function Name: ShowHandlerNodeStatus
 * Description  : Processes the mocactl show --nodestatus <nodeId> command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowHandlerNodeStatus( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS ;
   UINT32 ulNodeId =0;
   UINT32 csv = 0;

   if( pOpt->nNumParms == 0 ) {
    
       nRet = CMSRET_INVALID_ARGUMENTS;
       fprintf( stderr, "%s: invalid number of parameters for option "
             "%s\n", g_szPgmName, pOpt->pszOptName );
   }
   else
   {
      char *pszEnd = NULL ;
      while(pOpt->nNumParms > 0)
      {
           pOpt->nNumParms--;

          if (strcmp( pOpt->pszParms[pOpt->nNumParms],"csv") == 0)
          {
            csv = 1;
          }
          else
          {
              ulNodeId = (long) strtol ( pOpt->pszParms[pOpt->nNumParms], &pszEnd, 10 ) ;
              if( *pszEnd != '\0' ) {
                 nRet = CMSRET_INVALID_ARGUMENTS ;
                 fprintf( stderr, "%s: invalid parameter for option %s\n",
                       g_szPgmName, pOpt->pszOptName ) ;
              }
          }

      }
   }

   if (nRet == CMSRET_SUCCESS)
   {
      MoCA_NODE_STATUS_ENTRY nodeStatus ;

      nodeStatus.nodeId = ulNodeId ;
      nRet = MoCACtl2_GetNodeStatus( g_mocaHandle, &nodeStatus) ;
      if (nRet == CMSRET_SUCCESS) {
         mocacli_display_node_status (&nodeStatus, 1, csv, 1) ;
      }
   }

   return( nRet ) ;
} /* ShowHandlerNodeStatus */


/***************************************************************************
 * Function Name: ShowHandlerNodeStats
 * Description  : Processes the mocactl show --nodestats <nodeId> command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowHandlerNodeStats( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS ;
   UINT32 ulReset = 0;
   UINT32 ulNodeId ;
   MoCA_NODE_STATUS_ENTRY nodeStatus ;

   if(( pOpt->nNumParms == 2 ) && !strcmp( pOpt->pszParms[1], "reset" ) ) 
      ulReset = 1 ;

   if ((pOpt->nNumParms == 1) || (pOpt->nNumParms == 2)) {
      char *pszEnd = NULL ;
      ulNodeId = (long) strtol ( pOpt->pszParms[0], &pszEnd, 10 ) ;
      if( *pszEnd != '\0' ) {
         nRet = CMSRET_INVALID_ARGUMENTS ;
         fprintf( stderr, "%s: invalid parameter for option %s\n",
               g_szPgmName, pOpt->pszOptName ) ;
      }
   }
   else {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf( stderr, "%s: invalid number of parameters for option "
            "%s\n", g_szPgmName, pOpt->pszOptName );
   }

   if (nRet == CMSRET_SUCCESS)
   {
      nodeStatus.nodeId = ulNodeId ;
      nRet = MoCACtl2_GetNodeStatus( g_mocaHandle, &nodeStatus) ;
   }

   if (nRet == CMSRET_SUCCESS)
   {
      MoCA_NODE_STATISTICS_ENTRY nodeStats ;


      nodeStats.nodeId = ulNodeId ;
      nRet = MoCACtl2_GetNodeStatistics( g_mocaHandle, &nodeStats, ulReset) ;
      if (nRet == CMSRET_SUCCESS) {
         mocacli_display_node_stats (&nodeStatus, &nodeStats) ;
      }
   }

   if (nRet == CMSRET_SUCCESS)
   {
      MoCA_NODE_STATISTICS_EXT_ENTRY nodeStats ;

      nodeStats.nodeId = ulNodeId ;
      nRet = MoCACtl2_GetNodeStatisticsExt( g_mocaHandle, &nodeStats, ulReset) ;
      
      if (nRet == CMSRET_SUCCESS) {
         mocacli_display_node_stats_ext (&nodeStats) ;
      }
   }   

   return( nRet ) ;
} /* ShowHandlerNodeStats */

/***************************************************************************
 * Function Name: ShowHandlerMoCARegister
 * Description  : Processes the mocactl show --mocareg <regAddr> command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowHandlerMoCARegister( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS ;
   MoCA_CONFIG_PARAMS configParms;
   UINT64 configMask ;

   memset (&configParms, 0x00, sizeof(configParms)) ;
   configMask = 0x0LL ;

   if( pOpt->nNumParms == 1)
   {
      char *pszEnd = NULL ;
      configParms.RegMem.input = (long) strtoul ( pOpt->pszParms[0], &pszEnd, 16 ) ;
      configMask |= MoCA_CFG_PARAM_LAB_REG_MEM_MASK ;
   }
   else {
      nRet = CMSRET_INVALID_ARGUMENTS;
   }

   if( nRet != CMSRET_SUCCESS )
      fprintf( stderr, "%s: invalid parameter for option %s\n",
            g_szPgmName, pOpt->pszOptName );

   if (nRet == CMSRET_SUCCESS)
   {
      nRet = MoCACtl2_GetCfg( g_mocaHandle, &configParms, configMask );

      if (nRet == CMSRET_SUCCESS) {
         fprintf( stderr, "%s: Register 0x%08x = 0x%08x\n", 
            g_szPgmName, configParms.RegMem.input, configParms.RegMem.value[0] );
      }
      else {
         fprintf( stderr, "%s: MoCACtl2_GetCfg failed. Error = 0x%x\n", __FUNCTION__, nRet );
      }
   }

   return( nRet ) ;
} /* ShowHandlerMoCARegister */


/***************************************************************************
 * Function Name: ShowTblHandler
 * Description  : Processes the mocactl showtbl command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int ShowTblHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS ;

   while( nRet == CMSRET_SUCCESS && nNumOptions )
   {
      if( !strcmp( pOptions->pszOptName, "--nodestatus" ) )
      {
         nRet = ShowTblHandlerNodeStatus( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--nodestats" ) )
      {
         nRet = ShowTblHandlerNodeStats( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--ucfwd" ) )
      {
         nRet = ShowTblHandlerUcFwd( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--srcaddr" ) )
      {
         nRet = ShowTblHandlerSrcAddr( pOptions ) ;
      }
      else if( !strcmp( pOptions->pszOptName, "--mcfwd" ) )
      {
         nRet = ShowTblHandlerMcFwd( pOptions ) ;
      }

      nNumOptions-- ;
      pOptions++ ;
   }

   return( nRet ) ;
} /* ShowTblHandler */


/***************************************************************************
 * Function Name: ShowTblHandlerNodeStatus
 * Description  : Processes the mocactl operate showtbl --nodestats command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowTblHandlerNodeStatus( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS;
   unsigned int csv = 0;

   if( pOpt->nNumParms < 2 ) 
   {
      int      nodes ;
      UINT32   tblSize ;
      MoCA_NODE_STATUS_ENTRY        nodeStatus [MoCA_MAX_NODES] ;
      MoCA_NODE_COMMON_STATUS_ENTRY nodeCommonStatus ;

      if( pOpt->nNumParms == 1 ) {    

         if (strcmp( pOpt->pszParms[0],"csv") == 0)
         {
            csv = 1;
         }
         else
         {
            fprintf( stderr, "%s: invalid parameter for option %s\n",
                     g_szPgmName, pOpt->pszOptName ) ;
         }
      }

      nRet = MoCACtl2_GetNodeTblStatus( g_mocaHandle, &nodeStatus [0], &nodeCommonStatus, &tblSize ) ;
         
      if (nRet == CMSRET_SUCCESS) {
         tblSize /= sizeof (MoCA_NODE_STATUS_ENTRY) ;  /* No of Nodes */

         if (!csv)
         {
             printf ("           MoCA Node Status Table            \n");
             printf ("=============================================\n");
         }
         
         for (nodes = 0; nodes < (int)tblSize; nodes++) {
            //mocacli_display_node_status (&nodeStatus[nodes], 0) ;
            mocacli_display_node_status (&nodeStatus[nodes], 1, csv, !nodes);
         } /* for (nodes) */

         if (!csv)
         {
             printf ("All Node Information \n") ;
             printf ("=====================\n") ;
             printf ("\tNbas  Preamble     CP    TxPower   RxPower  Rate \n") ;
             printf ("===========================================================\n") ;
             printf ("TxBc\t%4d      %d        %d    %3d dBm    N/A     %u bps \n",nodeCommonStatus.txBc.nBas,
                   nodeCommonStatus.txBc.preambleType, nodeCommonStatus.txBc.cp,
                   nodeCommonStatus.txBc.txPower, nodeCommonStatus.maxCommonPhyRates.txBcPhyRate) ;
             printf ("TxMap\t%4d      %d        %d    %3d dBm    N/A     %u bps \n",nodeCommonStatus.txMap.nBas,
                   nodeCommonStatus.txMap.preambleType, nodeCommonStatus.txMap.cp,
                   nodeCommonStatus.txMap.txPower, nodeCommonStatus.maxCommonPhyRates.txMapPhyRate) ;
             printf ("===========================================================\n") ;
             printf ("   Tx Bcast Bit Loading Info    \t      Tx Map Bit Loading Info  \n" ) ;
             printf ("--------------------------------\t    ---------------------------\n") ;
             mocacli_display_bit_loading (&nodeCommonStatus.txBc.bitLoading[0], &nodeCommonStatus.txMap.bitLoading[0]) ;
             printf ("--------------------------------\t   -------------------------------\n") ;
         }
      } /* Success */
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf(stderr,"%s: invalid parameter for option showtbl nodestats %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet );
} /* ShowTblHandlerNodeStatus */


/***************************************************************************
 * Function Name: ShowTblHandlerNodeStats
 * Description  : Processes the mocactl operate showtbl --nodestats command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowTblHandlerNodeStats( POPTION_INFO pOpt )
{
   UINT32 ulReset = 0 ;
   CmsRet nRet = CMSRET_SUCCESS;

   if(( pOpt->nNumParms == 1 ) && !strcmp( pOpt->pszParms[0], "reset" ) ) 
      ulReset = 1;

   if( pOpt->nNumParms <= 1 )
   {
      MoCA_NODE_STATISTICS_ENTRY nodeStats [MoCA_MAX_NODES] ;
      MoCA_NODE_STATISTICS_EXT_ENTRY nodeStatsExt [MoCA_MAX_NODES] ;
      
      UINT32 tblSize ;
      int nodes ;

      if (nRet == CMSRET_SUCCESS)
      {
         nRet = MoCACtl2_GetNodeTblStatistics( g_mocaHandle, &nodeStats [0], &tblSize, ulReset ) ;
         if (nRet == CMSRET_SUCCESS) {
            tblSize /= sizeof (MoCA_NODE_STATISTICS_ENTRY) ;  /* No of Nodes */
            printf ("        MoCA Node Statistics Table           \n");
            printf ("=============================================\n");
            for (nodes = 0; nodes < (int)tblSize; nodes++) {
                MoCA_NODE_STATUS_ENTRY nodeStatus ;

                nodeStatus.nodeId = nodes+1 ;
                nRet = MoCACtl2_GetNodeStatus( g_mocaHandle, &nodeStatus) ;

                mocacli_display_node_stats (&nodeStatus, &nodeStats[nodes]) ;            

            } /* for (nodes) */
         } /* Success */
      }

      nRet = MoCACtl2_GetNodeTblStatisticsExt( g_mocaHandle, &nodeStatsExt [0], &tblSize, ulReset ) ;
      if (nRet == CMSRET_SUCCESS) {
         tblSize /= sizeof (MoCA_NODE_STATISTICS_EXT_ENTRY) ;  /* No of Nodes */
         printf ("     MoCA Node Extended Statistics Table     \n");
         printf ("=============================================\n");
         for (nodes = 0; nodes < (int)tblSize; nodes++) {

            mocacli_display_node_stats_ext (&nodeStatsExt[nodes]) ;

         } /* for (nodes) */
      } /* Success */
      
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf(stderr,"%s: invalid parameter for option showtbl nodestats %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet );
} /* ShowTblHandlerNodeStats */


/***************************************************************************
 * Function Name: ShowTblHandlerUcFwd
 * Description  : Processes the mocactl operate showtbl --ucfwd command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowTblHandlerUcFwd( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS;

   if( pOpt->nNumParms == 0 )
   {
      MoCA_UC_FWD_ENTRY ucFwdTbl [MoCA_MAX_UC_FWD_ENTRIES] ;
      UINT32 tblSize ;
      int fwdEntries ;

      nRet = MoCACtl2_GetUcFwdTbl( g_mocaHandle, &ucFwdTbl [0], &tblSize ) ;
      if (nRet == CMSRET_SUCCESS) {
         tblSize /= sizeof (MoCA_UC_FWD_ENTRY) ;  /* No of UC Fwd Entries */
         printf ("                MoCA Unicast Forwarding Table          \n");
         printf ("=======================================================\n");
         printf (" No\tMAC Address\t\t\tDestNodeId \n") ;
         printf ("----\t-------------\t\t\t------------\n");
         for (fwdEntries = 0; fwdEntries < (int)tblSize; fwdEntries++) {

            printf ("%d.\t%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\t\t\t%d ",
                  (fwdEntries+1), macaddr_getbyte(ucFwdTbl[fwdEntries].nodeMacAddr, 0), 
                  macaddr_getbyte(ucFwdTbl[fwdEntries].nodeMacAddr, 1), 
                  macaddr_getbyte(ucFwdTbl[fwdEntries].nodeMacAddr, 2), 
                  macaddr_getbyte(ucFwdTbl[fwdEntries].nodeMacAddr, 3), 
                  macaddr_getbyte(ucFwdTbl[fwdEntries].nodeMacAddr, 4), 
                  macaddr_getbyte(ucFwdTbl[fwdEntries].nodeMacAddr, 5), 
                  ucFwdTbl[fwdEntries].ucDestNodeId) ;
            
            printf ("\n") ;
         } /* for (nodes) */
         printf ("=======================================================\n");
      } /* Success */
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf(stderr,"%s: invalid parameter for option showtbl --ucfwd  %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet );
} /* ShowTblHandlerUcFwd */


/***************************************************************************
 * Function Name: ShowTblHandlerSrcAddr
 * Description  : Processes the mocactl operate showtbl --srcaddr command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowTblHandlerSrcAddr( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS;

   if( pOpt->nNumParms == 0 )
   {
      MoCA_SRC_ADDR_ENTRY srcAddrTbl [MoCA_MAX_SRC_ADDR_ENTRIES] ;
      UINT32 tblSize ;
      int fwdEntries ;

      nRet = MoCACtl2_GetSrcAddrTbl( g_mocaHandle, &srcAddrTbl [0], &tblSize ) ;
      if (nRet == CMSRET_SUCCESS) {
         tblSize /= sizeof (MoCA_SRC_ADDR_ENTRY) ;  /* No of Src Addr Entries */
         printf ("                MoCA Source Address Table              \n");
         printf ("=======================================================\n");
         printf (" No\tMAC Address\t\t\tSelfNodeId \n") ;
         printf ("----\t-------------\t\t\t------------\n");
         for (fwdEntries = 0; fwdEntries < (int)tblSize; fwdEntries++) {

            printf ("%d.\t%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\t\t\t%d ",
                  (fwdEntries+1), macaddr_getbyte(srcAddrTbl[fwdEntries].nodeSrcMacAddr, 0), 
                  macaddr_getbyte(srcAddrTbl[fwdEntries].nodeSrcMacAddr, 1),
                  macaddr_getbyte(srcAddrTbl[fwdEntries].nodeSrcMacAddr, 2),
                  macaddr_getbyte(srcAddrTbl[fwdEntries].nodeSrcMacAddr, 3),
                  macaddr_getbyte(srcAddrTbl[fwdEntries].nodeSrcMacAddr, 4),
                  macaddr_getbyte(srcAddrTbl[fwdEntries].nodeSrcMacAddr, 5), srcAddrTbl[fwdEntries].selfNodeId) ;
            printf ("\n") ;
         } /* for (nodes) */
         printf ("=======================================================\n");
      } /* Success */
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf(stderr,"%s: invalid parameter for option showtbl --srcaddr  %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet );
} /* ShowTblHandlerSrcAddr */


/***************************************************************************
 * Function Name: ShowTblHandlerMcFwd
 * Description  : Processes the mocactl operate showtbl --mcfwd command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static CmsRet ShowTblHandlerMcFwd( POPTION_INFO pOpt )
{
   CmsRet nRet = CMSRET_SUCCESS;

   if( pOpt->nNumParms == 0 )
   {
      nRet = RetrieveMCFwdTbl() ;
   }
   else
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf(stderr,"%s: invalid parameter for option showtbl --mcfwd  %s\n",
            g_szPgmName, pOpt->pszOptName );
   }

   return( nRet );
} /* ShowTblHandlerMcFwd */


/***************************************************************************
 * Function Name: TraceHandler
 * Description  : Processes the mocactl trace command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int TraceHandler ( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS ;
   MoCA_TRACE_PARAMS traceParams ;

   if ( mocacli_parse_trace_parms(g_szPgmName, pOptions, 
           nNumOptions, &traceParams ) == 0)
      nRet = CMSRET_SUCCESS;
   else
      nRet = CMSRET_INVALID_ARGUMENTS;

   if( nRet == CMSRET_SUCCESS ) {

      nRet = MoCACtl2_SetTraceConfig( g_mocaHandle, &traceParams ) ;

      /* Store the default value in NVRAM */
      if ( (nRet == CMSRET_SUCCESS) && traceParams.bRestoreDefault ) {
         nRet = MoCACtl2_GetTraceConfig( g_mocaHandle, &traceParams ) ;
      }
         
      if ( g_NvModeEnabled )
         MoCACtl2_SetPersistent(g_mocaHandle, "MoCATRCLEVEL", (char *) &traceParams.traceLevel, sizeof (UINT32)) ;
   }

   return( nRet );
} /* TraceHandler */



/***************************************************************************
 * Function Name: RestoreDefaultsHandler
 * Description  : Processes the mocactl restore_defaults command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int RestoreDefaultsHandler( POPTION_INFO pOptions, int nNumOptions )
{ 
    MoCA_CONFIG_PARAMS configParms ;
    MoCA_INITIALIZATION_PARMS initParms ;
    MoCA_TRACE_PARAMS  traceParams ;
    MoCA_VERSION MoCAVersion ;

    CmsRet             nRet = CMSRET_SUCCESS ;

    memset(&configParms, 0, sizeof(configParms));
    memset(&initParms, 0, sizeof(initParms));

    MoCACtl2_RestoreDefaults(g_mocaHandle);

    nRet = MoCACtl2_GetCfg( g_mocaHandle, &configParms, MoCA_CFG_PARAM_ALL_MASK);

    if (nRet != CMSRET_SUCCESS)
    {
        fprintf(stderr,"Unable to get default config parms (%d)\n", nRet);
        return(nRet);
    }
    
    nRet = MoCACtl2_GetInitParms( g_mocaHandle, &initParms);
    
    if (nRet != CMSRET_SUCCESS)
    {
        fprintf(stderr,"Unable to get default init parms (%d)\n", nRet);
        return(nRet);
    }
    
    /* Clear all MoCA config params except for the LOF */
    if (g_NvModeEnabled)
    {
        // set these two in this order
        MoCACtl2_SetPersistent(g_mocaHandle, "MoCACFGPARMS", (char *) &configParms, sizeof (MoCA_CONFIG_PARAMS)) ;            
        MoCACtl2_SetPersistent(g_mocaHandle, "MoCAINITPARMS", (char *) &initParms, sizeof (MoCA_INITIALIZATION_PARMS)) ;
    }

    traceParams.bRestoreDefault = TRUE ;
    nRet = MoCACtl2_SetTraceConfig( g_mocaHandle, &traceParams ) ;
    if (nRet != CMSRET_SUCCESS) 
    {
       fprintf( stderr, "%s: MoCACtl2_SetTraceConfig error\n", g_szPgmName ) ;
    }

    if (g_NvModeEnabled)
    {
       MoCACtl2_SetPersistent(g_mocaHandle, "MoCATRCLEVEL", NULL, 0) ;
    }

    nRet = MoCACtl2_GetVersion( g_mocaHandle, &MoCAVersion) ;
    if (nRet != CMSRET_SUCCESS) 
    {
       fprintf( stderr, "%s: MoCACtl2_GetVersion error\n", g_szPgmName ) ;
    }
    else if (MoCAVersion.coreSwVersion) // moca has been started, restart it
    {
       MoCACtl2_ReInitialize(g_mocaHandle, &initParms, MoCA_INIT_PARAM_ALL_MASK,
                             &configParms, MoCA_CFG_NON_LAB_PARAM_ALL_MASK);
    }

   return (CMSRET_SUCCESS) ;
} /* RestoreDefaultsHandler */


static CmsRet RetrieveMCFwdTbl ()
{
   int               fwdEntries, num ;
   UINT32            tblSize ;
   CmsRet            nRet = CMSRET_SUCCESS ;
   MoCA_MC_FWD_ENTRY mcFwdTbl [MoCA_MAX_MC_FWD_ENTRIES] ;

   nRet = MoCACtl2_GetMcFwdTbl( g_mocaHandle, &mcFwdTbl [0], &tblSize ) ;
   if (nRet == CMSRET_SUCCESS) {
      tblSize /= sizeof (MoCA_MC_FWD_ENTRY) ;  /* No of MC Fwd Entries */
      printf ("                MoCA Multicast Forwarding Table          \n") ;
      printf ("=========================================================\n") ;
      for (fwdEntries = 0; fwdEntries < (int)tblSize; fwdEntries++) {

         printf ("*******************************************************\n");
         printf (" Group Id       : %d \n", fwdEntries) ;
         printf (" num of members : %d \n", mcFwdTbl[fwdEntries].numOfMembers) ;
         printf (" No\tMembers\t\tMC MAC Address\t\tDestNodeId \n") ;
         printf ("----\t--------\t-------------\t\t------------\n");
         printf ("%d.\t%d\t\t%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\t%d ",
               (fwdEntries+1), mcFwdTbl[fwdEntries].numOfMembers,
               macaddr_getbyte(mcFwdTbl[fwdEntries].mcMacAddr, 0),
               macaddr_getbyte(mcFwdTbl[fwdEntries].mcMacAddr, 1),
               macaddr_getbyte(mcFwdTbl[fwdEntries].mcMacAddr, 2),
               macaddr_getbyte(mcFwdTbl[fwdEntries].mcMacAddr, 3),
               macaddr_getbyte(mcFwdTbl[fwdEntries].mcMacAddr, 4),
               macaddr_getbyte(mcFwdTbl[fwdEntries].mcMacAddr, 5), 
               mcFwdTbl[fwdEntries].destNodeId) ;
         printf ("\n\n") ;
         for (num = 0; num < (int)mcFwdTbl [fwdEntries].numOfMembers; num++) {
            printf ("Member %d : %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x \n", num, 
                  macaddr_getbyte(mcFwdTbl[fwdEntries].nodeAddr[num].macAddr, 0),
                  macaddr_getbyte(mcFwdTbl[fwdEntries].nodeAddr[num].macAddr, 1),
                  macaddr_getbyte(mcFwdTbl[fwdEntries].nodeAddr[num].macAddr, 2),
                  macaddr_getbyte(mcFwdTbl[fwdEntries].nodeAddr[num].macAddr, 3),
                  macaddr_getbyte(mcFwdTbl[fwdEntries].nodeAddr[num].macAddr, 4),
                  macaddr_getbyte(mcFwdTbl[fwdEntries].nodeAddr[num].macAddr , 5)) ;
         }
         printf ("*******************************************************\n");
      } /* for (nodes) */
      printf ("=========================================================\n");
   } /* Success */
   else {
      printf ("Retrieval Error Status = %d \n", nRet) ;
   }

   return ( nRet ) ;
} /* End of RetrieveMCFwdTbl */

static CmsRet moca_start_event_loop(void * ctx, MoCAOS_ThreadHandle *thread)
{
   pqos_cond = 0;

   *thread = MoCAOS_CreateThread((MoCAOS_ThreadEntry)moca_event_loop, ctx);

   if (*thread == MOCAOS_INVALID_THREAD) {
      fprintf( stderr, "%s: MoCAOS_CreateThread failed\n", 
         g_szPgmName);
      return(CMSRET_INTERNAL_ERROR);
   }

   /* Give the thread a chance to run */
   MoCAOS_MSleep(1);

   return(CMSRET_SUCCESS);
}

static int moca_wait_for_event(void * ctx, MoCAOS_ThreadHandle thread, uint32_t timeout_s)
{
   unsigned int now;
   unsigned int start;

   MoCAOS_GetTimeOfDay(&start, NULL);
   timeout_s++;

   do
   {
	   if (pqos_cond)
		   break;
	   MoCAOS_GetTimeOfDay(&now, NULL);
	   MoCAOS_MSleep(100);	   
   } while(now < start + timeout_s);

   if (!pqos_cond)
      printf("Operation timed out.\n");

   return(0);
}

char * moca_decision_string(UINT32 value)
{
   static char buf[11];
   
   switch (value)
   {
      case 0x1:
         return "DECISION_SUCCESS";
         break;
      case 0x3:
         return "DECISION_FLOW_EXISTS";
         break;
      case 0x4:
         return "DECISION_INSUF_INGR_BW";
         break;
      case 0x5: 
         return "DECISION_INSUF_EGR_BW"; 
         break;
      case 0x6: 
         return "DECISION_TOO_MANY_FLOWS"; 
         break;
      case 0x8: 
         return "DECISION_INVALID_TSPEC"; 
         break;
      case 0x9: 
         return "DECISION_INVALID_DA"; 
         break;
      case 0xA: 
         return "DECISION_LEASE_EXPIRED"; 
         break;
      case 0xB:
         return "DECISION_INVALID_BURST_SIZE";
         break;
      case 0x10: 
         return "DECISION_FLOW_NOT_FOUND"; 
         break;
      case 0x11: 
         return "DECISION_INSUF_AGGR_STPS"; 
         break;
      case 0x12: 
         return "DECISION_INSUF_AGGR_TXPS"; 
         break; 
      default:
         snprintf(buf, sizeof(buf), "0x%x", value);
         return buf;
         break;
   }
}

static void pqos_callback_return(void * arg)
{
   moca_cancel_event_loop(arg);
   pqos_cond = 1;
}

static void pqos_create_response_cb(void *arg, struct moca_pqos_create_response *in)
{
   printf("Response: %s\n", moca_l2_error_name(in->responsecode));
   printf("----------------------------\n");
   printf("Decision       :   %s\n", moca_decision_string(in->decision));
   printf("  Available BW :   %d\n", in->maxpeakdatarate);
   printf("  POST_STPS    :   %d\n", in->totalstps);
   printf("  POST_TXPS    :   %d\n", in->totaltxps);

   pqos_callback_return(arg);
}

static void pqos_create_response_status_cb(void *arg, struct moca_pqos_create_response *in)
{
   printf("Summed up STPS :   %u\n", in->totalstps);
   printf("Summed up TXPS :   %u\n", in->totaltxps);
   printf("QOS STPS       :   %u\n", in->flowstps);
   printf("QOS TXPS       :   %u\n", in->flowtxps);

   pqos_callback_return(arg);
}

static void pqos_update_response_cb(void *arg, struct moca_pqos_update_response *in)
{
   printf("Response: %s\n", moca_l2_error_name(in->responsecode));
   printf("----------------------------\n");
   printf("Decision       :   %s\n", moca_decision_string(in->decision));
   printf("  Available BW :   %d\n", in->maxpeakdatarate);
   printf("  POST_STPS    :   %d\n", in->totalstps);
   printf("  POST_TXPS    :   %d\n", in->totaltxps);

   pqos_callback_return(arg);
}

static void pqos_delete_response_cb(void *arg, struct moca_pqos_delete_response *in)
{
   printf("Response: %s\n", moca_l2_error_name(in->responsecode));
   printf("----------------------------\n");

   pqos_callback_return(arg);
}

static void pqos_list_response_cb(void *arg, struct moca_pqos_list_response *in)
{
   int i;
   uint32_t *flowid;
   uint32_t number_of_flows = 0;

   flowid = &in->flowid0_hi;

   for (i = 0; i < 32; i++)
   {
      if (flowid[i*2] != 0 || flowid[i*2+1] != 0)
      {
         number_of_flows++;
      }
   }

   if (arg != NULL)
   {
      *((uint32_t *)arg) += number_of_flows;
   }

   printf("   Number of Flows:  %u\n", number_of_flows);
   number_of_flows = 0;
   for (i = 0; i < 32; i++)
   {
      if (flowid[i*2] != 0 || flowid[i*2+1] != 0)
      {
         printf("   Flow ID (%2i):     %02x:%02x:%02x:%02x:%02x:%02x\n", 
            number_of_flows, 
            (flowid[i*2] >> 24) & 0xFF,
            (flowid[i*2] >> 16) & 0xFF,
            (flowid[i*2] >>  8) & 0xFF,
            (flowid[i*2] >>  0) & 0xFF,
            (flowid[i*2+1] >> 24) & 0xFF,
            (flowid[i*2+1] >> 16) & 0xFF);
         number_of_flows++;
      }
   }

   pqos_callback_return(g_mocaHandle);
}

static void pqos_query_response_print_cb(void *arg, struct moca_pqos_query_response *in)
{
   MAC_ADDRESS ingr_mac={0};
   MAC_ADDRESS egr_mac;
   struct moca_gen_status gs;
   struct moca_gen_node_status gsn;
   struct moca_init_time init;
   int egr_mac_found = 0, ingr_mac_found = 0;
   int ret;
   
   /* get node bitmask */
   moca_get_gen_status(arg, &gs);

   if((gs.node_id == in->ingressnodeid) ||
      (gs.node_id == in->egressnodeid)) 
   {
      moca_get_init_time(arg, &init);
      if (gs.node_id == in->ingressnodeid)
      {
         ingr_mac_found = 1;
         moca_u32_to_mac(ingr_mac, init.mac_addr_hi, init.mac_addr_lo);
      }
      else
      {
         egr_mac_found = 1;
         moca_u32_to_mac(egr_mac, init.mac_addr_hi, init.mac_addr_lo);
      }
   }
   if (ingr_mac_found == 0)
   {
      ret = moca_get_gen_node_status(arg, in->ingressnodeid, &gsn);
      if (ret == 0)
         moca_u32_to_mac(ingr_mac, gsn.eui_hi, gsn.eui_lo);
      else
         printf("%s: moca_get_gen_node_status returned %d for ingr node %d\n",
            __FUNCTION__, ret, in->ingressnodeid);
   }
   if (egr_mac_found == 0)
   {
      /* check for broadcast node id */
      if (in->egressnodeid == 0x3f)
         memset(egr_mac, 0xff, sizeof(MAC_ADDRESS));
      else
      {
         ret = moca_get_gen_node_status(arg, in->egressnodeid, &gsn);
         if (ret == 0)
            moca_u32_to_mac(egr_mac, gsn.eui_hi, gsn.eui_lo);
         else
            printf("%s: moca_get_gen_node_status returned %d for egr node %d\n",
               __FUNCTION__, ret, in->egressnodeid);
      }
   }


   printf("Response: %s\n", moca_l2_error_name(in->responsecode));
   printf("----------------------------\n");
   printf("Flow ID            %02x:%02x:%02x:%02x:%02x:%02x\n", 
      in->flowid[0], in->flowid[1], in->flowid[2],
      in->flowid[3], in->flowid[4], in->flowid[5]);
   if ((in->packetda[0] != 0) ||
       (in->packetda[1] != 0) ||
       (in->packetda[2] != 0) ||
       (in->packetda[3] != 0) ||
       (in->packetda[4] != 0) ||
       (in->packetda[5] != 0) )
   {
      printf("Ingress Node       %02x:%02x:%02x:%02x:%02x:%02x\n", 
         ingr_mac[0], ingr_mac[1], ingr_mac[2], ingr_mac[3], 
         ingr_mac[4], ingr_mac[5]);
      printf("Egress Node        %02x:%02x:%02x:%02x:%02x:%02x\n", 
         egr_mac[0], egr_mac[1], egr_mac[2], egr_mac[3], 
         egr_mac[4], egr_mac[5]);
      printf("Packet size        %d\n", in->tpacketsize);
      printf("Peak data rate     %d\n", in->tpeakdatarate);
      printf("Burst count        %d\n", in->tburstsize);
      if (in->leasetimeleft == 0xFFFFFFFF)
         printf("Lease time left    infinite\n");
      else
         printf("Lease time left    %d\n", in->leasetimeleft);
      printf("Cfg lease time     %d\n", in->tleasetime);
      printf("Flow Tag           %d\n", in->flowtag);
   }
   else
   {
      printf("Flow does not exist\n");
   }

   pqos_callback_return(arg);
}

static void pqos_query_response_copy_cb(void *arg, struct moca_pqos_query_response *in)
{
   if (arg != NULL)
   {
      memcpy((struct moca_pqos_query_response *)arg, in, 
         sizeof(struct moca_pqos_query_response));
   }

   pqos_callback_return(g_mocaHandle);
}



static int mocacli_list_active_nodes( void * ctx )
{
   int i;
   struct moca_gen_status gs;
   struct moca_gen_node_status gsn;
   struct moca_init_time init;
   MAC_ADDRESS  mac;

   /* get node bitmask */
   moca_get_gen_status(ctx, &gs);

   /* get status entry for each node */
   printf("Node ID   MAC Addr\n");
   for(i = 0; i < MOCA_MAX_NODES; i++) {
      if(! (gs.connected_nodes & (1 << i)))
         continue;
      if(gs.node_id == i) 
      {
         moca_get_init_time(ctx, &init);
         moca_u32_to_mac(mac, init.mac_addr_hi, init.mac_addr_lo);
         printf ("%2i        %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\n",
               i, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
      }
      else
      {
         moca_get_gen_node_status(ctx, i, &gsn);
         moca_u32_to_mac(mac, gsn.eui_hi, gsn.eui_lo);
         printf ("%2i        %2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x\n",
               i, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
      }
   }

   return 0;
}


static uint16_t fmrinfo[MOCA_MAX_NODES][MOCA_MAX_NODES];

static void fmr_response_cb(void *arg, struct moca_fmr_response *in)
{
   int i, j;
   uint32_t *responded_node;
   uint16_t *fmrinfo_node;

   for (i = 0; i < 9; i++)
   {
      responded_node = (uint32_t *)((size_t)&in->responded_node_0 + ((sizeof(in->responded_node_0)*i) + (sizeof(in->fmrinfo_node_0)*i)));
      fmrinfo_node = (uint16_t *)(responded_node + 1);
      if (*responded_node != 0xFF)
      {
         for (j = 0; j < MOCA_MAX_NODES; j++ )
         {
            fmrinfo[*responded_node][j] = fmrinfo_node[j];
         }
      }
   }

   pqos_callback_return(arg);
}

static void print_fmr_info(void * ctx, uint32_t connectedNodes)
{
   int i, j;

   printf("----------------------------\n");
   mocacli_list_active_nodes(ctx);

   printf("OFDMb/GAP\n");
   printf("Tx\\Rx     0        1        2        3        4        5        6        7");
   for (i = 0; i < MOCA_MAX_NODES; i++)
   {
      if (connectedNodes & (1 << i))
      {
         printf("\n  %2d", i);
         for (j = 0; j < 8; j++ )
         {
            printf("  %4d/%-2d", fmrinfo[i][j] & 0x7FF, fmrinfo[i][j] >> 11);
         }
      }
   }

   printf("\n          8        9       10       11       12       13        14      15");
   for (i = 0; i < MOCA_MAX_NODES; i++)
   {
      if (connectedNodes & (1 << i))
      {
         printf("\n  %2d", i);
         for (j = 8; j < 16; j++ )
         {
            printf("  %4d/%-2d", fmrinfo[i][j] & 0x7FF, fmrinfo[i][j] >> 11);
         }
      }
   }
   printf("\n");

}


static void mr_response_cb(void *arg, struct moca_mr_response *in)
{
   uint8_t *nodes;
   int i;
   
   printf("mr completed\n");
   printf("NonDefSeqNum = %d\n", in->NonDefSeqNum);
   printf("ResetStatus = %d\n", in->ResetStatus);
   printf("ResponseCode = %d\n", in->ResponseCode);

   nodes = &in->n00ResetStatus;

   for (i=0;i<16;i++)
   {
      printf("Node %2d: ResetStatus = %d\n",i, *nodes);
      nodes++;
      printf("Node %2d: RspCode = %d\n",i, *nodes);   
      nodes++;
   }

   pqos_callback_return(g_mocaHandle);
}


static void mr_response_assign_channel_cb(void *arg, struct moca_mr_response *in)
{
   MoCA_INITIALIZATION_PARMS initParms;
   uint8_t *nodes;
   int i;
   CmsRet          nRet = CMSRET_SUCCESS ;
   
   printf("mr completed\n");
   printf("NonDefSeqNum = %d\n", in->NonDefSeqNum);
   printf("ResetStatus = %d\n", in->ResetStatus);
   printf("ResponseCode = %d\n", in->ResponseCode);

   nodes = &in->n00ResetStatus;

   for (i=0;i<16;i++)
   {
      printf("Node %2d: ResetStatus = %d\n",i, *nodes);
      nodes++;
      printf("Node %2d: RspCode = %d\n",i, *nodes);   
      nodes++;
   }
   
   if ((nRet == CMSRET_SUCCESS) && (in->ResponseCode == MOCA_L2_SUCCESS)) {
      nRet = MoCACtl2_GetInitParms( g_mocaHandle, &initParms ) ;
      if ((nRet == CMSRET_SUCCESS) && (g_NvModeEnabled)) {
        initParms.beaconChannel = (UINT32)(uintptr_t) arg;
        MoCACtl2_SetPersistent(g_mocaHandle, "MoCAINITPARMS", (char *) &initParms, sizeof (MoCA_INITIALIZATION_PARMS)) ;
      }
   }

   pqos_callback_return(g_mocaHandle);
}



/***************************************************************************
 * Function Name: FmrHandler
 * Description  : Processes the mocactl fmr command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int FmrHandler(POPTION_INFO pOptions, int nNumOptions )
{
   uint32_t                      mac_hi_lo[2] = {0, 0};
   uint32_t                      fmr_nodemask = 0;
   uint32_t                      i=0;
   CmsRet                        nRet = CMSRET_SUCCESS ;
   MoCAOS_ThreadHandle           event_thread;
   struct moca_gen_status        gen_status;
   struct moca_gen_node_status   node_status;
   MAC_ADDRESS                   mac;
   int                           ret;
   struct moca_fmr_request       req;

   if (nNumOptions != 1)
   {
      fprintf (stderr, "Usage:\n"
                       "moca fmr [--s <xx:xx:xx:xx:xx:xx>] [--a]\n"
                       "--s           Display FMR info for single node\n"
                       "--a           Display FMR info for all nodes\n");
      nRet = CMSRET_INVALID_ARGUMENTS ;
   } 

   while( (nRet == CMSRET_SUCCESS) && nNumOptions )
   {
      if( !strcmp(pOptions->pszOptName, "--s") ) 
      {
         MAC_ADDRESS mac;
         if ( ParseMacAddress ( pOptions->pszParms[ 0 ], &mac) != 0)
         {
            nRet = CMSRET_INVALID_ARGUMENTS ;
         }
         
         moca_mac_to_u32(&mac_hi_lo[0], &mac_hi_lo[1], mac);
      }
      else if (!strcmp(pOptions->pszOptName, "--a"))
      {
         mac_hi_lo[0] = 0;
         mac_hi_lo[1] = 0;
      }
      else {
         nRet = CMSRET_INVALID_ARGUMENTS;
      }

      if( nRet != CMSRET_SUCCESS )
          fprintf( stderr, "%s: invalid parameter for option %s\n",
              g_szPgmName, pOptions->pszOptName ) ;

      nNumOptions--;
      pOptions++;
   }


    ret = moca_get_gen_status(g_mocaHandle, &gen_status);

    if (ret != 0)
    {
        fprintf(stderr, "%s: Error!  Mocactl failure\n", g_szPgmName);
        return(CMSRET_INTERNAL_ERROR);
    }

   if ((mac_hi_lo[0] == 0) && (mac_hi_lo[1] == 0))
   {
      // Do FMR for all addresses
        fmr_nodemask = gen_status.connected_nodes;
   }
   else
   {
      /* get status entry for each node */
      for(i = 0; i < MOCA_MAX_NODES; i++) 
      {        
         if(! (gen_status.connected_nodes & (1 << i)))
             continue;
         ret = moca_get_gen_node_status(g_mocaHandle, i, (struct moca_gen_node_status *)&node_status);
         moca_u32_to_mac(mac, node_status.eui_hi, node_status.eui_lo);
         if ((ret == 0) &&           
             (node_status.eui_hi == mac_hi_lo[0]) &&
             (node_status.eui_lo == mac_hi_lo[1]) &&
             ((node_status.protocol_support >> 24) == MoCA_VERSION_11))
         {           
             fmr_nodemask = (1 << i);
             break;
         }
      }  
   }

   /* Might have to get the FMR data in two reads since only 9 entries 
      can be returned at a time */
   if (fmr_nodemask & 0xff)
   {
      nRet = moca_start_event_loop(g_mocaHandle, &event_thread);

      if (nRet == CMSRET_SUCCESS) 
      {
         moca_register_fmr_response_cb(g_mocaHandle, &fmr_response_cb, g_mocaHandle);

         memset(&req, 0, sizeof(req));
         req.wave0Nodemask = fmr_nodemask & 0xff;
         nRet = moca_set_fmr_request(g_mocaHandle, &req);

         if (nRet == 0) {
            moca_wait_for_event(g_mocaHandle, event_thread, 5);
            nRet = CMSRET_SUCCESS;
         }
         else {
             fprintf( stderr, "%s: Error!  Unable to get FMR for node %d\n", 
               g_szPgmName, i ) ;
             return(nRet);
         }
      }

      // ----------- Finish
#if defined(__gnu_linux__)
      if (nRet == CMSRET_SUCCESS)
      {
         pthread_join(event_thread, NULL); /* Allow event loop to be cancelled */
      }
#endif
   }

   if (fmr_nodemask & 0xff00)
   {
      nRet = moca_start_event_loop(g_mocaHandle, &event_thread);

      if (nRet == CMSRET_SUCCESS) 
      {
         moca_register_fmr_response_cb(g_mocaHandle, &fmr_response_cb, g_mocaHandle);

         memset(&req, 0, sizeof(req));
         req.wave0Nodemask = fmr_nodemask & 0xff00;
         nRet = moca_set_fmr_request(g_mocaHandle, &req);

         if (nRet == 0) {
            moca_wait_for_event(g_mocaHandle, event_thread, 5);
            nRet = CMSRET_SUCCESS;
         }
         else {
             fprintf( stderr, "Error!  Unable to get FMR for node %d\n", i ) ;
             return(nRet);
         }
      }

      // ----------- Finish
#if defined(__gnu_linux__)
      if (nRet == CMSRET_SUCCESS)
      {
         pthread_join(event_thread, NULL); /* Allow event loop to be cancelled */
      }
#endif
   }

   print_fmr_info(g_mocaHandle, fmr_nodemask);


   
   return (nRet) ;
} /* FmrRequestHandler */

/***************************************************************************
 * Function Name: MrHandler
 * Description  : Processes the mocactl mr command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int MrHandler(POPTION_INFO pOptions, int nNumOptions )
{
   MoCA_MR_PARAMS  mrParams ;
   CmsRet          nRet = CMSRET_SUCCESS ;
   MoCAOS_ThreadHandle event_thread;

   memset (&mrParams, 0x00, sizeof(mrParams)) ;
   mrParams.non_def_seq_num = 0xFFFF;
   mrParams.reset_timer = 1;

   while( (nRet == CMSRET_SUCCESS) && nNumOptions )
   {
      if( !strcmp(pOptions->pszOptName, "--seq") ) 
      {
         mrParams.non_def_seq_num = atoi(pOptions->pszParms[ 0 ]);
      }
      else if (!strcmp(pOptions->pszOptName, "--time"))
      {
          mrParams.reset_timer = atoi(pOptions->pszParms[ 0 ]);
      }
      else 
      {
         nRet = CMSRET_INVALID_ARGUMENTS;
      }

      if( nRet != CMSRET_SUCCESS )
          fprintf( stderr, "%s: invalid parameter for option %s\n",
              g_szPgmName, pOptions->pszOptName ) ;

      nNumOptions--;
      pOptions++;
   }

   if (nRet == CMSRET_SUCCESS)
   {
      nRet = moca_start_event_loop(g_mocaHandle, &event_thread);

      if (nRet == CMSRET_SUCCESS) 
      {
         moca_register_mr_response_cb(g_mocaHandle, &mr_response_cb, g_mocaHandle);
         nRet = MoCACtl2_Mr(g_mocaHandle, &mrParams);
         if (nRet == CMSRET_SUCCESS) {
            moca_wait_for_event(g_mocaHandle, event_thread,15);
         }
         else {
             fprintf( stderr, "%s: MoCACtl2_Mr returned error %d\n",
                 g_szPgmName, nRet ) ;
         }
      }
   }
   
   return (nRet) ;
} /* MrHandler */


/***************************************************************************
 * Function Name: ChSelHandler
 * Description  : Processes the mocactl chsel command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int ChSelHandler(POPTION_INFO pOptions, int nNumOptions )
{
   uint32_t        freq = 0;
   CmsRet          nRet = CMSRET_SUCCESS ;
   MoCAOS_ThreadHandle  event_thread;
   MoCA_MR_PARAMS  mrParams ;

   memset (&mrParams, 0x00, sizeof(mrParams)) ;
   mrParams.non_def_seq_num = 0xFFFFFFFF;
   mrParams.reset_timer = 1;   
 
   while( (nRet == CMSRET_SUCCESS) && nNumOptions )
   {
      if( !strcmp(pOptions->pszOptName, "--freq") ) 
      {
         freq = atoi(pOptions->pszParms[ 0 ]);
      }
      else 
      {
         nRet = CMSRET_INVALID_ARGUMENTS;
      }

      if( nRet != CMSRET_SUCCESS )
          fprintf( stderr, "%s: invalid parameter for option %s\n",
              g_szPgmName, pOptions->pszOptName ) ;

      nNumOptions--;
      pOptions++;
   }

   if (freq == 0)
   {
      fprintf( stderr, "%s: frequency not specified\n", g_szPgmName ) ;
      nRet = CMSRET_INVALID_ARGUMENTS;
   }

   if (nRet == CMSRET_SUCCESS)
   {
      nRet = moca_start_event_loop(g_mocaHandle, &event_thread);

      if (nRet == CMSRET_SUCCESS) 
      {
         moca_register_mr_response_cb(g_mocaHandle, &mr_response_assign_channel_cb, (void*)(uintptr_t)freq);
         nRet = MoCACtl2_ChSel(g_mocaHandle, freq);         
         
         if (nRet == CMSRET_SUCCESS)
         {
            nRet = MoCACtl2_Mr(g_mocaHandle, &mrParams);
            
            if (nRet == CMSRET_SUCCESS)
            {
               printf("Waiting for MR_Response\n");
               moca_wait_for_event(g_mocaHandle, event_thread, 15);
            }
         }
         else 
         {
             fprintf( stderr, "%s: MoCACtl2_ChSel returned error %d\n",
                 g_szPgmName, nRet ) ;
         }
      }
   }
   
   return (nRet) ;
} /* ChSelHandler */


/***************************************************************************
 * Function Name: PQoSCHandler
 * Description  : Processes the mocactl pqosc command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int PQoSCHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS;
   MoCA_CREATE_PQOS_PARAMS pqos ;
   UINT32 *pulValue ;
   MAC_ADDRESS *pmacAddr;
   UBOOL8   igPresent = FALSE;
   UBOOL8   egPresent = FALSE;
   MoCAOS_ThreadHandle pqos_thread;

   memset (&pqos, 0x00, sizeof(MoCA_CREATE_PQOS_PARAMS)) ;
   pqos.peak_rate = MoCA_PQOS_PEAK_RATE_DEFAULT;
   pqos.packet_size = MoCA_PQOS_PACKET_SIZE_DEFAULT;
   pqos.burst_count = MoCA_PQOS_BURST_COUNT_DEFAULT;
   pqos.lease_time = MoCA_PQOS_LEASE_TIME_DEFAULT;
   pqos.vlan_id = MoCA_PQOS_VLAN_ID_DEFAULT;
   pqos.vlan_prio = MoCA_PQOS_VLAN_PRIO_DEFAULT;
   pqos.packet_da[0] = 0x01;
   pqos.packet_da[1] = 0x00;
   pqos.packet_da[2] = 0x5E;
   pqos.packet_da[3] = 0x00;
   pqos.packet_da[4] = 0x01;
   pqos.packet_da[5] = 0x00;

   while( nRet == CMSRET_SUCCESS && nNumOptions )
   {
      pulValue = NULL;
      pmacAddr = NULL;
      if( !strcmp(pOptions->pszOptName, "--ig") ) 
      {
         igPresent = TRUE;
         pmacAddr = &pqos.ingress_node;
      }
      else if( !strcmp(pOptions->pszOptName, "--eg") )
      {
         egPresent = TRUE;
         pmacAddr = &pqos.egress_node;
      }
      else if( !strcmp(pOptions->pszOptName, "--listener1") )
      {
         pmacAddr = &pqos.listeners[0];
      }
      else if( !strcmp(pOptions->pszOptName, "--listener2") )
      {
         pmacAddr = &pqos.listeners[1];
      }
      else if( !strcmp(pOptions->pszOptName, "--listener3") )
      {
         pmacAddr = &pqos.listeners[2];
      }
      else if( !strcmp(pOptions->pszOptName, "--listener4") )
      {
         pmacAddr = &pqos.listeners[3];
      }
      else if( !strcmp(pOptions->pszOptName, "--packetDA") )
      {
         pmacAddr = &pqos.packet_da;
      }
      else if( !strcmp(pOptions->pszOptName, "--peak") )
      {
         pulValue = &pqos.peak_rate;
      }
      else if( !strcmp(pOptions->pszOptName, "--psize") )
      {
         pulValue = &pqos.packet_size;
      }
      else if( !strcmp(pOptions->pszOptName, "--burst") )
      {
         pulValue = &pqos.burst_count;
      }
      else if( !strcmp(pOptions->pszOptName, "--time") )
      {
         pulValue = (UINT32 *)&pqos.lease_time;
      }
      else if( !strcmp(pOptions->pszOptName, "--flowtag") )
      {
         pulValue = &pqos.flow_tag;
      }
      else if( !strcmp(pOptions->pszOptName, "--talker") )
      {
         pmacAddr = &pqos.talker;
      }
      else if( !strcmp(pOptions->pszOptName, "--vlan_id") )
      {
         pulValue = &pqos.vlan_id;
      }
      else if( !strcmp(pOptions->pszOptName, "--vlan_prio") )
      {
         pulValue = &pqos.vlan_prio;
      }
      else 
      {
         nRet = CMSRET_INVALID_ARGUMENTS;

         fprintf( stderr, "%s: invalid parameter for option %s\n",
               g_szPgmName, pOptions->pszOptName );
      }

      if ( pmacAddr )
      {
         if ( ParseMacAddress ( pOptions->pszParms[ 0 ], pmacAddr) != 0 )
         {
            fprintf( stderr, "%s: invalid parameter for option %s\n", 
               g_szPgmName, pOptions->pszOptName ) ;
            fprintf( stderr, "  MAC Address format: 1a:2b:3c:4d:5e:6f\n" ) ;
            nRet = CMSRET_INVALID_ARGUMENTS ;
         }
      }
      if ( pulValue )
      {
         /* Convert the value for a particular option to an integer. */
         if( pOptions->nNumParms == 1 )
         {
            char *pszEnd = NULL;

            if (pulValue)
               *pulValue = (long) strtol( pOptions->pszParms[0], &pszEnd, 10 ) ;

            if( *pszEnd != '\0' )
            {
               nRet = CMSRET_INVALID_ARGUMENTS;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     g_szPgmName, pOptions->pszOptName );
            }
         }
         else
         {
            nRet = CMSRET_INVALID_ARGUMENTS;
            fprintf( stderr, "%s: invalid number of parameters for option "
                  "%s\n", g_szPgmName, pOptions->pszOptName );
         }
      }

      nNumOptions--;
      pOptions++;
   }

   if( nRet == CMSRET_SUCCESS ) {

      if (!(egPresent && igPresent))
      {
         nRet = CMSRET_INVALID_ARGUMENTS;
         fprintf( stderr, "%s: Missing mandatory parameter --eg or --ig\n",
               g_szPgmName );
      }
      else
      {
         nRet = moca_start_event_loop(g_mocaHandle, &pqos_thread);
         if (nRet == CMSRET_SUCCESS)
         {
            moca_register_pqos_create_response_cb(g_mocaHandle, &pqos_create_response_cb, g_mocaHandle);
            nRet = MoCACtl2_CreatePQoSFlow(g_mocaHandle, &pqos);
            if (nRet == CMSRET_SUCCESS)
               moca_wait_for_event(g_mocaHandle, pqos_thread, 5);
         }
      }
   }

   return( nRet );
} /* PQoSCHandler */


/***************************************************************************
 * Function Name: PQoSUHandler
 * Description  : Processes the mocactl pqosu command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int PQoSUHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS;
   MoCA_UPDATE_PQOS_PARAMS pqos;
   MoCA_QUERY_PQOS_PARAMS query;
   struct moca_pqos_query_response query_rsp;
   UINT32 *pulValue ;
   UBOOL8   flowIdPresent = FALSE;
   MoCAOS_ThreadHandle pqos_thread;

   memset (&pqos, 0x00, sizeof(MoCA_UPDATE_PQOS_PARAMS)) ;

   while( nRet == CMSRET_SUCCESS && nNumOptions )
   {
      pulValue = NULL;

      if( !strcmp(pOptions->pszOptName, "--flow_id") ) 
      {
         flowIdPresent = TRUE;

         if ( ParseMacAddress ( pOptions->pszParms[ 0 ], &query.flow_id) != 0 )
         {
            fprintf( stderr, "%s: invalid parameter for option %s\n", 
               g_szPgmName, pOptions->pszOptName ) ;
            fprintf( stderr, "  MAC Address format: 1a:2b:3c:4d:5e:6f\n" ) ;
            nRet = CMSRET_INVALID_ARGUMENTS ;
         }
         else
         {
            memcpy(pqos.flow_id, query.flow_id, sizeof(MAC_ADDRESS));

            nRet = moca_start_event_loop(g_mocaHandle, &pqos_thread);
            if (nRet == CMSRET_SUCCESS)
            {
               moca_register_pqos_query_response_cb(g_mocaHandle, 
                  &pqos_query_response_copy_cb, &query_rsp);
               nRet = MoCACtl2_QueryPQoSFlow(g_mocaHandle, &query);
               if (nRet == CMSRET_SUCCESS)
               {
                  moca_wait_for_event(g_mocaHandle, pqos_thread, 5);
               }
            }
         
            if ((query_rsp.responsecode == MOCA_L2_SUCCESS) &&
                ((query_rsp.packetda[0] != 0) ||
                 (query_rsp.packetda[1] != 0) ||
                 (query_rsp.packetda[2] != 0) ||
                 (query_rsp.packetda[3] != 0) ||
                 (query_rsp.packetda[4] != 0) ||
                 (query_rsp.packetda[5] != 0)))
            {
               pqos.burst_count = query_rsp.tburstsize;
               pqos.flow_tag = query_rsp.flowtag;
               if (query_rsp.leasetimeleft != 0xFFFFFFFF)
                  pqos.lease_time = query_rsp.leasetimeleft;
               pqos.packet_size = query_rsp.tpacketsize;
               pqos.peak_rate = query_rsp.tpeakdatarate;
               memcpy(pqos.packet_da, query_rsp.packetda, 
                      sizeof(pqos.packet_da));
            }
            else
            {
               nRet = CMSRET_INVALID_ARGUMENTS;

               fprintf( stderr, "%s: flow_id doesn't exist\n",
                     g_szPgmName );
            }
         }
      }
      else if( !strcmp(pOptions->pszOptName, "--peak") )
      {
         pulValue = &pqos.peak_rate;
      }
      else if( !strcmp(pOptions->pszOptName, "--psize") )
      {
         pulValue = &pqos.packet_size;
      }
      else if( !strcmp(pOptions->pszOptName, "--burst") )
      {
         pulValue = &pqos.burst_count;
      }
      else if( !strcmp(pOptions->pszOptName, "--time") )
      {
         pulValue = (UINT32 *)&pqos.lease_time;
      }
      else if( !strcmp(pOptions->pszOptName, "--flowtag") )
      {
         pulValue = &pqos.flow_tag;
      }
      else 
      {
         nRet = CMSRET_INVALID_ARGUMENTS;

         fprintf( stderr, "%s: invalid parameter for option %s\n",
               g_szPgmName, pOptions->pszOptName );
      }

      if ( pulValue )
      {
         if (!flowIdPresent)
         {
            nRet = CMSRET_INVALID_ARGUMENTS;
            fprintf( stderr, "%s: Missing mandatory first parameter --flow_id\n",
                  g_szPgmName );
         }
         else
         {

            /* Convert the value for a particular option to an integer. */
            if( pOptions->nNumParms == 1 )
            {
               char *pszEnd = NULL;

               if (pulValue)
                  *pulValue = (long) strtol( pOptions->pszParms[0], &pszEnd, 10 ) ;

               if( *pszEnd != '\0' )
               {
                  nRet = CMSRET_INVALID_ARGUMENTS;
                  fprintf( stderr, "%s: invalid parameter for option %s\n",
                        g_szPgmName, pOptions->pszOptName );
               }
            }
            else
            {
               nRet = CMSRET_INVALID_ARGUMENTS;
               fprintf( stderr, "%s: invalid number of parameters for option "
                     "%s\n", g_szPgmName, pOptions->pszOptName );
            }
         }
      }

      nNumOptions--;
      pOptions++;
   }

   if( nRet == CMSRET_SUCCESS ) 
   {
      nRet = moca_start_event_loop(g_mocaHandle, &pqos_thread);
      if (nRet == CMSRET_SUCCESS)
      {
         moca_register_pqos_update_response_cb(g_mocaHandle, &pqos_update_response_cb, g_mocaHandle);
         nRet = MoCACtl2_UpdatePQoSFlow(g_mocaHandle, &pqos);
         if (nRet == CMSRET_SUCCESS)
            moca_wait_for_event(g_mocaHandle, pqos_thread, 5);
      }
   }

   return( nRet );
} /* PQoSUHandler */


/***************************************************************************
 * Function Name: PQoSDHandler
 * Description  : Processes the mocactl pqosd command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int PQoSDHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS;
   MoCA_DELETE_PQOS_PARAMS pqos ;
   MAC_ADDRESS *pmacAddr;
   MoCAOS_ThreadHandle pqos_thread;
   
   memset (&pqos, 0x00, sizeof(MoCA_DELETE_PQOS_PARAMS)) ;
   pqos.flow_id[0] = 0x01;
   pqos.flow_id[1] = 0x00;
   pqos.flow_id[2] = 0x5E;
   pqos.flow_id[3] = 0x00;
   pqos.flow_id[4] = 0x01;
   pqos.flow_id[5] = 0x00;

   while( nRet == CMSRET_SUCCESS && nNumOptions )
   {
      pmacAddr = NULL;
      if( !strcmp(pOptions->pszOptName, "--flow_id") ) 
      {
         pmacAddr = &pqos.flow_id;
      }
      else 
      {
         nRet = CMSRET_INVALID_ARGUMENTS;

         fprintf( stderr, "%s: invalid parameter for option %s\n",
               g_szPgmName, pOptions->pszOptName );
      }

      if ( pmacAddr )
      {
         if ( ParseMacAddress ( pOptions->pszParms[ 0 ], pmacAddr) != 0 )
         {
            fprintf( stderr, "%s: invalid parameter for option %s\n", 
               g_szPgmName, pOptions->pszOptName ) ;
            fprintf( stderr, "  MAC Address format: 1a:2b:3c:4d:5e:6f\n" ) ;
            nRet = CMSRET_INVALID_ARGUMENTS ;
         }
      }

      nNumOptions--;
      pOptions++;
   }

   if( nRet == CMSRET_SUCCESS ) {

      nRet = moca_start_event_loop(g_mocaHandle, &pqos_thread);
      if (nRet == CMSRET_SUCCESS)
      {
         moca_register_pqos_delete_response_cb(g_mocaHandle, &pqos_delete_response_cb, g_mocaHandle);
         nRet = MoCACtl2_DeletePQoSFlow(g_mocaHandle, &pqos);
         if (nRet == CMSRET_SUCCESS)
         {
            moca_wait_for_event(g_mocaHandle, pqos_thread, 5);
         }
      }
   }

   return( nRet );
} /* PQoSDHandler */


/***************************************************************************
 * Function Name: PQoSLHandler
 * Description  : Processes the mocactl pqosl command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int PQoSLHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS;
   MoCA_LIST_PQOS_PARAMS pqos ;
   MAC_ADDRESS *pmacAddr;
   MAC_ADDRESS mac;
   int total_flows = 0;
   int list_type = MOCA_LIST_PQOS_NONE;
   MoCA_STATUS status;
   MoCA_NODE_STATUS_ENTRY node_status;
   int i;
   MoCAOS_ThreadHandle pqos_thread;
   int ret;

   memset (&pqos, 0x00, sizeof(MoCA_LIST_PQOS_PARAMS)) ;

   while( nRet == CMSRET_SUCCESS && nNumOptions )
   {
      pmacAddr = NULL;
      if( !strcmp(pOptions->pszOptName, "--ig") ) 
      {
         pmacAddr = &pqos.ingress_mac;
         list_type = MOCA_LIST_PQOS_SINGLE;
      }
      else if( !strcmp(pOptions->pszOptName, "--a") ) 
      {
         list_type = MOCA_LIST_PQOS_ALL;
      }
      else 
      {
         nRet = CMSRET_INVALID_ARGUMENTS;

         fprintf( stderr, "%s: invalid parameter for option %s\n",
               g_szPgmName, pOptions->pszOptName );
      }

      if ( pmacAddr )
      {
         if ( ParseMacAddress ( pOptions->pszParms[ 0 ], pmacAddr) != 0 )
         {
            fprintf( stderr, "%s: invalid parameter for option %s\n", 
               g_szPgmName, pOptions->pszOptName ) ;
            fprintf( stderr, "  MAC Address format: 1a:2b:3c:4d:5e:6f\n" ) ;
            nRet = CMSRET_INVALID_ARGUMENTS ;
         }
      }

      nNumOptions--;
      pOptions++;
   }

   if (list_type == MOCA_LIST_PQOS_NONE)
   {
      nRet = CMSRET_INVALID_ARGUMENTS;
      fprintf( stderr, "%s: Missing mandatory parameter --ig or --a\n",
            g_szPgmName );
   }

   if( nRet == CMSRET_SUCCESS ) 
   {
      if (list_type == MOCA_LIST_PQOS_SINGLE)
      {
         printf("Ingress Node MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n",
            pqos.ingress_mac[0], pqos.ingress_mac[1], pqos.ingress_mac[2],
            pqos.ingress_mac[3], pqos.ingress_mac[4], pqos.ingress_mac[5]);

         nRet = moca_start_event_loop(g_mocaHandle, &pqos_thread);
         if (nRet == CMSRET_SUCCESS)
         {
            moca_register_pqos_list_response_cb(g_mocaHandle, &pqos_list_response_cb, (void *)&total_flows);
            nRet = MoCACtl2_ListPQoSFlow(g_mocaHandle, &pqos);
            if (nRet == CMSRET_SUCCESS)
            {
               moca_wait_for_event(g_mocaHandle, pqos_thread, 5);
            }
         }
      }
      else if (list_type == MOCA_LIST_PQOS_ALL)
      {
         /* Get the number of total nodes and loop through them all */
         nRet = MoCACtl2_GetStatus(g_mocaHandle, &status);
         if (nRet == CMSRET_SUCCESS)
         {
            for (i = 0; 
                 status.generalStatus.connectedNodes; 
                 status.generalStatus.connectedNodes >>= 1, i++)
            {
               pmacAddr = NULL;
               if (status.generalStatus.connectedNodes & 0x1)
               {
                  if (status.generalStatus.nodeId == i)
                  {
                     pmacAddr = &status.miscStatus.macAddr;
                     
                  }
                  else
                  {
                     node_status.nodeId = i;
                     nRet = MoCACtl2_GetNodeStatus(g_mocaHandle, &node_status);
                     if (nRet == CMSRET_SUCCESS)
                     {
                        moca_u32_to_mac(mac, node_status.eui[0], node_status.eui[1]);
                        pmacAddr = &mac;
                     }
                  }
               }

               if (pmacAddr != NULL)
               {
                  pqos.node_id = i;
                  printf("Ingress Node MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n",
                     (*pmacAddr)[0], (*pmacAddr)[1], (*pmacAddr)[2],
                     (*pmacAddr)[3], (*pmacAddr)[4], (*pmacAddr)[5]);

                  ret = moca_start_event_loop(g_mocaHandle, &pqos_thread);
                  if (ret == 0) {
                     moca_register_pqos_list_response_cb(g_mocaHandle, &pqos_list_response_cb, (void *)&total_flows);
                     nRet = MoCACtl2_ListPQoSFlow(g_mocaHandle, &pqos);
                     if (nRet == CMSRET_SUCCESS)
                     {
                        moca_wait_for_event(g_mocaHandle, pqos_thread, 5);
                     }
                  }
               }
            }

            printf("\nTotal existing Flows:  %u\n", total_flows);
         }
      }
   }

   return( nRet );
} /* PQoSLHandler */


/***************************************************************************
 * Function Name: PQoSQHandler
 * Description  : Processes the mocactl pqosq command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int PQoSQHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS;
   MoCA_QUERY_PQOS_PARAMS pqos ;
   MAC_ADDRESS *pmacAddr;
   MoCAOS_ThreadHandle pqos_thread;

   memset (&pqos, 0x00, sizeof(MoCA_QUERY_PQOS_PARAMS)) ;
   pqos.flow_id[0] = 0x01;
   pqos.flow_id[1] = 0x00;
   pqos.flow_id[2] = 0x5E;
   pqos.flow_id[3] = 0x00;
   pqos.flow_id[4] = 0x01;
   pqos.flow_id[5] = 0x00;

   while( nRet == CMSRET_SUCCESS && nNumOptions )
   {
      pmacAddr = NULL;
      if( !strcmp(pOptions->pszOptName, "--flow_id") ) 
      {
         pmacAddr = &pqos.flow_id;
      }
      else 
      {
         nRet = CMSRET_INVALID_ARGUMENTS;

         fprintf( stderr, "%s: invalid parameter for option %s\n",
               g_szPgmName, pOptions->pszOptName );
      }

      if ( pmacAddr )
      {
         if ( ParseMacAddress ( pOptions->pszParms[ 0 ], pmacAddr) != 0 )
         {
            fprintf( stderr, "%s: invalid parameter for option %s\n", 
               g_szPgmName, pOptions->pszOptName ) ;
            fprintf( stderr, "  Flow ID format: 1a:2b:3c:4d:5e:6f\n" ) ;
            nRet = CMSRET_INVALID_ARGUMENTS ;
         }
      }

      nNumOptions--;
      pOptions++;
   }

   if( nRet == CMSRET_SUCCESS ) 
   {
      nRet = moca_start_event_loop(g_mocaHandle, &pqos_thread);
      if (nRet == CMSRET_SUCCESS)
      {
         moca_register_pqos_query_response_cb(g_mocaHandle, &pqos_query_response_print_cb, g_mocaHandle);
         nRet = MoCACtl2_QueryPQoSFlow(g_mocaHandle, &pqos);
         if (nRet == CMSRET_SUCCESS)
         {
            moca_wait_for_event(g_mocaHandle, pqos_thread, 5);
         }
      }
   }

   return( nRet );
} /* PQoSQHandler */

/***************************************************************************
 * Function Name: PQoSSHandler
 * Description  : Processes the mocactl pqoss command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int PQoSSHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet nRet = CMSRET_SUCCESS;
   MoCAOS_ThreadHandle pqos_thread;

   nRet = moca_start_event_loop(g_mocaHandle, &pqos_thread);
   if (nRet == CMSRET_SUCCESS)
   {
      moca_register_pqos_create_response_cb(g_mocaHandle, &pqos_create_response_status_cb, g_mocaHandle);
      nRet = MoCACtl2_GetPQoSStatus(g_mocaHandle);
      if (nRet == CMSRET_SUCCESS)
      {
         moca_wait_for_event(g_mocaHandle, pqos_thread, 5);
      }
   }

   return( nRet );
} /* PQoSSHandler */


/***************************************************************************
 * Function Name: FnCallHandler
 * Description  : Processes the mocactl pqos-maintenance command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int FnCallHandler( POPTION_INFO pOptions, int nNumOptions )
{
   MoCA_FUNC_CALL_PARAMS fnCallParams ;
   CmsRet             nRet = CMSRET_SUCCESS ;

   if (nNumOptions > NUM_FUNC_CALL_OPTIONS)
   {
      printf ("Too many options for function call command (only %u params max allowed). \n", 
         (NUM_FUNC_CALL_OPTIONS - 1)) ;
 	   HelpHandler ( pOptions, nNumOptions );
   }

   memset (&fnCallParams, 0x00, sizeof(fnCallParams)) ;

   while( nRet == CMSRET_SUCCESS && nNumOptions )
   {
      if( !strcmp(pOptions->pszOptName, "--address") ) 
      {
         if( pOptions->nNumParms != 1)
         {
             nRet = CMSRET_INVALID_ARGUMENTS;
         }
         else 
         {               
            char *pszEnd = NULL;
            fnCallParams.Address = ((UINT32) strtoul ( pOptions->pszParms[0], &pszEnd, 16 )) ;
            if( *pszEnd != '\0' )
            {
               nRet = CMSRET_INVALID_ARGUMENTS;
               fprintf( stderr, "%s: invalid parameter %s for option %s (received %d from strtol)\n",
                     g_szPgmName, pOptions->pszParms[0], pOptions->pszOptName, *pszEnd );
            }
         }
      }

	   else if( !strcmp(pOptions->pszOptName, "--params") ) 
	   {
         if( pOptions->nNumParms > 3)
         {
   		    nRet = CMSRET_INVALID_ARGUMENTS;
         }
         else {
            if (pOptions->nNumParms > 0)
            {
               char *pszEnd = NULL;
               fnCallParams.param1 = (UINT32) strtol (pOptions->pszParms[0], &pszEnd, 10 ) ;
               fnCallParams.numParams = 1;
            }
            if (pOptions->nNumParms > 1)
            {
               char *pszEnd = NULL;
               fnCallParams.param2 = (UINT32) strtol (pOptions->pszParms[1], &pszEnd, 10 ) ;
               fnCallParams.numParams = 2;
            }
            if (pOptions->nNumParms > 2)
            {
               char *pszEnd = NULL;
               fnCallParams.param3 = (UINT32) strtol (pOptions->pszParms[2], &pszEnd, 10 ) ;
               fnCallParams.numParams = 3;
            }
         }
      }

      else
      {
         nRet = CMSRET_INVALID_ARGUMENTS;
      }

      if( nRet != CMSRET_SUCCESS )
          fprintf( stderr, "%s: invalid parameter for option %s\n",
              g_szPgmName, pOptions->pszOptName ) ;

      nNumOptions--;
      pOptions++;
   }

   if (nRet == CMSRET_SUCCESS)
   {
      printf ("Sending function call.\n") ;
      nRet = MoCACtl2_FunctionCall( g_mocaHandle, &fnCallParams) ;
   }
   
   return (nRet) ;
} /* FnCallHandler */

/***************************************************************************
 * Function Name: McFwdHandler
 * Description  : Processes the mocactl mcfwd command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int McFwdHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet            nRet = CMSRET_SUCCESS ;
   MoCA_MC_FWD_ENTRY mcFwdEntry ;
   UINT32            parmNumber = 0;
   MAC_ADDRESS       mac;

   while( (nRet == CMSRET_SUCCESS) && nNumOptions )
   {
      memset (&mcFwdEntry, 0, sizeof (MoCA_MC_FWD_ENTRY)) ;

      if( !strcmp(pOptions->pszOptName, "--create") ) {
         if ( (pOptions->nNumParms < 2) || (pOptions->nNumParms > MoCA_MAX_NODES + 1) ) {

            fprintf( stderr, "%s: invalid number of parameters for %s\n",
                     g_szPgmName, pOptions->pszOptName ) ;
            fprintf( stderr, "usage:\n# moca mcfwd --create <mcast mac addr> <unicast mac addr 1> ... <unicast mac addr 16>\n" ) ;
            fprintf( stderr, "mac address format: 1a:2b:3c:4d:5e:6f\n" ) ;
            nRet = CMSRET_INVALID_ARGUMENTS ;
         }
         else {
            for ( parmNumber = 0 ; 
                  ((int)parmNumber < pOptions->nNumParms) && (nRet == CMSRET_SUCCESS) ; 
                  parmNumber++ ) {

               if ( ParseMacAddress ( pOptions->pszParms[ parmNumber ], &mac ) == 0 )
               {
                  mcFwdEntry.numOfMembers++ ;
               }
               else
               {
                  fprintf( stderr, "%s: invalid mac address %s\n", g_szPgmName, pOptions->pszParms[ parmNumber ] ) ;
                  fprintf( stderr, "mac address format: 1a:2b:3c:4d:5e:6f\n" ) ;
                  nRet = CMSRET_INVALID_ARGUMENTS ;
               }

               if ( parmNumber == 0 )
               {
                  moca_mac_to_u32(&mcFwdEntry.mcMacAddr[0], &mcFwdEntry.mcMacAddr[1], mac);
               }
               else
               {
                  moca_mac_to_u32(&mcFwdEntry.nodeAddr[parmNumber - 1].macAddr[0],
                    &mcFwdEntry.nodeAddr[parmNumber - 1].macAddr[1], mac);
               }
            }

            if ( nRet == CMSRET_SUCCESS ) {
               nRet = MoCACtl2_CreateMcFwdTblGroup( g_mocaHandle, &mcFwdEntry) ;
               printf ("MoCACtl2_CreateMcFwdTblGroup Status = %d \n", nRet) ;
            }
         }
      }
      else if ( !strcmp(pOptions->pszOptName, "--delete") ) {
         if ( pOptions->nNumParms != 1 ) {

            fprintf( stderr, "%s: invalid number of parameters for %s\n",
                     g_szPgmName, pOptions->pszOptName ) ;
            fprintf( stderr, "usage:\n# moca mcfwd --delete <mcast mac addr>\n" ) ;
            fprintf( stderr, "mac address format: 1a:2b:3c:4d:5e:6f\n" ) ;
            nRet = CMSRET_INVALID_ARGUMENTS ;
         }
         else {
            if ( ParseMacAddress ( pOptions->pszParms[ parmNumber ], &mac ) != 0 )
            {
               fprintf( stderr, "%s: invalid mac address %s\n", g_szPgmName, pOptions->pszParms[ parmNumber ] ) ;
               fprintf( stderr, "mac address format: 1a:2b:3c:4d:5e:6f\n" ) ;
               nRet = CMSRET_INVALID_ARGUMENTS ;
            }

            moca_mac_to_u32(&mcFwdEntry.mcMacAddr[0], &mcFwdEntry.mcMacAddr[1], mac);

            if ( nRet == CMSRET_SUCCESS ) {
               nRet = MoCACtl2_DeleteMcFwdTblGroup( g_mocaHandle, &mcFwdEntry) ;
               printf ("MoCACtl2_DeleteMcFwdTblGroup Status = %d \n", nRet) ;
            }
         }
      }

      nNumOptions-- ;
      pOptions++ ;
   }
   
   return (nRet) ;
} /* McFwdHandler */

void mocad_printf_callback(void * userarg, struct moca_mocad_printf * out)
{
    printf("%s", out->msg);
    fflush(stdout);
}

void lmo_callback(void *userarg, struct moca_lmo_info *out)
{
   struct moca_lmo_cb_params * cb_params;
   MoCA_SNR_DATA   snrData;
   static UINT32   data [256*8];
   MoCA_CIR_DATA   irData;
   CmsRet          nRet;
   int             i;
   MoCA_NODE_STATUS_ENTRY nodestatus;
   MAC_ADDRESS     macAddr;
   MoCA_STATUS     status;

   memset( &status, 0x00, sizeof(status) );
   cb_params = (struct moca_lmo_cb_params *)userarg;

   /* Read the current status */ 
   
   nRet = MoCACtl2_GetStatus( cb_params->ctx, &status ) ;
   if (nRet != CMSRET_SUCCESS)
   {
       fprintf(stderr, "Warning!  Cannot get MoCA status\n");
   }
   
   nodestatus.nodeId = out->lmo_node_id;
   
   nRet = MoCACtl2_GetNodeStatus(cb_params->ctx, &nodestatus);
   
   if (nRet != CMSRET_SUCCESS)
   {
       fprintf(stderr, "Warning!  Cannot get node status\n");
   }
   
   moca_u32_to_mac(macAddr, nodestatus.eui[0], nodestatus.eui[1]);
   
   if ((cb_params->flags & MOCA_LAB_SNR_PRINTS) &&
       (cb_params->snr_node_id == out->lmo_node_id))
   {
      snrData.pData = (UINT8 *) &data [0];
      snrData.probe = MoCA_MAX_PROBES;
      nRet = MoCACtl2_GetSNRData (cb_params->ctx, &snrData);

      if (nRet == CMSRET_SUCCESS)
      {
         printf("Node %u SNR ", out->lmo_node_id);
         
         printf("LN=%02X:%02X:%02X:%02X:%02X:%02X ",
               macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5] );
         
         printf("Self=%02X:%02X:%02X:%02X:%02X:%02X ",
               status.miscStatus.macAddr[0],
               status.miscStatus.macAddr[1],
               status.miscStatus.macAddr[2],
               status.miscStatus.macAddr[3],
               status.miscStatus.macAddr[4],
               status.miscStatus.macAddr[5]) ;

         printf("LOF=%d Data:\n", status.generalStatus.rfChannel);
         

         printf("-----------------------------------------------------------------------");
         for (i = 0; i < 256*8; i++)
         {
            if (i % 8 == 0) printf("\n");
            
            if (cb_params->print_as_db)
            {
                if ((i&0xFF) == 0) printf("Probe %d:\n", (i>>8) + 1);
                if ((i%8) == 0) printf("%3d: ", i&0xFF);

                printf("%5.2lf ", 10.0/log(10.0)*(log(2147483648.0) - log((double)data[i])));
            }
            else
                printf("%08x ", data[i]);
    
            
         }
         printf("\n\n");
      }
      else
      {
         fprintf(stderr, "Error reading SNR data 0x%x\n", nRet);
      }
   }

   if ((cb_params->flags & MOCA_LAB_CIR_PRINTS) && (out->lmo_node_id != status.generalStatus.nodeId))
   {   
      irData.nodeId = out->lmo_node_id;
      irData.size = 256*4;
      irData.pData = (UINT8 *) &data [0];
      nRet = MoCACtl2_GetCIRData (cb_params->ctx, &irData);

      if (nRet == CMSRET_SUCCESS)
      {
         printf("Node %u CIR ", out->lmo_node_id);

         printf("LN=%02X:%02X:%02X:%02X:%02X:%02X ",
               macAddr[0], macAddr[1], macAddr[2], macAddr[3], macAddr[4], macAddr[5] );
         
         printf("Self=%02X:%02X:%02X:%02X:%02X:%02X ",
               status.miscStatus.macAddr[0],
               status.miscStatus.macAddr[1],
               status.miscStatus.macAddr[2],
               status.miscStatus.macAddr[3],
               status.miscStatus.macAddr[4],
               status.miscStatus.macAddr[5]) ;

         printf("LOF=%d Data:\n", status.generalStatus.rfChannel);
         
         printf("-----------------------------------------------------------------------");
         for (i = 0; i < 256; i++)
         {
            if (i % 8 == 0) printf("\n");
            printf("%08x ", data[i]);
         }
         printf("\n\n");
      }
      else
      {
         fprintf(stderr, "Error reading CIR data 0x%x\n", nRet);
      }
   }
   
   if ((cb_params->flags & MOCA_LAB_BITLOADING_PRINTS) && 
       ((cb_params->bitloading_id == out->lmo_node_id) ||
        (cb_params->bitloading_id == 0xFFFFFFFF)))
   {
       UINT32   tblSize ;
       MoCA_NODE_STATUS_ENTRY        nodeStatus [MoCA_MAX_NODES] ;
       MoCA_NODE_COMMON_STATUS_ENTRY nodeCommonStatus ;
              
       MoCACtl2_GetNodeTblStatus( g_mocaHandle, &nodeStatus [0], &nodeCommonStatus, &tblSize ) ;
       
       printf("Node %u Bitloading\n", out->lmo_node_id);    
       printf ("   Tx Unicast Bit Loading Info  \t   Rx Unicast Bit Loading Info \n" ) ;
       printf ("--------------------------------\t   -------------------------------\n") ;
       mocacli_display_bit_loading(&nodestatus.txUc.bitLoading[0], &nodestatus.rxUc.bitLoading[0]) ;
       printf ("--------------------------------\t   -------------------------------\n") ;
       
       printf ("   Rx Broadcast Bit Loading Info  \t   Rx Map Bit Loading Info \n" ) ;
       printf ("----------------------------------\t   -----------------------------\n") ;
       mocacli_display_bit_loading(&nodestatus.rxBc.bitLoading[0], &nodestatus.rxMap.bitLoading[0]) ;
       printf ("--------------------------------\t   -------------------------------\n") ;

       if (out->lmo_node_id == status.generalStatus.nodeId)
       {
          printf ("   Tx Bcast Bit Loading Info    \t      Tx Map Bit Loading Info  \n" ) ;
          printf ("--------------------------------\t    ---------------------------\n") ;
          mocacli_display_bit_loading (&nodeCommonStatus.txBc.bitLoading[0], &nodeCommonStatus.txMap.bitLoading[0]) ;
          printf ("--------------------------------\t   -------------------------------\n") ;       
       }
   }

   if ((cb_params->flags & MOCA_LAB_NODESTATUS_PRINTS) && 
       ((cb_params->nodestatus_id == out->lmo_node_id) ||
        (cb_params->nodestatus_id == 0xFFFFFFFF)))
   {
       printf("Node %u NodeStatus\n", out->lmo_node_id);      
       mocacli_display_node_status(&nodestatus,0,1,1);
   }
      
   return;
}

/***************************************************************************
 * Function Name: LabHandler
 * Description  : Processes the mocactl lab command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int LabHandler(POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet                     nRet = CMSRET_SUCCESS;
   struct moca_lmo_cb_params  cb_params;
   UINT32                     *pulValue;
   MoCA_CONFIG_PARAMS         config;
   UINT64                     configMask = 0;
   MoCA_INITIALIZATION_PARMS  InitParms;
   
   if (nNumOptions == 0)
   {
      printf ("Usage:\n"
              "moca lab [--snr <node ID>] [--db] [--cir] [--bitloading <node ID>]\n"
              "         [--nodestatus <node ID>] [--monitor]\n"
              "--snr        Display SNR data for specified nodes\n"
              "  --db       Display SNR data in dB\n"
              "--cir        Display CIR data for all nodes\n"
              "--bitloading Display bitloading info for specified nodes\n"
              "--nodestatus Display nodestatus info for specified nodes\n"
              "--monitor    Display all mocad prints\n");
      return( CMSRET_INVALID_ARGUMENTS );
   } 

   memset(&cb_params, 0x0, sizeof(struct moca_lmo_cb_params));
   memset(&config, 0x0, sizeof(MoCA_CONFIG_PARAMS));

   /* Read the current global configuration. */
   nRet = MoCACtl2_GetInitParms( g_mocaHandle, &InitParms );

   while( (nRet == CMSRET_SUCCESS) && nNumOptions )
   {
      pulValue = NULL;
      if( !strcmp(pOptions->pszOptName, "--db") )
      {
         cb_params.print_as_db = 1;
      }
      else if( !strcmp(pOptions->pszOptName, "--snr") ) 
      {
         cb_params.flags |= MOCA_LAB_SNR_PRINTS;
         pulValue = &cb_params.snr_node_id;
      }
      else if (!strcmp(pOptions->pszOptName, "--cir"))
      {
         cb_params.flags |= MOCA_LAB_CIR_PRINTS;
      }
      else if (!strcmp(pOptions->pszOptName, "--bitloading"))
      {
         cb_params.flags |= MOCA_LAB_BITLOADING_PRINTS; 
         pulValue = &cb_params.bitloading_id;
      }
      else if (!strcmp(pOptions->pszOptName, "--monitor"))
      {
         cb_params.flags |= MOCA_LAB_MONITOR; 
      }
      else if (!strcmp(pOptions->pszOptName, "--nodestatus"))
      {
         cb_params.flags |= MOCA_LAB_NODESTATUS_PRINTS; 
         pulValue = &cb_params.nodestatus_id;
      }
      else 
      {
         fprintf( stderr, "%s: invalid option %s\n",
            g_szPgmName, pOptions->pszOptName );
         nRet = CMSRET_INVALID_ARGUMENTS;
      }

      if( pulValue )
      {
         /* Convert the value for a particular option to an integer. */
         if( pOptions->nNumParms == 1 )
         {
            char *pszEnd = NULL;

            *pulValue = (long) strtol( pOptions->pszParms[0], &pszEnd, 10 );

            if( *pszEnd != '\0' )
            {
               nRet = CMSRET_INVALID_ARGUMENTS;
               fprintf( stderr, "%s: invalid parameter for option %s\n",
                     g_szPgmName, pOptions->pszOptName );
            }
         }
         else if ( pOptions->nNumParms == 0)
         {
            *pulValue = 0xFFFFFFFF;
         }
         else
         {
            nRet = CMSRET_INVALID_ARGUMENTS;
            fprintf( stderr, "%s: invalid number of parameters for option "
                  "%s\n", g_szPgmName, pOptions->pszOptName );
         }
      }

      nNumOptions--;
      pOptions++;
   }

   if ((nRet == CMSRET_SUCCESS) && (InitParms.labMode != MoCA_LAB_MODE) && 
       (cb_params.flags & ~(MOCA_LAB_BITLOADING_PRINTS | MOCA_LAB_NODESTATUS_PRINTS | MOCA_LAB_MONITOR)))
   {
      printf ("MoCA not in lab mode. Try 'mocactl restart --labMode on' first.\n");
      nRet = CMSRET_REQUEST_DENIED;
   }

   if (nRet == CMSRET_SUCCESS)
   {
      if (cb_params.flags & MOCA_LAB_SNR_PRINTS)
      {
         if (cb_params.snr_node_id == 0xFFFFFFFF)
         {
            fprintf( stderr, "%s: no node id for snr prints\n",
                     g_szPgmName );
            nRet = CMSRET_INVALID_ARGUMENTS;
         }
         else
         {
             config.MoCASnrGraphSetNodeId = cb_params.snr_node_id;
             configMask |= MoCA_CFG_PARAM_SNR_GRAPH_SET_MASK;
         }
      }

      if (nRet == CMSRET_SUCCESS)
         nRet = MoCACtl2_SetCfg(g_mocaHandle, &config, configMask);
   }
   if ((nRet == CMSRET_SUCCESS) && (cb_params.flags != 0))
   {
      cb_params.ctx = g_mocaHandle;

      moca_register_lmo_info_cb(g_mocaHandle, lmo_callback, (void *)&cb_params);

      if (cb_params.flags & MOCA_LAB_MONITOR)
      {
         moca_register_mocad_printf_cb(g_mocaHandle, mocad_printf_callback, (void *)&cb_params);
      }
      
      if (nRet == CMSRET_SUCCESS) 
      {
         if (cb_params.flags & MOCA_LAB_SNR_PRINTS)
            printf("Printing SNR data after each Node %u LMO cycle.\n",
               cb_params.snr_node_id);
         if (cb_params.flags & MOCA_LAB_CIR_PRINTS)
            printf("Printing CIR data after each LMO cycle.\n");
         printf("\nType <CTRL>-c to exit\n\n");
         moca_event_loop(g_mocaHandle);
      }
      else {
          fprintf( stderr, "%s: moca_start_event_loop returned error %d\n",
              g_szPgmName, nRet );
      }
   }
   
   return (nRet);
} /* FmrRequestHandler */


/***************************************************************************
 * Function Name: E2MHandler
 * Description  : Processes the mocactl e2m command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int E2MHandler( POPTION_INFO pOptions, int nNumOptions )
{
   struct moca_error_to_mask e2m = {0, 0, 0};
   char *pszEnd = NULL;
   int ret = 0;

   if (nNumOptions > 1)
   {
      printf ("Too many parameters for e2m command.\n");
      return(-1);
   }
   else
   {
      if (nNumOptions == 0)
      {
         ret = moca_get_error_to_mask( g_mocaHandle, &e2m );

         if (ret == 0) {
            fprintf( stderr, "%s: E2M: %d %d %d\n", 
               g_szPgmName, e2m.error1, e2m.error2, e2m.error3);
         }
         else {
            fprintf( stderr, "%s: moca_get_error_to_mask failed. Error = 0x%x\n", 
               __FUNCTION__, ret );
         }

         return( ret ) ;
      }

      if( !strcmp(pOptions->pszOptName, "--nums") )
      {
         if (pOptions->nNumParms >= 1)
            e2m.error1 = strtol(pOptions->pszParms[0], &pszEnd, 0);
         if (pOptions->nNumParms >= 2)
            e2m.error2 = strtol(pOptions->pszParms[1], &pszEnd, 0);
         if (pOptions->nNumParms >= 3)
            e2m.error3 = strtol(pOptions->pszParms[2], &pszEnd, 0);

         ret = moca_set_error_to_mask(g_mocaHandle, &e2m);
      }
   }      

   return (ret) ;
} /* E2MHandler */

/***************************************************************************
 * Function Name: TpcapHandler
 * Description  : Processes the mocactl tpcap command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int TpcapHandler( POPTION_INFO pOptions, int nNumOptions )
{
#if !defined(CHIP_6816) && !defined(__EMU_HOST_11__)
    int type = 1;
    int nsamples = 1000;
    MoCA_VERSION MoCAVersion;
    unsigned int paddr;
    unsigned int node = 0;
    unsigned int port = 0;
    unsigned int macphy = 0;
    unsigned int clock = 0;
    unsigned int rate = 0;
    unsigned int lpbk = 0;
    unsigned int wait = 0;
    int mode = 0;
    MoCA_TPCAP_PARAMS dp;

    MoCACtl2_GetVersion( g_mocaHandle, &MoCAVersion) ;
    
    while (nNumOptions > 0)
    {
        if( !strcmp(pOptions->pszOptName, "--nsamples") )
        {
            nsamples = strtol(pOptions->pszParms[0], NULL, 0);
        }
        else if( !strcmp(pOptions->pszOptName, "--lpbk") )
        {
            lpbk = strtol(pOptions->pszParms[0], NULL, 0);
        }        
        else if( !strcmp(pOptions->pszOptName, "--clock") )
        {
            clock = strtol(pOptions->pszParms[0],NULL,0);
        }
        else if( !strcmp(pOptions->pszOptName, "--rate") )
        {
            rate = strtol(pOptions->pszParms[0],NULL,0);
        }
        else if( !strcmp(pOptions->pszOptName, "--port") )
        {
            port = strtol(pOptions->pszParms[0],NULL,0);
        }        
        else if( !strcmp(pOptions->pszOptName, "--bursttype") )
        {
            type = strtol(pOptions->pszParms[0],NULL,0);

            if ((type < 1) || (type > 13))
                printf("WARNING: type should be in the range of 1-13\n");
        }
        else if( !strcmp(pOptions->pszOptName, "--mode") )
        {
            mode = strtol(pOptions->pszParms[0],NULL,0);

            if ((mode < 0) || (mode > 7))
                printf("WARNING: mode should be in the range of 0-7\n");
        }        
        else if( !strcmp(pOptions->pszOptName, "--node") )
        {
            node = strtol(pOptions->pszParms[0],NULL,0);

            if ((node < 0) || (node > 15))
                printf("WARNING: node should be in the range of 0-15\n");
        }
        else if( !strcmp(pOptions->pszOptName, "--wait") )
        {
            wait = 1;
        }
        
        else if( !strcmp(pOptions->pszOptName, "--macphy") )
        {
            macphy = strtol(pOptions->pszParms[0],NULL,0);
        }
        
        nNumOptions--;        
        pOptions++;
    }

    TPCAP_Init(MoCAVersion.coreHwVersion);

    printf("Allocating memory...\n");
    MoCAOS_AllocPhysMem((nsamples*4) + 256, (unsigned int **)&paddr);
    paddr = (paddr+255) & 0xFFFFFF00; // do some alignment

    if (paddr == 0)
    {
        fprintf(stderr,"Unable to allocate memory\n");
        return(-1);
    }

    dp.type = (type <<16) | node;
    dp.enable = 2; // 1 will allocate a memory buffer

    printf("Notifying firmware...\n");
    MoCACtl2_SetTPCAP( g_mocaHandle, &dp);

    printf("Starting capture...\n");
    TPCAP_Start(mode, port, nsamples, paddr, macphy, rate, clock, lpbk, wait);

    moca_set_miscval(g_mocaHandle, paddr);

#else
    printf("TPCAP not supported on DSL chips\n");
#endif
    return(0);
}

/***************************************************************************
 * Function Name: TpcapDumpHandler
 * Description  : Dumps the tpcap buffer to screen or file
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int TpcapDumpHandler( POPTION_INFO pOptions, int nNumOptions )
{
#if !defined(CHIP_6816) && !defined(__EMU_HOST_11__)
    FILE *fp = stdout;
    unsigned int display = 0;
    unsigned int paddr = 0;
    unsigned int i;

    moca_get_miscval(g_mocaHandle, &paddr);    

    if (paddr == 0)
    {
        fprintf(stderr,"No tpcap buffer found\n");
        return(0);
    }

    printf("Reading from address 0x%08X...\n", paddr);
    
    while (nNumOptions > 0)
    {
        if( !strcmp(pOptions->pszOptName, "--file") )
        {
            fp = fopen(pOptions->pszParms[0], "w");
            if (!fp)
            {
                fprintf(stderr,"Unable to open file %s for writing\n", pOptions->pszParms[0]);
                return(-1);
            }
        }
        else if( !strcmp(pOptions->pszOptName, "--display") )
        {
            display = strtol(pOptions->pszParms[0],NULL,0);

            if ((display < 0) || (display > 1))
                printf("WARNING: display should be in the range of 0-1\n");
        }        
        
        nNumOptions--;        
        pOptions++;
    }

    printf("Writing file...\n");

    if (paddr)
    {
        for (i=0;;i++)
        {
            unsigned int val = TPCAP_ReadMem(paddr+i*4);

            if (val == 0xAAAAAAAA)
                break;
        
            if (display == 1)
                fprintf(fp, "%6d\t%08X\t%6d\t%6d\n", i, val, (short)(val >> 16), (short)(val & 0xFFFF) );
            else
                fprintf(fp, "%04X %04X\n", val>>16, val&0xFFFF);
        }
    }
    printf("Done\n");
    fclose(fp);
#else
    printf("TPCAP not supported on DSL chips\n");
#endif
    return(0);
}

static int WolHandler( POPTION_INFO pOptions, int nNumOptions )
{
   int retval;
   int enable = 1;
   if (!nNumOptions || nNumOptions > 1)
   {
      printf ("Usage:\n"
              "moca wol [--enable|--disable]\n"
              "--enable     Enable MoCA Wake-on-LAN\n"
              "--disable    Disable MoCA Wake-on-LAN\n");
      return( CMSRET_INVALID_ARGUMENTS );
   }

   if( !strcmp(pOptions->pszOptName, "--enable") )
   {
      enable = 1;
   }
   else if( !strcmp(pOptions->pszOptName, "--disable") ) 
   {
      enable = 0;
   }

   retval = MoCACtl2_Wol(g_mocaHandle, enable) ;

   return retval;

}

static int CpuRateHandler( POPTION_INFO pOptions, int nNumOptions )
{
#if !defined(CHIP_6816) && !defined(__EMU_HOST_11__)

    int retval = 0;    
    unsigned int rate = 0;
    unsigned int divider = 0;
    
    extern void regw(unsigned int addr, unsigned int val);    
    
    if (!nNumOptions || nNumOptions > 1)
    {
       printf ("Usage:\n"
               "moca cpurate [--rate <val>]\n"
               "--rate       Clock rate in MHz\n");
       return( CMSRET_INVALID_ARGUMENTS );
    }
    
    if( !strcmp(pOptions->pszOptName, "--rate") )
    {
       rate = strtol(pOptions->pszParms[0],NULL,0);
       if ((rate <= 0) || (rate > 3600))
       {
          printf("Invalid rate value: %d\n", rate);
          return(-1);
       }
    }

    divider = 3600/rate;

    printf("Nearest actual rate: %d MHz (divider=%d)\n", 3600/divider, divider);
    regw(0x10430160, divider << 6);

    return retval;
#else
    printf("CpuRateHandler: Function not supported\n");
    return 0;
#endif
}

/***************************************************************************
 * Function Name: VersionHandler
 * Description  : Processes the mocactl version command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int VersionHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet cmsRet ;
   MoCA_VERSION MoCAVersion ;

   cmsRet = MoCACtl2_GetVersion( g_mocaHandle, &MoCAVersion) ;
   if (cmsRet != CMSRET_SUCCESS) 
   {
      fprintf( stderr, "%s: MoCACtl2_GetVersion error\n", g_szPgmName ) ;
      cmsRet = CMSRET_INTERNAL_ERROR ;
   }
   else {
      UINT32 coreversionMajor, coreversionMinor, coreversionBuild ;
      coreversionMajor = MoCAVersion.coreSwVersion >> 28 ;
      coreversionMinor = (MoCAVersion.coreSwVersion << 4) >> 28 ;
      coreversionBuild = (MoCAVersion.coreSwVersion << 8) >> 8 ;
      fprintf (stderr, "\nMoCA CLI version " MoCACTL_VERSION"\n") ;
      printf ("\nMoCA Version\n") ;
      printf ("-----------------------\n") ;
      printf ("MoCA coreHWVersion   : 0x%x\n", MoCAVersion.coreHwVersion) ;
      printf ("MoCA coreSWVersion   : %d.%d.%d\n", coreversionMajor, coreversionMinor,
            coreversionBuild) ;
      printf ("MoCA self version    : 0x%x\n", MoCAVersion.selfVersion) ;
      printf ("MoCA driver version  : %d.%d.%x\n", MoCAVersion.drvMjVersion, MoCAVersion.drvMnVersion,
            MoCAVersion.drvBuildVersion) ;
      printf ("-----------------------\n") ;
   }

   return( cmsRet ) ;
} /* VersionHandler */


/***************************************************************************
 * Function Name: HelpHandler
 * Description  : Processes the mocactl help command.
 * Returns      : 0 - success, non-0 - error
 ***************************************************************************/
static int HelpHandler( POPTION_INFO pOptions, int nNumOptions )
{
   CmsRet cmsRet = CMSRET_SUCCESS;
   MoCA_VERSION MoCAVersion ;

   if ((nNumOptions == 1) && !strcmp(pOptions->pszOptName, "--advanced"))
   {
   fprintf( stderr,
         "Usage: %s [--help] [--version]\n"
         "       %s start [--nc auto|on|off] [--singleCh on|off|on2] [--privacy on|off]\n"
         "                [--tpc on|off] [--constTxMode normal|tx|rx|tone <sc1> <sc2>|cw]\n"
         "                [--continuousRxModeAttn <signval_indB>]\n"
         "                [--maxTxPower <signval_indBm>] [--nodeType terminal|intermediate]\n"
         "                [--password <password_string>] [--qam256Capability on|off]\n"
         "                [--lof <freq_in_decimals> ] [--mcastMode bcast|normal]\n"
         "                [--labMode on|off ] [--rfType bandD|bandE|bandF|bandH|bandC4]\n"
         "                [--tabooFixedMaskStart <val>] [--tabooFixedChannelMask <val>]\n"
         "                [--tabooLeftMask <val>] [--tabooRightMask <val>]\n"
         "                [--padPower <signval_indBm>] [--version <hex_version>]\n"
         "                [--preferredNC on|off] [--ledMode <0/1/2/3>]\n"
         "                [--egrMcFilter on|off] [--lowPriQNum <qnum>]\n"         
         "                [--backoffMode slow|fast] [--res1 <val>]\n"         
         "                [--res2 <val>] [--res3 <val>] [--freqMask <val>] [--pnsFreqMask <val>]\n"
         "                [--otfEn <val>] [--beaconChannel <freq_in_decimals>]\n"
         "                [--turboEn <val>] [--mrNonDefSeqNum <uint>] [--wait <0/1>]\n"
         "                [--beaconPwrReduction <val>] [--beaconPwrReductionEn <val>]\n"
         "                [--flowControlEn <val>] [--mtmEn <0|1>] [--qam1024En <0|1>] [--T50TimeMin <val>] [--T50TimeMax <val>]\n"
         "       %s restart [--nc auto|on|off] [--singleCh on|off|on2] [--privacy on|off]\n"
         "                [--tpc on|off] [--constTxMode normal|tx|rx|tone <sc1> <sc2>|cw]\n"
         "                [--maxTxPower <signval_indBm>] [--nodeType terminal|intermediate]\n"
         "                [--continuousRxModeAttn <signval_indB>]\n"         
         "                [--password <password_string>] [--qam256Capability on|off]\n"
         "                [--lof <freq_in_decimals> ] [--mcastMode bcast|normal]\n"
         "                [--labMode on|off ] [--rfType bandD|bandE|bandF|bandH|bandC4]\n"
         "                [--tabooFixedMaskStart <val>] [--tabooFixedChannelMask <val>]\n"
         "                [--tabooLeftMask <val>] [--tabooRightMask <val>]\n"         
         "                [--padPower <signval_indBm>] [--version <hex_version>]\n"
         "                [--preferredNC on|off] [--ledMode <0/1/2/3>]\n"
         "                [--egrMcFilter on|off] [--lowPriQNum <qnum>]\n"         
         "                [--backoffMode slow|fast] [--res1 <val>]\n"         
         "                [--res2 <val>] [--res3 <val>] [--freqMask] [--pnsFreqMask <val>]\n"         
         "                [--otfEn <val>] [--beaconChannel <freq_in_decimals>]\n"
         "                [--turboEn <val>] [--mrNonDefSeqNum <uint>] [--wait <0/1>]\n"        
         "                [--beaconPwrReduction <val>] [--beaconPwrReductionEn <val>]\n"
         "                [--flowControlEn <val>] [--mtmEn <0|1>] [--qam1024En <0|1>] [--T50TimeMin <val>] [--T50TimeMax <val>]\n"
         "       %s stop \n"
         "       %s config [--frameSize <val_in_bytes>]\n"
         "                [--maxTxTime <val>] [--minBwThreshold <val_in_Mbps>]\n"
         "                [--snrMgn <signfloat_inhalfdBs> ] [--outOfOrderLMO <nodeid>]\n"
         "                [--ieRRInsert on|off] [--ieMapInsert on|off] [--maxAggr <val> ]\n"
         "                [--maxConstellationNode <val> ]\n"
         "                [--sapm <on|off|reset> [arpl_th] [ [subcarrier margin] ... ] ]\n"
         "                [--sapm_LTE <on|off|reset> [arpl_th] ]\n"
         "                [--sapm_GSM <on|off|reset> [arpl_th] [GSM Freq 1] [GSM Freq 2] [GSM Freq 3] ]\n"
         "                [--rlapm <on|off|phy> [ [power margin] ... ] ] [--rlapmCap <val_in_dB>]\n"         
         "                [--maxConstellationInfo bpsk|qpsk|qam8|qam16|qam32|qam64|qam128\n"
         "                 |qam256|qam512|qam1024 ] [--pmk <val_in_hrs> ]\n"
         "                [--tek <val_in_mins> ]\n"
         "                [--prio <resv_high> <resv_med> <resv_low> <limit_high>\n"
         "                <limit_med> <limit_low>] [--phyRate128 <val_in_mbps>]\n"
         "                [--phyRate256 <val_in_mbps>] [--minMapCycle <val_in_microsec>]\n"
         "                [--phyRateTurbo <val_in_mbps>] [--phyRateTurboPlus <val_in_mbps>]\n"
         "                [--maxMapCycle <val_in_microsec>] [--rxTxPacketsPerQM]\n"
         "                [--extraRxPacketsPerQM] [--nbasCappingEn <0|1>]\n"
         "                [--selectiveRR <val>] [--loopbackEn <0|1>]\n"
         "                [--snrMgnOffset <val1> <val2> <val3> <val4> <val5>\n"
         "                 <val6> <val7> <val8> <val9> <val10>]\n"
         "                [--mocareg <hex addr> <hex value>]\n"
         "                [--tpcap <enable> <type>] [--powersave on|off]\n"
         "                [--freqShiftMode <off|plus|minus>] [--rxPowerTuning <val>]\n"
         "                [--egrMcFilterEntry <entryId> <valid> <mac_addr>]\n"                    
         "                [--enCapable <0|1>] [--diplexer [val_in_db]]\n"
         "                [--enMaxRateInMaxBo <val>] [--hostQOSEn <val>]\n"
         "       %s mcfwd [--create <mc addr> <uc addr1> [<uc addr2> ...]]\n"
         "                [--delete <mc addr>]\n"
         "       %s show  [--initparms] [--config] [--status]\n"
         "                [--stats [reset]]\n"
         "                [--traceconfig] [--nodestatus <nodeid>]\n"
         "                [--nodestats <nodeid> [reset]] [--mocareg <hex addr>]\n"
         "       %s showtbl [--nodestatus] [--nodestats [reset]] [--ucfwd] [--srcaddr]\n"
         "                [--mcfwd]\n"
         "       %s fn-call --address <addr> [--params <param1> <param2> <param3>]\n"
         "       %s trace [--none] [--entry] [--exit] [--dbg] [--verbose] [--info]\n"
         "                [--trap] [--core] [--mmpdump] [--time] [--default] [--all]\n"
         "       %s lab   [--snr <node ID>] [--db] [--cir] [--bitloading <node ID>]\n"
         "                [--nodestatus] [--monitor]\n"
         "       %s tpcap [--bursttype <burst_type>] [--nsamples <val>] [--port <val>\n"
         "                [--mode <cap_mode>] [--wait] [--node <node_id>]\n"
         "                [--macphy <0/1>] [--clock <val>] [--rate <val>] [--lpbk <val>]\n"
         "       %s tpcapdump [--file <filename>] [--display <val>]\n"
         "       %s wol   [--enable] [--disable]\n"
         "       %s restore_defaults \n",
      g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName,
      g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName,
      g_szPgmName, g_szPgmName, g_szPgmName) ;
   }
   else
   {
      fprintf( stderr,
         "Usage: %s [--help] [--version]\n"
         "       %s start [--singleCh on|off|on2] [--privacy on|off]\n"
         "                [--constTxMode normal|tx|rx|tone <sc1> <sc2>|cw]\n"
         "                [--continuousRxModeAttn <signval_indB>]\n"         
         "                [--maxTxPower <signval_indBm>] [--nodeType terminal|intermediate]\n"
         "                [--password <password_string>] [--qam256Capability on|off]\n"
         "                [--lof <freq_in_decimals> ] [--mcastMode bcast|normal]\n"
         "                [--labMode on|off ]\n"
         "                [--tabooFixedMaskStart <val>] [--tabooFixedChannelMask <val>]\n"
         "                [--tabooLeftMask <val>] [--tabooRightMask <val>]\n"         
         "                [--padPower <signval_indBm>] [--version <hex_version>]\n"
         "                [--preferredNC on|off] [--ledMode <0/1/2/3>]\n"
         "                [--backoffMode slow|fast] [--freqMask <val>] [--pnsFreqMask <val>]\n"         
         "                [--egrMcFilter on|off] [--lowPriQNum <qnum>]\n"
         "                [--beaconChannel <freq_in_decimals>]\n"
         "                [--turboEn <val>] [--mrNonDefSeqNum <uint>] [--wait <0/1>]\n"
         "       %s restart  [--singleCh on|off|on2] [--privacy on|off]\n"
         "                [--constTxMode normal|tx|rx|tone <sc1> <sc2>|cw]\n"
         "                [--continuousRxModeAttn <signval_indB>]\n"         
         "                [--maxTxPower <signval_indBm>] [--nodeType terminal|intermediate]\n"
         "                [--password <password_string>] [--qam256Capability on|off]\n"         
         "                [--lof <freq_in_decimals> ] [--mcastMode bcast|normal]\n"
         "                [--labMode on|off ]\n"
         "                [--tabooFixedMaskStart <val>] [--tabooFixedChannelMask <val>]\n"
         "                [--tabooLeftMask <val>] [--tabooRightMask <val>]\n"         
         "                [--padPower <signval_indBm>] [--version <hex_version>]\n"
         "                [--preferredNC on|off] [--ledMode <0/1/2/3>]\n"
         "                [--backoffMode slow|fast] [--freqMask <val>] [--pnsFreqMask <val>]\n"        
         "                [--egrMcFilter on|off] [--lowPriQNum <qnum>]\n"         
         "                [--beaconChannel <freq_in_decimals>]\n"
         "                [--turboEn <val>] [--mrNonDefSeqNum <uint>] [--wait <0/1>]\n"       
         "       %s stop \n"
         "       %s config [--frameSize <val_in_bytes>]\n"
         "                [--maxTxTime <val>] [--minBwThreshold <val_in_Mbps>]\n"
         "                [--snrMgn <signfloat_inhalfdBs> ] [--outOfOrderLMO <nodeid>]\n"
         "                [--ieRRInsert on|off] [--ieMapInsert on|off] [--maxAggr <val> ]\n"
         "                [--maxConstellationNode <val> ]\n"
         "                [--sapm <on|off|reset> [arpl_th] [ [subcarrier margin] ... ] ]\n"
         "                [--rlapm <on|off|phy> [ [power margin] ... ] ]\n"         
         "                [--maxConstellationInfo bpsk|qpsk|qam8|qam16|qam32|qam64|qam128\n"
         "                 |qam256|qam512|qam1024 ] [--pmk <val_in_hrs> ]\n"
         "                [--tek <val_in_mins> ] [--loopbackEn <0|1>]\n"
         "                [--phyRate128 <val_in_mbps>] [--phyRate256 <val_in_mbps>]\n"
         "                [--phyRateTurbo <val_in_mbps>] [--phyRateTurboPlus <val_in_mbps>]\n"         
         "                [--rxTxPacketsPerQM] [--extraRxPacketsPerQM] [--nbasCappingEn <0|1>]\n"
         "                [--snrMgnOffset <val1> <val2> <val3> <val4> <val5>\n"
         "                 <val6> <val7> <val8> <val9> <val10>]\n"
         "                [--mocareg <hex addr> <hex value>]\n"
         "                [--tpcap <enable> <type>] [--powersave on|off]\n"
         "                [--freqShiftMode <off|plus|minus>] [--rxPowerTuning <val>]\n"
         "                [--egrMcFilterEntry <entryId> <valid> <mac_addr>]\n"
         "                [--enCapable <0|1>] [diplexer [val_in_db]]>]\n"
         "                [--enMaxRateInMaxBo <val>]\n"
         "       %s mcfwd [--create <mc addr> <uc addr1> [<uc addr2> ...]]\n"
         "                [--delete <mc addr>]\n"
         "       %s show  [--initparms] [--config] [--status]\n"
         "                [--stats [reset]]\n"
         "                [--traceconfig] [--nodestatus <nodeid>]\n"
         "                [--nodestats <nodeid> [reset]] [--mocareg <hex addr>]\n"
         "       %s showtbl [--nodestatus] [--nodestats [reset]] [--ucfwd] [--srcaddr]\n"
         "                [--mcfwd]\n"
         "       %s fn-call --address <addr> [--params <param1> <param2> <param3>]\n"
         "       %s trace [--none] [--entry] [--exit] [--dbg] [--verbose] [--info]\n"
         "                [--trap] [--core] [--mmpdump] [--time] [--default] [--all]\n"
         "       %s wol   [--enable] [--disable]\n"
         "       %s restore_defaults \n",
      g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName,
      g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName) ;
   }
   /* Only show the 1.1 feature commands in the help if we're running in 1.1 mode */

   if (g_mocaHandle)
   {
      cmsRet = MoCACtl2_GetVersion( g_mocaHandle, &MoCAVersion) ;
   }
   else
   {
      MoCAVersion.selfVersion = MoCA_VERSION_11;
   }
   
   if ((cmsRet == CMSRET_SUCCESS) && (MoCAVersion.selfVersion == MoCA_VERSION_11))
   {
      fprintf( stderr,
            "       %s chsel --freq <freq_in_decimals>\n"
            "       %s mr --seq <default sequence number> --time <reset time>\n"
            "       %s fmr [--s <uc node mac addr>] [--a]\n"
            "       %s pqosc --ig <xx:xx:xx:xx:xx:xx> --eg <xx:xx:xx:xx:xx:xx>\n"
            "              [--listener1 <xx:xx:xx:xx:xx:xx>]\n"
            "              [--listener2 <xx:xx:xx:xx:xx:xx>]\n"
            "              [--listener3 <xx:xx:xx:xx:xx:xx>]\n"
            "              [--listener4 <xx:xx:xx:xx:xx:xx>]\n"
            "              [--packetDA <xx:xx:xx:xx:xx:xx> ] [--peak <kpbs> ]\n"
            "              [--psize <size_in_bytes>] [--burst <burst_count>]\n"
            "              [--time <in_seconds> ] [--flowtag <tag>]\n"
            "              [--talker <xx:xx:xx:xx:xx:xx>]\n"
            "              [--vlan_id <VLAN id>] [--vlan_prio <VLAN priority>]\n"
            "       %s pqosu --flow_id <xx:xx:xx:xx:xx:xx> [--peak <kpbs> ]\n"
            "              [--psize <size_in_bytes>] [--burst <burst_count>]\n"
            "              [--time <in_seconds> ] [--flowtag <tag>]\n"
            "       %s pqosd [--flow_id <xx:xx:xx:xx:xx:xx>]\n"
            "       %s pqosl [--ig <xx:xx:xx:xx:xx:xx>] [--a]\n"
            "       %s pqosq [--flow_id <xx:xx:xx:xx:xx:xx>]\n"
            "       %s pqoss\n",
            g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName, g_szPgmName,
            g_szPgmName, g_szPgmName, g_szPgmName );

   }

   if (g_mocaHandle)
   VersionHandler( NULL, 0 );

   return( 0 );
} /* HelpHandler */
