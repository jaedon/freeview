/******************************************************************************
 *
 *  Copyright (c) 2010  Broadcom Corporation
 *  All Rights Reserved
 *
<:license-private
 *
 ************************************************************************/

/***************************************************************************
 *
 *     Copyright (c) 2010, Broadcom Corporation
 *     All Rights Reserved
 *     Confidential Property of Broadcom Corporation
 *
 *  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED SOFTWARE LICENSE
 *  AGREEMENT  BETWEEN THE USER AND BROADCOM.  YOU HAVE NO RIGHT TO USE OR
 *  EXPLOIT THIS MATERIAL EXCEPT SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
 *
 *  Description: MoCA TPCAP diagnostics -- TPCAP capture test functions
 *
 ***************************************************************************/

#if defined(__gnu_linux__)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <error.h>
#include <stdint.h>
#include <sys/mman.h>

#include "tpcap.h"

unsigned int TPCAPBASE=0x10401400;                         
unsigned int MEMC_ARB0_BASE=0x103b1000; // this varies by chip, this is the 7420 value
unsigned int MOCA_EXTRAS_BASE=0x102a1400; 
unsigned int SUN_RGR_BASE=0x10400800;  
unsigned int SUN_TOP_CTRL_BASE=0x10404000;
unsigned int SUN_L2_BASE=0x10401800;
unsigned int MOCA_PHY_BASE=0x10288000;
unsigned int MOCA_TESTPORT_NUMBER=0x13;

unsigned int  TPCAP_CONTROL;
unsigned int  TPCAP_BLOCK_SELECT;
unsigned int  TPCAP_DEST_ADDR;
unsigned int  TPCAP_SIZE;
unsigned int  TPCAP_START_TRIGGER_MASK_HI;
unsigned int  TPCAP_START_TRIGGER_MASK_LO;
unsigned int  TPCAP_START_TRIGGER_VALUE_HI;
unsigned int  TPCAP_START_TRIGGER_VALUE_LO;
unsigned int  TPCAP_STOP_TRIGGER_MASK_HI;
unsigned int  TPCAP_STOP_TRIGGER_MASK_LO;
unsigned int  TPCAP_STOP_TRIGGER_VALUE_HI;
unsigned int  TPCAP_STOP_TRIGGER_VALUE_LO;

unsigned int  SUN_RGR_SW_RESET_1;
unsigned int  SUN_TOP_CTRL_TEST_PORT_CTRL;
unsigned int  SUN_L2_CPU_CLEAR;

unsigned int  MOCA_EXTRAS_TPCAP_SEL;
unsigned int  MOCA_EXTRAS_TP_SEL;
unsigned int  MOCA_EXTRAS_REG_TEST_MUX_SEL;

unsigned int  MOCA_PHY_BASE;
unsigned int  MOCA_PHY_FIXED_REG_11;
unsigned int  MOCA_PHY_BURST_TX_RX_REG_2;
unsigned int  MOCA_PHY_FIXD_CMN_TEST_PORTS = 0;
unsigned int  MOCA_PHY_BURST_CMN_INIT_GEN = 0;


unsigned int  MOCA_MAC_CTRL;

unsigned int  MEMC_ARB_0_CLIENT_INFO_65;


static unsigned int tpcap_mapphys(unsigned int addr)
{
    static unsigned int base = 0xffffffff;
    static int fd = -1;
    static int pagesize = 0, pagemask;
    static void *mapping;

    if(fd == -1) 
    {
        fd = open("/dev/mem", O_RDWR | O_SYNC);
        if(fd < 0) 
        {
                printf("can't open /dev/mem: %s\n", strerror(errno));
                exit(1);
        }
        pagesize = getpagesize();
        pagemask = ~(pagesize - 1);
    }

    if((addr & pagemask) == (base & pagemask))
        return((unsigned int)mapping + (addr & ~pagemask));

    if(mapping)
        munmap(mapping, pagesize);
    base = addr & pagemask;

    mapping = mmap(NULL, pagesize, (PROT_READ | PROT_WRITE),
                                    MAP_SHARED, fd, base);
    if(mapping == (void *)-1) 
    {
        printf("mmap failed: %s\n", strerror(errno));
        exit(1);
    }
    return((unsigned int)mapping + (addr & ~pagemask));
}

static unsigned int regr(unsigned int addr)
{
    unsigned int *x = (unsigned int *)tpcap_mapphys(addr);
    return(*x);
}

void regw(unsigned int addr, unsigned int val)
{    
    unsigned int *x = (unsigned int *)tpcap_mapphys(addr);

    *x = val;    
}

unsigned int TPCAP_ReadMem(unsigned int paddr)
{
    return(regr(paddr));
}

void TPCAP_Start(unsigned int probe_sel, unsigned int port, unsigned int num_samples, 
    unsigned int dest_addr, unsigned int macphy_tp, unsigned int rate, unsigned int clock,
    unsigned int lpbk, unsigned int wait)
{
    regw(SUN_RGR_SW_RESET_1, 1); // reset tpcap
    sleep(1);
    regw(SUN_RGR_SW_RESET_1, 0); // take TPCAP out of reset

    regw(TPCAP_CONTROL, regr(TPCAP_CONTROL) & 0xFFFFFFFE); // SUNDRY.TPCAP.CONTROL.CAPT_ENABLE = 0   ' clear condition
    
    regw(TPCAP_DEST_ADDR, dest_addr);
    regw(TPCAP_SIZE, num_samples * 4);
    
    regw(TPCAP_START_TRIGGER_MASK_HI, 0xFFFFFFFF);
    regw(TPCAP_START_TRIGGER_MASK_LO, 0xFFFFFFFF);
    regw(TPCAP_START_TRIGGER_VALUE_HI, 0);
    regw(TPCAP_START_TRIGGER_VALUE_LO, 0);


    regw(TPCAP_STOP_TRIGGER_MASK_HI, 0xFFFFFFFF);
    regw(TPCAP_STOP_TRIGGER_MASK_LO, 0xFFFFFFFF);
    regw(TPCAP_STOP_TRIGGER_VALUE_HI, 0);
    regw(TPCAP_STOP_TRIGGER_VALUE_LO, 0);

    regw(TPCAP_CONTROL, regr(TPCAP_CONTROL) & 0xFFFF8FFF); // SUNDRY.TPCAP.CONTROL.DEMUX_MODE = 0 ' no demuxing at source
#if __BYTE_ORDER == __LITTLE_ENDIAN
    regw(TPCAP_CONTROL, (regr(TPCAP_CONTROL) & 0xFFFFFF7F) | 0x80); //SUNDRY.TPCAP.CONTROL.LITTLE_ENDIAN = 1 ' 1= Little Endian
#else    
    regw(TPCAP_CONTROL, regr(TPCAP_CONTROL) & 0xFFFFFF7F); //SUNDRY.TPCAP.CONTROL.LITTLE_ENDIAN = 0 ' 0= Big Endian
#endif    
    regw(TPCAP_CONTROL, (regr(TPCAP_CONTROL) & 0xFFFFFCFF) | 0x300); // SUNDRY.TPCAP.CONTROL.CAPT_WIDTH = 3 ' 0= 8 bits, 1= 16 bits, 2= 32 bits, 3= 64 bits
    regw(TPCAP_CONTROL, regr(TPCAP_CONTROL) & 0xFFFFFFBF); // SUNDRY.TPCAP.CONTROL.ENA_PTRN_STOP_TRIGGER = 0
    regw(TPCAP_CONTROL, regr(TPCAP_CONTROL) & 0xFFFFFFDF); // SUNDRY.TPCAP.CONTROL.ENA_CTRL_STOP_TRIGGER = 0
    regw(TPCAP_CONTROL, regr(TPCAP_CONTROL) & 0xFFFFFFEF); // SUNDRY.TPCAP.CONTROL.ENA_PTRN_START_TRIGGER = 0
    regw(TPCAP_CONTROL, regr(TPCAP_CONTROL) & 0xFFFFFFF7); //SUNDRY.TPCAP.CONTROL.ENA_CTRL_START_TRIGGER = 0
    regw(TPCAP_CONTROL, regr(TPCAP_CONTROL) & 0xFFFFFFFB); // SUNDRY.TPCAP.CONTROL.ENA_PTRN_CLK_ENA = 0
    regw(TPCAP_CONTROL, (regr(TPCAP_CONTROL) & 0xFFFFFFFD) | 0x2); // SUNDRY.TPCAP.CONTROL.ENA_CTRL_CLK_ENA = 1 ' The clock enable TP_AUX[0] is valid only if the ENA_CTRL_CLK_ENA bit is set.	
    if (MOCA_PHY_BURST_TX_RX_REG_2)
        regw(MOCA_PHY_BURST_TX_RX_REG_2, regr(TPCAP_CONTROL) | (1<<17)); // MOCA_PHY_BURST_TX_RX_REG_2.tpcap_en
    else 
        regw(MOCA_PHY_BURST_CMN_INIT_GEN, regr(MOCA_PHY_BURST_CMN_INIT_GEN) | (1<<17));  //  xxxx.tpcap_en = 1
        
    // Mux out the MOCA probes
    if (port == 0) // phy probes
    {
        regw(MOCA_EXTRAS_TPCAP_SEL, (regr(MOCA_EXTRAS_TPCAP_SEL) & 0xFFFFFFE8) | probe_sel); // MOCA_TOP.MOCA.MOCA_EXTRAS.MOCA_EXTRAS.TPCAP_SEL.sel = probe_sel 
//        regw(MOCA_EXTRAS_TP_SEL, 0); //MOCA_TOP.MOCA.MOCA_EXTRAS.MOCA_EXTRAS.TP_SEL.sel = &hFFFFFFFF&  ' Select TP as output
        regw(MOCA_EXTRAS_TP_SEL, 0xFFFFFFFF); //MOCA_TOP.MOCA.MOCA_EXTRAS.MOCA_EXTRAS.TP_SEL.sel = &hFFFFFFFF&  ' Select TP as output        
        regw(MOCA_EXTRAS_TPCAP_SEL, (regr(MOCA_EXTRAS_TPCAP_SEL) & 0xFFFFFFE7) | 0x8); //MOCA_TOP.MOCA.MOCA_EXTRAS.MOCA_EXTRAS.TPCAP_SEL.overlay = 1 ' Select TPCAP as output, phy probes input to tpcap
    }
    else // mac/phy tp
    {
        // set MOCA_EXTRAS_TP_SEL to 0 to capture gpio
        regw(MOCA_EXTRAS_TP_SEL, 0xFFFFFFFF); //MOCA_TOP.MOCA.MOCA_EXTRAS.MOCA_EXTRAS.TP_SEL.sel = &hFFFFFFFF&  ' Select TP as output
//       regw(MOCA_EXTRAS_TP_SEL, 0); //MOCA_TOP.MOCA.MOCA_EXTRAS.MOCA_EXTRAS.TP_SEL.sel = &hFFFFFFFF&  ' Select TP as output        
        if ( MOCA_PHY_FIXD_CMN_TEST_PORTS )
            regw(MOCA_PHY_FIXD_CMN_TEST_PORTS,  macphy_tp | (clock << 2)); // set to mac or phy TP, 00 = mac, 01 phy, 11 moca signature

        if (MOCA_EXTRAS_REG_TEST_MUX_SEL)
            regw(MOCA_EXTRAS_REG_TEST_MUX_SEL,  macphy_tp | (clock << 2)); // set to mac or phy TP, 00 = mac, 01 phy, 11 moca signature
        regw(MOCA_EXTRAS_TPCAP_SEL, (regr(MOCA_EXTRAS_TPCAP_SEL) & 0xFFFFFF07) | 0x38); //MOCA_TOP.MOCA.MOCA_EXTRAS.MOCA_EXTRAS.TPCAP_SEL.overlay = 1 ' Select TPCAP as output, phy probes input to tpcap, force clock enable
        regw(TPCAP_CONTROL, (regr(TPCAP_CONTROL) & 0xFFFFFFD7) | 0x28); // SUNDRY.TPCAP.CONTROL.ENA_CTRL_START_TRIGGER=1, SUNDRY.TPCAP.CONTROL.ENA_CTRL_STOP_TRIGGER=1

        regw(MOCA_PHY_FIXED_REG_11, (regr(MOCA_PHY_FIXED_REG_11) & 0xFFFE7F00) | probe_sel | (rate << 15)); // bits 0-3 data bus, 4-7 control bus

        if (!macphy_tp)
            regw(MOCA_MAC_CTRL, (regr(MOCA_MAC_CTRL) & 0xFFFFFFF1) | probe_sel << 1); // 3 bits mux selector to read the 16 mac internal probs (8 groups 2x types of clock domains)
    }

    regw(SUN_TOP_CTRL_TEST_PORT_CTRL, MOCA_TESTPORT_NUMBER); //SUNDRY.SUN_TOP_CTRL.TEST_PORT_CTRL = &h13&   ' select MOCA on SUN_TOP testport


    regw(TPCAP_BLOCK_SELECT, 0); // SUNDRY.TPCAP.BLOCK_SELECT.encoded_tpcap_en = 0	' Select MoCA as TPCAP input
    
    // Set up memory client for TPCAP (client #65)
    regw(MEMC_ARB_0_CLIENT_INFO_65, (regr(MEMC_ARB_0_CLIENT_INFO_65) & 0xFFFFFF7F) | 0x80); //MEMC_ARB_0.CLIENT_INFO_65.RR_EN = 1   			' basic way to enable this client
    regw(MEMC_ARB_0_CLIENT_INFO_65, (regr(MEMC_ARB_0_CLIENT_INFO_65) & 0xFFE000FF) | 0x1FFF00); //MEMC_ARB_0.CLIENT_INFO_65.BO_VAL = &h1FFF&  	'&H1fff  '!!! reduce dflt 0x1fff to increase BW
    
    // clear interrupt
    regw(SUN_L2_CPU_CLEAR, (regr(SUN_L2_CPU_CLEAR) & ~(1<<22)) | (1<<22));//SUNDRY.SUN_L2.CPU_CLEAR.TPCAP_FIFO_OVERFLOW = 1
    regw(SUN_L2_CPU_CLEAR, regr(SUN_L2_CPU_CLEAR) & ~(1<<22));//SUNDRY.SUN_L2.CPU_CLEAR.TPCAP_FIFO_OVERFLOW = 0

    regw(TPCAP_CONTROL, (regr(TPCAP_CONTROL) & 0xFFFEFFFF) | (lpbk<<16)); // SUNDRY.TPCAP.CONTROL.LOOP_BACK_ENABLE
    
    // start capture, now that configuration is complete.
    regw(TPCAP_CONTROL, (regr(TPCAP_CONTROL) & 0xFFFFFFFE) | 1); // SUNDRY.TPCAP.CONTROL.CAPT_ENABLE = 1   

    printf ("TPCAP configured for MoCA\n");

    if (wait)
    {
        printf ("Waiting for TPCAP to finish capturing ...\n");

        // Poll on TPCAP to finish capturing
        while (regr(TPCAP_CONTROL) & 1)
        {
            usleep(100000);
        }

        printf ("Capture complete\n");
    }
}

void TPCAP_Init(unsigned int chipid)
{   
    if ((chipid & 0xFFFF0000) == 0x73400000)
    {
        MEMC_ARB0_BASE=0x10501000;
        MOCA_EXTRAS_TPCAP_SEL = (MOCA_EXTRAS_BASE+0x5c);
        MOCA_EXTRAS_TP_SEL = (MOCA_EXTRAS_BASE+0x58);
        MOCA_EXTRAS_REG_TEST_MUX_SEL = (MOCA_EXTRAS_BASE+0x2c);        
        MOCA_PHY_FIXED_REG_11 = (MOCA_PHY_BASE+0x7c);
        MOCA_PHY_BURST_TX_RX_REG_2 = (MOCA_PHY_BASE+0xcc);                
        
        MOCA_MAC_CTRL = (0x10280400);
    }
    else if ((chipid & 0xFFFF0000) == 0x73440000)
    {
        TPCAPBASE=0x10400c00;
        SUN_RGR_BASE=0x10400400;
        MEMC_ARB0_BASE=0x10a01000;
        SUN_TOP_CTRL_TEST_PORT_CTRL=0x10404380;
        SUN_L2_BASE=0x10403000;
        MOCA_EXTRAS_TPCAP_SEL = (MOCA_EXTRAS_BASE+0x5c);
        MOCA_EXTRAS_TP_SEL = (MOCA_EXTRAS_BASE+0x58);
        MOCA_EXTRAS_REG_TEST_MUX_SEL = (MOCA_EXTRAS_BASE+0x2c);        
        MOCA_PHY_FIXED_REG_11 = (MOCA_PHY_BASE+0x7c);
        MOCA_PHY_BURST_TX_RX_REG_2 = (MOCA_PHY_BASE+0xcc);                
        
        MOCA_MAC_CTRL = (0x10280400);
    }
    else if (((chipid & 0xFFFF0000) == 0x73460000) || 
             ((chipid & 0xFFFF0000) == 0x74220000) ||
             ((chipid & 0xFFFF00FF) == 0x742500A0))
    {
        TPCAPBASE=0x10400c00;
        SUN_RGR_BASE=0x10400400;
        MEMC_ARB0_BASE=0x103b1000;
        SUN_TOP_CTRL_TEST_PORT_CTRL=0x10404380;
        SUN_L2_BASE=0x10403000;
        MOCA_TESTPORT_NUMBER=0x2f;
        MOCA_EXTRAS_TPCAP_SEL = (MOCA_EXTRAS_BASE+0x5c);
        MOCA_EXTRAS_TP_SEL = (MOCA_EXTRAS_BASE+0x58);
        MOCA_EXTRAS_REG_TEST_MUX_SEL = (MOCA_EXTRAS_BASE+0x2c);     
        MOCA_PHY_FIXED_REG_11 = (MOCA_PHY_BASE+0x7c);
        MOCA_PHY_BURST_TX_RX_REG_2 = (MOCA_PHY_BASE+0xcc); 
        
        MOCA_MAC_CTRL = (0x10280400);
    }
    else if ((chipid & 0xFFFF00FF) == 0x742500b0)
    {    
        TPCAPBASE=0x10400c00;                         
        MEMC_ARB0_BASE=0x103b1000;
        MOCA_EXTRAS_BASE=0x10ffec00; 
        SUN_RGR_BASE=0x10400400;  
        SUN_TOP_CTRL_BASE=0x10404000;
        SUN_L2_BASE=0x10403000;
        MOCA_PHY_BASE=0x10fe0000;
        MOCA_TESTPORT_NUMBER=0x2f;
    
        SUN_TOP_CTRL_TEST_PORT_CTRL=0x10404380;
        MOCA_EXTRAS_TPCAP_SEL = (MOCA_EXTRAS_BASE+0x2c);
        MOCA_EXTRAS_TP_SEL = (MOCA_EXTRAS_BASE+0x28);
        MOCA_PHY_FIXD_CMN_TEST_PORTS = MOCA_PHY_BASE + 0xc;
        MOCA_PHY_BURST_CMN_INIT_GEN = (MOCA_PHY_BASE+0x20a4);  

        MOCA_EXTRAS_REG_TEST_MUX_SEL = 0;
    
        MOCA_PHY_FIXED_REG_11 = 0;
        MOCA_PHY_BURST_TX_RX_REG_2 = 0;

        MOCA_MAC_CTRL = 0;

    }
    else
    {
        SUN_TOP_CTRL_TEST_PORT_CTRL = (SUN_TOP_CTRL_BASE+0x200);
        MOCA_EXTRAS_TPCAP_SEL = (MOCA_EXTRAS_BASE+0x5c);
        MOCA_EXTRAS_TP_SEL = (MOCA_EXTRAS_BASE+0x58);
        MOCA_EXTRAS_REG_TEST_MUX_SEL = (MOCA_EXTRAS_BASE+0x2c);
        MOCA_PHY_FIXED_REG_11 = (MOCA_PHY_BASE+0x7c);
        MOCA_PHY_BURST_TX_RX_REG_2 = (MOCA_PHY_BASE+0xcc);        
        MOCA_MAC_CTRL = 0x10280400;        
    }

    TPCAP_CONTROL = (TPCAPBASE+0x00);
    TPCAP_BLOCK_SELECT = (TPCAPBASE+0x04);
    TPCAP_DEST_ADDR = (TPCAPBASE+0x08);
    TPCAP_SIZE = (TPCAPBASE+0x0c);
    TPCAP_START_TRIGGER_MASK_HI = (TPCAPBASE+0x54);
    TPCAP_START_TRIGGER_MASK_LO = (TPCAPBASE+0x58);
    TPCAP_START_TRIGGER_VALUE_HI = (TPCAPBASE+0x5c);
    TPCAP_START_TRIGGER_VALUE_LO = (TPCAPBASE+0x60);
    TPCAP_STOP_TRIGGER_MASK_HI = (TPCAPBASE+0x64);
    TPCAP_STOP_TRIGGER_MASK_LO = (TPCAPBASE+0x68);
    TPCAP_STOP_TRIGGER_VALUE_HI = (TPCAPBASE+0x6c);
    TPCAP_STOP_TRIGGER_VALUE_LO = (TPCAPBASE+0x70);

    SUN_RGR_SW_RESET_1 = (SUN_RGR_BASE+0x10);
    
    SUN_L2_CPU_CLEAR = (SUN_L2_BASE+0x08);

    MEMC_ARB_0_CLIENT_INFO_65 = (MEMC_ARB0_BASE+0x0108);
}

#else

void TPCAP_Init(unsigned int chipid)
{
}

unsigned int TPCAP_ReadMem(unsigned int paddr)
{
    return(0);
}

void TPCAP_Start(unsigned int probe_sel, unsigned int port, unsigned int num_samples, unsigned int dest_addr, unsigned int macphy_tp)
{
}

#endif
